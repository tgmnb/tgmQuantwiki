<template>
  <div class="library-split">
    <div class="library-sidebar">
      <div class="library-sidebar__header">
        <div
          class="search-box"
          style="flex:1;"
        >
          <el-icon class="search-box__icon">
            <Search />
          </el-icon>
          <input
            v-model="search"
            type="text"
            placeholder="搜索选股策略..."
            class="search-box__input"
          >
          <button
            v-if="search"
            class="search-box__clear"
            @click="search = ''"
          >
            <el-icon :size="12">
              <Close />
            </el-icon>
          </button>
        </div>
        <button
          class="btn btn--ghost btn--sm"
          title="新建选股策略"
          @click="startCreate"
        >
          <el-icon :size="14">
            <Plus />
          </el-icon>
        </button>
      </div>
      <div class="library-sidebar__body scroll-auto">
        <template
          v-for="(groupItems, group) in filteredGroups"
          :key="group"
        >
          <div
            v-if="groupItems.length > 0"
            class="factor-group"
          >
            <div
              class="group-header"
              @click="toggleGroup(group)"
            >
              <span
                class="group-arrow"
                :style="{ transform: isGroupExpanded(group) ? 'rotate(90deg)' : '' }"
              >&#9654;</span>
              <span class="group-name">{{ group }}</span>
              <span class="group-count">{{ groupItems.length }}</span>
            </div>
            <div
              v-if="isGroupExpanded(group)"
              class="group-items"
            >
              <div
                v-for="item in groupItems"
                :key="item.path"
                class="tree-item"
                :class="{ 'tree-item--active': selected?.path === item.path }"
                @click="loadCode(item)"
              >
                {{ item.name }}
              </div>
            </div>
          </div>
        </template>
        <div
          v-if="totalItems === 0"
          class="empty-hint"
        >
          暂无选股策略
        </div>
      </div>
    </div>
    <div class="library-content">
      <template v-if="selected || mode === 'create'">
        <div class="code-panel">
          <div class="code-header">
            <div class="code-header__left">
              <el-icon class="code-header__icon">
                <Filter />
              </el-icon>
              <span class="code-header__name">{{ mode === 'create' ? '新建选股策略' : selected?.name }}</span>
            </div>
            <div class="code-header__actions">
              <template v-if="isView">
                <button
                  class="btn btn--ghost btn--sm"
                  @click="startEdit"
                >
                  <el-icon :size="13">
                    <Edit />
                  </el-icon> 编辑
                </button>
                <button
                  class="btn btn--ghost btn--sm"
                  @click="copyFile"
                >
                  <el-icon :size="13">
                    <CopyDocument />
                  </el-icon> 复制
                </button>
                <button
                  class="btn btn--danger btn--sm"
                  @click="deleteFile"
                >
                  <el-icon :size="13">
                    <Delete />
                  </el-icon> 删除
                </button>
              </template>
              <template v-else>
                <button
                  class="btn btn--primary btn--sm"
                  :disabled="isSaving"
                  @click="saveEdit"
                >
                  {{ isSaving ? '...' : '保存' }}
                </button>
                <button
                  class="btn btn--ghost btn--sm"
                  @click="cancelEdit"
                >
                  取消
                </button>
              </template>
            </div>
          </div>
          <div class="code-body">
            <template v-if="isView">
              <div
                v-if="mode === 'create'"
                class="code-create-form"
              >
                <el-select
                  v-model="newFolderPath"
                  placeholder="选择文件夹"
                  class="lib-select"
                >
                  <el-option
                    v-for="opt in folderOptions"
                    :key="opt.path"
                    :label="opt.label"
                    :value="opt.path"
                  />
                </el-select>
                <input
                  v-model="newFileName"
                  placeholder="文件名"
                  class="lib-input"
                >
              </div>
              <CodeEditor
                :model-value="codeDisplay"
                language="python"
                :readonly="true"
                :show-toolbar="false"
                height="100%"
              />
            </template>
            <CodeEditor
              v-else
              v-model="editContent"
              language="python"
              height="100%"
            />
          </div>
        </div>
      </template>
      <div
        v-else-if="loading"
        class="library-empty"
      >
        <Loading />
      </div>
      <div
        v-else
        class="library-empty"
      >
        <el-icon
          :size="48"
          color="var(--text-muted)"
          style="opacity:0.3"
        >
          <Filter />
        </el-icon>
        <div class="library-empty__title">
          选择左侧选股策略或点击新建
        </div>
        <button
          class="btn btn--secondary btn--sm"
          style="margin-top:8px;"
          @click="startCreate"
        >
          <el-icon :size="14">
            <Plus />
          </el-icon> 新建
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import Loading from '@/components/common/Loading.vue';

import CodeEditor from '@/components/editor/CodeEditor.vue';
import { selectionApi } from '@/api/selection';

const search = ref('');
const items = ref<any[]>([]);
const groupedFiles = ref<Record<string, any[]>>({});
const expandedGroups = ref<Record<string, boolean>>({});
const selected = ref<{ name: string; path: string } | null>(null);
const codeContent = ref<{ lines?: string[] }>({});
const mode = ref<'view' | 'edit' | 'create'>('view');
const editContent = ref('');
const isSaving = ref(false);
const saveMsg = ref<{ type: string; text: string } | null>(null);
const isModified = ref(false);
const newFileName = ref('');
const newFolderPath = ref('backtest/select_hub');
const folderOptions = computed(() => {
  const dirs = new Map<string, string>();
  dirs.set('backtest/select_hub', '根目录');
  for (const f of items.value) {
    const path = typeof f === 'string' ? f : (f.path || '');
    if (!path.includes('/')) continue;
    const dir = path.substring(0, path.lastIndexOf('/'));
    if (dir && dir !== 'backtest/select_hub') {
      dirs.set(dir, dir.split('/').pop() || dir);
    }
  }
  return Array.from(dirs.entries()).map(([path, label]) => ({ label, path }));
});
const loading = ref(false);

const isGroupExpanded = (group: string) => {
  const searchActive = search.value.trim().length > 0;
  return searchActive || (expandedGroups.value[group] || false);
};

const codeDisplay = computed(() => (codeContent.value.lines || []).join('\n'));
const isView = computed(() => mode.value === 'view');

const filteredGroups = computed(() => {
  const q = search.value.toLowerCase();
  const result: Record<string, any[]> = {};
  for (const [group, groupItems] of Object.entries(groupedFiles.value)) {
    const filtered = groupItems.filter(item =>
      !q || (item.name || '').toLowerCase().includes(q) ||
      (item.path || '').toLowerCase().includes(q)
    );
    if (filtered.length > 0) result[group] = filtered;
  }
  return result;
});

const totalItems = computed(() => {
  let n = 0;
  for (const groupItems of Object.values(filteredGroups.value)) n += groupItems.length;
  return n;
});

function toggleGroup(group: string) {
  expandedGroups.value[group] = !expandedGroups.value[group];
}

onMounted(async () => {
  await loadList();
});

async function loadList() {
  loading.value = true;
  try {
    const d: any = await selectionApi.list();
    const arr: any[] = Array.isArray(d.strategies) ? d.strategies : (Array.isArray(d) ? d : []);
    items.value = arr;
    const groups: Record<string, any[]> = {};
    for (const f of arr) {
      const path = typeof f === 'string' ? f : (f.path || '');
      const name = typeof f === 'string' ? f : (f.name || path);
      const parts = path.split('/');
      const category = parts.length > 1 ? parts[parts.length - 2] : '其他';
      if (!groups[category]) groups[category] = [];
      groups[category].push({ path, name, ...(typeof f === 'object' ? f : {}) });
    }
    groupedFiles.value = groups;
    const firstGroup = Object.keys(groups)[0];
    if (firstGroup && !expandedGroups.value[firstGroup]) {
      expandedGroups.value = { [firstGroup]: true };
    }
  } catch { ElMessage.error('加载选股策略失败'); }
  finally { loading.value = false; }
}

async function loadCode(item: any) {
  selected.value = { name: item.name, path: item.path };
  codeContent.value = {};
  mode.value = 'view';
  isModified.value = false;
  editContent.value = '';
  saveMsg.value = null;
  newFileName.value = '';
  try {
    const d: any = await selectionApi.getContent(item.path);
    codeContent.value = d;
  } catch { ElMessage.error('加载代码失败'); }
}

function startEdit() {
  if (!selected.value || !codeContent.value) return;
  editContent.value = (codeContent.value.lines || []).join('\n');
  isModified.value = false;
  mode.value = 'edit';
  saveMsg.value = null;
}

function startCreate() {
  selected.value = null;
  codeContent.value = { lines: [] };
  editContent.value = '';
  isModified.value = false;
  mode.value = 'create';
  saveMsg.value = null;
  newFileName.value = '';
}

function cancelEdit() {
  mode.value = 'view';
  editContent.value = '';
  isModified.value = false;
  saveMsg.value = null;
  newFileName.value = '';
}

async function saveEdit() {
  if (mode.value === 'create') {
    const fileName = newFileName.value.trim();
    if (!fileName) { ElMessage.warning('请输入文件名'); return; }
    const path = `${newFolderPath.value}/${fileName}`;
    isSaving.value = true;
    saveMsg.value = null;
    try {
      const res: any = await selectionApi.save(path, editContent.value);
      if (res.success) {
        saveMsg.value = { type: 'success', text: '已保存' };
        isModified.value = false;
        mode.value = 'view';
        selected.value = { name: fileName, path };
        newFileName.value = '';
        await loadList();
      } else {
        saveMsg.value = { type: 'error', text: res.detail || '保存失败' };
      }
    } catch (e: any) { saveMsg.value = { type: 'error', text: '保存失败: ' + (e.message || e) }; }
    finally { isSaving.value = false; }
  } else {
    if (!selected.value) return;
    isSaving.value = true;
    saveMsg.value = null;
    try {
      const res: any = await selectionApi.save(selected.value.path, editContent.value);
      if (res.success) {
        saveMsg.value = { type: 'success', text: '已保存' };
        isModified.value = false;
        mode.value = 'view';
        const d: any = await selectionApi.getContent(selected.value.path);
        codeContent.value = d;
      } else {
        saveMsg.value = { type: 'error', text: res.detail || '保存失败' };
      }
    } catch (e: any) { saveMsg.value = { type: 'error', text: '保存失败: ' + (e.message || e) }; }
    finally { isSaving.value = false; }
  }
}

async function deleteFile() {
  if (!selected.value) return;
  try {
    await ElMessageBox.confirm('删除 ' + selected.value.name + '?', '确认删除', { type: 'warning' });
    const res: any = await selectionApi.delete(selected.value.path);
    if (res.success) { selected.value = null; codeContent.value = {}; mode.value = 'view'; await loadList(); ElMessage.success('已删除'); }
  } catch { /* ignore */ }
}
async function copyFile() {
  if (!selected.value) return;
  const newPath = selected.value.path.replace(/(\.[^.]+)$/, '_copy$1');
  try {
    const content = (codeContent.value.lines || []).join('\n');
    const res: any = await selectionApi.save(newPath, content);
    if (res.success) {
      await loadList();
      ElMessage.success('已复制');
    } else {
      ElMessage.error(res.detail || '复制失败');
    }
  } catch (e: any) { ElMessage.error(e.message || '复制失败'); }
}
</script>

<style scoped>
.factor-group { margin-bottom: 4px; }
.code-panel { display: flex; flex-direction: column; height: 100%; overflow: hidden; }
.code-header { display: flex; align-items: center; padding: 10px 16px; border-bottom: 1px solid var(--border-color); flex-shrink: 0; gap: 8px; }
.code-header__left { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
.code-header__icon { color: var(--accent); font-size: 16px; }
.code-header__name { font-weight: 600; font-size: var(--font-md); color: var(--text-primary); }
.code-header__actions { display: flex; gap: 6px; margin-left: auto; }
.code-body { flex: 1; overflow: auto; padding: 0; }
.code-create-form { display: flex; gap: 8px; margin-bottom: 12px; }
</style>
