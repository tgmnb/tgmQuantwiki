import { ref } from 'vue';
import { ElMessage } from 'element-plus';
import { useWorkflowStore } from '@/stores/workflow';

export function useInlineEdit() {
  const workflowStore = useWorkflowStore();

  // ── 名称编辑 ──
  const editingName = ref(false);
  const editableName = ref('');

  function startEditName() {
    editableName.value = workflowStore.currentWorkflow?.name || '';
    editingName.value = true;
  }

  function saveName() {
    if (!workflowStore.currentWorkflow || !editableName.value.trim()) {
      editingName.value = false;
      return;
    }
    workflowStore.updateWorkflow(workflowStore.currentWorkflow.id, { name: editableName.value.trim() });
    editingName.value = false;
  }

  // ── Atomic 面板字段编辑 ──
  const editingField = ref('');
  const editingValue = ref('');

  function startEditField(field: string) {
    if (!workflowStore.currentWorkflow) return;
    editingField.value = field;
    editingValue.value = (workflowStore.currentWorkflow as Record<string, unknown>)[field] as string || '';
  }

  function saveField(field: string) {
    if (!workflowStore.currentWorkflow || !editingField.value) return;
    const updates: Record<string, string> = {};
    updates[field] = editingValue.value;
    workflowStore.updateWorkflow(workflowStore.currentWorkflow.id, updates);
    editingField.value = '';
    editingValue.value = '';
    ElMessage.success('已更新');
  }

  return {
    editingName,
    editableName,
    startEditName,
    saveName,
    editingField,
    editingValue,
    startEditField,
    saveField,
  };
}
