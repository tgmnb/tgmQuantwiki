import axios from 'axios';

// 可配置的全局错误处理器（默认静默，main.ts 启动时注入 ElMessage.error）
let _errorHandler: ((msg: string) => void) | null = null;

export function setErrorHandler(handler: (msg: string) => void) {
  _errorHandler = handler;
}

/**
 * 结构化 API 错误类
 */
export class ApiError extends Error {
  constructor(
    public readonly code: string,
    message: string,
    public readonly statusCode?: number,
    public readonly detail?: any
  ) {
    super(message);
    this.name = 'ApiError';
  }

  static fromResponse(response: any, statusCode?: number): ApiError {
    return new ApiError(
      response?.code || 'UNKNOWN_ERROR',
      response?.detail || response?.message || 'Request failed',
      statusCode,
      response
    );
  }

  static networkError(originalError: Error): ApiError {
    return new ApiError('NETWORK_ERROR', originalError.message);
  }

  static timeoutError(): ApiError {
    return new ApiError('TIMEOUT', 'Request timeout');
  }
}

const instance = axios.create({
  baseURL: '',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
});

instance.interceptors.response.use(
  (response) => response.data,
  (error) => {
    let apiError: ApiError;

    if (axios.isAxiosError(error)) {
      if (error.response) {
        // 服务器返回错误状态码
        apiError = ApiError.fromResponse(error.response.data, error.response.status);
      } else if (error.code === 'ECONNABORTED') {
        // 请求超时
        apiError = ApiError.timeoutError();
      } else {
        // 网络错误
        apiError = ApiError.networkError(error);
      }
    } else {
      apiError = new ApiError('UNKNOWN', error.message || 'Unknown error');
    }

    console.error('[API Error]', apiError.code, apiError.message);
    _errorHandler?.(apiError.message);
    return Promise.reject(apiError);
  },
);

export const request = {
  get<T = any>(url: string, config?: any): Promise<T> {
    return instance.get(url, config) as any;
  },
  post<T = any>(url: string, data?: any, config?: any): Promise<T> {
    return instance.post(url, data, config) as any;
  },
  put<T = any>(url: string, data?: any, config?: any): Promise<T> {
    return instance.put(url, data, config) as any;
  },
  delete<T = any>(url: string, config?: any): Promise<T> {
    return instance.delete(url, config) as any;
  },
  patch<T = any>(url: string, data?: any, config?: any): Promise<T> {
    return instance.patch(url, data, config) as any;
  },
};
