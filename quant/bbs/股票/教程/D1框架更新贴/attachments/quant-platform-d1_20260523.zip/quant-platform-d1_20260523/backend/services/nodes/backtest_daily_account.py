from . import register_node

register_node({
    "id": "backtest_daily_account",
    "type": "atomic",
    "name": "\u65e5\u9891\u8d26\u6237\u56de\u6d4b",
    "description": "\u65e5\u7ebf\u7ea7\u522b\u591a\u7b56\u7565\u8d26\u6237\u7efc\u5408\u56de\u6d4b",
    "icon": "icon-dashboard",
    "category": "\u56de\u6d4b",
    "slots_in": [
        {"id": "factor_data", "name": "\u56e0\u5b50\u6570\u636e", "type": "file", "required": False},
        {"id": "select_result", "name": "\u9009\u80a1\u7ed3\u679c", "type": "file", "required": False},
    ],
    "slots_out": [
        {"id": "backtest_result", "name": "\u8d26\u6237\u56de\u6d4b\u7ed3\u679c", "type": "file"},
    ],
    "params": [
        {
            "id": "account_name_list",
            "name": "\u8d26\u6237\u540d\u79f0\u5217\u8868",
            "type": "list[str]",
            "default": [],
            "required": True,
            "ui": {"widget": "tag_input", "placeholder": "\u8f93\u5165\u8d26\u6237\u540d\u79f0"},
        },
        {
            "id": "date_start",
            "name": "\u5f00\u59cb\u65e5\u671f",
            "type": "str",
            "default": "2020-01-01",
            "ui": {"widget": "date_picker", "format": "YYYY-MM-DD", "allow_link": False},
        },
        {
            "id": "date_end",
            "name": "\u7ed3\u675f\u65e5\u671f",
            "type": "str",
            "default": "2024-12-31",
            "ui": {"widget": "date_picker", "format": "YYYY-MM-DD", "allow_link": False},
        },
    ],
    "script": "workflow/\u8d26\u6237\u56de\u6d4b.py",
    "func": "\u56de\u6d4b",
    "conda_env": "quantpy312",
})
