<template>
  <MetricBadge
    v-bind="$attrs"
    label="年化收益"
    :value="annualReturn"
    format="percent"
    :thresholds="{ good: 0.1, warn: 0, invert: false }"
  />
</template>
<script setup lang="ts">
defineProps<{ annualReturn: number | string }>();
</script>
