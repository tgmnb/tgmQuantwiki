<template>
  <div class="detail-wrap">
    <!-- Header -->
    <div class="detail-header">
      <h3 class="detail-title">
        {{ detail.name || '回测详情' }}
      </h3>
    </div>

    <!-- Tab bar -->
    <div class="detail-tabs">
      <button
        v-for="tab in tabs"
        :key="tab.key"
        class="detail-tab"
        :class="{ 'detail-tab--active': activeTab === tab.key }"
        @click="activeTab = tab.key"
      >
        <span class="detail-tab__icon">{{ tab.icon }}</span>
        <span class="detail-tab__label">{{ tab.label }}</span>
        <span
          v-if="tab.badge"
          class="detail-tab__badge"
        >{{ tab.badge }}</span>
      </button>
    </div>

    <!-- Tab content -->
    <div class="detail-body">
      <!-- Tab: Overview -->
      <template v-if="activeTab === 'overview'">
        <MetricPanel
          v-if="detail.metrics && Object.keys(detail.metrics).length > 0"
          :metrics="detail.metrics"
        />
        <ResizableChart
          v-if="detail.nav"
          :default-height="320"
          :min-height="180"
          :max-height="500"
        >
          <NavChart
            :nav="detail.nav"
            :name="detail.name"
          />
        </ResizableChart>

        <!-- Yearly & Monthly Analysis -->
        <div
          v-if="detail.nav"
          class="analysis-grid"
        >
          <div class="analysis-col">
            <YearlyReturnTable :nav="detail.nav" />
          </div>
          <div class="analysis-col">
            <MonthlyHeatmap :nav="detail.nav" />
          </div>
        </div>
      </template>

      <!-- Tab: Trade Records -->
      <template v-if="activeTab === 'trades'">
        <TradeTable
          v-if="tradeTrades && tradeTrades.rows && tradeTrades.rows.length > 0"
          :trades="tradeTrades"
          :detail-path="detail.path || ''"
          :strategy-base="strategyBase"
        />
        <EmptyState
          v-else
          title="暂无交易记录"
        />
      </template>

      <!-- Tab: Stock K-line -->
      <template v-if="activeTab === 'stocks'">
        <div
          v-if="detail.path"
          style="flex: 1; min-height: 0; overflow: hidden;"
        >
          <StockChart
            :detail-path="detail.path"
            :strategy-base="strategyBase"
          />
        </div>
        <EmptyState
          v-else
          title="暂无个股数据"
        />
      </template>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import type { PropType } from 'vue';
import MetricPanel from './MetricPanel.vue';
import NavChart from './NavChart.vue';
import TradeTable from './TradeTable.vue';
import StockChart from './StockChart.vue';
import YearlyReturnTable from './YearlyReturnTable.vue';
import MonthlyHeatmap from './MonthlyHeatmap.vue';
import ResizableChart from '@/components/common/ResizableChart.vue';

interface Detail {
  path?: string;
  name?: string;
  metrics?: Record<string, any>;
  nav?: any;
  trades?: any;
}

interface TradeData {
  headers?: string[];
  rows?: Record<string, any>[];
  total?: number;
  page?: number;
  page_size?: number;
  path?: string;
}

const props = defineProps({
  detail: {
    type: Object as PropType<Detail>,
    required: true,
  },
  strategyBase: {
    type: String,
    default: '',
  },
});

// ── Tab state ──────────────────────────────────────────
const activeTab = ref<'overview' | 'trades' | 'stocks'>('overview');

const tradeCount = computed(() => (props.detail?.trades as TradeData | undefined)?.total || 0);

const tabs = computed(() => [
  { key: 'overview' as const, label: '概览', icon: '📊', badge: undefined },
  { key: 'trades' as const, label: '交易记录', icon: '📋', badge: tradeCount.value > 0 ? String(tradeCount.value) : undefined },
  { key: 'stocks' as const, label: '个股K线', icon: '📈', badge: undefined },
]);

// ── Trade table ───────────────────────────────────────
const tradeTrades = computed(() => props.detail?.trades as TradeData | undefined);
</script>

<style scoped>
.detail-wrap {
  display: flex;
  flex-direction: column;
  flex: 1;
  overflow: hidden;
  min-height: 0;
}

.detail-header {
  display: flex;
  align-items: center;
  gap: var(--space-5);
  padding: var(--space-6) var(--space-7) var(--space-4);
  flex-shrink: 0;
}

.detail-title {
  margin: 0;
  font-size: var(--font-lg);
  font-weight: 700;
  color: var(--text-primary);
}

/* ── Tab bar ── */
.detail-tabs {
  display: flex;
  gap: var(--space-1);
  padding: 0 16px 10px;
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
}

.detail-tab {
  display: inline-flex;
  align-items: center;
  gap: 5px;
  padding: var(--space-2) var(--space-6);
  font-size: var(--font-sm);
  font-weight: 500;
  color: var(--text-muted);
  background: transparent;
  border: 1px solid transparent;
  border-bottom: none;
  border-radius: var(--radius) var(--radius) 0 0;
  cursor: pointer;
  transition: all 0.15s;
  position: relative;
  font-family: inherit;
}

.detail-tab:hover {
  color: var(--text-secondary);
  background: var(--bg-hover);
}

.detail-tab--active {
  color: var(--accent);
  background: var(--bg-secondary);
  border-color: var(--border);
}

.detail-tab--active::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  right: 0;
  height: 2px;
  background: var(--bg-secondary);
}

.detail-tab__icon {
  font-size: var(--font-md);
  line-height: 1;
}

.detail-tab__label {
  font-size: var(--font-sm);
}

.detail-tab__badge {
  font-size: var(--font-2xs);
  font-weight: 600;
  color: var(--accent);
  background: var(--accent-dim);
  padding: 0 5px;
  border-radius: 8px;
  line-height: 16px;
}

/* ── Tab body ── */
.detail-body {
  flex: 1;
  overflow-y: auto;
  min-height: 0;
  padding: var(--space-6) var(--space-7);
  display: flex;
  flex-direction: column;
  gap: var(--space-6);
}

/* ── Analysis grid ── */
.analysis-grid {
  display: grid;
  grid-template-columns: 2fr 3fr;
  gap: var(--space-5);
}

.analysis-col {
  min-width: 0;
  display: flex;
  flex-direction: column;
}

/* Responsive: stack on narrow screens */
@media (max-width: 900px) {
  .analysis-grid {
    grid-template-columns: 1fr;
  }
}
</style>
