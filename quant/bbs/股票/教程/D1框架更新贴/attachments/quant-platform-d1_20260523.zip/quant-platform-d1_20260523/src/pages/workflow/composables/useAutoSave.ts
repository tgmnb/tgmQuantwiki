import { ref, onUnmounted } from 'vue'

export type SaveStatus = 'idle' | 'saving' | 'saved' | 'error'

/**
 * 工作流自动保存 composable
 * - 检测 dirty 状态，自动防抖保存
 * - 暴露 saveStatus，UI 可直接渲染 "保存中..." / "已保存 ✓" / "保存失败"
 */
export function useAutoSave(
  saveFn: () => Promise<void>,
  delay = 800,
) {
  const saveStatus = ref<SaveStatus>('idle')
  let _debounceTimer: ReturnType<typeof setTimeout> | null = null
  let _savedTimer: ReturnType<typeof setTimeout> | null = null

  // 防抖保存
  function scheduleAutoSave() {
    if (saveStatus.value === 'saving') return
    saveStatus.value = 'idle'
    if (_debounceTimer) clearTimeout(_debounceTimer)
    _debounceTimer = setTimeout(async () => {
      try {
        saveStatus.value = 'saving'
        await saveFn()
        saveStatus.value = 'saved'
        // 2s 后变回 idle，避免一直显示"已保存"
        if (_savedTimer) clearTimeout(_savedTimer)
        _savedTimer = setTimeout(() => {
          saveStatus.value = 'idle'
        }, 2000)
      } catch {
        saveStatus.value = 'error'
      }
    }, delay)
  }

  // 立即保存（手动 Ctrl+S）
  async function saveNow() {
    if (_debounceTimer) clearTimeout(_debounceTimer)
    try {
      saveStatus.value = 'saving'
      await saveFn()
      saveStatus.value = 'saved'
      if (_savedTimer) clearTimeout(_savedTimer)
      _savedTimer = setTimeout(() => {
        saveStatus.value = 'idle'
      }, 2000)
    } catch {
      saveStatus.value = 'error'
    }
  }

  onUnmounted(() => {
    if (_debounceTimer) clearTimeout(_debounceTimer)
    if (_savedTimer) clearTimeout(_savedTimer)
  })

  return { saveStatus, scheduleAutoSave, saveNow }
}