import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import type { Strategy } from '@/types';
import type { StrategyListResponse, BacktestDetailResponse } from '@/types/api';
import { backtestApi } from '@/api/backtest';

export const useBacktestStore = defineStore('backtest', () => {
  const strategies = ref<Strategy[]>([]);
  const currentStrategy = ref<BacktestDetailResponse | null>(null);
  const loading = ref(false);

  const strategyList = computed(() => strategies.value);
  const groupedStrategies = computed(() => {
    const groups: Record<string, Strategy[]> = {};
    strategies.value.forEach((s) => {
      if (!groups[s.group]) {
        groups[s.group] = [];
      }
      groups[s.group].push(s);
    });
    return groups;
  });

  async function loadStrategies() {
    loading.value = true;
    try {
      const resp: StrategyListResponse = await backtestApi.getList();
      const groups = resp.groups || {};
      strategies.value = Object.values(groups).flat() as Strategy[];
    } finally {
      loading.value = false;
    }
  }

  async function loadStrategyDetail(path: string, base: string = '') {
    loading.value = true;
    try {
      const resp: BacktestDetailResponse = await backtestApi.getDetail(path, base);
      currentStrategy.value = resp ?? null;
    } finally {
      loading.value = false;
    }
  }

  return {
    strategies,
    currentStrategy,
    loading,
    strategyList,
    groupedStrategies,
    loadStrategies,
    loadStrategyDetail,
  };
});
