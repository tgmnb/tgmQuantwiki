from . import register_node

register_node({
    "id": "get_select_targets_from_account_list",
    "type": "tool",
    "name": "\u4ece\u8d26\u6237\u5217\u8868\u83b7\u53d6\u9009\u80a1\u76ee\u6807",
    "description": "\u6839\u636e\u8d26\u6237\u540d\u79f0\u5217\u8868\uff0c\u83b7\u53d6\u5bf9\u5e94\u8d26\u6237\u7684\u6301\u4ed3\u80a1\u7968\u4f5c\u4e3a\u9009\u80a1\u76ee\u6807",
    "icon": "icon-strategy",
    "category": "tool",
    "slots_in": [
        {"id": "account_list", "name": "\u8d26\u6237\u5217\u8868", "type": "any", "required": True},
    ],
    "slots_out": [
        {"id": "select_list", "name": "\u9009\u80a1\u5217\u8868", "type": "file"},
    ],
    "params": [
        {
            "id": "account_name_list",
            "name": "\u8d26\u6237\u540d\u79f0\u5217\u8868",
            "type": "list[str]",
            "default": [],
            "description": "\u8d26\u6237\u540d\u79f0\u5217\u8868\uff0c\u5982 ['account_a', 'account_b']",
            "ui": {"widget": "tag_input", "placeholder": "\u8f93\u5165\u8d26\u6237\u540d\u79f0"},
        },
        {
            "id": "backtest_type",
            "name": "\u56de\u6d4b\u7c7b\u578b",
            "type": "select",
            "options": [
                {"value": "stock_daily", "label": "\u65e5\u9891"},
                {"value": "stock_1h", "label": "\u5c0f\u65f6\u9891"},
            ],
            "default": "stock_daily",
            "ui": {"widget": "select", "allow_link": False},
        },
    ],
    "script": "workflow/\u9009\u80a1.py",
    "func": "get_select_targets_from_account_list",
    "conda_env": "quantpy312",
})
