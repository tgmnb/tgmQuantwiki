from . import register_node

register_node({
    "id": "get_select_targets_from_strategy_list",
    "type": "tool",
    "name": "\u4ece\u7b56\u7565\u5217\u8868\u83b7\u53d6\u9009\u80a1\u76ee\u6807",
    "description": "\u6839\u636e\u7b56\u7565\u540d\u79f0\u5217\u8868\uff0c\u83b7\u53d6\u5bf9\u5e94\u7b56\u7565\u7684\u9009\u80a1\u7ed3\u679c",
    "icon": "icon-strategy",
    "category": "tool",
    "slots_in": [],
    "slots_out": [
        {"id": "select_list", "name": "\u9009\u80a1\u5217\u8868", "type": "file"},
    ],
    "params": [
        {
            "id": "strategy_name_list",
            "name": "\u7b56\u7565\u540d\u79f0\u5217\u8868",
            "type": "list[str]",
            "default": [],
            "ui": {"widget": "tag_input", "placeholder": "\u8f93\u5165\u7b56\u7565\u540d\u79f0"},
        },
        {
            "id": "backtest_type",
            "name": "\u56de\u6d4b\u7c7b\u578b",
            "type": "select",
            "options": [
                {"value": "stock_daily", "label": "\u65e5\u9891"},
                {"value": "stock_1h", "label": "\u5c0f\u65f6\u9891"},
            ],
            "default": "stock_daily",
            "ui": {"widget": "select", "allow_link": False},
        },
    ],
    "script": "workflow/\u9009\u80a1.py",
    "func": "get_select_targets_from_strategy_list",
    "conda_env": "quantpy312",
})
