"""启动 D1-quant-platform 后端服务"""
import os, sys
from pathlib import Path

BASE = Path(__file__).parent.resolve()

if __name__ == "__main__":
    import uvicorn
    sys.path.insert(0, str(BASE))
    os.chdir(BASE)
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=5180,
        reload=False,
    )
