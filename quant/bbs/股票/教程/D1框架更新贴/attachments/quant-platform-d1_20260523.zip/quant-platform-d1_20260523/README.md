# 量化交易平台 (Quant Trading Platform - Vue 3)

## 功能特性

- **工作流管理** - 卡片式工作流管理、步骤编排、SSE 实时日志
- **回测分析** - 策略绩效指标、净值曲线、交易记录、K 线买卖点、多策略对比
- **策略构建器** - 可视化/代码双模式、CodeMirror Python 编辑器
- **策略库** - 因子、财务因子、选股、择时模块浏览与代码查看
- **设置页面** - 主题切换（dark/light/eye-care）、API 配置

## 技术栈

| 层面 | 技术 |
|------|------|
| 框架 | Vue 3.4+ / TypeScript 5.7+ |
| 构建 | Vite 6+ |
| 状态管理 | Pinia 2+ |
| UI | Element Plus 2.9+ |
| 图表 | ECharts 5.6+ |
| 代码编辑器 | CodeMirror 6 |
| 测试 | Vitest 3+ |
| 后端 | FastAPI + Polars（`backend/` 目录） |

## 快速开始

```bash
# 安装依赖
npm install

# 启动前端开发服务器（localhost:5173）
npm run dev

# 启动后端（另一个终端）
cd backend
conda activate quantpy312
python main.py
# 后端运行在 localhost:5180，前端通过 Vite proxy 转发 /api 请求
```

## 可用脚本

```bash
npm run dev          # 开发服务器
npm run build        # vue-tsc 类型检查 + vite 构建（输出到 dist/）
npm run preview      # 预览构建产物
npm run lint         # ESLint 检查并自动修复
npm run format       # Prettier 格式化
npm run type-check   # 仅 TypeScript 类型检查
npm run test         # 运行 Vitest 测试
```

## 项目结构

```
src/
├── api/              # API 请求封装（Axios，按模块拆分）
├── assets/styles/    # 全局样式、CSS 变量（主题）
├── components/
│   ├── common/       # Button, Card, Loading, MetricCard, MetricBadge 等
│   ├── editor/       # CodeEditor, CodeToolbar, CodeViewer（CodeMirror 6）
│   └── layout/       # AppLayout, Sidebar, TopBar
├── composables/      # useSSE, useSavedParams, useLibraryCode
├── pages/
│   ├── workflow/     # 工作流管理（卡片列表 + 步骤编排 + 参数面板）
│   ├── backtest/     # 回测分析（净值曲线、指标、交易表、热力图）
│   ├── builder/      # 策略构建器（可视化/代码模式）
│   ├── library/      # 策略库（因子、财务因子、选股、择时 tab）
│   └── settings/     # 系统设置
├── router/           # 路由配置（懒加载）+ 守卫
├── stores/           # Pinia Store（workflow, simplifiedWorkflow, backtest, builder, ui）
├── types/            # TypeScript 类型定义
└── utils/            # ECharts 封装、编辑器主题、日期工具等
```

## 主题

支持 dark/light/eye-care 三主题，通过设置页面或顶栏图标切换，偏好保存在 `localStorage`（key: `d1-theme`）。

## 开发规范

- ESLint flat config（`eslint.config.js`）+ Prettier（`.prettierrc`）
- Git 提交遵循 Conventional Commits
- TypeScript strict 模式
- Path alias：`@/` → `src/`
