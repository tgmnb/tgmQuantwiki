import { defineStore } from 'pinia';
import { ref, computed } from 'vue';
import type { Workflow, NodeDefinition } from '@/types';
import type { WorkflowListResponse, WorkflowResponse } from '@/types/api';
import type { WorkflowRun } from '@/api/workflow';
import { workflowApi } from '@/api/workflow';

export interface RunCallbacks {
  onComplete?: (status: 'completed' | 'failed' | 'stopped', error?: string) => void;
  onEvent?: (msg: unknown) => void;
}

// ── SSE 重连配置 ──
const SSE_MAX_RETRIES = 5;
const SSE_BASE_DELAY = 1000; // 1s
const SSE_MAX_DELAY = 30000; // 30s

export const useWorkflowStore = defineStore('workflow', () => {
  const workflows = ref<Workflow[]>([]);
  const currentWorkflow = ref<Workflow | null>(null);
  const loading = ref(false);
  const saving = ref(false);
  const running = ref(false);
  const runningId = ref<string | null>(null);
  const logLines = ref<string[]>([]);
  const MAX_LOG_LINES = 500;
  const stepStatusMap = ref<Record<string, string>>({});
  const stepProgressMap = ref<Record<string, number>>({});
  const currentStepName = ref('');
  const runHistory = ref<WorkflowRun[]>([]);
  const sseConnected = ref(false);
  const nodeDefinitions = ref<NodeDefinition[]>([]);
  let _debounceTimer: ReturnType<typeof setTimeout> | null = null;

  // ── SSE 内部状态 ──
  let _eventSource: EventSource | null = null;
  let _streamUrl = '';
  let _retryCount = 0;
  let _retryTimer: ReturnType<typeof setTimeout> | undefined;
  let _currentCallbacks: RunCallbacks | undefined;
  let _intentionalClose = false;
  let _realtimeLogBackup: string[] = [];

  const workflowList = computed(() => workflows.value);
  const currentSteps = computed(() => currentWorkflow.value?.steps || []);

  const runProgress = computed(() => {
    const statuses = stepStatusMap.value;
    const total = Object.keys(statuses).length;
    if (total === 0) return { completed: 0, total: 0, percentage: 0, runningStepName: '' };
    const completed = Object.values(statuses).filter(s => s === 'done' || s === 'failed').length;
    const runningEntry = Object.entries(statuses).find(([_, s]) => s === 'running');
    return {
      completed,
      total,
      percentage: Math.round((completed / total) * 100),
      runningStepName: runningEntry ? runningEntry[0] : '',
    };
  });

  async function loadWorkflows() {
    loading.value = true;
    try {
      const data: WorkflowListResponse = await workflowApi.list();
      workflows.value = data.workflows || [];
    } catch {
      // error handled by interceptor
    } finally {
      loading.value = false;
    }
  }

  async function loadWorkflow(id: string) {
    loading.value = true;
    try {
      const result: WorkflowResponse = await workflowApi.get(id);
      currentWorkflow.value = result.workflow || null;
    } finally {
      loading.value = false;
    }
  }

  async function createWorkflow(data: Partial<Workflow>) {
    saving.value = true;
    try {
      const result: WorkflowResponse = await workflowApi.create(data);
      const workflow = result.workflow;
      if (workflow) {
        workflows.value.push(workflow);
      }
      return workflow;
    } finally {
      saving.value = false;
    }
  }

  async function updateWorkflow(id: string, data: Partial<Workflow>) {
    saving.value = true;
    try {
      const result: WorkflowResponse = await workflowApi.update(id, data);
      const workflow = result.workflow;
      if (workflow) {
        const index = workflows.value.findIndex((w) => w.id === id);
        if (index !== -1) {
          workflows.value[index] = workflow;
        }
        if (currentWorkflow.value?.id === id) {
          currentWorkflow.value = workflow;
        }
      }
    } finally {
      saving.value = false;
    }
  }

  async function deleteWorkflow(id: string) {
    loading.value = true;
    try {
      await workflowApi.delete(id);
      workflows.value = workflows.value.filter((w) => w.id !== id);
      if (currentWorkflow.value?.id === id) {
        currentWorkflow.value = null;
      }
    } finally {
      loading.value = false;
    }
  }

  let _notificationPermissionRequested = false;

  function _requestNotificationPermission() {
    if (_notificationPermissionRequested) return;
    _notificationPermissionRequested = true;
    if ('Notification' in window && Notification.permission === 'default') {
      Notification.requestPermission();
    }
  }

  // ── SSE 消息处理 ──
  function _handleSSEMessage(msg: any, rawData: string) {
    if (msg.type === 'step_start') {
      currentStepName.value = msg.step_name || msg.step_id || ''
      if (msg.step_id) setStepStatus(msg.step_id, 'running')
      addLog(`▶ 开始: ${msg.step_name || msg.step_id}`)
    } else if (msg.type === 'step_done') {
      if (msg.step_id) setStepStatus(msg.step_id, 'done')
      const dur = msg.duration ? ` (${msg.duration}s)` : ''
      addLog(`✔ 完成: ${msg.step_name || msg.step_id}${dur}`)
    } else if (msg.type === 'step_failed') {
      const stepId = msg.step_id || msg.step_name || 'unknown';
      if (msg.step_id) setStepStatus(msg.step_id, 'failed')
      const err = msg.error ? ` — ${msg.error}` : '';
      addLog(`✘ 失败: ${msg.step_name || msg.step_id}${err}`);
      if (msg.error && running.value) {
        console.warn(`[SSE] Step failed: ${stepId}`, msg.error);
      }
    } else if (msg.type === 'progress') {
      const pct = Math.round(msg.progress || 0)
      if (msg.step_name && pct > 0) {
        addLog(`⏳ [${msg.step_name}] ${pct}%`)
      }
      // 更新 per-step 进度
      if (msg.step_id) {
        stepProgressMap.value[msg.step_id] = pct
      }
    } else if (msg.type === 'log') {
      const lines: string[] = msg.lines || (msg.line ? [msg.line] : [])
      const prefix = msg.step_name ? `[${msg.step_name}] ` : ''
      const recentSet = new Set(logLines.value.slice(-100))
      for (const line of lines) {
        if (line.trim()) {
          const fullLine = prefix + line
          if (!recentSet.has(fullLine)) {
            addLog(fullLine)
            recentSet.add(fullLine)
          }
        }
      }
    } else if (msg.type === 'done' || msg.status === 'done' || msg.status === 'failed') {
      if (msg.step_status) {
        for (const [stepId, status] of Object.entries(msg.step_status)) {
          setStepStatus(stepId, status as string)
        }
      }
      if (msg.error) {
        addLog(`❌ 错误: ${msg.error}`)
      } else {
        addLog(msg.status === 'failed' ? '❌ 工作流执行失败' : '✔ 工作流执行完成')
      }
    } else {
      addLog(typeof msg === 'string' ? msg : rawData)
    }
  }

  function sendCompletionNotification(name: string, status: string, duration?: number) {
    if (document.visibilityState !== 'hidden') return;
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    const title = status === 'completed' ? '工作流执行完成' : '工作流执行失败';
    const body = `${name}${duration ? ` · 耗时 ${duration}s` : ''}`;
    const notification = new Notification(title, { body });
    notification.onclick = () => {
      window.focus();
      notification.close();
    };
  }

  // ── SSE 连接管理 ──

  /** 关闭当前 SSE 连接（不触发重连） */
  function _closeSSE() {
    clearTimeout(_retryTimer);
    if (_eventSource) {
      _intentionalClose = true;
      _eventSource.close();
      _eventSource = null;
    }
    sseConnected.value = false;
  }

  /** 带指数退避的 SSE 重连 */
  function _scheduleReconnect() {
    if (_intentionalClose || !running.value) return;
    if (_retryCount >= SSE_MAX_RETRIES) {
      addLog(`❌ SSE 连接重试失败（已尝试 ${SSE_MAX_RETRIES} 次），工作流运行中断`);
      _finishRun('failed', 'SSE connection lost after max retries');
      return;
    }

    _retryCount++;
    const rawDelay = SSE_BASE_DELAY * Math.pow(2, _retryCount - 1);
    const delay = Math.max(rawDelay, SSE_BASE_DELAY);
    const actualDelaySec = (delay / 1000).toFixed(1);
    addLog(`⚠ SSE 连接断开，${actualDelaySec}s 后重连（第 ${_retryCount}/${SSE_MAX_RETRIES} 次，最大延迟 ${SSE_MAX_DELAY / 1000}s）`);

    _retryTimer = setTimeout(() => {
      if (!running.value || _intentionalClose) return;
      _connectSSE();
    }, delay);
  }

  /** 建立 SSE 连接（首次或重连） */
  function _connectSSE() {
    if (!_streamUrl) return;

    _closeSSE();
    _intentionalClose = false;

    const es = new EventSource(_streamUrl);
    _eventSource = es;

    es.onopen = () => {
      sseConnected.value = true;
      if (_retryCount > 0) {
        addLog(`✔ SSE 连接已恢复（第 ${_retryCount} 次重连成功）`);
        _retryCount = 0; // 重连成功后重置计数
      }
    };

    es.onmessage = (event: MessageEvent) => {
      try {
        const msg = JSON.parse(event.data);
        _handleSSEMessage(msg, event.data);
        _currentCallbacks?.onEvent?.(msg);
      } catch {
        addLog(event.data);
      }
    };

    es.addEventListener('done', (event: MessageEvent) => {
      // 后端执行完成 → 正常结束，不重连
      let finalStatus: 'completed' | 'failed' | 'stopped' = 'completed';
      try {
        const msg = JSON.parse(event.data);
        if (msg.error) {
          finalStatus = 'failed';
        }
      } catch { /* ignore parse error, default to completed */ }
      _finishRun(finalStatus);
      _closeSSE();
    });

    es.onerror = () => {
      sseConnected.value = false;
      if (_intentionalClose) return;

      // 如果后端任务仍在运行，尝试重连
      if (running.value) {
        _eventSource = null;
        // 防止无限重连：当任务实际已结束但状态未同步时，延迟后检查并自动清理
        _scheduleReconnect();
      } else {
        _closeSSE();
      }
    };
  }

  /** 标记运行结束 */
  function _finishRun(status: 'completed' | 'failed' | 'stopped', error?: string) {
    running.value = false;
    sseConnected.value = false;
    _retryCount = 0;
    _currentCallbacks?.onComplete?.(status, error);
  }

  /** 运行工作流（POST 启动 + SSE 日志流） */
  async function runWorkflow(
    id: string,
    startFromStep?: number,
    callbacks?: RunCallbacks,
    stepParams?: Record<string, unknown>,
  ): Promise<void> {
    _requestNotificationPermission();
    _currentCallbacks = callbacks;

    await workflowApi.run(id, startFromStep, stepParams);

    running.value = true;
    runningId.value = id;
    _retryCount = 0;
    _intentionalClose = false;
    clearLogs();
    clearStepStatus();

    // 建立 SSE 连接（注意：workflowApi.run 已经 POST 了，
    // 这里重新创建 EventSource 连接到 stream 端点）
    _streamUrl = `/api/workflows/${id}/stream`;
    _connectSSE();
  }

  /** 主动停止工作流 */
  async function stopWorkflow() {
    _intentionalClose = true;
    _closeSSE();
    if (runningId.value) {
      try {
        await workflowApi.stop(runningId.value);
      } catch {
        // Backend stop failed, but we still clean up local state
      }
    }
    running.value = false;
    runningId.value = null;
  }

  async function loadRunHistory(wfId: string) {
    const data = await workflowApi.listRuns(wfId);
    runHistory.value = data || [];
  }

  async function loadRunLogs(wfId: string, runId: string): Promise<string[]> {
    const data = await workflowApi.getRunLogs(wfId, runId);
    return data?.lines || [];
  }

  function addLog(line: string) {
    const lines = logLines.value;
    const isErrorType = line.includes('[ERROR_TYPE:');
    const timestamp = isErrorType ? `[${new Date().toLocaleTimeString()}] ` : '';
    const finalLine = isErrorType ? `${timestamp}⚠ ${line}` : line;
    if (lines.length >= MAX_LOG_LINES) {
      logLines.value = [...lines.slice(lines.length - MAX_LOG_LINES + 1), finalLine];
    } else {
      lines.push(finalLine);
    }
  }

  function backupRealtimeLogs() {
    _realtimeLogBackup = [...logLines.value]
  }

  function restoreRealtimeLogs() {
    logLines.value = [..._realtimeLogBackup]
    _realtimeLogBackup = []
  }

  function clearLogs() {
    logLines.value = [];
  }

  function setStepStatus(stepId: string, status: string) {
    stepStatusMap.value[stepId] = status;
  }

  function clearStepStatus() {
    stepStatusMap.value = {};
    stepProgressMap.value = {};
    currentStepName.value = '';
  }

  function updateWorkflowDebounced(id: string, data: Partial<Workflow>) {
    if (_debounceTimer) clearTimeout(_debounceTimer);
    _debounceTimer = setTimeout(() => {
      updateWorkflow(id, data);
      _debounceTimer = null;
    }, 300);
  }

  async function loadNodes(): Promise<NodeDefinition[]> {
    if (nodeDefinitions.value.length > 0) return nodeDefinitions.value
    try {
      const data = await workflowApi.listNodes()
      nodeDefinitions.value = data.nodes || []
      return nodeDefinitions.value
    } catch {
      return []
    }
  }

  return {
    workflows,
    currentWorkflow,
    loading,
    saving,
    running,
    runningId,
    logLines,
    stepStatusMap,
    stepProgressMap,
    currentStepName,
    runHistory,
    sseConnected,
    nodeDefinitions,
    workflowList,
    currentSteps,
    runProgress,
    loadWorkflows,
    loadWorkflow,
    createWorkflow,
    updateWorkflow,
    updateWorkflowDebounced,
    deleteWorkflow,
    runWorkflow,
    loadRunHistory,
    loadRunLogs,
    stopWorkflow,
    addLog,
    clearLogs,
    backupRealtimeLogs,
    restoreRealtimeLogs,
    setStepStatus,
    clearStepStatus,
    sendCompletionNotification,
    loadNodes,
  };
});
