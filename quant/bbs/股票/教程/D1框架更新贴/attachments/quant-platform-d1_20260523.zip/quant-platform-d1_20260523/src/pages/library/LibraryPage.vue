<template>
  <div class="library-layout">
    <div class="library-header">
      <div class="tab-bar">
        <button
          v-for="tab in tabs"
          :key="tab.id"
          class="tab-btn"
          :class="{ active: activeTab === tab.id }"
          @click="activeTab = tab.id"
        >
          <el-icon class="tab-btn__icon">
            <component :is="tab.icon" />
          </el-icon>
          <span class="tab-btn__label">{{ tab.label }}</span>
        </button>
      </div>
      <div class="search-box">
        <el-icon class="search-box__icon">
          <Search />
        </el-icon>
        <input
          v-model="localSearch"
          type="text"
          class="search-box__input"
          placeholder="搜索策略..."
        >
        <button
          v-if="localSearch"
          class="search-box__clear"
          @click="localSearch = ''"
        >
          <el-icon :size="12">
            <Close />
          </el-icon>
        </button>
      </div>
    </div>
    <div class="library-body">
      <Transition
        name="tab-switch"
        mode="out-in"
      >
        <component
          :is="activeComponent"
          :search="effectiveSearch"
        />
      </Transition>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import FactorsTab from './tabs/FactorsTab.vue';
import SelectionTab from './tabs/SelectionTab.vue';
import TimingTab from './tabs/TimingTab.vue';
import FinancialFactorsTab from './tabs/FinancialFactorsTab.vue';

const activeTab = ref('factors');
const localSearch = ref('');

const tabs = [
  { id: 'factors', label: '因子', icon: 'DataLine' },
  { id: 'selection', label: '选股', icon: 'Filter' },
  { id: 'timing', label: '择时', icon: 'TrendCharts' },
  { id: 'financial_factors', label: '财务因子', icon: 'Coin' },
];

const componentMap: Record<string, any> = {
  factors: FactorsTab,
  selection: SelectionTab,
  timing: TimingTab,
  financial_factors: FinancialFactorsTab,
};

const activeComponent = computed(() => componentMap[activeTab.value]);
const effectiveSearch = computed(() => localSearch.value);
</script>

<style scoped>
.library-layout {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

.library-header {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 10px 16px;
  border-bottom: 1px solid var(--border-color);
  flex-shrink: 0;
  background: var(--bg-secondary);
}

.tab-bar {
  display: flex;
  align-items: center;
  gap: 2px;
  padding: 3px;
  background: var(--bg-tertiary);
  border-radius: var(--radius-md);
  border: 1px solid var(--border-color);
}

.tab-btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 14px;
  border: none;
  background: none;
  cursor: pointer;
  font-size: var(--font-sm);
  font-weight: 500;
  color: var(--text-secondary);
  border-radius: var(--radius-sm);
  transition: all var(--transition);
  position: relative;
}

.tab-btn:hover {
  color: var(--text-primary);
  background: var(--bg-hover);
}

.tab-btn.active {
  background: var(--accent-dim);
  color: var(--accent);
  font-weight: 600;
}

.tab-btn__icon {
  font-size: 14px;
}

.tab-btn__label {
  white-space: nowrap;
}

.search-box {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 6px;
  background: var(--bg-primary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius);
  padding: 0 10px;
  height: 32px;
  width: 220px;
  transition: border-color var(--transition), box-shadow var(--transition);
}

.search-box:focus-within {
  border-color: var(--accent);
  box-shadow: 0 0 0 3px var(--accent-glow);
}

.search-box__icon {
  color: var(--text-muted);
  font-size: var(--font-sm);
  flex-shrink: 0;
}

.search-box__input {
  flex: 1;
  background: none;
  border: none;
  outline: none;
  color: var(--text-primary);
  font-size: var(--font-sm);
  font-family: inherit;
}

.search-box__input::placeholder {
  color: var(--text-muted);
}

.search-box__clear {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 18px;
  height: 18px;
  border-radius: 50%;
  border: none;
  background: var(--bg-tertiary);
  color: var(--text-muted);
  cursor: pointer;
  flex-shrink: 0;
  transition: all var(--transition);
}

.search-box__clear:hover {
  background: var(--border2);
  color: var(--text-primary);
}

.library-body {
  flex: 1;
  overflow: hidden;
  position: relative;
}

/* Tab switch transition */
.tab-switch-enter-active,
.tab-switch-leave-active {
  transition: opacity 0.15s ease;
}

.tab-switch-enter-from,
.tab-switch-leave-to {
  opacity: 0;
}
</style>
