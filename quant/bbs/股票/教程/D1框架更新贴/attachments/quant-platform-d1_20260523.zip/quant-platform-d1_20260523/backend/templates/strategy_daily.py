from backtest.strategies.templates.stock_daily_base import (
    init_config, init_stock_signals, init_risk_signals,
    update_risk_signals, calculate_single_stock_cast, buy_stock, sell_stock
)
from backtest.core.context import Context


def initialize(context: Context):
    init_config(context)
    init_stock_signals(context)
    init_risk_signals(context)


def handle_data(context: Context):
    update_risk_signals(context)
    calculate_single_stock_cast(context)
    if context.swap_type != 'overnight':
        sell_stock(context)
        buy_stock(context)
    else:
        buy_stock(context)
        sell_stock(context)
