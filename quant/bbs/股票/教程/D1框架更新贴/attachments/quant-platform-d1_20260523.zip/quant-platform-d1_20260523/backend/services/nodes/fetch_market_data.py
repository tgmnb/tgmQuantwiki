from . import register_node

register_node({
    "id": "fetch_market_data",
    "type": "atomic",
    "name": "\u83b7\u53d6\u884c\u60c5\u6570\u636e",
    "description": "\u4ece\u672c\u5730CSV\u6587\u4ef6\u52a0\u8f7d\u80a1\u7968\u65e5\u7ebf/\u5c0f\u65f6\u7ea7\u522b\u884c\u60c5\u6570\u636e",
    "icon": "icon-data",
    "category": "\u6570\u636e\u6e90",
    "slots_in": [],
    "slots_out": [
        {"id": "price_data", "name": "\u884c\u60c5\u6570\u636e", "type": "file"},
    ],
    "params": [
        {
            "id": "data_type",
            "name": "\u6570\u636e\u7c7b\u578b",
            "type": "select",
            "options": [
                {"value": "stock_daily", "label": "\u80a1\u7968\u65e5\u7ebf"},
                {"value": "stock_1h", "label": "\u80a1\u7968\u5c0f\u65f6"},
                {"value": "futures", "label": "\u671f\u8d27"},
            ],
            "default": "stock_daily",
            "ui": {"widget": "select", "placeholder": "\u8bf7\u9009\u62e9\u6570\u636e\u7c7b\u578b"},
        },
        {
            "id": "date_start",
            "name": "\u5f00\u59cb\u65e5\u671f",
            "type": "str",
            "default": "2020-01-01",
            "ui": {"widget": "date_picker", "format": "YYYY-MM-DD", "allow_link": False},
        },
        {
            "id": "date_end",
            "name": "\u7ed3\u675f\u65e5\u671f",
            "type": "str",
            "default": "2024-12-31",
            "ui": {"widget": "date_picker", "format": "YYYY-MM-DD", "allow_link": False},
        },
    ],
    "script": "workflow/\u6570\u636e\u52a0\u8f7d.py",
    "func": "\u52a0\u8f7d\u884c\u60c5\u6570\u636e",
    "conda_env": "quantpy312",
    "note": "\u4ece quant-test-d1-pro \u6570\u636e\u76ee\u5f55\u8bfb\u53d6 CSV \u884c\u60c5\u6570\u636e\uff0c\u8f93\u51fa\u6807\u51c6\u5316 DataFrame",
})
