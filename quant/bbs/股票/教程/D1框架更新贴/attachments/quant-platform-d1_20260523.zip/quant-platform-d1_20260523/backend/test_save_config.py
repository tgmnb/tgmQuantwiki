"""Test save_config endpoint end-to-end"""
import sys
sys.path.insert(0, '.')

import config as _config
from config import QUANT_PROJ
from pathlib import Path

strategy_name = '热门抱团策略'
backtest_type = 'stock_daily'
strategy_config = {
    'select_target': '板块轮动热门抱团选股',
    'day_buy_num_max': 3,
    'cap_amount': 3,
    'hold_period': 2,
    'swap_time': 'open-close',
    'stop_win': {'is_open': False, 'ratio': 0.15},
    'stop_lose': {'is_open': False, 'ratio': -0.15},
    'moving_win': {'is_open': False, 'ratio': 0.2},
    'sell_uplimit_hold_mode': True,
}
timing_config = {
    'period': 'daily',
    'risk': {'is_open': False},
    'stock': {'is_open': False},
}

stg_dir = QUANT_PROJ / 'backtest' / 'strategies' / backtest_type / strategy_name
print('stg_dir:', stg_dir)
print('exists:', stg_dir.exists())

def _dict_repr(d, indent=4):
    pad = ' ' * indent
    lines = []
    for k, v in d.items():
        if isinstance(v, dict):
            lines.append(pad + "'" + k + "': {")
            for sub_k, sub_v in v.items():
                if isinstance(sub_v, bool):
                    val_str = 'True' if sub_v else 'False'
                elif isinstance(sub_v, (int, float)):
                    val_str = repr(sub_v)
                else:
                    val_str = repr(sub_v)
                lines.append(pad + "    '" + sub_k + "': " + val_str + ",")
            lines.append(pad + "},")
        elif isinstance(v, bool):
            lines.append(pad + "'" + k + "': " + ('True' if v else 'False') + ",")
        elif isinstance(v, (int, float)):
            lines.append(pad + "'" + k + "': " + repr(v) + ",")
        elif isinstance(v, list):
            items = ', '.join(repr(x) for x in v)
            lines.append(pad + "'" + k + "': [" + items + "],")
        else:
            lines.append(pad + "'" + k + "': " + repr(v) + ",")
    return '\n'.join(lines)

sc_str = _dict_repr(strategy_config)
tc_str = _dict_repr(timing_config)

header = """
"""
header += strategy_name + """ 策略配置

自动生成，请勿手动修改
"""
code = header + """
strategy_config = {
""" + sc_str + """
}

timing_config = {
""" + tc_str + """
}
"""

print('Code generated OK, length:', len(code))
print('First 300 chars:')
print(code[:300])
print()

config_path = stg_dir / 'stg_config.py'
config_path.write_text(code, encoding='utf-8')
print('Write OK')

print('Verification:')
print(config_path.read_text(encoding='utf-8')[:400])

# Test cache invalidation
from services.data_service import invalidate_scan_cache
cache_key = str((QUANT_PROJ / 'backtest' / 'strategies').resolve())
invalidate_scan_cache(cache_key)
print('Cache invalidation OK')