# -*- coding: utf-8 -*-
"""Shared fixtures for backend tests."""

import sys
import sqlite3
import threading
from pathlib import Path
from unittest.mock import MagicMock
from queue import Queue

import pytest


# ---------------------------------------------------------------------------
# Mock config module so services can be imported without a real project
# ---------------------------------------------------------------------------
class _MockConfig:
    """Stand-in for backend/config.py used during tests."""

    QUANT_PROJ: Path = None  # will be overridden by fixtures


@pytest.fixture(autouse=True)
def _ensure_mock_config(monkeypatch):
    """Make ``import config`` return a lightweight mock before any service is imported."""
    mock_cfg = _MockConfig()
    # If the real config is already imported, patch its QUANT_PROJ; otherwise inject a mock module.
    if "config" in sys.modules:
        monkeypatch.setattr(sys.modules["config"], "QUANT_PROJ", None, raising=False)
    else:
        sys.modules["config"] = mock_cfg
    yield
    # Cleanup: remove the mock module so it doesn't leak between tests
    if sys.modules.get("config") is mock_cfg:
        del sys.modules["config"]


# ---------------------------------------------------------------------------
# In-memory SQLite database helpers (for db_service tests)
# ---------------------------------------------------------------------------

_WORKFLOW_RUNS_DDL = """
CREATE TABLE IF NOT EXISTS workflow_runs (
    run_id           TEXT PRIMARY KEY,
    wf_id            TEXT NOT NULL,
    status           TEXT NOT NULL,
    started_at       REAL NOT NULL,
    ended_at         REAL,
    step_status_json TEXT,
    error            TEXT,
    created_at       REAL NOT NULL,
    updated_at       REAL NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_workflow_runs_wf_id ON workflow_runs(wf_id);
"""


@pytest.fixture()
def in_memory_db():
    """Return an in-memory SQLite connection with workflow_runs table created."""
    conn = sqlite3.connect(":memory:", check_same_thread=False)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.row_factory = sqlite3.Row
    conn.executescript(_WORKFLOW_RUNS_DDL)
    conn.commit()
    yield conn
    conn.close()


@pytest.fixture()
def tmp_proj_dir(tmp_path):
    """Return a temporary directory that acts as QUANT_PROJ, with workflows/ subdir."""
    wf_dir = tmp_path / "workflows"
    wf_dir.mkdir()
    return tmp_path
