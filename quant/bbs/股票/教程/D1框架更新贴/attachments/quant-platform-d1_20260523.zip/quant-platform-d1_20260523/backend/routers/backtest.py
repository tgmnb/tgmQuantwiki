"""
回测分析 API — 策略列表/净值/绩效/对比

数据来源: QUANT_PROJ/backtest/data（stock_daily / stock_minute / future）
路径解析: list 返回每条策略的 {path, base}，resolver 根据 base 直接定位。
文件发现: 按语义模式匹配（*净值* / *交易* / *绩效*），无硬编码文件名。
"""

from __future__ import annotations

import asyncio
import logging
import re
from pathlib import Path

import config as _config
import hashlib

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import JSONResponse, Response, StreamingResponse

from services.cache_manager import LRUCache
from services.data_service import load_csv, get_cached
from services.metrics_service import calc_full_metrics
from services.tree_service import safe_resolve, to_posix_path
from services.backtest_service import create_task as _create_backtest_task

_logger = logging.getLogger("quant.backtest")

router = APIRouter(prefix="/api/backtest", tags=["backtest"])

# ---------------------------------------------------------------------------
# 缓存配置
# ---------------------------------------------------------------------------

# list 接口 LRU 缓存（容量上限 1，TTL 60 秒）— 线程安全替代全局变量
_list_cache = LRUCache(max_size=1, default_ttl=60.0)

# compare 接口 LRU 缓存（容量上限 50，TTL 300 秒）
_compare_cache = LRUCache(max_size=50, default_ttl=300.0)
_COMPARE_CACHE_TTL = 300.0

# 预编译正则（用于 _extract_nav_series，避免重复编译）
_TIME_CANDIDATES_RE = [re.compile(p, re.IGNORECASE) for p in [r"时间", r"date", r"日期", r"datetime"]]
_VALUE_CANDIDATES_RE = [re.compile(p, re.IGNORECASE) for p in [r"总资产", r"nav", r"累积净值", r"净资产"]]


def _compare_cache_key(paths: list[str], bases: list[str]) -> str:
    """生成 compare 接口的缓存键。"""
    return "|".join(f"{p}:{bases[i] if i < len(bases) else ''}" for i, p in enumerate(paths))


# ============================================================================
# API: 回测执行
# ============================================================================

@router.post("/run")
async def run_backtest(
    strategy_name: str,
    backtest_type: str = "stock_daily",
    asset_type: str = "stock",
    date_start: str | None = None,
    date_end: str | None = None,
):
    """提交回测任务到后台执行。

    POST /api/backtest/run
    {
        "strategy_name": "AH溢价策略",
        "backtest_type": "stock_daily",   // stock_daily / stock_1h / stock_minute / future
        "asset_type": "stock",            // stock / future
        "date_start": "2020-01-01",       // 可选，默认使用 config.py
        "date_end": "2024-12-31"         // 可选，默认使用 config.py（最近交易日）
    }

    Returns:
        {"task_id": str, "status": str}
    """
    try:
        result = _create_backtest_task(
            strategy_name=strategy_name,
            backtest_type=backtest_type,
            asset_type=asset_type,
            date_start=date_start,
            date_end=date_end,
        )
        _logger.info("回测任务已提交: strategy=%s, task_id=%s", strategy_name, result["task_id"])
        return result
    except RuntimeError as exc:
        _logger.warning("回测任务提交失败: %s", exc)
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        _logger.error("回测任务提交异常: %s", exc)
        raise HTTPException(status_code=500, detail=f"回测提交失败: {exc}") from exc


@router.get("/task/{task_id}")
async def get_backtest_task(task_id: str):
    """查询回测任务状态和进度。"""
    from services.backtest_service import get_task as _get_backtest_task
    task = _get_backtest_task(task_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"任务不存在: {task_id}")
    return task


@router.get("/task/{task_id}/log")
async def get_backtest_task_log(task_id: str, lines: int = Query(200, ge=10, le=2000)):
    """获取回测任务最近日志。"""
    from services.backtest_service import get_task_with_log as _get_backtest_task_log
    try:
        result = _get_backtest_task_log(task_id)
        result["log"] = result.pop("log_tail", "")[:lines * 200]  # 限制大小
        return result
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/task/{task_id}/stop")
async def stop_backtest_task(task_id: str):
    """停止运行中的回测任务。"""
    from services.backtest_service import stop_task as _stop_backtest_task
    try:
        return _stop_backtest_task(task_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.get("/tasks")
async def list_backtest_tasks(status: str | None = Query(None)):
    """列出所有回测任务（可按状态过滤）。"""
    from services.backtest_service import list_tasks as _list_backtest_tasks
    return {"tasks": _list_backtest_tasks(status)}


@router.get("/task/running")
async def get_running_backtest_task():
    """获取当前正在运行的回测任务。"""
    from services.backtest_service import get_running_task as _get_running_backtest_task
    task = _get_running_backtest_task()
    if not task:
        return {"task": None}
    return {"task": task}

# ---------------------------------------------------------------------------
# 路径解析（根据 base 标识直接定位，不试错）
# ---------------------------------------------------------------------------

def _resolve(path: str, base: str = "") -> Path:
    """将 list 接口返回的相对路径解析为绝对路径。

    回测数据唯一来源: QUANT_PROJ/backtest/data

    Args:
        path: 相对路径（如 "stock_minute/AH溢价策略"）
        base: 来源标识 ("backtest")。为空时自动检测。

    Raises:
        ValueError: 路径越界或不存在
    """
    if base == "backtest":
        return safe_resolve(_config._BACKTEST_PROJ_DIR, path)

    # 无 base 时自动检测（兼容直接 URL 调用）
    if _config._BACKTEST_PROJ_DIR is not None:
        try:
            p = safe_resolve(_config._BACKTEST_PROJ_DIR, path)
            if p.exists():
                return p
        except (ValueError, Exception) as exc:
            _logger.warning("自动路径解析失败: base=%s, path=%s, exc=%s", base, path, exc)
            raise ValueError(f"路径不存在或无法访问: {path}") from exc
    _logger.error("路径不存在或无法访问: base=%s, path=%s", base, path)
    raise ValueError(f"路径不存在或无法访问: {path}")


# ---------------------------------------------------------------------------
# 文件发现（模式匹配，无硬编码）
# ---------------------------------------------------------------------------

# 语义文件名模式 —— 按关键词模糊匹配，不依赖精确文件名
_FILE_PATTERNS = {
    "nav":      [r"净值", r"资金净值", r"nav"],
    "trade":    [r"交易", r"trade"],
    "metrics":  [r"绩效指标", r"绩效", r"metrics"],
}

# 数值列名模式 —— 自动转为 float 的列（预编译正则，避免每次遍历重复编译）
_NUMERIC_COL_PATTERNS = [
    re.compile(r"可用资金", re.IGNORECASE),
    re.compile(r"总资产", re.IGNORECASE),
    re.compile(r"现金流", re.IGNORECASE),
    re.compile(r"累积净值", re.IGNORECASE),
    re.compile(r"当日收益", re.IGNORECASE),
    re.compile(r"当日涨跌", re.IGNORECASE),
    re.compile(r"收益率", re.IGNORECASE),
]


def _find_csv(base_dir: Path, purpose: str) -> Path | None:
    """在目录中按语义目的查找 CSV 文件。

    Args:
        base_dir: 策略目录
        purpose: "nav" | "trade" | "metrics" | ""(任意)
    """
    if not base_dir.is_dir():
        return None

    patterns = _FILE_PATTERNS.get(purpose, [])
    csv_files = sorted(
        f for f in base_dir.iterdir()
        if f.is_file() and f.suffix.lower() == ".csv"
    )

    if patterns:
        for pat in patterns:
            for f in csv_files:
                if re.search(pat, f.name, re.IGNORECASE):
                    return f
    return csv_files[0] if csv_files else None


def _auto_numeric(rows: list[dict]) -> None:
    """自动将数值列转 float（原地修改）。先扫描表头确定数值列，再批量转换。"""
    if not rows:
        return
    # 首行扫描：确定哪些列命中数值模式（使用预编译正则）
    numeric_keys = set()
    for k in rows[0].keys():
        if any(p.search(k) for p in _NUMERIC_COL_PATTERNS):
            numeric_keys.add(k)
    if not numeric_keys:
        return
    # 仅对数值列做 float 转换
    for row in rows:
        for k in numeric_keys:
            v = row.get(k)
            if v is None or v == "" or isinstance(v, (int, float)):
                continue
            s = str(v).strip()
            try:
                row[k] = float(s)
            except (ValueError, TypeError):
                pass


# ===========================================================================
# API: 策略列表
# ===========================================================================

@router.get("/list")
async def list_backtest():
    """列出回测框架输出的所有策略结果。

    数据来源：QUANT_PROJ/backtest/data（stock_daily / stock_minute / future）
    每条策略返回 { name, path, base, files }。
    60 秒缓存，避免频繁扫描文件系统。
    """
    cached_result = _list_cache.get("backtest_list")
    if cached_result is not None:
        return cached_result

    groups = {}
    bt_root = _config._BACKTEST_PROJ_DIR
    if bt_root and bt_root.exists():
        _logger.info("扫描回测目录：%s", bt_root)
        for type_dir in sorted(bt_root.iterdir()):
            if not type_dir.is_dir() or type_dir.name == "param_sweep_results":
                continue
            strategies = _scan_strategy_dirs(type_dir, base="backtest")
            if strategies:
                groups[f"回测_{type_dir.name}"] = strategies
        _logger.info("回测列表扫描完成，共 %d 个分类", len(groups))
    else:
        _logger.warning("回测目录不存在或未配置：bt_root=%s, exists=%s",
                        bt_root, bt_root.exists() if bt_root else False)
        return {"groups": {}, "warning": f"回测目录不存在，请检查配置中 quant_proj 路径（当前：{bt_root}）"}
    if not groups:
        _logger.warning("回测目录为空：bt_root=%s", bt_root)
        return {"groups": {}, "warning": "回测目录为空，请先运行回测生成数据"}
    result = {"groups": groups}
    _list_cache.set("backtest_list", result)
    return result


def _scan_strategy_dirs_uncached(parent: Path, base: str) -> list[dict]:
    """扫描一个分类目录下的所有策略子目录。"""
    result = []
    for strat_dir in sorted(parent.iterdir()):
        if not strat_dir.is_dir():
            continue
        csv_files = sorted(
            f.name for f in strat_dir.iterdir()
            if f.is_file() and f.suffix.lower() == ".csv"
        )
        if not csv_files:
            continue
        rel = to_posix_path(strat_dir, _config._BACKTEST_PROJ_DIR)
        result.append({
            "name": strat_dir.name,
            "path": rel,
            "base": base,
            "files": csv_files,
        })
    return result


def _scan_strategy_dirs(parent: Path, base: str) -> list[dict]:
    cache_key = str(parent.resolve())
    return get_cached(cache_key, _scan_strategy_dirs_uncached, parent, base)


# ===========================================================================
# API: 回测详细数据（通用）
# ===========================================================================

@router.get("/data")
async def get_backtest_data(
    path: str = Query(...),
    base: str = Query(""),
    data_type: str = Query(""),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=10, le=500),
):
    """获取策略详细数据（默认返回交易记录，type 可指定 nav/trade/metrics）。"""
    target = _resolve_dir_or_file(path, base)
    target = _pick_by_type(target, data_type)

    rows = load_csv(target)
    if not rows:
        return {"headers": [], "rows": [], "total": 0, "page": 1, "page_size": page_size}

    total = len(rows)
    start = (page - 1) * page_size
    paged_rows = rows[start:start + page_size]

    headers = list(paged_rows[0].keys()) if paged_rows else []
    _auto_numeric(paged_rows)
    return {
        "headers": headers,
        "rows": paged_rows,
        "total": total,
        "page": page,
        "page_size": page_size,
    }


# ===========================================================================
# API: 合并策略详情（指标 + 净值 + 交易记录）
# ===========================================================================

@router.get("/detail")
async def get_backtest_detail(
    path: str = Query(...),
    base: str = Query(""),
    trade_page: int = Query(1, ge=1),
    trade_page_size: int = Query(30, ge=10, le=500),
    start_date: str | None = Query(None),
    end_date: str | None = Query(None),
    request: Request = None,
):
    """一次返回策略完整详情：绩效指标 + 净值曲线 + 交易记录（分页）。支持日期筛选。"""
    target = _resolve_dir_or_file(path, base)

    # ETag: 基于目录下所有 CSV 文件的 mtime + 分页参数
    etag = None
    search_dir = target if target.is_dir() else target.parent
    csv_mtimes = sorted(
        f.stat().st_mtime for f in search_dir.iterdir()
        if f.is_file() and f.suffix.lower() == ".csv"
    )
    if csv_mtimes:
        etag = f'"{hashlib.md5(f"{csv_mtimes}:{trade_page}:{trade_page_size}:{start_date}:{end_date}".encode()).hexdigest()}"'

    if etag and request:
        if_none_match = request.headers.get("if-none-match", "")
        if if_none_match == etag:
            return Response(status_code=304, content=b"")

    # 净值数据（全量，用于绘图和指标计算）
    nav_rows = []
    nav_file = _find_csv(target, "nav")
    if nav_file:
        nav_rows = load_csv(nav_file)
        _auto_numeric(nav_rows)

    # 交易数据（全量加载用于指标计算，分页切片返回）
    all_trade_rows = []
    trade_file = _find_csv(target, "trade")
    if trade_file:
        all_trade_rows = load_csv(trade_file)

    # 日期筛选
    if start_date or end_date:
        from services.metrics_service import _find_key as _mfk
        date_key = _mfk(all_trade_rows[0] if all_trade_rows else {}, ["交易时间", "时间", "date", "datetime", "日期"]) if all_trade_rows else None
        if date_key:
            filtered_rows = []
            for row in all_trade_rows:
                dt = str(row.get(date_key, ""))[:10]
                if start_date and dt < start_date:
                    continue
                if end_date and dt > end_date:
                    continue
                filtered_rows.append(row)
            all_trade_rows = filtered_rows

    total_trades = len(all_trade_rows)
    start = (trade_page - 1) * trade_page_size
    paged_trade_rows = all_trade_rows[start:start + trade_page_size]
    _auto_numeric(paged_trade_rows)
    trade_headers = list(paged_trade_rows[0].keys()) if paged_trade_rows else []

    # 完整绩效指标：优先使用策略绩效指标.csv，其次实时计算
    perf_metrics = _get_metrics_from_perf_csv(target)
    if perf_metrics:
        # 净值指标仍从 nav_rows 实时计算（更可靠），交易类指标用现成数据
        metrics = calc_full_metrics(nav_rows, None)
        metrics.update(perf_metrics)
    else:
        # 复用已加载的交易数据，避免重复读文件
        trade_rows_for_metrics = all_trade_rows if all_trade_rows else _get_trade_rows_for_metrics(target)
        metrics = calc_full_metrics(nav_rows, trade_rows_for_metrics)

    # 提取所有交易的 PnL 值（用于分布图）：优先结算明细/交易记录中的盈亏
    pnls = []
    trade_rows_for_pnls = all_trade_rows if all_trade_rows else _get_trade_rows_for_metrics(target)
    if trade_rows_for_pnls:
        from services.metrics_service import _find_key as _mfk
        pnl_key = _mfk(trade_rows_for_pnls[0], ["收益", "盈亏", "当日收益", "当日盈亏", "当日涨跌", "pnl", "利润"])
        for row in trade_rows_for_pnls:
            try:
                v = float(row.get(pnl_key, 0))
                if v != 0:
                    pnls.append(v)
            except (ValueError, TypeError):
                pass

    resp = {
        "name": target.name if target.is_dir() else target.stem,
        "path": path,
        "metrics": metrics,
        "nav": {
            "headers": list(nav_rows[0].keys()) if nav_rows else [],
            "rows": nav_rows,
            "total": len(nav_rows),
        },
        "trades": {
            "headers": trade_headers,
            "rows": paged_trade_rows,
            "total": total_trades,
            "page": trade_page,
            "page_size": trade_page_size,
        },
        "pnls": pnls,
    }

    if etag:
        return JSONResponse(
            content=resp,
            headers={"ETag": etag, "Cache-Control": "max-age=60"},
        )
    return resp


# ===========================================================================
# API: 原有绩效指标（5项，保持向后兼容）
# ===========================================================================

@router.get("/metrics")
async def get_backtest_metrics(path: str = Query(...), base: str = Query("")):
    """获取回测绩效指标（原有接口）。"""
    target = _resolve_dir_or_file(path, base)
    metrics_file = _find_csv(target, "metrics") or _find_csv(target, "")
    if not metrics_file:
        return {}

    rows = load_csv(metrics_file)
    if not rows:
        return {}
    return _extract_legacy_metrics(rows)


# ===========================================================================
# API: 资金净值曲线
# ===========================================================================

@router.get("/nav")
async def get_backtest_nav(
    path: str = Query(...),
    base: str = Query(""),
    max_points: int = Query(800, ge=50, le=5000),
):
    """获取资金净值数据（用于绘制折线图），自动降采样至 max_points 点。"""
    target = _resolve_dir_or_file(path, base)
    nav_file = _find_csv(target, "nav")
    if not nav_file:
        return JSONResponse(status_code=404, content={"detail": "未找到净值数据文件"})

    rows = load_csv(nav_file)
    if not rows:
        return {"headers": [], "rows": [], "total": 0}

    headers = list(rows[0].keys())
    _auto_numeric(rows)

    # 降采样：数据点超过 max_points 时均匀抽取
    total = len(rows)
    if total > max_points:
        step = total / max_points
        rows = [rows[min(int(i * step), total - 1)] for i in range(max_points)]

    return {"headers": headers, "rows": rows, "total": len(rows), "downsampled": total > max_points}


# ============================================================================
# API: 回测数据导出 CSV
# ============================================================================

@router.get("/export")
async def export_backtest_csv(
    path: str = Query(...),
    base: str = Query(""),
    data_type: str = Query("trade"),
):
    """导出回测数据为 CSV 文件流。"""
    import io

    target = _resolve_dir_or_file(path, base)
    target = _pick_by_type(target, data_type if data_type else "trade")

    rows = load_csv(target)
    if not rows:
        return JSONResponse(status_code=404, content={"detail": "无数据"})

    output = io.StringIO()
    if rows:
        import csv as _csv
        writer = _csv.DictWriter(output, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)

    filename = f"backtest_{path.replace('/', '_')}_{data_type}.csv"
    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename*=UTF-8''{filename}"},
    )


# ============================================================================
# API: 完整绩效指标（12项）
# ============================================================================

@router.get("/full_metrics")
async def get_full_backtest_metrics(
    path: str = Query(...),
    base: str = Query(""),
    request: Request = None,
):
    """完整的12项回测绩效指标（综合净值/交易记录计算），支持 ETag 缓存。"""
    target = _resolve_dir_or_file(path, base)

    # ETag: 基于目录下所有 CSV 文件的 mtime
    etag = None
    search_dir = target if target.is_dir() else target.parent
    csv_mtimes = sorted(
        f.stat().st_mtime for f in search_dir.iterdir()
        if f.is_file() and f.suffix.lower() == ".csv"
    )
    if csv_mtimes:
        etag = f'"{hashlib.md5(str(csv_mtimes).encode()).hexdigest()}"'

    if etag and request:
        if_none_match = request.headers.get("if-none-match", "")
        if if_none_match == etag:
            return Response(status_code=304, content=b"")

    nav_rows = []
    trade_rows = None

    nav_file = _find_csv(target, "nav")
    if nav_file:
        nav_rows = load_csv(nav_file)

    # 优先使用策略绩效指标.csv，其次实时计算
    perf_metrics = _get_metrics_from_perf_csv(target)
    if perf_metrics:
        result = calc_full_metrics(nav_rows, None)
        result.update(perf_metrics)
    else:
        trade_rows = _get_trade_rows_for_metrics(target)
        result = calc_full_metrics(nav_rows, trade_rows)
    if etag:
        return JSONResponse(
            content=result,
            headers={"ETag": etag, "Cache-Control": "max-age=60"},
        )
    return result


# ===========================================================================
# API: 多策略对比
# ===========================================================================

@router.get("/compare")
async def compare_strategies(paths: list[str] = Query(alias="paths"), bases: list[str] = Query(alias="bases", default=[])):
    """多策略对比：净值叠加图 + 指标表（LRU 缓存 + asyncio 并发加载）。

    GET /api/backtest/compare?paths=p1&paths=p2&bases=backtest&bases=backtest
    """
    # 检查 LRU 缓存
    cache_key = _compare_cache_key(paths, bases)
    cached_result = _compare_cache.get(cache_key)
    if cached_result is not None:
        return cached_result

    async def _load_one_strategy(i: int, p: str) -> dict | None:
        """异步加载单个策略数据（nav + trade 并发读取）。"""
        b = bases[i] if i < len(bases) else ""
        try:
            target = _resolve(p, b)
        except (ValueError, Exception) as exc:
            return None  # 跳过无效路径，不中断其他策略

        nav_file = _find_csv(target, "nav")
        if not nav_file:
            return None

        # 并发加载 nav 和 trade 文件（避免 I/O 阻塞事件循环）
        nav_rows = await asyncio.to_thread(load_csv, nav_file)
        trade_file = _find_csv(target, "trade")
        trade_rows = await asyncio.to_thread(load_csv, trade_file) if trade_file else None

        return {
            "name": target.name,
            "path": p,
            "nav_data": _extract_nav_series(nav_rows),
            "full_metrics": calc_full_metrics(nav_rows, trade_rows),
        }

    # 并发加载所有策略
    tasks = [_load_one_strategy(i, p) for i, p in enumerate(paths)]
    loaded = await asyncio.gather(*tasks)

    results = [r for r in loaded if r is not None]
    skipped_count = len(paths) - len(results)

    resp: dict = {"strategies": results}
    if skipped_count > 0:
        resp["skipped"] = [{"reason": f"共跳过 {skipped_count} 个无效路径"}]

    # 写入 LRU 缓存
    _compare_cache.set(cache_key, resp, _COMPARE_CACHE_TTL)
    return resp


# ===========================================================================
# API: 回测同步（扫描目录 → 批量导入 SQLite）
# ===========================================================================

@router.post("/sync")
async def sync_backtests():

    """扫描回测根目录，列出所有策略及其绩效指标。

    直接从文件系统读取，不导入数据库。
    """

    bt_root = _config._BACKTEST_PROJ_DIR
    if not bt_root:
        return JSONResponse(
            status_code=500,
            content={"detail": f"回测目录未配置（quant_proj 未设置），当前值：{bt_root}"},
        )
    if not bt_root.exists():
        return JSONResponse(
            status_code=400,
            content={"detail": f"回测目录不存在: {bt_root}"},
        )

    result = scan_backtest_data(bt_dir=bt_root)
    errors = [r for r in result if "error" in r]
    return {
        "scanned": len(result),
        "errors": len(errors),
        "strategies": result,
        "root": str(bt_root),
    }


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------

def _resolve_dir_or_file(path: str, base: str) -> Path:
    """解析路径并确保指向存在的目录或文件。"""
    try:
        target = _resolve(path, base)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if target.is_file() or target.is_dir():
        return target
    raise HTTPException(status_code=400, detail=f"路径不存在: {path}")


def _pick_by_type(target: Path, type_hint: str) -> Path:
    """根据 type 参数从目录中挑选目标文件。"""
    if target.is_file():
        return target
    if not target.is_dir():
        raise HTTPException(status_code=400, detail=f"不是有效目录: {target}")

    if type_hint:
        found = _find_csv(target, type_hint)
        if found:
            return found
        raise HTTPException(status_code=404, detail=f"目录中未找到类型为 '{type_hint}' 的数据文件")

    # 默认：优先交易记录，否则第一个 CSV
    found = _find_csv(target, "trade") or _find_csv(target, "")
    if not found:
        raise HTTPException(status_code=404, detail=f"目录中未找到 CSV 数据文件: {target}")
    return found


def _extract_legacy_metrics(rows: list[dict]) -> dict:
    """从 CSV 行中提取旧版 5+ 项指标（保持 /metrics 兼容）。"""
    last = rows[-1] if rows else {}

    key_map = {
        "累积净值": ["累积净值"],
        "年化收益": ["年化收益"],
        "最大回撤": ["最大回撤"],
        "年化收益/回撤比": ["年化收益/回撤比", "收益回撤比"],
        "胜率": ["胜率"],
        "盈亏收益比": ["盈亏收益比"],
        "总交易次数": ["总交易次数"],
        "盈利次数": ["盈利次数"],
        "亏损次数": ["亏损次数"],
    }

    metrics = {}
    for std_key, aliases in key_map.items():
        for alias in aliases:
            if alias in last and last[alias]:
                val = _parse_value(last[alias])
                if val is not None:
                    metrics[std_key] = round(val, 4) if isinstance(val, float) else val
                    break
        # 如果最后一行没找到，遍历所有行
        if std_key not in metrics:
            for row in rows:
                for alias in aliases:
                    if alias in row and row[alias]:
                        val = _parse_value(row[alias])
                        if val is not None:
                            metrics[std_key] = round(val, 4) if isinstance(val, float) else val
                            break
                if std_key in metrics:
                    break
    return metrics


def _get_trade_rows_for_metrics(target: Path) -> list[dict] | None:
    """加载用于计算交易类指标的数据行。优先交易记录（含盈亏），其次结算明细。"""
    trade_file = _find_csv(target, "trade")
    if trade_file:
        rows = load_csv(trade_file)
        if rows:
            from services.metrics_service import _find_key
            pnl_key = _find_key(rows[0], ["收益", "盈亏", "当日收益", "当日盈亏", "当日涨跌", "pnl", "利润"])
            if pnl_key:
                return rows

    # 交易记录没有盈亏列，尝试结算明细
    if target.is_dir():
        for f in sorted(target.iterdir()):
            if f.is_file() and f.suffix.lower() == ".csv" and re.search(r"结算明细", f.name):
                rows = load_csv(f)
                if rows:
                    return rows

    # 兜底：返回交易记录（即使无盈亏列）
    if trade_file:
        return load_csv(trade_file)
    return None


def _get_metrics_from_perf_csv(target: Path) -> dict | None:
    """尝试从策略绩效指标.csv读取现成指标。"""
    if not target.is_dir():
        return None
    for f in sorted(target.iterdir()):
        if f.is_file() and f.suffix.lower() == ".csv" and re.search(r"绩效指标", f.name):
            rows = load_csv(f)
            if rows:
                return _extract_perf_metrics(rows)
    return None


def _extract_perf_metrics(rows: list[dict]) -> dict | None:
    """从策略绩效指标.csv提取指标，映射到统一键名。"""
    if not rows:
        return None
    last = rows[-1]

    # 字段映射: 统一键名 -> 可能的CSV列名
    key_map = {
        "累积净值":       ["累积净值"],
        "年化收益率":     ["年化收益"],
        "最大回撤":       ["最大回撤"],
        "胜率":           ["胜率"],
        "盈亏比":         ["盈亏收益比"],
        "总交易次数":     ["总交易次数"],
        "最大连续亏损":   ["最大连续亏损次数"],
        "最大连续盈利":   ["最大连续盈利次数"],
    }

    metrics = {}
    for std_key, aliases in key_map.items():
        for alias in aliases:
            if alias in last and last[alias]:
                val = _parse_value(last[alias])
                if val is not None:
                    metrics[std_key] = round(val, 4) if isinstance(val, float) else val
                    break

    # 总交易次数 = 盈利次数 + 亏损次数（CSV 中通常没有直接的总次数列）
    if "总交易次数" not in metrics:
        win_count = _parse_value(last.get("盈利次数"))
        loss_count = _parse_value(last.get("亏损次数"))
        if win_count is not None and loss_count is not None:
            metrics["总交易次数"] = int(win_count + loss_count)

    # 最大连续亏损/盈利：绩效指标 CSV 中是"次数"（笔数），而结算明细实时计算的是"金额"（元）。
    # 为避免语义混淆，不映射 CSV 中的"次数"，让这两个指标由结算明细/交易记录计算（金额）。
    metrics.pop("最大连续亏损", None)
    metrics.pop("最大连续盈利", None)

    return metrics if metrics else None


def _extract_nav_series(rows: list[dict]) -> list[dict]:
    """提取 (date, value) 序列用于绘图。"""
    if not rows:
        return []

    first = rows[0]
    time_key = next((k for k in first if any(p.search(k) for p in _TIME_CANDIDATES_RE)), None)
    value_key = next((k for k in first if any(p.search(k) for p in _VALUE_CANDIDATES_RE)), None)

    result = []
    for row in rows:
        dv = row.get(time_key, "") if time_key else ""
        val = _to_float(row.get(value_key))
        if dv and val > 0:
            result.append({"date": str(dv)[:10], "value": val})
    return result


def _to_float(v, default=0.0) -> float:
    try:
        return float(v)
    except (TypeError, ValueError):
        return default


def _parse_value(v) -> float | None:
    """解析数值字符串（处理尾部百分号、空值等）。"""
    if v is None:
        return None
    s = str(v).strip().rstrip("%")
    try:
        return float(s)
    except (ValueError, TypeError):
        return None

# ===========================================================================
# API: 个股买卖点（用于 K 线叠加标注）
# ===========================================================================

@router.get("/trades_by_stock")
async def get_trades_by_stock(
    path: str = Query(...),
    base: str = Query(""),
    stock_code: str = Query(...),
    page: int = Query(1, ge=1),
    page_size: int = Query(200, ge=10, le=500),
):
    """获取某个策略中指定股票的买卖记录，用于 K 线上标注买卖点。
    
    返回格式:
    {
        "stock_code": "sh601318",
        "trades": [
            {"date": "2020-01-02", "action": "买", "price": 41.59, "volume": 4800, ...},
            {"date": "2020-01-08", "action": "卖", "price": 43.12, "volume": 4800, ...},
        ],
        "buy_count": 5,
        "sell_count": 5,
    }
    """
    target = _resolve_dir_or_file(path, base)
    trade_file = _find_csv(target, "trade")
    if not trade_file:
        return JSONResponse(status_code=404, content={"detail": "未找到交易记录"})
    
    all_rows = load_csv(trade_file)
    if not all_rows:
        return {"stock_code": stock_code, "trades": [], "buy_count": 0, "sell_count": 0}
    
    # 标准化 stock_code: 去掉前缀/后缀统一比较
    _EXCHANGE_PREFIXES = ("sh", "sz", "bj")

    def _strip_prefix_suffix(c: str) -> str:
        s = c.strip().lower()
        for p in _EXCHANGE_PREFIXES:
            if s.startswith(p):
                s = s.removeprefix(p)
                break
        for p in _EXCHANGE_PREFIXES:
            if s.endswith(f".{p}"):
                s = s.removesuffix(f".{p}")
                break
        return s

    def _norm_code(c):
        return str(c).strip().lower()

    norm_target = _norm_code(stock_code)
    norm_target_core = _strip_prefix_suffix(stock_code)

    # 查找代码列名
    from services.metrics_service import _find_key as _mfk
    code_key = _mfk(all_rows[0], ["股票代码", "代码", "code", "证券代码"])
    action_key = _mfk(all_rows[0], ["交易动作", "动作", "action", "买卖", "方向"])
    date_key = _mfk(all_rows[0], ["交易时间", "时间", "date", "datetime", "日期"])
    price_key = _mfk(all_rows[0], ["价格", "成交价", "price", "买入价", "卖出价"])
    vol_key = _mfk(all_rows[0], ["成交量", "数量", "volume", "vol"])
    amount_key = _mfk(all_rows[0], ["成交额", "金额", "amount"])
    name_key = _mfk(all_rows[0], ["股票名称", "名称", "name"])

    if not code_key:
        return {"stock_code": stock_code, "trades": [], "buy_count": 0, "sell_count": 0}

    # 过滤该股票的交易
    stock_trades = []
    for row in all_rows:
        row_code = _norm_code(row.get(code_key, ""))
        row_code_core = _strip_prefix_suffix(row_code)
        if (
            row_code == norm_target
            or row_code.endswith(norm_target)
            or norm_target.endswith(row_code)
            or row_code_core == norm_target_core
        ):
            trade = {
                "date": str(row.get(date_key, ""))[:10],
                "action": str(row.get(action_key, "")),
                "price": _to_float(row.get(price_key)),
                "volume": _to_float(row.get(vol_key)),
                "amount": _to_float(row.get(amount_key)),
            }
            if name_key:
                trade["name"] = str(row.get(name_key, ""))
            stock_trades.append(trade)

    buy_count = sum(1 for t in stock_trades if "买" in t["action"])
    sell_count = sum(1 for t in stock_trades if "卖" in t["action"])
    
    return {
        "stock_code": stock_code,
        "trades": stock_trades,
        "buy_count": buy_count,
        "sell_count": sell_count,
    }


@router.get("/trade_stocks")
async def get_trade_stocks(
    path: str = Query(...),
    base: str = Query(""),
):
    """获取某个策略交易过的所有股票代码列表（去重），用于前端选择股票查看买卖点。"""
    target = _resolve_dir_or_file(path, base)
    trade_file = _find_csv(target, "trade")
    if not trade_file:
        return {"stocks": []}
    
    all_rows = load_csv(trade_file)
    if not all_rows:
        return {"stocks": []}
    
    from services.metrics_service import _find_key as _mfk
    code_key = _mfk(all_rows[0], ["股票代码", "代码", "code", "证券代码"])
    name_key = _mfk(all_rows[0], ["股票名称", "名称", "name"])
    action_key = _mfk(all_rows[0], ["交易动作", "动作", "action"])
    
    if not code_key:
        return {"stocks": []}
    
    # 统计每只股票的买卖次数
    stock_map = {}
    for row in all_rows:
        code = str(row.get(code_key, "")).strip()
        if not code:
            continue
        name = str(row.get(name_key, "")) if name_key else ""
        action = str(row.get(action_key, "")) if action_key else ""
        
        if code not in stock_map:
            stock_map[code] = {"code": code, "name": name, "buy_count": 0, "sell_count": 0, "trade_count": 0}
        
        stock_map[code]["trade_count"] += 1
        if "买" in action:
            stock_map[code]["buy_count"] += 1
        elif "卖" in action:
            stock_map[code]["sell_count"] += 1
    
    # 按交易次数降序排列
    stocks = sorted(stock_map.values(), key=lambda x: x["trade_count"], reverse=True)
    return {"stocks": stocks}
