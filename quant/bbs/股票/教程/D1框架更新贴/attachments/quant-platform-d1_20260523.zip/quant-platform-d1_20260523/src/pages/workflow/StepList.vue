<template>
  <div class="step-list">
    <!-- 步骤卡片列表 -->
    <TransitionGroup
      name="step-list__transition"
      tag="div"
      class="step-list__items"
    >
      <div
        v-for="(step, index) in steps"
        :key="step.id"
        class="step-card"
        :class="[
          `step-card--${statusMap[step.id] || 'idle'}`,
          { 'step-card--selected': step.id === selectedId },
          { 'step-card--drag-over': dragOverIndex === index },
        ]"
        draggable
        @dragstart="onDragStart($event, index)"
        @dragover="onDragOver($event, index)"
        @dragleave="onDragLeave"
        @drop="onDrop($event, index)"
        @dragend="onDragEnd"
        @click="$emit('select', step.id)"
      >
        <!-- 拖拽手柄 -->
        <div
          class="step-card__handle"
          title="拖拽排序"
        >
          <el-icon :size="14">
            <Rank />
          </el-icon>
        </div>

        <!-- 状态圆点 -->
        <span
          class="step-card__dot"
          :class="`step-card__dot--${statusMap[step.id] || 'idle'}`"
        />

        <!-- 序号 -->
        <span class="step-card__index">{{ index + 1 }}</span>

        <!-- 图标 -->
        <span class="step-card__icon">
          {{ step.icon || '\u{1F4CB}' }}
        </span>

        <!-- 名称与状态 -->
        <div class="step-card__body">
          <span class="step-card__name">{{ step.name }}</span>
          <span
            class="step-card__status"
            :class="`step-card__status--${statusMap[step.id] || 'idle'}`"
          >
            {{ statusLabel(statusMap[step.id]) }}
          </span>
        </div>

        <!-- 操作按钮组（hover 显示） -->
        <div class="step-card__actions">
          <el-icon
            v-if="statusMap[step.id] === 'done' && !running"
            class="step-card__action"
            title="从此步骤重新运行"
            @click.stop="$emit('rerun-from', index)"
          >
            <RefreshRight />
          </el-icon>
          <el-icon
            v-if="!running"
            class="step-card__action"
            title="复制步骤"
            @click.stop="clipboard = { ...step, params: step.params ? { ...step.params } : {} }"
          >
            <CopyDocument />
          </el-icon>
          <el-icon
            v-if="!running"
            class="step-card__action step-card__action--delete"
            @click.stop="$emit('delete', step.id)"
          >
            <Close />
          </el-icon>
        </div>

        <!-- 进度条（运行中） -->
        <div
          v-if="statusMap[step.id] === 'running' && progressMap?.[step.id] != null"
          class="step-card__progress"
        >
          <div
            class="step-card__progress-bar"
            :style="{ width: `${progressMap[step.id]}%` }"
          />
        </div>
      </div>
    </TransitionGroup>

    <!-- 空状态 -->
    <div
      v-if="!steps.length"
      class="step-list__empty"
    >
      <span>暂无步骤，点击下方按钮添加</span>
    </div>

    <!-- 添加步骤按钮 -->
    <div
      v-if="!running"
      class="step-list__footer"
    >
      <el-button
        size="small"
        @click="$emit('open-picker')"
      >
        <el-icon><Plus /></el-icon>
        添加步骤
      </el-button>
      <el-button
        v-if="clipboard"
        size="small"
        type="info"
        @click="handlePaste"
      >
        <el-icon><DocumentCopy /></el-icon>
        粘贴: {{ clipboard.name }}
      </el-button>
    </div>
  </div>
</template>

<script setup lang="ts">
import type { WorkflowStep } from '@/types'

const props = defineProps<{
  steps: WorkflowStep[]
  statusMap: Record<string, string>
  progressMap?: Record<string, number>
  running: boolean
  selectedId?: string
}>()

const emit = defineEmits<{
  select: [id: string]
  delete: [id: string]
  'open-picker': []
  'rerun-from': [index: number]
  'paste-step': [step: WorkflowStep]
  reorder: [steps: WorkflowStep[]]
}>()

const clipboard = ref<WorkflowStep | null>(null)

// --- 拖拽排序 ---
const dragIndex = ref<number | null>(null)
const dragOverIndex = ref<number | null>(null)

function onDragStart(_e: DragEvent, index: number) {
  dragIndex.value = index
}

function onDragOver(e: DragEvent, index: number) {
  e.preventDefault()
  dragOverIndex.value = index
}

function onDragLeave() {
  dragOverIndex.value = null
}

function onDrop(_e: DragEvent, dropIndex: number) {
  const from = dragIndex.value
  if (from === null || from === dropIndex) {
    resetDragState()
    return
  }
  const reordered = [...props.steps]
  const [moved] = reordered.splice(from, 1)
  reordered.splice(dropIndex, 0, moved)
  emit('reorder', reordered)
  resetDragState()
}

function onDragEnd() {
  resetDragState()
}

function resetDragState() {
  dragIndex.value = null
  dragOverIndex.value = null
}

// --- 粘贴步骤 ---
function handlePaste() {
  if (!clipboard.value) return
  emit('paste-step', { ...clipboard.value, params: clipboard.value.params ? { ...clipboard.value.params } : {} })
}

// --- 状态标签 ---
function statusLabel(status?: string): string {
  switch (status) {
    case 'running':
      return '运行中'
    case 'done':
      return '已完成'
    case 'failed':
      return '失败'
    case 'skipped':
      return '已跳过'
    default:
      return '等待中'
  }
}
</script>

<style scoped>
.step-list {
  display: flex;
  flex-direction: column;
  gap: 0;
  padding: 12px;
}

.step-list__items {
  display: flex;
  flex-direction: column;
  gap: 0;
}

.step-list__empty {
  text-align: center;
  padding: 32px 0;
  color: var(--text-muted);
  font-size: 13px;
}

.step-list__footer {
  display: flex;
  justify-content: center;
  padding-top: 8px;
}

/* ---- 步骤卡片 ---- */
.step-card {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 12px 10px 0;
  border-radius: var(--radius);
  border: 1px solid transparent;
  background: var(--bg-secondary);
  cursor: pointer;
  transition: background 0.2s, border-color 0.2s, box-shadow 0.2s;
  position: relative;
  user-select: none;
  margin-bottom: 2px;
}

.step-card:hover {
  background: var(--bg-tertiary);
  border-color: var(--border);
}

.step-card:hover .step-card__actions {
  opacity: 1;
}

.step-card--selected {
  border-color: var(--accent);
  box-shadow: 0 0 0 1px var(--accent-dim);
}

.step-card--drag-over {
  border-color: var(--accent);
  background: var(--accent-dim);
  transform: scale(1.01);
}

/* 状态样式 — 通过圆点表达 */
.step-card--running {
  background: var(--bg-secondary);
}

.step-card--done {
  background: var(--bg-secondary);
}

.step-card--failed {
  background: var(--bg-secondary);
}

.step-card--skipped {
  opacity: 0.5;
}

/* ---- 状态圆点 ---- */
.step-card__dot {
  width: 8px;
  height: 8px;
  border-radius: 50%;
  flex-shrink: 0;
  background: var(--text-muted);
  margin-left: 12px;
  transition: all 0.2s ease;
}

.step-card__dot--idle { background: var(--text-muted); }
.step-card__dot--running {
  background: var(--accent);
  box-shadow: 0 0 6px var(--accent);
  animation: dot-pulse 1.5s ease-in-out infinite;
}
.step-card__dot--done { background: var(--success); }
.step-card__dot--failed { background: var(--error); }
.step-card__dot--skipped { background: var(--text-muted); opacity: 0.5; }

@keyframes dot-pulse {
  0%, 100% { box-shadow: 0 0 0 0 rgba(124, 110, 245, 0.4); }
  50% { box-shadow: 0 0 8px 2px rgba(124, 110, 245, 0.3); }
}

/* ---- 拖拽手柄 ---- */
.step-card__handle {
  display: flex;
  align-items: center;
  color: var(--text-muted);
  cursor: grab;
  flex-shrink: 0;
  opacity: 0.3;
  transition: opacity 0.2s;
}

.step-card:hover .step-card__handle {
  opacity: 0.7;
}

.step-card__handle:active {
  cursor: grabbing;
}

/* ---- 序号 ---- */
.step-card__index {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: var(--radius-xs);
  background: var(--bg-elevated);
  color: var(--text-muted);
  font-size: 10px;
  font-weight: 600;
  flex-shrink: 0;
  transition: all 0.2s ease;
}

.step-card--running .step-card__index {
  background: var(--accent);
  color: white;
}

.step-card--done .step-card__index {
  background: rgba(0, 200, 122, 0.15);
  color: var(--success);
}

.step-card--failed .step-card__index {
  background: rgba(255, 77, 94, 0.15);
  color: var(--error);
}

/* ---- 图标 ---- */
.step-card__icon {
  font-size: 16px;
  flex-shrink: 0;
  line-height: 1;
}

/* ---- 名称与状态 ---- */
.step-card__body {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.step-card__name {
  font-size: 13px;
  font-weight: 500;
  color: var(--text-primary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.step-card__status {
  font-size: 11px;
  color: var(--text-muted);
}

.step-card__status--idle { color: var(--text-muted); }
.step-card__status--running { color: var(--accent); }
.step-card__status--done { color: var(--success); }
.step-card__status--failed { color: var(--error); }
.step-card__status--skipped { color: var(--text-muted); }

/* ---- 操作按钮组（hover 显示） ---- */
.step-card__actions {
  display: flex;
  gap: 2px;
  opacity: 0;
  transition: opacity 0.2s;
  flex-shrink: 0;
  margin-right: 4px;
}

.step-card__action {
  color: var(--text-muted);
  font-size: 14px;
  transition: color 0.2s;
  cursor: pointer;
}

.step-card__action:hover {
  color: var(--accent);
}

.step-card__action--delete:hover {
  color: var(--error);
}

/* 运行中隐藏操作 */
.step-card--running .step-card__actions {
  opacity: 0;
  pointer-events: none;
}

/* ---- 进度条覆盖层 ---- */
.step-card__progress {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 3px;
  background: var(--bg-hover);
  border-radius: 0 0 var(--radius) var(--radius);
  overflow: hidden;
}

.step-card__progress-bar {
  height: 100%;
  background: var(--accent);
  transition: width 0.3s ease;
}

/* ---- 连接线 ---- */
.step-card::before {
  content: '';
  position: absolute;
  left: 19px;
  top: -2px;
  bottom: -2px;
  width: 1px;
  background: var(--border);
}

.step-card:first-child::before {
  top: 50%;
}

.step-card:last-child::before {
  bottom: 50%;
}

.step-card:only-child::before {
  display: none;
}

/* 已完成步骤连接线变绿 */
.step-card--done + .step-card::before {
  background: var(--success);
  opacity: 0.3;
}

/* ---- 列表过渡动画 ---- */
.step-list__transition-enter-active,
.step-list__transition-leave-active {
  transition: all 0.25s ease;
}

.step-list__transition-enter-from {
  opacity: 0;
  transform: translateY(-8px);
}

.step-list__transition-leave-to {
  opacity: 0;
  transform: translateX(16px);
}

.step-list__transition-move {
  transition: transform 0.25s ease;
}
</style>
