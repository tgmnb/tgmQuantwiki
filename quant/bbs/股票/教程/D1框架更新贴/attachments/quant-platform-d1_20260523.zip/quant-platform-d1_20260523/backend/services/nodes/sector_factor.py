from . import register_node

register_node({
    "id": "sector_factor",
    "type": "atomic",
    "name": "\u677f\u5757\u56e0\u5b50\u5206\u6790",
    "description": "\u8ba1\u7b97\u677f\u5757\u56e0\u5b50\uff08\u884c\u4e1a\u56e0\u5b50\u5206\u6790\uff09",
    "icon": "icon-factor",
    "category": "\u56e0\u5b50",
    "slots_in": [
        {
            "id": "factor_data",
            "name": "\u56e0\u5b50\u6570\u636e",
            "type": "file",
            "required": False,
            "ui": {"widget": "hidden"},
        },
    ],
    "slots_out": [
        {"id": "sector_factor_data", "name": "\u677f\u5757\u56e0\u5b50\u6570\u636e", "type": "file"},
    ],
    "params": [
        {
            "id": "factor_to_calc",
            "name": "\u6307\u5b9a\u56e0\u5b50",
            "type": "list[str]",
            "default": None,
            "required": False,
            "ui": {"widget": "tag_input", "placeholder": "\u8f93\u5165\u56e0\u5b50\u540d\u79f0"},
        },
    ],
    "script": "workflow/\u56e0\u5b50\u8ba1\u7b97_\u677f\u5757.py",
    "func": "\u56e0\u5b50\u8ba1\u7b97_\u677f\u5757",
    "conda_env": "quantpy312",
})
