# -*- coding: utf-8 -*-
"""Workflow storage module - JSON file CRUD, caching, and lookup utilities."""
from __future__ import annotations

import hashlib
import json
import logging
import os
import time
import uuid
from pathlib import Path
from typing import Optional

from filelock import FileLock

import config as _config

logger = logging.getLogger("quant.workflow_storage")

_wf_list_cache = {"data": None, "file_hashes": {}}

_NODE_TO_ATOMIC_WF = {
    "factor_compute": "factor",
    "factor_financial": "factor",
    "stock_select": "select",
    "backtest_daily_single": "backtest_daily",
    "backtest_daily_account": "backtest_account",
    "backtest_hourly_single": "backtest_1h",
    "backtest_hourly_account": "backtest_account",
    "index_synthesis": "index_synthesis",
    "export_results": "export_results",
    "display_results": "display_results",
    "fetch_market_data": "fetch_market_data",
}


def _workflows_dir():
    qp = _config.QUANT_PROJ
    if not qp:
        return None
    d = qp / "workflows"
    d.mkdir(parents=True, exist_ok=True)
    return d


def _get_proj_dir():
    """Get project directory."""
    qp = _config.QUANT_PROJ
    if not qp:
        raise RuntimeError("quant_proj not configured")
    return qp


def _node_to_atomic_wf(node_id: str, node_def: dict) -> dict:
    wf_id = _NODE_TO_ATOMIC_WF.get(node_id, node_id)
    return {
        "id": wf_id,
        "name": node_def.get("name", node_id),
        "description": node_def.get("description", ""),
        "category": node_def.get("category", ""),
        "icon": node_def.get("icon", ""),
        "script": node_def.get("script", ""),
        "conda_env": node_def.get("conda_env", "quantpy312"),
        "node_type": node_id,
        "params": node_def.get("params", []),
        "steps": [],
        "created_at": 0,
        "updated_at": 0,
    }


def _default_workflows() -> list:
    from services.nodes import NODE_REGISTRY

    seen_wf_ids = set()
    atomic_workflows = []
    for node_id, node_def in NODE_REGISTRY.items():
        if node_def.get("type") == "tool":
            continue
        wf = _node_to_atomic_wf(node_id, node_def)
        if wf["id"] not in seen_wf_ids:
            seen_wf_ids.add(wf["id"])
            atomic_workflows.append(wf)

    pipeline_workflows = [
        {
            "id": "daily",
            "name": "日频回测",
            "description": "因子计算 → 选股 → 日频回测",
            "category": "回测",
            "icon": "icon-backtest",
            "steps": [
                {"id": "factor", "name": "因子计算", "icon": "icon-factor", "node_type": "factor_compute", "script": "", "conda_env": "quantpy312", "params": {}},
                {"id": "select", "name": "选股", "icon": "icon-strategy", "node_type": "stock_select", "script": "", "conda_env": "quantpy312", "params": {}},
                {"id": "backtest_daily", "name": "日频单策略回测", "icon": "icon-backtest", "node_type": "backtest_daily_single", "script": "", "conda_env": "quantpy312", "params": {}},
            ],
            "created_at": 0,
            "updated_at": 0,
        },
        {
            "id": "hourly",
            "name": "小时回测",
            "description": "因子计算 → 选股 → 小时回测",
            "category": "回测",
            "icon": "icon-chart",
            "steps": [
                {"id": "factor", "name": "因子计算", "icon": "icon-factor", "node_type": "factor_compute", "script": "", "conda_env": "quantpy312", "params": {}},
                {"id": "select", "name": "选股", "icon": "icon-strategy", "node_type": "stock_select", "script": "", "conda_env": "quantpy312", "params": {}},
                {"id": "backtest_1h", "name": "小时单策略回测", "icon": "icon-chart", "node_type": "backtest_hourly_single", "script": "", "conda_env": "quantpy312", "params": {}},
            ],
            "created_at": 0,
            "updated_at": 0,
        },
        {
            "id": "account",
            "name": "完整账户回测",
            "description": "因子计算 → 选股 → 账户回测",
            "category": "回测",
            "icon": "icon-dashboard",
            "steps": [
                {"id": "factor", "name": "因子计算", "icon": "icon-factor", "node_type": "factor_compute", "script": "", "conda_env": "quantpy312", "params": {}},
                {"id": "select", "name": "选股", "icon": "icon-strategy", "node_type": "stock_select", "script": "", "conda_env": "quantpy312", "params": {}},
                {"id": "backtest_account", "name": "账户回测", "icon": "icon-dashboard", "node_type": "backtest_daily_account", "script": "", "conda_env": "quantpy312", "params": {}},
            ],
            "created_at": 0,
            "updated_at": 0,
        },
    ]
    return atomic_workflows + pipeline_workflows


def list_templates() -> list:
    """返回可用的预设模板列表（仅 pipeline 类型，不含原子节点）。"""
    templates = []
    for wf in _default_workflows():
        if wf.get("steps"):
            templates.append({
                "id": wf["id"],
                "name": wf["name"],
                "description": wf["description"],
                "category": wf.get("category", ""),
                "icon": wf.get("icon", ""),
                "steps": wf["steps"],
            })
    return templates


def _migrate_legacy_workflow(wf: dict) -> dict:
    """将旧格式工作流迁移为线性格式。"""
    if "type" not in wf:
        return wf

    if "category" not in wf:
        wf["category"] = _infer_category(wf)

    for step in wf.get("steps", []):
        step.pop("deps", None)
        step.pop("type", None)
        step.pop("enabled", None)
        step.setdefault("params", {})
        step.setdefault("script", "")
        step.setdefault("conda_env", "quantpy312")

    wf.pop("type", None)
    return wf


def _infer_category(wf: dict) -> str:
    """根据步骤内容推断分类。"""
    steps = wf.get("steps", [])
    node_types = [s.get("node_type", "") for s in steps]
    if any("backtest" in nt for nt in node_types):
        return "回测"
    if any("factor" in nt for nt in node_types):
        return "因子"
    if any("select" in nt or "stock" in nt for nt in node_types):
        return "选股"
    return "综合"


def _filter_workflows(workflows: list, category: Optional[str]) -> list:
    if category is None:
        return workflows
    filtered = [w for w in workflows if w.get("category") == category]
    return filtered


def list_workflows(category: Optional[str] = None) -> list:
    """Return all saved workflows (without step details)."""
    d = _workflows_dir()
    if not d:
        return _filter_workflows(_default_workflows(), category)

    current_hashes = {}
    for f in d.glob("*.json"):
        try:
            current_hashes[f.name] = hashlib.md5(f.read_bytes()).hexdigest()
        except OSError:
            continue

    if _wf_list_cache["data"] is not None and current_hashes == _wf_list_cache.get("file_hashes", {}):
        return _filter_workflows(_wf_list_cache["data"], category)

    workflows = []
    for f in d.glob("*.json"):
        try:
            with open(f, "r", encoding="utf-8") as fh:
                wf = json.load(fh)
                wf = _migrate_legacy_workflow(wf)
                workflows.append({
                    "id": wf.get("id"),
                    "name": wf.get("name"),
                    "description": wf.get("description"),
                    "category": wf.get("category", ""),
                    "icon": wf.get("icon"),
                    "script": wf.get("script"),
                    "conda_env": wf.get("conda_env"),
                    "steps_count": len(wf.get("steps", [])),
                    "created_at": wf.get("created_at"),
                    "updated_at": wf.get("updated_at"),
                })
        except Exception:
            continue

    if not workflows:
        return _filter_workflows(_default_workflows(), category)

    result = sorted(workflows, key=lambda w: w.get("updated_at", 0), reverse=True)
    _wf_list_cache["data"] = result
    _wf_list_cache["file_hashes"] = current_hashes
    return _filter_workflows(result, category)


def get_workflow(wf_id: str) -> Optional[dict]:
    """Return full workflow content (including steps)."""
    d = _workflows_dir()
    if not d:
        defaults = _default_workflows()
        return next((w for w in defaults if w["id"] == wf_id), None)

    fpath = d / f"{wf_id}.json"
    if fpath.exists():
        with open(fpath, "r", encoding="utf-8") as f:
            wf = json.load(f)
        return _migrate_legacy_workflow(wf)

    defaults = _default_workflows()
    return next((w for w in defaults if w["id"] == wf_id), None)


def get_workflows_batch(ids: list[str]) -> dict[str, dict]:
    results = {}
    for wf_id in ids:
        wf = get_workflow(wf_id)
        if wf:
            results[wf_id] = wf
    return results


def create_workflow(name: str, description: str = "", category: str = "",
                    steps: list = None, script: str = "", conda_env: str = "quantpy312") -> dict:
    """Create a new workflow."""
    d = _workflows_dir()
    if not d:
        raise RuntimeError("quant_proj not configured")

    wf_id = uuid.uuid4().hex[:12]
    now = time.time()
    wf = {
        "id": wf_id,
        "name": name,
        "description": description,
        "category": category,
        "steps": steps or [],
        "script": script,
        "conda_env": conda_env,
        "created_at": now,
        "updated_at": now,
    }
    fpath = d / f"{wf_id}.json"
    with open(fpath, "w", encoding="utf-8") as f:
        json.dump(wf, f, ensure_ascii=False, indent=2)
    _wf_list_cache["data"] = None
    return wf


def save_workflow(wf_id: str, data: dict) -> dict:
    """Save workflow content (name/description/category/steps/script)."""
    d = _workflows_dir()
    if not d:
        raise RuntimeError("quant_proj not configured")

    fpath = d / f"{wf_id}.json"
    now = time.time()

    lock_path = fpath.with_suffix('.json.lock')
    with FileLock(str(lock_path)):
        if fpath.exists():
            with open(fpath, "r", encoding="utf-8") as f:
                existing = json.load(f)
        else:
            existing = {"id": wf_id, "created_at": now}
            defaults = _default_workflows()
            default_wf = next((w for w in defaults if w["id"] == wf_id), None)
            if default_wf:
                existing["name"] = default_wf.get("name", "")
                existing["description"] = default_wf.get("description", "")
                existing["steps"] = default_wf.get("steps", [])
                existing["script"] = default_wf.get("script", "")

        existing["name"] = data.get("name", existing.get("name", ""))
        existing["description"] = data.get("description", existing.get("description", ""))
        existing["category"] = data.get("category", existing.get("category", ""))

        if data.get("steps") is not None:
            steps = data["steps"]
            for s in steps:
                if not isinstance(s, dict):
                    raise ValueError("each step must be an object")
                if "id" not in s:
                    raise ValueError("each step must have id")
            existing["steps"] = steps

        if data.get("script") is not None:
            existing["script"] = data["script"]
        if data.get("conda_env") is not None:
            existing["conda_env"] = data["conda_env"]

        existing["updated_at"] = now
        with open(fpath, "w", encoding="utf-8") as f:
            json.dump(existing, f, ensure_ascii=False, indent=2)
    _wf_list_cache["data"] = None
    return existing


def delete_workflow(wf_id: str) -> bool:
    """Delete a workflow and its associated data (runs, logs, in-memory state)."""
    d = _workflows_dir()
    if not d:
        return False
    fpath = d / f"{wf_id}.json"
    if not fpath.exists():
        return False

    # Query run records BEFORE deleting from DB (to get log file paths)
    runs = []
    try:
        from services import db_service
        runs = db_service.list_workflow_runs(wf_id, limit=100)
    except Exception as e:
        logger.warning("Failed to list workflow runs for %s: %s", wf_id, e)

    # Delete associated log files using queried runs
    proj_dir = _get_proj_dir()
    log_dir = proj_dir / "workflow_logs"
    if log_dir.exists():
        try:
            for run in runs:
                log_file = log_dir / f"{run['run_id']}.log"
                if log_file.exists():
                    log_file.unlink()
        except Exception as e:
            logger.warning("Failed to delete log files for %s: %s", wf_id, e)

    # Now delete DB records
    try:
        from services import db_service
        db_service.delete_workflow_runs(wf_id)
    except Exception as e:
        logger.warning("Failed to delete workflow runs for %s: %s", wf_id, e)

    # Delete the workflow definition file
    fpath.unlink()
    _wf_list_cache["data"] = None

    # Clean up in-memory run state
    from services.workflow_service import _run_states, _states_lock
    with _states_lock:
        if wf_id in _run_states:
            del _run_states[wf_id]

    return True


def find_workflow_by_script(script_name: str):
    """Find workflow ID by script name."""
    all_wfs = list_workflows()
    for wf_summary in all_wfs:
        wf = get_workflow(wf_summary["id"])
        if wf and wf.get("script") == script_name:
            return wf["id"]
    return None


def find_workflow_by_category(category: str):
    """Find workflow IDs by category."""
    # Lazy import to avoid circular dependency at module level
    from services.nodes import NODE_REGISTRY

    all_wfs = list_workflows()
    matched_ids = []
    for wf_summary in all_wfs:
        wf = get_workflow(wf_summary["id"])
        if not wf:
            continue
        node_type = wf.get("node_type")
        if not node_type:
            node_def = NODE_REGISTRY.get(wf.get("script", ""))
            if node_def:
                node_type = node_def.get("category")
        if node_type == category:
            matched_ids.append(wf["id"])
    return matched_ids
