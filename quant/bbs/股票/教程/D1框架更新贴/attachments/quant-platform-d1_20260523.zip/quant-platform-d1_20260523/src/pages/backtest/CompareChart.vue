<template>
  <div class="compare-chart-wrap">
    <div
      class="chart-resize-handle"
      @mousedown.prevent="onResizeStart"
    >
      <div class="chart-resize-dots" />
    </div>
    <div
      ref="chartRef"
      :style="{ height: chartHeight + 'px', width: '100%' }"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch, nextTick } from 'vue';
import type { PropType } from 'vue';
import { getEcharts } from '@/utils/echarts';

interface Strategy { name: string; nav_data?: Array<{ date: string; value: number }>; }
interface CompareData { strategies?: Strategy[]; }

const props = defineProps({ data: { type: Object as PropType<CompareData>, required: true } });
const chartRef = ref<HTMLElement | null>(null);
const chartHeight = ref(280);
let chartInstance: any = null;
let resizeHandler: () => void = () => chartInstance?.resize();

const COLORS = ['#6366f1', '#ef4444', '#22c55e', '#f59e0b', '#8b5cf6', '#06b6d4', '#ec4899'];

// Drag state
let dragging = false;
let startY = 0;
let startH = 0;
const MIN_H = 180;
const MAX_H = 500;

function onResizeStart(e: MouseEvent) {
  dragging = true;
  startY = e.clientY;
  startH = chartHeight.value;
  document.body.style.userSelect = 'none';
  document.body.style.cursor = 'ns-resize';
  window.addEventListener('mousemove', onResizeMove);
  window.addEventListener('mouseup', onResizeEnd);
}

function onResizeMove(e: MouseEvent) {
  if (!dragging) return;
  const delta = e.clientY - startY;
  chartHeight.value = Math.min(MAX_H, Math.max(MIN_H, startH + delta));
  nextTick(() => chartInstance?.resize());
}

function onResizeEnd() {
  if (!dragging) return;
  dragging = false;
  document.body.style.userSelect = '';
  document.body.style.cursor = '';
  window.removeEventListener('mousemove', onResizeMove);
  window.removeEventListener('mouseup', onResizeEnd);
}

async function initChart() {
  if (!chartRef.value || !props.data?.strategies?.length) return;
  if (chartInstance) { chartInstance.dispose(); chartInstance = null; }

  const ec = await getEcharts();
  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
  const textColor = isDark ? '#9ca3af' : '#374151';
  const gridColor = isDark ? '#1f1f2e' : '#e5e7eb';

  const strategies = props.data.strategies || [];
  // Collect all unique dates
  const dateSet = new Set<string>();
  strategies.forEach(s => (s.nav_data || []).forEach(d => dateSet.add(String(d.date).slice(0, 10))));
  const dates = Array.from(dateSet).sort();

  const series = strategies.map((s, i) => {
    const color = COLORS[i % COLORS.length];
    const dataMap = new Map((s.nav_data || []).map(d => [String(d.date).slice(0, 10), d.value]));
    const values = dates.map(d => {
      const v = dataMap.get(d);
      return v === undefined ? null : v;
    });
    const initVal = values.find(v => v != null) || 1;
    const normVals = values.map(v => v == null ? null : v / initVal);
    return {
      name: s.name, type: 'line' as const, data: normVals, smooth: false, showSymbol: false,
      lineStyle: { color, width: 2 },
    };
  });

  chartInstance = ec.init(chartRef.value, isDark ? 'custom-dark' : null, { renderer: 'canvas' });
  chartInstance.setOption({
    animation: false,
    backgroundColor: 'transparent',
    grid: { left: 60, right: 30, top: 40, bottom: 40 },
    legend: {
      show: true, top: 8, left: 'center', itemWidth: 14, itemHeight: 2,
      textStyle: { color: textColor, fontSize: 13 },
    },
    tooltip: {
      trigger: 'axis', axisPointer: { type: 'cross' },
      backgroundColor: isDark ? '#0f0f14' : '#ffffff',
      borderColor: gridColor, textStyle: { color: textColor, fontSize: 13 },
    },
    xAxis: {
      type: 'category', data: dates, boundaryGap: false,
      axisLine: { lineStyle: { color: gridColor } },
      axisTick: { show: false },
      axisLabel: { color: textColor, fontSize: 12 },
      splitLine: { show: false },
    },
    yAxis: {
      scale: true, axisLine: { show: false }, axisTick: { show: false },
      axisLabel: { color: textColor, fontSize: 12 },
      splitLine: { lineStyle: { color: gridColor, type: 'dashed' } },
      name: '净值',
      nameTextStyle: { color: textColor, fontSize: 12, padding: [0, 0, 0, -20] },
    },
    series,
    dataZoom: [{ type: 'inside', start: 0, end: 100 }],
  });

  window.addEventListener('resize', resizeHandler);
}

onMounted(() => nextTick(() => initChart()));
watch(() => props.data, () => nextTick(() => initChart()), { deep: true });
onUnmounted(() => {
  window.removeEventListener('resize', resizeHandler);
  window.removeEventListener('mousemove', onResizeMove);
  window.removeEventListener('mouseup', onResizeEnd);
  chartInstance?.dispose();
  chartInstance = null;
});
</script>

<style scoped>
.compare-chart-wrap { padding: 0 14px 12px; }
.chart-resize-handle {
  height: 12px; cursor: ns-resize; display: flex; align-items: center; justify-content: center;
}
.chart-resize-handle:hover .chart-resize-dots { opacity: 1; }
.chart-resize-dots {
  width: 32px; height: 3px;
  background: repeating-linear-gradient(
    90deg,
    var(--border) 0px, var(--border) 2px,
    transparent 2px, transparent 5px
  );
  border-radius: 2px; opacity: 0.5; transition: opacity 0.15s;
}
</style>
