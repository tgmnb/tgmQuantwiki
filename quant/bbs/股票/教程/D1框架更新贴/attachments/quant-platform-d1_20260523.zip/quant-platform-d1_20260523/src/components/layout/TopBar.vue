<template>
  <div class="topbar">
    <div class="topbar-breadcrumb">
      <Transition
        name="title-fade"
        mode="out-in"
      >
        <span
          :key="pageTitle"
          class="topbar-title"
        >{{ pageTitle }}</span>
      </Transition>
    </div>
    <div class="topbar-actions">
      <button
        class="theme-toggle"
        :title="themeTooltip"
        @click="uiStore.toggleTheme()"
      >
        <el-icon :size="16">
          <Sunny v-if="uiStore.theme === 'light'" />
          <Moon v-else-if="uiStore.theme === 'dark'" />
          <View v-else />
        </el-icon>
      </button>
      <slot />
    </div>
  </div>
</template>

<script setup lang="ts">
import { Sunny, Moon, View } from '@element-plus/icons-vue'
import { useUIStore } from '@/stores/ui'

defineProps<{ pageTitle?: string }>()

const uiStore = useUIStore()

const themeTooltip = computed(() => {
  if (uiStore.theme === 'dark') return '切换到亮色主题'
  if (uiStore.theme === 'eye-care') return '切换到暗色主题'
  return '切换到护眼主题'
})
</script>

<style scoped>
.topbar {
  height: var(--topbar-h);
  display: flex;
  align-items: center;
  padding: 0 var(--content-padding);
  border-bottom: 1px solid var(--border-color);
  background: var(--bg-secondary);
  gap: 16px;
  flex-shrink: 0;
}

.topbar-breadcrumb {
  display: flex;
  align-items: center;
  gap: 8px;
  overflow: hidden;
}

.topbar-title {
  font-size: var(--font-lg);
  font-weight: 600;
  color: var(--text-primary);
  white-space: nowrap;
  letter-spacing: -0.2px;
}

.topbar-actions {
  margin-left: auto;
  display: flex;
  align-items: center;
  gap: 8px;
}

.theme-toggle {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border: 1px solid var(--border-color);
  border-radius: var(--radius-sm);
  background: var(--bg-tertiary);
  color: var(--text-secondary);
  cursor: pointer;
  transition: all 0.2s ease;
}

.theme-toggle:hover {
  background: var(--accent-dim);
  border-color: var(--accent);
  color: var(--accent);
}

/* Title transition */
.title-fade-enter-active,
.title-fade-leave-active {
  transition: opacity 0.15s ease;
}
.title-fade-enter-from,
.title-fade-leave-to {
  opacity: 0;
}

@media (max-width: 767px) {
  .topbar {
    padding: 0 var(--space-3);
    gap: var(--space-2);
  }
  .topbar-title {
    font-size: var(--font-md);
  }
}
</style>
