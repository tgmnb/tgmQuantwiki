<template>
  <div class="param-panel">
    <div
      v-if="!selectedStep"
      class="param-panel__empty"
    >
      <el-icon
        :size="32"
        color="var(--text-muted)"
      >
        <Setting />
      </el-icon>
      <p>点击节点以配置参数</p>
    </div>

    <div
      v-else
      class="param-panel__content"
    >
      <div class="param-panel__header">
        <span class="param-panel__title">{{ selectedStep.name }}</span>
        <el-icon
          class="param-panel__close"
          @click="emit('close')"
        >
          <Close />
        </el-icon>
      </div>

      <div
        v-for="(param, index) in stepParams"
        :key="index"
        class="param-group"
      >
        <label class="param-label">
          {{ param.label }}
          <span
            v-if="param.type !== 'checkbox'"
            class="param-type-hint"
          >{{ param.type }}</span>
        </label>

        <el-input
          v-if="param.type === 'string' || param.type === 'number'"
          v-model="paramValues[param.key]"
          :type="param.type === 'number' ? 'number' : 'text'"
          :placeholder="param.placeholder"
          size="small"
          @change="updateParam(param.key, paramValues[param.key])"
        />

        <el-select
          v-else-if="param.type === 'select'"
          v-model="paramValues[param.key]"
          size="small"
          @change="updateParam(param.key, paramValues[param.key])"
        >
          <el-option
            v-for="opt in param.options"
            :key="opt.value"
            :label="opt.label"
            :value="opt.value"
          />
        </el-select>

        <el-switch
          v-else-if="param.type === 'checkbox'"
          v-model="paramValues[param.key]"
          @change="updateParam(param.key, paramValues[param.key])"
        />

        <el-input
          v-else-if="param.type === 'text'"
          v-model="paramValues[param.key]"
          type="textarea"
          :rows="3"
          size="small"
          @change="updateParam(param.key, paramValues[param.key])"
        />
      </div>

      <div
        v-if="stepParams.length === 0"
        class="param-panel__hint"
      >
        此节点暂无可配置参数
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue'
import { Setting, Close } from '@element-plus/icons-vue'
import type { WorkflowStep, NodeParam } from '@/types'
import { useWorkflowStore } from '@/stores/workflow'

interface ParamDef {
  key: string
  label: string
  type: 'string' | 'number' | 'select' | 'checkbox' | 'text' | 'date'
  options?: Array<{ value: string; label: string }>
  placeholder?: string
  default?: any
}

function mapParamType(param: NodeParam): ParamDef['type'] {
  const uiWidget = param.ui?.widget as string | undefined
  if (uiWidget === 'date_picker') return 'date'
  if (uiWidget === 'checkbox') return 'checkbox'

  switch (param.type) {
    case 'str':
      return uiWidget === 'date_picker' ? 'date' : 'string'
    case 'number':
      return 'number'
    case 'list[str]':
      return 'text'
    case 'select':
      return 'select'
    case 'dict':
      return 'text'
    case 'boolean':
    case 'bool':
      return 'checkbox'
    default:
      return 'string'
  }
}

const props = defineProps<{
  selectedStep: WorkflowStep | null
}>()

const emit = defineEmits<{
  (e: 'update:params', stepId: string, params: Record<string, any>): void
  (e: 'close'): void
}>()

const paramValues = ref<Record<string, any>>({})
const workflowStore = useWorkflowStore()
const nodesRegistry = computed(() => workflowStore.nodeDefinitions)

onMounted(async () => {
  try {
    await workflowStore.loadNodes()
  } catch (err) {
    console.warn('[ParamPanel] Failed to load nodes:', err)
  }
})

const stepParams = computed<ParamDef[]>(() => {
  if (!props.selectedStep) return []

  const node = nodesRegistry.value.find(
    n => n.id === props.selectedStep?.node_type,
  ) ?? nodesRegistry.value.find(
    n => n.script === props.selectedStep?.script,
  )

  if (!node?.params) return []

  return node.params.map((p: NodeParam) => ({
    key: p.id,
    label: p.name,
    type: mapParamType(p),
    options: p.options,
    placeholder: (p.ui?.placeholder as string) || p.description || '',
    default: p.default,
  }))
})

watch(
  () => props.selectedStep?.id,
  () => {
    if (!props.selectedStep) {
      paramValues.value = {}
      return
    }
    const params = stepParams.value
    const newValues: Record<string, any> = {}
    params.forEach(p => {
      const existing = props.selectedStep!.params?.[p.key]
      // For list[str] params stored as arrays, convert to comma-separated string for the textarea
      if (p.type === 'text' && Array.isArray(existing)) {
        newValues[p.key] = existing.join(', ')
      } else if (p.type === 'text' && typeof existing === 'object' && existing !== null) {
        // dict type displayed as text
        newValues[p.key] = JSON.stringify(existing, null, 2)
      } else {
        newValues[p.key] = existing ?? p.default ?? ''
      }
    })
    paramValues.value = newValues
  },
  { immediate: true },
)

function parseOutValue(key: string, value: any, paramDef: ParamDef): any {
  if (paramDef.type === 'text') {
    const node = nodesRegistry.value.find(
      n => n.id === props.selectedStep?.node_type,
    ) ?? nodesRegistry.value.find(
      n => n.script === props.selectedStep?.script,
    )
    if (node) {
      const regParam = node.params?.find((p: NodeParam) => p.id === key)
      if (regParam?.type === 'list[str]' && typeof value === 'string') {
        return value
          .split(',')
          .map((s: string) => s.trim())
          .filter(Boolean)
      }
      if (regParam?.type === 'dict' && typeof value === 'string') {
        try {
          return JSON.parse(value)
        } catch {
          return value
        }
      }
    }
  }
  return value
}

function updateParam(key: string, value: any) {
  if (!props.selectedStep) return

  const paramDef = stepParams.value.find(p => p.key === key)
  const parsed = paramDef ? parseOutValue(key, value, paramDef) : value
  paramValues.value[key] = value

  const currentParams = props.selectedStep.params || {}
  emit('update:params', props.selectedStep.id, { ...currentParams, [key]: parsed })
}
</script>

<style scoped>
.param-panel {
  display: flex;
  flex-direction: column;
  height: 100%;
  width: 320px;
  border-left: 1px solid var(--border-color);
  background: var(--bg-primary);
  overflow: hidden;
}

.param-panel__empty {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 12px;
  color: var(--text-muted);
  font-size: 13px;
}

.param-panel__content {
  flex: 1;
  overflow-y: auto;
  padding: 0 16px 16px;
}

.param-panel__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 12px 16px;
  margin: 0 -16px 12px;
  border-bottom: 1px solid var(--border-color);
  position: sticky;
  top: 0;
  background: var(--bg-primary);
  z-index: 1;
}

.param-panel__title {
  font-size: var(--font-sm, 14px);
  font-weight: 600;
  color: var(--text-primary);
}

.param-panel__close {
  cursor: pointer;
  color: var(--text-muted);
  transition: color 0.2s;
}

.param-panel__close:hover {
  color: var(--text-primary);
}

.param-group {
  margin-bottom: 14px;
}

.param-label {
  display: flex;
  align-items: center;
  gap: 4px;
  margin-bottom: 4px;
  font-size: 12px;
  font-weight: 500;
  color: var(--text-secondary);
}

.param-type-hint {
  font-size: 10px;
  color: var(--text-muted);
  background: var(--bg-tertiary);
  padding: 0 4px;
  border-radius: 3px;
}

.param-panel__hint {
  padding: 20px;
  text-align: center;
  color: var(--text-muted);
  font-size: 12px;
  background: var(--bg-tertiary);
  border-radius: 8px;
}
</style>
