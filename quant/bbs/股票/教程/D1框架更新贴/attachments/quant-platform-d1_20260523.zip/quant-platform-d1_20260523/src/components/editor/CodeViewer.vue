<template>
  <div
    class="code-viewer-wrapper"
    :class="{ 'code-viewer-wrapper--no-header': hideHeader }"
  >
    <CodeEditor
      :model-value="code"
      :language="language"
      :readonly="true"
      :height="height"
      :show-toolbar="!hideHeader"
      :file-name="fileName"
      :copyable="copyable"
    />
  </div>
</template>

<script setup lang="ts">
import CodeEditor from './CodeEditor.vue'

interface Props {
  code: string
  language?: string
  copyable?: boolean
  fileName?: string
  hideHeader?: boolean
  height?: string
}

withDefaults(defineProps<Props>(), {
  language: '',
  copyable: true,
  fileName: '',
  hideHeader: false,
  height: '400px',
})
</script>

<style scoped>
.code-viewer-wrapper {
  width: 100%;
  border-radius: 6px;
  overflow: hidden;
}

.code-viewer-wrapper--no-header {
  border-radius: 0;
}
</style>
