<template>
  <MetricBadge
    v-bind="$attrs"
    label="最大回撤"
    :value="maxDrawdown"
    format="percent"
    :thresholds="{ good: -0.1, warn: -0.2, invert: true }"
  />
</template>
<script setup lang="ts">
defineProps<{ maxDrawdown: number | string }>();
</script>
