import { describe, it, expect, beforeEach, vi } from 'vitest';
import { createPinia, setActivePinia } from 'pinia';
import { useBacktestStore } from '../backtest';
import { backtestApi } from '@/api/backtest';

vi.mock('@/api/backtest', () => ({
  backtestApi: {
    getList: vi.fn(),
    getDetail: vi.fn(),
  },
}));

describe('Backtest Store', () => {
  beforeEach(() => {
    setActivePinia(createPinia());
    vi.clearAllMocks();
  });

  it('should initialize with default state', () => {
    const store = useBacktestStore();
    expect(store.strategies).toEqual([]);
    expect(store.currentStrategy).toBeNull();
    expect(store.loading).toBe(false);
    expect(store.strategyList).toEqual([]);
    expect(store.groupedStrategies).toEqual({});
  });

  it('should load strategies', async () => {
    const mockStrategies = [
      { name: 's1', group: 'g1', path: 'p1' },
      { name: 's2', group: 'g1', path: 'p2' },
    ];
    (backtestApi.getList as any).mockResolvedValue({
      groups: { g1: mockStrategies },
    });

    const store = useBacktestStore();
    await store.loadStrategies();

    expect(backtestApi.getList).toHaveBeenCalled();
    expect(store.strategies).toEqual(mockStrategies);
    expect(store.loading).toBe(false);
    expect(store.groupedStrategies).toEqual({ g1: mockStrategies });
  });

  it('should handle empty strategy list', async () => {
    (backtestApi.getList as any).mockResolvedValue({ groups: {} });

    const store = useBacktestStore();
    await store.loadStrategies();

    expect(store.strategies).toEqual([]);
    expect(store.groupedStrategies).toEqual({});
  });

  it('should set loading state during loadStrategies', async () => {
    let resolveFn: any;
    const promise = new Promise((resolve) => {
      resolveFn = resolve;
    });
    (backtestApi.getList as any).mockReturnValue(promise);

    const store = useBacktestStore();
    const loadPromise = store.loadStrategies();

    expect(store.loading).toBe(true);

    resolveFn({ groups: {} });
    await loadPromise;

    expect(store.loading).toBe(false);
  });

  it('should load strategy detail', async () => {
    const detail = { path: 'p1', metrics: {} } as any;
    (backtestApi.getDetail as any).mockResolvedValue(detail);

    const store = useBacktestStore();
    await store.loadStrategyDetail('p1');

    expect(backtestApi.getDetail).toHaveBeenCalledWith('p1', '');
    expect(store.currentStrategy).toEqual(detail);
    expect(store.loading).toBe(false);
  });

  it('should load strategy detail with base parameter', async () => {
    const detail = { path: 'p1', base: 'b1' } as any;
    (backtestApi.getDetail as any).mockResolvedValue(detail);

    const store = useBacktestStore();
    await store.loadStrategyDetail('p1', 'b1');

    expect(backtestApi.getDetail).toHaveBeenCalledWith('p1', 'b1');
  });
});
