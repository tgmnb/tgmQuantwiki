<template>
  <div class="code-toolbar">
    <div class="code-toolbar__left">
      <span
        v-if="fileName"
        class="code-toolbar__filename"
      >{{ fileName }}</span>
      <span
        v-if="language"
        class="code-toolbar__language"
      >{{ language }}</span>
      <span
        v-if="readonly"
        class="code-toolbar__badge"
      >只读</span>
    </div>
    <div class="code-toolbar__right">
      <button
        v-if="copyable"
        class="code-toolbar__btn"
        :class="{ 'code-toolbar__btn--copied': copied }"
        @click="copyCode"
      >
        <el-icon :size="14">
          <DocumentCopy />
        </el-icon>
        <span>{{ copied ? '已复制' : '复制' }}</span>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { DocumentCopy } from '@element-plus/icons-vue'

interface Props {
  fileName?: string
  language?: string
  readonly?: boolean
  copyable?: boolean
  code?: string
}

const props = withDefaults(defineProps<Props>(), {
  fileName: '',
  language: '',
  readonly: false,
  copyable: true,
  code: '',
})

let copyTimer: ReturnType<typeof setTimeout> | undefined
const copied = ref(false)

onUnmounted(() => clearTimeout(copyTimer))

async function copyCode() {
  try {
    await navigator.clipboard.writeText(props.code)
    copied.value = true
    clearTimeout(copyTimer)
    copyTimer = setTimeout(() => {
      copied.value = false
    }, 2000)
  } catch {
    console.error('Failed to copy code')
  }
}
</script>

<style scoped>
.code-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  height: 36px;
  padding: 0 12px;
  background-color: var(--bg-secondary);
  border-bottom: 1px solid var(--border-color);
  flex-shrink: 0;
  gap: 8px;
}

.code-toolbar__left {
  display: flex;
  align-items: center;
  gap: 8px;
  overflow: hidden;
  flex: 1;
  min-width: 0;
}

.code-toolbar__filename {
  font-size: 13px;
  font-weight: 600;
  color: var(--text-primary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.code-toolbar__language {
  font-size: 11px;
  padding: 2px 8px;
  border-radius: 4px;
  background-color: var(--bg-tertiary);
  color: var(--text-muted);
  font-family: var(--font-mono);
  flex-shrink: 0;
  border: 1px solid var(--border-color);
}

.code-toolbar__badge {
  font-size: 11px;
  padding: 1px 6px;
  border-radius: 3px;
  background-color: var(--accent-dim);
  color: var(--accent);
  font-weight: 500;
  flex-shrink: 0;
}

.code-toolbar__right {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.code-toolbar__btn {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  font-size: 12px;
  font-weight: 500;
  border: 1px solid var(--border-color);
  border-radius: 6px;
  background-color: var(--bg-tertiary);
  color: var(--text-secondary);
  cursor: pointer;
  transition: all 0.2s ease;
}

.code-toolbar__btn:hover {
  background-color: var(--accent-dim);
  border-color: var(--accent);
  color: var(--accent);
}

.code-toolbar__btn--copied {
  background-color: rgba(0, 200, 122, 0.15);
  border-color: var(--success);
  color: var(--success);
}
</style>
