# -*- coding: utf-8 -*-
"""
终端服务 — 管理 Windows PTY 会话

使用 pywinpty (PtyProcess) 创建伪终端，通过 WebSocket 双向转发 I/O。
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from typing import Dict

import config as _config

logger = logging.getLogger("quant.terminal")

_sessions: Dict[str, TerminalSession] = {}


class TerminalSession:
    """单个 PTY 终端会话"""

    def __init__(self, cols: int = 80, rows: int = 24, cwd: str | None = None):
        self.id = uuid.uuid4().hex[:12]
        self._cwd = cwd or self._resolve_cwd()
        self._cols = cols
        self._rows = rows
        self._proc = None
        self._read_task: asyncio.Task | None = None

    @staticmethod
    def _resolve_cwd() -> str:
        cfg = _config.get_config()
        proj = cfg.get("QUANT_PROJ")
        if proj and proj.exists():
            return str(proj)
        return str(_config.PROJECT_DIR)

    def start(self) -> None:
        from winpty import PtyProcess

        self._proc = PtyProcess.spawn(
            r"C:\Windows\System32\WindowsPowerShell\v1.0\powershell.exe",
            cwd=self._cwd,
        )
        self._proc.setwinsize(self._rows, self._cols)
        logger.info("终端会话 %s 已启动 (cwd=%s)", self.id, self._cwd)

    @property
    def proc(self):
        return self._proc

    def write(self, data: str) -> None:
        if self._proc and self._proc.isalive():
            self._proc.write(data)

    def read(self, size: int = 4096) -> str:
        if self._proc and self._proc.isalive():
            return self._proc.read(size)
        return ""

    def resize(self, cols: int, rows: int) -> None:
        if self._proc:
            self._proc.setwinsize(rows, cols)

    def close(self) -> None:
        if self._proc:
            try:
                self._proc.terminate()
            except Exception:
                pass
        if self._read_task and not self._read_task.done():
            self._read_task.cancel()
        logger.info("终端会话 %s 已关闭", self.id)


def create_session(cols: int = 80, rows: int = 24, cwd: str | None = None) -> TerminalSession:
    session = TerminalSession(cols=cols, rows=rows, cwd=cwd)
    session.start()
    _sessions[session.id] = session
    return session


def get_session(session_id: str) -> TerminalSession | None:
    return _sessions.get(session_id)


def remove_session(session_id: str) -> None:
    session = _sessions.pop(session_id, None)
    if session:
        session.close()


def get_cwd_path() -> str:
    return TerminalSession._resolve_cwd()
