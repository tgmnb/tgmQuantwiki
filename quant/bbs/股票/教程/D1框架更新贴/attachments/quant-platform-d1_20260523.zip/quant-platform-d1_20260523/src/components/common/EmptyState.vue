<template>
  <div class="empty-state">
    <div class="empty-state__icon">
      <slot name="icon">
        <div class="empty-state__illustration">
          <div class="empty-state__circle" />
          <div class="empty-state__triangle" />
          <div class="empty-state__dashed-line" />
        </div>
      </slot>
    </div>
    <div class="empty-state__title">
      {{ title }}
    </div>
    <div
      v-if="description"
      class="empty-state__description"
    >
      {{ description }}
    </div>
    <button
      v-if="actionText"
      class="empty-state__action"
      @click="emit('action')"
    >
      {{ actionText }}
    </button>
  </div>
</template>

<script setup lang="ts">
interface Props {
  title?: string;
  description?: string;
  actionText?: string;
}

withDefaults(defineProps<Props>(), {
  title: '暂无数据',
  description: '',
  actionText: '',
});

const emit = defineEmits<{
  (e: 'action'): void
}>();
</script>

<style scoped>
.empty-state {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: var(--space-10);
  text-align: center;
}

.empty-state__icon {
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: var(--space-7);
}

.empty-state__illustration {
  position: relative;
  width: 120px;
  height: 120px;
}

.empty-state__circle {
  position: absolute;
  top: 10px;
  left: 15px;
  width: 44px;
  height: 44px;
  border-radius: 50%;
  background: rgba(var(--text-muted-rgb, 90, 90, 110), 0.25);
  background: color-mix(in srgb, var(--text-muted) 25%, transparent);
}

.empty-state__triangle {
  position: absolute;
  top: 35px;
  right: 18px;
  width: 0;
  height: 0;
  border-left: 24px solid transparent;
  border-right: 24px solid transparent;
  border-bottom: 42px solid color-mix(in srgb, var(--text-muted) 25%, transparent);
}

.empty-state__dashed-line {
  position: absolute;
  bottom: 20px;
  left: 50%;
  transform: translateX(-50%);
  width: 72px;
  height: 0;
  border-top: 3px dashed color-mix(in srgb, var(--text-muted) 30%, transparent);
}

.empty-state__title {
  font-size: var(--font-xl);
  font-weight: 600;
  color: var(--text-primary);
  line-height: 1.4;
}

.empty-state__description {
  margin-top: var(--space-3);
  font-size: var(--font-md);
  color: var(--text-secondary);
  line-height: 1.5;
  max-width: 320px;
}

.empty-state__action {
  margin-top: var(--space-7);
  padding: 0 var(--space-7);
  height: var(--h-lg);
  font-size: var(--font-sm);
  font-weight: 500;
  color: var(--accent);
  background: transparent;
  border: 1px solid var(--accent);
  border-radius: var(--radius);
  cursor: pointer;
  transition: all var(--transition);
  font-family: inherit;
}

.empty-state__action:hover {
  background: var(--accent-dim);
  box-shadow: var(--shadow-glow);
}

.empty-state__action:active {
  transform: scale(0.97);
  transition-duration: 0.05s;
}
</style>
