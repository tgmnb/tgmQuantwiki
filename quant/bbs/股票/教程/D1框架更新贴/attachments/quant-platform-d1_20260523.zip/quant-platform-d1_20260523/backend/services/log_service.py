"""
日志服务 — 结构化日志 + 内存缓冲 + 文件持久化

提供：
- setup_logging()      初始化日志系统（写入文件 + 内存缓冲）
- get_recent_logs()    API 查询最近 N 条日志
- LogService           结构化日志类（替代普通 logger）
"""

from __future__ import annotations

import json
import logging
import os
import time
from collections import deque
from datetime import datetime
from logging.handlers import RotatingFileHandler
from pathlib import Path
from threading import Lock
from typing import Optional

# ---------------------------------------------------------------------------
# 配置
# ---------------------------------------------------------------------------
_MAX_BUFFER = 500          # 内存最多保留条数
_LOG_FILE = Path(__file__).resolve().parent.parent / "logs" / "platform.log"
_MAX_BYTES = 5 * 1024 * 1024   # 5MB 单文件
_BACKUP_COUNT = 3

# 全局内存缓冲区（线程安全）
_log_buffer: deque[dict] = deque(maxlen=_MAX_BUFFER)
_buffer_lock = Lock()

# ---------------------------------------------------------------------------
# 核心：写入内存缓冲区
# ---------------------------------------------------------------------------

def _emit(level: str, message: str, **kwargs):
    """写入内存环形缓冲区，供 API 查询。"""
    entry = {
        "ts": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "level": level,
        "message": message,
    }
    if kwargs:
        entry["context"] = kwargs
    with _buffer_lock:
        _log_buffer.append(entry)


# ---------------------------------------------------------------------------
# 日志系统初始化
# ---------------------------------------------------------------------------

def setup_logging(name: str = "quant") -> logging.Logger:
    """初始化日志系统：控制台 + 文件（带轮转）+ 内存缓冲。"""
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    # 避免重复添加 handler（reload 场景）
    if logger.handlers:
        return logger

    # 日志格式
    fmt = "%(asctime)s [%(levelname)s] %(name)s: %(message)s"
    datefmt = "%Y-%m-%d %H:%M:%S"
    formatter = logging.Formatter(fmt, datefmt)

    # 1. 控制台 Handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # 2. 文件 Handler（轮转）
    _LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    fh = RotatingFileHandler(
        _LOG_FILE,
        maxBytes=_MAX_BYTES,
        backupCount=_BACKUP_COUNT,
        encoding="utf-8",
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    # 3. 自定义 Handler：捕获所有 >= INFO 的写入内存缓冲区
    class _BufferHandler(logging.Handler):
        def emit(self, record: logging.LogRecord):
            if record.levelno >= logging.INFO:
                msg = self.format(record)
                _emit(record.levelname, msg)

    bh = _BufferHandler()
    bh.setFormatter(formatter)
    logger.addHandler(bh)

    logger.info("日志系统初始化完成，日志文件: %s", _LOG_FILE)
    return logger


# ---------------------------------------------------------------------------
# API 查询接口
# ---------------------------------------------------------------------------

def get_recent_logs(
    limit: int = 50,
    level: Optional[str] = None,
    search: Optional[str] = None,
) -> dict:
    """返回最近 N 条日志（供 /api/logs 使用）。

    Args:
        limit:   最大返回条数
        level:   过滤级别（DEBUG/INFO/WARNING/ERROR）
        search:  模糊搜索消息内容
    """
    with _buffer_lock:
        logs = list(_log_buffer)

    if level:
        logs = [l for l in logs if l.get("level", "").upper() == level.upper()]
    if search:
        term = search.lower()
        logs = [l for l in logs if term in l.get("message", "").lower()]

    return {
        "total": len(logs),
        "logs": logs[-limit:] if limit > 0 else logs,
    }


def clear_buffer():
    """清空内存日志缓冲区（测试用）。"""
    with _buffer_lock:
        _log_buffer.clear()


# ---------------------------------------------------------------------------
# JSON 结构化日志（生产环境）
# ---------------------------------------------------------------------------

class JSONFormatter(logging.Formatter):
    """输出 JSON 格式的结构化日志。"""

    def format(self, record: logging.LogRecord) -> str:
        entry = {
            "timestamp": self.formatTime(record),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "request_id": getattr(record, "request_id", ""),
            "pathname": record.pathname,
            "lineno": record.lineno,
        }
        if record.exc_info:
            entry["exception"] = self.formatException(record.exc_info)
        return json.dumps(entry, ensure_ascii=False)


def get_json_formatter() -> JSONFormatter:
    """返回 JSONFormatter 实例，字段包含：
    timestamp, level, logger, message, request_id, pathname, lineno
    """
    return JSONFormatter()


def setup_json_logging(name: str = "quant") -> logging.Logger:
    """初始化 JSON 格式日志系统（用于生产环境）。

    控制台和文件均输出 JSON 格式，便于日志收集系统解析。
    """
    logger = logging.getLogger(name)
    logger.setLevel(logging.DEBUG)

    # 避免重复添加 handler（reload 场景）
    if logger.handlers:
        return logger

    formatter = get_json_formatter()

    # 1. 控制台 Handler
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    ch.setFormatter(formatter)
    logger.addHandler(ch)

    # 2. 文件 Handler（轮转）
    _LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    fh = RotatingFileHandler(
        _LOG_FILE,
        maxBytes=_MAX_BYTES,
        backupCount=_BACKUP_COUNT,
        encoding="utf-8",
    )
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(formatter)
    logger.addHandler(fh)

    # 3. 自定义 Handler：捕获所有 >= INFO 的写入内存缓冲区
    class _BufferHandler(logging.Handler):
        def emit(self, record: logging.LogRecord):
            if record.levelno >= logging.INFO:
                msg = self.format(record)
                _emit(record.levelname, msg)

    bh = _BufferHandler()
    bh.setFormatter(formatter)
    logger.addHandler(bh)

    logger.info("JSON 日志系统初始化完成，日志文件: %s", _LOG_FILE)
    return logger
