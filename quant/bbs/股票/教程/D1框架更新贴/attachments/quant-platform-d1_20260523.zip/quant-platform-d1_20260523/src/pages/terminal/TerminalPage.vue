<template>
  <div class="terminal-page">
    <div class="terminal-toolbar">
      <div class="terminal-toolbar__left">
        <h2 class="terminal-toolbar__title">终端</h2>
        <div
          v-if="activeTab"
          class="terminal-status"
          :class="`terminal-status--${activeTab.wsState}`"
        >
          <span class="terminal-status__dot" />
          <span class="terminal-status__text">{{ statusLabel }}</span>
        </div>
      </div>
      <div class="terminal-toolbar__right">
        <div
          v-if="cwdPath"
          class="terminal-path"
          @click="copyPath"
        >
          <el-icon :size="12"><FolderOpened /></el-icon>
          <span class="terminal-path__text">{{ cwdPath }}</span>
        </div>
        <button class="tb-btn" title="减小字号" @click="changeFontSize(-1)">
          <el-icon :size="14"><ZoomOut /></el-icon>
        </button>
        <span class="tb-font-size">{{ fontSize }}</span>
        <button class="tb-btn" title="增大字号" @click="changeFontSize(1)">
          <el-icon :size="14"><ZoomIn /></el-icon>
        </button>
        <div class="tb-divider" />
        <button class="tb-btn" title="清屏" @click="clearActiveTerminal">
          <el-icon :size="14"><Delete /></el-icon>
        </button>
        <button class="tb-btn" title="重新连接当前终端" @click="reconnectActive">
          <el-icon :size="14"><RefreshRight /></el-icon>
        </button>
      </div>
    </div>

    <div
      v-if="tabs.length > 0"
      class="terminal-tabs"
    >
      <div class="terminal-tabs__list">
        <button
          v-for="tab in tabs"
          :key="tab.id"
          class="tab-item"
          :class="{ 'tab-item--active': tab.id === activeTabId }"
          @click="switchTab(tab.id)"
        >
          <span class="tab-item__dot" :class="`tab-item__dot--${tab.wsState}`" />
          <span class="tab-item__label">{{ tab.label }}</span>
          <span class="tab-item__close" @click.stop="closeTab(tab.id)">&times;</span>
        </button>
      </div>
      <button class="tab-add" title="新建终端" @click="addTab">
        <el-icon :size="14"><Plus /></el-icon>
      </button>
    </div>

    <div
      v-if="tabs.length > 0"
      class="terminal-viewport"
    >
      <div
        v-for="tab in tabs"
        :key="tab.id"
        :ref="(el) => setContainer(tab.id, el as HTMLElement)"
        class="terminal-body"
        :style="{ display: tab.id === activeTabId ? 'block' : 'none' }"
      />
    </div>

    <div
      v-else
      class="terminal-empty"
    >
      <button
        class="terminal-empty__btn"
        @click="addTab"
      >
        <el-icon :size="20"><Plus /></el-icon>
        <span>新建终端</span>
      </button>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onBeforeUnmount, nextTick, watch } from 'vue'
import { Terminal } from '@xterm/xterm'
import { FitAddon } from '@xterm/addon-fit'
import { WebLinksAddon } from '@xterm/addon-web-links'
import '@xterm/xterm/css/xterm.css'
import { useUIStore } from '@/stores/ui'
import { request } from '@/api/request'

const uiStore = useUIStore()
const cwdPath = ref('')
const fontSize = ref(14)
let tabCounter = 0

interface TabInstance {
  id: number
  label: string
  wsState: 'connecting' | 'connected' | 'disconnected'
  terminal: Terminal | null
  fitAddon: FitAddon | null
  ws: WebSocket | null
  dataDisposable: { dispose(): void } | null
  reconnectTimer: ReturnType<typeof setTimeout> | null
  reconnectAttempts: number
  container: HTMLElement | null
}

const tabs = ref<TabInstance[]>([])
const activeTabId = ref<number>(-1)

const activeTab = computed(() => tabs.value.find((t) => t.id === activeTabId.value) ?? null)

const statusLabel = computed(() => {
  const m = { connecting: '连接中...', connected: '已连接', disconnected: '已断开' } as const
  return activeTab.value ? m[activeTab.value.wsState] : ''
})

const containerRefs = new Map<number, HTMLElement>()
function setContainer(tabId: number, el: HTMLElement | null) {
  if (el) containerRefs.set(tabId, el)
}

// ---- Theme ----

const THEMES = {
  dark: {
    background: '#111118', foreground: '#e8e8ed', cursor: '#7c6ef5', cursorAccent: '#111118',
    selectionBackground: 'rgba(124, 110, 245, 0.3)',
    black: '#1e1e28', red: '#ff4d5e', green: '#00c87a', yellow: '#f5a623',
    blue: '#5b9cf5', magenta: '#c678dd', cyan: '#56b6c2', white: '#e8e8ed',
    brightBlack: '#5a5a6e', brightRed: '#ff6b7a', brightGreen: '#2ee89e',
    brightYellow: '#ffc857', brightBlue: '#7db8ff', brightMagenta: '#d890ff',
    brightCyan: '#7dd6e2', brightWhite: '#ffffff',
  },
  light: {
    background: '#ffffff', foreground: '#1a1a2e', cursor: '#5b4cc4', cursorAccent: '#ffffff',
    selectionBackground: 'rgba(91, 76, 196, 0.2)',
    black: '#1a1a2e', red: '#e53e4f', green: '#00a86b', yellow: '#d48a00',
    blue: '#3b7dd8', magenta: '#a855f7', cyan: '#0891b2', white: '#6b7280',
    brightBlack: '#9ca3af', brightRed: '#ef4444', brightGreen: '#22c55e',
    brightYellow: '#eab308', brightBlue: '#60a5fa', brightMagenta: '#c084fc',
    brightCyan: '#22d3ee', brightWhite: '#1a1a2e',
  },
  'eye-care': {
    background: '#f5f0e8', foreground: '#3d3a35', cursor: '#7c6ef5', cursorAccent: '#f5f0e8',
    selectionBackground: 'rgba(124, 110, 245, 0.2)',
    black: '#3d3a35', red: '#c0392b', green: '#27ae60', yellow: '#b8860b',
    blue: '#2980b9', magenta: '#8e44ad', cyan: '#16a085', white: '#5d5a55',
    brightBlack: '#7d7a75', brightRed: '#e74c3c', brightGreen: '#2ecc71',
    brightYellow: '#f39c12', brightBlue: '#3498db', brightMagenta: '#9b59b6',
    brightCyan: '#1abc9c', brightWhite: '#3d3a35',
  },
} as const

function currentTheme() {
  return THEMES[uiStore.theme as keyof typeof THEMES] ?? THEMES.dark
}

watch(() => uiStore.theme, () => {
  tabs.value.forEach((tab) => {
    if (tab.terminal) tab.terminal.options.theme = currentTheme()
  })
})

// ---- WebSocket ----

function getWsUrl() {
  const protocol = location.protocol === 'https:' ? 'wss:' : 'ws:'
  const isDev = import.meta.env.DEV
  const host = isDev ? 'localhost:5180' : location.host
  return `${protocol}//${host}/api/terminal/ws`
}

const MAX_RECONNECT = 5
const RECONNECT_BASE_MS = 1000

function connectTab(tab: TabInstance) {
  cleanupTab(tab)
  tab.wsState = 'connecting'

  const cols = tab.terminal?.cols ?? 80
  const rows = tab.terminal?.rows ?? 24
  const ws = new WebSocket(`${getWsUrl()}?cols=${cols}&rows=${rows}`)
  tab.ws = ws

  ws.onopen = () => {
    tab.wsState = 'connected'
    tab.reconnectAttempts = 0
    if (tab.id === activeTabId.value) tab.terminal?.focus()
  }

  ws.onmessage = (e) => {
    tab.terminal?.write(e.data)
  }

  ws.onclose = () => {
    tab.wsState = 'disconnected'
    scheduleReconnect(tab)
  }

  ws.onerror = () => {
    tab.wsState = 'disconnected'
  }

  bindInput(tab)
}

function scheduleReconnect(tab: TabInstance) {
  if (tab.reconnectAttempts >= MAX_RECONNECT) return
  tab.reconnectAttempts++
  const delay = RECONNECT_BASE_MS * tab.reconnectAttempts
  tab.reconnectTimer = setTimeout(() => connectTab(tab), delay)
}

function cleanupTab(tab: TabInstance) {
  if (tab.ws) {
    tab.ws.onclose = null
    tab.ws.onerror = null
    tab.ws.close()
    tab.ws = null
  }
  if (tab.reconnectTimer) {
    clearTimeout(tab.reconnectTimer)
    tab.reconnectTimer = null
  }
  tab.dataDisposable?.dispose()
  tab.dataDisposable = null
}

function bindInput(tab: TabInstance) {
  tab.dataDisposable?.dispose()
  tab.dataDisposable =
    tab.terminal?.onData((data) => {
      if (tab.ws?.readyState === WebSocket.OPEN) {
        tab.ws.send(JSON.stringify({ type: 'input', data }))
      }
    }) ?? null
}

function resizeTab(tab: TabInstance) {
  if (!tab.fitAddon || !tab.terminal) return
  tab.fitAddon.fit()
  if (tab.ws?.readyState === WebSocket.OPEN) {
    tab.ws.send(
      JSON.stringify({ type: 'resize', cols: tab.terminal.cols, rows: tab.terminal.rows }),
    )
  }
}

// ---- Tab management ----

function addTab() {
  if (tabs.value.length === 0) tabCounter = 0
  tabCounter++
  const id = tabCounter
  tabs.value.push({
    id,
    label: `终端 ${id}`,
    wsState: 'disconnected',
    terminal: null,
    fitAddon: null,
    ws: null,
    dataDisposable: null,
    reconnectTimer: null,
    reconnectAttempts: 0,
    container: null,
  })
  activeTabId.value = id

  nextTick(() => {
    const tab = tabs.value.find((t) => t.id === id)
    if (!tab) return
    const el = containerRefs.get(id)
    if (!el) return
    tab.container = el

    tab.terminal = new Terminal({
      cursorBlink: true,
      fontSize: fontSize.value,
      fontFamily: "'Cascadia Code', 'Fira Code', 'Consolas', monospace",
      theme: currentTheme(),
      allowProposedApi: true,
      scrollback: 5000,
    })

    tab.fitAddon = new FitAddon()
    tab.terminal.loadAddon(tab.fitAddon)
    tab.terminal.loadAddon(new WebLinksAddon())
    tab.terminal.open(el)
    tab.fitAddon.fit()

    connectTab(tab)
  })
}

function closeTab(id: number) {
  const idx = tabs.value.findIndex((t) => t.id === id)
  if (idx === -1) return
  const tab = tabs.value[idx]
  cleanupTab(tab)
  tab.terminal?.dispose()
  containerRefs.delete(id)
  tabs.value.splice(idx, 1)

  if (tabs.value.length === 0) {
    activeTabId.value = -1
  } else if (activeTabId.value === id) {
    const next = tabs.value[Math.min(idx, tabs.value.length - 1)]
    activeTabId.value = next.id
    nextTick(() => {
      resizeTab(next)
      next.terminal?.focus()
    })
  }
}

function switchTab(id: number) {
  if (activeTabId.value === id) return
  activeTabId.value = id
  const tab = tabs.value.find((t) => t.id === id)
  if (tab) {
    nextTick(() => {
      resizeTab(tab)
      tab.terminal?.focus()
    })
  }
}

// ---- Toolbar actions ----

function clearActiveTerminal() {
  activeTab.value?.terminal?.clear()
  activeTab.value?.terminal?.focus()
}

function reconnectActive() {
  const tab = activeTab.value
  if (!tab) return
  tab.reconnectAttempts = 0
  connectTab(tab)
}

function changeFontSize(delta: number) {
  const next = fontSize.value + delta
  if (next < 10 || next > 28) return
  fontSize.value = next
  tabs.value.forEach((tab) => {
    if (tab.terminal) {
      tab.terminal.options.fontSize = next
    }
  })
  const tab = activeTab.value
  if (tab) nextTick(() => resizeTab(tab))
}

async function copyPath() {
  if (!cwdPath.value) return
  try {
    await navigator.clipboard.writeText(cwdPath.value)
  } catch {
    // fallback
  }
}

// ---- Viewport resize ----

let viewportObserver: ResizeObserver | null = null

function handleViewportResize() {
  const tab = activeTab.value
  if (tab) resizeTab(tab)
}

// ---- Lifecycle ----

onMounted(async () => {
  try {
    const data = await request.get<{ path: string }>('/terminal/path')
    cwdPath.value = data?.path ?? ''
  } catch {
    // ignore
  }

  addTab()

  viewportObserver = new ResizeObserver(handleViewportResize)
  const vp = document.querySelector('.terminal-viewport')
  if (vp) viewportObserver.observe(vp)
})

onBeforeUnmount(() => {
  viewportObserver?.disconnect()
  tabs.value.forEach((tab) => {
    cleanupTab(tab)
    tab.terminal?.dispose()
  })
  tabs.value = []
  containerRefs.clear()
})
</script>

<style scoped>
.terminal-page {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* ---- Toolbar ---- */
.terminal-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3, 8px);
  padding: 10px 16px;
  border-bottom: 1px solid var(--border, var(--border-color));
  flex-shrink: 0;
  height: 48px;
  box-sizing: border-box;
  background: var(--bg-secondary);
}

.terminal-toolbar__left {
  display: flex;
  align-items: center;
  gap: 10px;
  min-width: 0;
}

.terminal-toolbar__title {
  font-size: var(--font-xs, 13px);
  font-weight: 600;
  color: var(--text-primary);
  letter-spacing: 0.5px;
  text-transform: uppercase;
  white-space: nowrap;
}

.terminal-toolbar__right {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}

/* ---- Status ---- */
.terminal-status {
  display: flex;
  align-items: center;
  gap: 5px;
}

.terminal-status__dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--text-muted);
  transition: background var(--transition, 0.15s ease);
}

.terminal-status__text {
  font-size: 11px;
  font-weight: 500;
  color: var(--text-muted);
  transition: color var(--transition, 0.15s ease);
}

.terminal-status--connected .terminal-status__dot {
  background: var(--success);
  box-shadow: 0 0 6px rgba(0, 200, 122, 0.35);
}

.terminal-status--connected .terminal-status__text {
  color: var(--success);
}

.terminal-status--connecting .terminal-status__dot {
  background: var(--warning);
  animation: pulse 1.5s ease-in-out infinite;
}

.terminal-status--connecting .terminal-status__text {
  color: var(--warning);
}

.terminal-status--disconnected .terminal-status__dot {
  background: var(--error);
}

.terminal-status--disconnected .terminal-status__text {
  color: var(--error);
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.35; }
}

/* ---- Path display ---- */
.terminal-path {
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 2px 8px;
  border-radius: var(--radius-sm, 6px);
  background: var(--bg-tertiary, var(--bg-hover));
  cursor: pointer;
  max-width: 300px;
  transition: background var(--transition, 0.15s ease);
}

.terminal-path:hover {
  background: var(--bg-hover);
}

.terminal-path__text {
  font-size: 11px;
  color: var(--text-muted);
  font-family: var(--font-mono, monospace);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

/* ---- Toolbar buttons ---- */
.tb-btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: var(--radius-sm, 6px);
  border: none;
  background: transparent;
  color: var(--text-secondary);
  cursor: pointer;
  transition: all var(--transition, 0.15s ease);
}

.tb-btn:hover {
  background: var(--bg-hover);
  color: var(--text-primary);
}

.tb-font-size {
  font-size: 11px;
  color: var(--text-muted);
  width: 20px;
  text-align: center;
  font-family: var(--font-mono, monospace);
}

.tb-divider {
  width: 1px;
  height: 16px;
  background: var(--border, var(--border-color));
  margin: 0 4px;
}

/* ---- Tab bar ---- */
.terminal-tabs {
  display: flex;
  align-items: center;
  background: var(--bg-secondary);
  border-bottom: 1px solid var(--border, var(--border-color));
  padding: 0 12px;
  height: 36px;
  flex-shrink: 0;
  gap: 2px;
}

.terminal-tabs__list {
  display: flex;
  align-items: center;
  gap: 2px;
  flex: 1;
  overflow-x: auto;
  min-width: 0;
}

.terminal-tabs__list::-webkit-scrollbar {
  height: 0;
}

.tab-item {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  border-radius: var(--radius-sm, 6px) var(--radius-sm, 6px) 0 0;
  border: none;
  background: transparent;
  color: var(--text-secondary);
  font-size: 12px;
  font-weight: 500;
  cursor: pointer;
  white-space: nowrap;
  transition: all var(--transition, 0.15s ease);
  font-family: inherit;
  position: relative;
}

.tab-item:hover {
  background: var(--bg-hover);
  color: var(--text-primary);
}

.tab-item--active {
  background: var(--bg-primary);
  color: var(--text-primary);
}

.tab-item--active::after {
  content: '';
  position: absolute;
  bottom: -1px;
  left: 0;
  right: 0;
  height: 2px;
  background: var(--accent);
  border-radius: 2px 2px 0 0;
}

.tab-item__dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--text-muted);
  flex-shrink: 0;
}

.tab-item__dot--connected {
  background: var(--success);
}

.tab-item__dot--connecting {
  background: var(--warning);
  animation: pulse 1.5s ease-in-out infinite;
}

.tab-item__dot--disconnected {
  background: var(--error);
}

.tab-item__close {
  font-size: 14px;
  line-height: 1;
  margin-left: 2px;
  opacity: 0;
  transition: opacity var(--transition, 0.15s ease);
  padding: 0 2px;
}

.tab-item:hover .tab-item__close {
  opacity: 0.6;
}

.tab-item__close:hover {
  opacity: 1 !important;
}

.tab-add {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: var(--radius-sm, 6px);
  border: none;
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
  transition: all var(--transition, 0.15s ease);
  flex-shrink: 0;
}

.tab-add:hover {
  background: var(--bg-hover);
  color: var(--text-primary);
}

/* ---- Viewport ---- */
.terminal-viewport {
  flex: 1;
  overflow: hidden;
  position: relative;
}

.terminal-body {
  width: 100%;
  height: 100%;
  padding: 4px 4px 4px 8px;
  background: var(--bg-primary);
  overflow: hidden;
}

.terminal-body :deep(.xterm) {
  height: 100%;
}

.terminal-body :deep(.xterm-viewport) {
  overflow-y: auto !important;
}

.terminal-body :deep(.xterm-screen) {
  height: 100% !important;
}

/* ---- Empty state ---- */
.terminal-empty {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  background: var(--bg-primary);
}

.terminal-empty__btn {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 10px;
  padding: 28px 44px;
  border-radius: var(--radius-lg, 14px);
  border: 1px dashed var(--border, var(--border-color));
  background: transparent;
  color: var(--text-muted);
  cursor: pointer;
  transition: all var(--transition, 0.15s ease);
  font-family: inherit;
}

.terminal-empty__btn:hover {
  border-color: var(--accent);
  color: var(--accent);
  background: var(--accent-glow, rgba(124, 110, 245, 0.08));
}

.terminal-empty__btn span {
  font-size: var(--font-sm, 14px);
  font-weight: 500;
}

/* ---- Responsive ---- */
@media (max-width: 767px) {
  .terminal-path {
    display: none;
  }
}
</style>
