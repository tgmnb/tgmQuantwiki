import { setActivePinia } from 'pinia';
import { createPinia } from 'pinia';
import { describe, it, expect, beforeEach } from 'vitest';
import { useUIStore } from '../ui';

describe('UI Store', () => {
  beforeEach(() => {
    setActivePinia(createPinia());
    // 清除 localStorage mock
    localStorage.clear();
  });

  it('should initialize with dark theme if localStorage is empty', () => {
    const store = useUIStore();
    expect(store.theme).toBe('dark');
    expect(store.isDark).toBe(true);
    expect(store.isEyeCare).toBe(false);
  });

  it('should initialize with light theme from localStorage', () => {
    localStorage.setItem('d1-theme', 'light');
    const store = useUIStore();
    expect(store.theme).toBe('light');
    expect(store.isDark).toBe(false);
    expect(store.isEyeCare).toBe(false);
  });

  it('should initialize with eye-care theme from localStorage', () => {
    localStorage.setItem('d1-theme', 'eye-care');
    const store = useUIStore();
    expect(store.theme).toBe('eye-care');
    expect(store.isDark).toBe(false);
    expect(store.isEyeCare).toBe(true);
  });

  it('should default to dark for invalid theme in localStorage', () => {
    localStorage.setItem('d1-theme', 'invalid');
    const store = useUIStore();
    expect(store.theme).toBe('dark');
    expect(store.isDark).toBe(true);
  });

  it('should set theme to light', () => {
    const store = useUIStore();
    store.setTheme('light');
    expect(store.theme).toBe('light');
    expect(store.isDark).toBe(false);
    expect(store.isEyeCare).toBe(false);
    expect(localStorage.getItem('d1-theme')).toBe('light');
  });

  it('should set theme to dark', () => {
    const store = useUIStore();
    store.setTheme('dark');
    expect(store.theme).toBe('dark');
    expect(store.isDark).toBe(true);
    expect(store.isEyeCare).toBe(false);
    expect(localStorage.getItem('d1-theme')).toBe('dark');
  });

  it('should set theme to eye-care', () => {
    const store = useUIStore();
    store.setTheme('eye-care');
    expect(store.theme).toBe('eye-care');
    expect(store.isDark).toBe(false);
    expect(store.isEyeCare).toBe(true);
    expect(localStorage.getItem('d1-theme')).toBe('eye-care');
  });

  it('should default to dark for invalid theme', () => {
    const store = useUIStore();
    store.setTheme('invalid');
    expect(store.theme).toBe('dark');
    expect(store.isDark).toBe(true);
    expect(store.isEyeCare).toBe(false);
  });

  it('should toggle theme in order: dark → light → eye-care → dark', () => {
    const store = useUIStore();
    expect(store.theme).toBe('dark');

    store.toggleTheme();
    expect(store.theme).toBe('light');

    store.toggleTheme();
    expect(store.theme).toBe('eye-care');

    store.toggleTheme();
    expect(store.theme).toBe('dark');
  });

  it('should toggle theme from eye-care correctly', () => {
    localStorage.setItem('d1-theme', 'eye-care');
    const store = useUIStore();
    expect(store.theme).toBe('eye-care');

    store.toggleTheme();
    expect(store.theme).toBe('dark');
  });

  it('should initialize theme on document', () => {
    const store = useUIStore();
    store.initTheme();
    expect(document.documentElement.getAttribute('data-theme')).toBe('dark');
  });

  it('should initialize eye-care theme on document', () => {
    localStorage.setItem('d1-theme', 'eye-care');
    const store = useUIStore();
    store.initTheme();
    expect(document.documentElement.getAttribute('data-theme')).toBe('eye-care');
  });
});
