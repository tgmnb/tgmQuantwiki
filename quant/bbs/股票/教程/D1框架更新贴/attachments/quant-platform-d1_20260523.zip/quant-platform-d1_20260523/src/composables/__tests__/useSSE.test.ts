import { ref } from 'vue';
import { vi, describe, it, expect, beforeEach } from 'vitest';
import { useSSE } from '../useSSE';

// Mock EventSource
let mockESInstance: any = null;

class MockEventSource {
  url: string;
  onopen: (() => void) | null = null;
  onmessage: ((event: MessageEvent) => void) | null = null;
  onerror: ((event: Event) => void) | null = null;
  readyState: number = EventSource.OPEN;
  
  constructor(url: string) {
    this.url = url;
    // eslint-disable-next-line @typescript-eslint/no-this-alias
    mockESInstance = this;
  }
  
  close() { 
    this.readyState = EventSource.CLOSED; 
    mockESInstance = null;
  }
  
  triggerOpen() { this.onopen?.(); }
  triggerMessage(data: string) { this.onmessage?.(new MessageEvent('message', { data })); }
  triggerError() { this.onerror?.(new Event('error')); }
}

globalThis.EventSource = MockEventSource as any;

describe('useSSE Composable', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    mockESInstance = null;
  });

  it('should initialize with disconnected state', () => {
    const url = ref('http://localhost:8000/api/stream');
    const { connected, error } = useSSE(url);
    
    expect(connected.value).toBe(false);
    expect(error.value).toBe(null);
  });

  it('should connect and set connected to true on open', () => {
    const url = ref('http://localhost:8000/api/stream');
    const { connected, connect } = useSSE(url);
    
    connect();
    mockESInstance?.triggerOpen();
    
    expect(connected.value).toBe(true);
  });

  it('should call onMessage when message received', () => {
    const url = ref('http://localhost:8000/api/stream');
    const onMessage = vi.fn();
    
    const { connect } = useSSE(url, { onMessage });
    connect();
    mockESInstance?.triggerMessage(JSON.stringify({ progress: 50 }));
    
    expect(onMessage).toHaveBeenCalledWith({ progress: 50 });
  });

  it('should call onError when error occurs', () => {
    const url = ref('http://localhost:8000/api/stream');
    const onError = vi.fn();
    
    const { connect } = useSSE(url, { onError });
    connect();
    mockESInstance?.triggerError();
    
    expect(onError).toHaveBeenCalled();
  });

  it('should disconnect and set connected to false', () => {
    const url = ref('http://localhost:8000/api/stream');
    const { connected, connect, disconnect } = useSSE(url);
    
    connect();
    mockESInstance?.triggerOpen();
    expect(connected.value).toBe(true);
    
    disconnect();
    expect(connected.value).toBe(false);
  });

  it('should not connect if url is empty', () => {
    const url = ref('');
    const { connect } = useSSE(url);
    const consoleSpy = vi.spyOn(console, 'error').mockImplementation(() => {});
    
    connect();
    
    expect(mockESInstance).toBe(null); // Should not create EventSource
    consoleSpy.mockRestore();
  });
});
