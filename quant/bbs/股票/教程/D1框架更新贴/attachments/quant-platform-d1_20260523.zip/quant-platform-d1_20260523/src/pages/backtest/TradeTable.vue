<template>
  <div class="bt-section">
    <div class="bt-section__header">
      <span class="bt-section__title">交易记录</span>
      <span style="font-size:11px;color:var(--text-muted);margin-left:auto;">{{ fmtCount(displayTotal) }} 笔</span>
    </div>
    <div style="padding:10px 14px;">
      <!-- Filters -->
      <div class="trade-filters">
        <span class="filter-label">日期:</span>
        <input
          v-model="tradeStartDate"
          type="date"
          class="input date-input"
        >
        <span class="filter-label">至</span>
        <input
          v-model="tradeEndDate"
          type="date"
          class="input date-input"
        >
        <button
          class="btn btn-sm"
          :class="hasActiveFilter ? 'btn-accent' : 'btn-ghost'"
          @click="applyTradeFilter"
        >
          筛选
        </button>
        <button
          v-if="hasActiveFilter"
          class="btn btn-ghost btn-sm"
          @click="clearTradeFilter"
        >
          清空
        </button>
        <div style="flex:1;" />
        <button
          class="btn btn-ghost btn-xs"
          :disabled="tradePage <= 1 || loading"
          @click="changeTradePage(-1)"
        >
          上一页
        </button>
        <span class="filter-label">{{ tradePage }} / {{ localTrades ? localTotalPages : totalPages }}</span>
        <button
          class="btn btn-ghost btn-xs"
          :disabled="tradePage >= (localTrades ? localTotalPages : totalPages) || loading"
          @click="changeTradePage(1)"
        >
          下一页
        </button>
      </div>

      <!-- Table -->
      <div class="table-wrap">
        <Loading
          v-if="loading"
          text="加载中..."
          size="sm"
        />
        <table class="bt-trade-table">
          <thead>
            <tr>
              <th
                v-for="header in (currentTrades?.headers || [])"
                :key="header"
                class="bt-trade-table__th"
                :class="{ 'bt-trade-table__th--active': sortKey === header }"
                @click="handleSort(header)"
              >
                {{ header }}
                <span
                  v-if="sortKey === header"
                  class="sort-icon"
                >{{ sortDir === 'asc' ? '↑' : '↓' }}</span>
              </th>
              <th
                v-if="resolvedPnlCol"
                class="bt-trade-table__th"
                style="width:80px;"
              >
                盈亏
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-if="sortedRows.length === 0 && !loading"
              class="bt-trade-table__empty"
            >
              <td :colspan="(currentTrades?.headers?.length || 0) + (resolvedPnlCol ? 1 : 0)">
                暂无数据
              </td>
            </tr>
            <tr
              v-for="(row, i) in sortedRows"
              :key="i"
              class="bt-trade-table__row"
            >
              <td
                v-for="header in (currentTrades?.headers || [])"
                :key="header"
                :class="getCellClass(header, row[header])"
              >
                {{ fmtCell(header, row[header]) }}
              </td>
              <td
                v-if="resolvedPnlCol"
                style="padding:4px 8px;"
              >
                <PnLBar
                  :val="row[resolvedPnlCol]"
                  :max-abs="maxAbsPnL"
                />
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed } from 'vue';
import type { PropType } from 'vue';
import { backtestApi } from '@/api/backtest';
import PnLBar from './PnLBar.vue';

interface TradeData {
  headers?: string[];
  rows?: Record<string, any>[];
  total?: number;
  page?: number;
  page_size?: number;
  path?: string;
}

const props = defineProps({
  trades: {
    type: Object as PropType<TradeData>,
    required: true,
  },
  pnlCol: {
    type: String as PropType<string | null>,
    default: null,
  },
  /** 回测详情路径（用于翻页API） */
  detailPath: {
    type: String as PropType<string>,
    default: '',
  },
  /** 策略base（用于翻页API） */
  strategyBase: {
    type: String as PropType<string>,
    default: '',
  },
});

const tradePage = ref(1);
const localTrades = ref<TradeData | null>(null);
const loading = ref(false);
const sortKey = ref<string | null>(null);
const sortDir = ref<'asc' | 'desc'>('asc');
const tradeStartDate = ref('');
const tradeEndDate = ref('');

// True when either date field has a value (used to style the filter button and show the clear button)
const hasActiveFilter = computed(() => tradeStartDate.value !== '' || tradeEndDate.value !== '');

// Pass start/end dates explicitly to avoid stale closure issues
async function loadTradePage(page: number, startDate?: string, endDate?: string) {
  try {
    loading.value = true;
    const path = props.detailPath || (props.trades as TradeData).path || '';
    const base = props.strategyBase ?? '';
    const d: any = await backtestApi.getDetail(path, base, {
      trade_page: page,
      start_date: startDate || undefined,
      end_date: endDate || undefined,
    });
    localTrades.value = d.trades;
  } catch (e) {
    console.error('Failed to load trade page', e);
    ElMessage.error('加载交易记录失败，请重试');
  } finally {
    loading.value = false;
  }
}

// Computed total pages based on the currently-displayed data source.
// Uses props fallback when localTrades hasn't been loaded yet (initial render or after filter cleared).
const localTotalPages = computed(() => {
  const lt = localTrades.value;
  const src = lt || props.trades;
  if (!src) return 1;
  return Math.ceil((src.total || 0) / (src.page_size || 30));
});

async function changeTradePage(delta: number) {
  if (loading.value) return;
  const fallbackTrades = props.trades;
  const ct = localTrades.value || fallbackTrades;
  if (!ct) return;
  const newPage = tradePage.value + delta;
  const totalP = Math.ceil((ct.total || 0) / (ct.page_size || fallbackTrades?.page_size || 30));
  if (newPage < 1 || newPage > totalP) return;
  localTrades.value = null; // clear FIRST so UI transitions to loading state
  tradePage.value = newPage;
  await loadTradePage(newPage, tradeStartDate.value, tradeEndDate.value);
}

async function applyTradeFilter() {
  if (loading.value) return;
  localTrades.value = null; // clear FIRST so currentTrades shows nothing while loading
  tradePage.value = 1;
  await loadTradePage(1, tradeStartDate.value, tradeEndDate.value);
}

async function clearTradeFilter() {
  if (loading.value) return;
  tradeStartDate.value = '';
  tradeEndDate.value = '';
  localTrades.value = null;
  tradePage.value = 1;
  await loadTradePage(1);
}

function handleSort(key: string) {
  if (sortKey.value === key) {
    sortDir.value = sortDir.value === 'asc' ? 'desc' : 'asc';
  } else {
    sortKey.value = key;
    sortDir.value = 'asc';
  }
}

const currentTrades = computed(() => localTrades.value || props.trades);

// Show filtered total when filtering (localTrades), original total otherwise
const displayTotal = computed(() => localTrades.value?.total ?? props.trades?.total ?? 0);

const sortedRows = computed(() => {
  if (!sortKey.value || !currentTrades.value?.rows) return currentTrades.value?.rows || [];
  return [...(currentTrades.value.rows as Record<string, any>[])].sort((a, b) => {
    const av = a[sortKey.value!];
    const bv = b[sortKey.value!];
    const an = parseFloat(av as string);
    const bn = parseFloat(bv as string);
    const cmp = isNaN(an) || isNaN(bn) ? String(av).localeCompare(String(bv)) : an - bn;
    return sortDir.value === 'asc' ? cmp : -cmp;
  });
});

const resolvedPnlCol = computed(() => {
  if (props.pnlCol) return props.pnlCol;
  if (!currentTrades.value?.headers) return null;
  return (currentTrades.value.headers as string[]).find((h: string) => /盈亏|收益|pnl/i.test(h)) || null;
});

const maxAbsPnL = computed(() => {
  if (!resolvedPnlCol.value || !currentTrades.value?.rows) return 0;
  const vals = (currentTrades.value.rows as Record<string, any>[]).map((r) =>
    Math.abs(parseFloat(r[resolvedPnlCol.value!]) || 0)
  );
  return Math.max(...vals, 1);
});

const totalPages = computed(() => {
  // When localTrades is null, we haven't loaded filtered data yet
  // Use the original props.trades total only as initial fallback
  if (!currentTrades.value) return 1;
  return Math.ceil((currentTrades.value.total || 0) / (currentTrades.value.page_size || 30));
});

// 判断是否为小时/分钟级别策略（根据路径中的关键词）
const isHourlyStrategy = computed(() => {
  const path = props.detailPath || (props.trades as TradeData).path || '';
  return /1h|minute|hour/i.test(path);
});

// ── Number formatters ─────────────────────────────────
const PRICE_KEYS = ['价格', '收盘价', '成交价', '成本价'];
const VOLUME_KEYS = ['成交量'];
const AMOUNT_KEYS = ['成交额', '总资产', '市值', '持仓市值', '资金余额'];
const FEE_KEYS = ['手续费', '印花税', '佣金', '滑点'];

function fmtCell(header: string, raw: any): string {
  if (raw === null || raw === undefined || raw === '') return '--';

  // 时间/日期列特殊处理
  const headerLow = header.toLowerCase();
  const isTimeCol = /时间|日期|date|datetime/.test(headerLow);
  if (isTimeCol) {
    const s = String(raw).trim();
    // 日线策略：只显示日期部分 YYYY-MM-DD
    if (!isHourlyStrategy.value) {
      return s.length >= 10 ? s.slice(0, 10) : s;
    }
    // 小时策略：显示到秒
    if (s.includes(' ')) {
      const [datePart, timePart] = s.split(' ');
      const parts = timePart.split(':');
      if (parts.length === 2) return `${datePart} ${parts[0]}:${parts[1]}:00`;
      if (parts.length >= 3) return `${datePart} ${parts[0]}:${parts[1]}:${parts[2].padStart(2, '0')}`;
    }
    return s;
  }

  const n = parseFloat(raw);
  if (isNaN(n)) return String(raw);

  if (PRICE_KEYS.some((k) => header.includes(k))) return n.toFixed(2);
  if (VOLUME_KEYS.some((k) => header.includes(k)))
    return n.toLocaleString('en-US', { maximumFractionDigits: 0 });
  if (AMOUNT_KEYS.some((k) => header.includes(k)))
    return n.toLocaleString('en-US', { maximumFractionDigits: 2 });
  if (FEE_KEYS.some((k) => header.includes(k))) return n.toFixed(2);

  // Fallback: format large numbers with commas
  if (Math.abs(n) >= 10000) return n.toLocaleString('en-US', { maximumFractionDigits: 2 });
  if (Number.isInteger(n)) return String(n);
  return n.toFixed(2);
}

function fmtCount(n?: number): string {
  if (!n) return '0';
  return n.toLocaleString('en-US');
}

function getCellClass(header: string, raw: any): string {
  const isAction = /动作|方向|action/i.test(header);
  if (isAction) {
    if (/买|多|买入|buy/i.test(String(raw))) return 'cell--buy';
    if (/卖|空|卖出|sell/i.test(String(raw))) return 'cell--sell';
  }
  return 'cell--neutral';
}
</script>

<style scoped>
.bt-section {
  background: var(--bg-secondary);
  border: 1px solid var(--border);
  border-radius: var(--radius, 8px);
  overflow: hidden;
  margin-bottom: var(--space-5);
}
.bt-section__header {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: var(--space-4) var(--space-6);
  background: var(--bg-secondary);
  border-bottom: 1px solid var(--border);
}
.bt-section__title {
  font-size: var(--font-xs);
  font-weight: 600;
  color: var(--text-secondary);
  text-transform: uppercase;
  letter-spacing: 0.4px;
}

.trade-filters {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  overflow-x: auto;
  margin-bottom: var(--space-4);
}
.filter-label { font-size: var(--font-xs); color: var(--text-muted); white-space: nowrap; }
.date-input { font-size: var(--font-xs); height: 28px; min-width: 120px; }

.table-wrap {
  overflow-x: auto;
  border-radius: var(--radius);
  border: 1px solid var(--border);
  position: relative;
  min-height: 80px;
}

.bt-trade-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-xs);
}
.bt-trade-table__th {
  padding: 5px 12px;
  text-align: left;
  font-weight: 600;
  color: var(--text-muted);
  background: var(--bg-tertiary);
  border-bottom: 1px solid var(--border);
  cursor: pointer;
  user-select: none;
  white-space: nowrap;
  height: var(--h-md);
  font-size: var(--font-2xs);
  text-transform: uppercase;
  letter-spacing: 0.5px;
}
.bt-trade-table__th:hover { background: var(--bg-tertiary); filter: brightness(1.05); }
.bt-trade-table__th--active { color: var(--accent) !important; }
.sort-icon { margin-left: 3px; }
.bt-trade-table__row {
  border-bottom: 1px solid var(--border);
  transition: background 0.1s;
}
.bt-trade-table__row:hover { background: rgba(99, 102, 241, 0.05); }
.bt-trade-table__row:last-child { border-bottom: none; }
.bt-trade-table__empty td {
  padding: var(--space-10) var(--space-5);
  text-align: center;
  color: var(--text-muted);
  font-size: var(--font-sm);
}
.bt-trade-table__row td {
  padding: var(--space-2) var(--space-5);
  color: var(--text-secondary);
  font-variant-numeric: tabular-nums;
  font-family: var(--font-mono, monospace);
  font-size: var(--font-xs);
}
.cell--up { color: var(--up) !important; }
.cell--down { color: var(--down) !important; }
.cell--neutral { color: var(--text-secondary) !important; }
.cell--buy { color: #ef4444 !important; font-weight: 600; }
.cell--sell { color: #22c55e !important; font-weight: 600; }

.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  padding: var(--space-1) var(--space-4);
  border-radius: 5px;
  font-size: var(--font-sm);
  cursor: pointer;
  border: 1px solid transparent;
  font-weight: 500;
  transition: all 0.15s;
}
.btn-ghost {
  background: transparent;
  color: var(--text-muted);
  border-color: var(--border);
}
.btn-ghost:hover { background: var(--bg-hover); color: var(--text-primary); }
.btn-ghost:disabled { opacity: 0.4; cursor: not-allowed; }
.btn-accent {
  background: var(--accent);
  color: #fff;
  border-color: var(--accent);
}
.btn-accent:hover { filter: brightness(1.1); }
.btn-sm { padding: 2px 8px; font-size: var(--font-xs); }
.btn-xs { padding: 1px 6px; font-size: var(--font-2xs); }
.filter-loading { font-size: var(--font-xs); color: var(--accent); }
.input {
  border: 1px solid var(--border);
  border-radius: 5px;
  padding: 0 8px;
  font-family: inherit;
  color: var(--text-primary);
  background: var(--bg-primary);
  outline: none;
}
.input:focus { border-color: var(--accent); }
</style>
