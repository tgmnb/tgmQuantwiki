from . import register_node

register_node({
    "id": "display_results",
    "type": "atomic",
    "name": "\u5c55\u793a\u7ee9\u6548\u62a5\u544a",
    "description": "\u5728\u5e73\u53f0\u4e0a\u5c55\u793a\u56de\u6d4b\u7ee9\u6548\u56fe\u8868\u548c\u5173\u952e\u6307\u6807",
    "icon": "icon-chart",
    "category": "\u8f93\u51fa",
    "slots_in": [
        {"id": "backtest_result", "name": "\u56de\u6d4b\u7ed3\u679c", "type": "file", "required": True},
    ],
    "slots_out": [],
    "params": [
        {
            "id": "show_metrics",
            "name": "\u5c55\u793a\u7ee9\u6548\u6307\u6807",
            "type": "bool",
            "default": True,
            "ui": {"widget": "checkbox"},
        },
        {
            "id": "show_equity_curve",
            "name": "\u5c55\u793a\u51c0\u503c\u66f2\u7ebf",
            "type": "bool",
            "default": True,
            "ui": {"widget": "checkbox"},
        },
    ],
    "script": "workflow/\u5c55\u793a\u7ed3\u679c.py",
    "func": "\u5c55\u793a\u7ed3\u679c",
    "conda_env": "quantpy312",
    "note": "\u524d\u7aef\u5c55\u793a\u56de\u6d4b\u7ee9\u6548\uff0c\u542b\u51c0\u503c\u66f2\u7ebf\u56fe\u3001\u6700\u5927\u56de\u64a4\u3001\u590f\u666e\u6bd4\u7387\u7b49\u5173\u952e\u6307\u6807",
})
