import { request } from './request';
import type {
  StrategyListResponse,
  BacktestDetailResponse,
  TradeStocksResponse,
  TradesByStockResponse,
  CompareResponse,
} from '@/types/api';

export const backtestApi = {
  /** 获取策略列表 */
  async getList(): Promise<StrategyListResponse> {
    return request.get('/api/backtest/list');
  },

  /** 获取回测详情（12 项指标 + 净值 + 分页交易记录 + PnL 分布） */
  async getDetail(
    path: string,
    base: string = '',
    options?: { trade_page?: number; start_date?: string; end_date?: string }
  ): Promise<BacktestDetailResponse> {
    const params: Record<string, string> = { path, base };
    if (options?.trade_page) params.trade_page = String(options.trade_page);
    if (options?.start_date) params.start_date = options.start_date;
    if (options?.end_date) params.end_date = options.end_date;
    return request.get('/api/backtest/detail', { params });
  },

  /** 多策略对比（LRU 缓存 + 并发加载） */
  async compare(paths: string[], bases: string[]): Promise<CompareResponse> {
    const params = new URLSearchParams();
    paths.forEach((p) => params.append('paths', p));
    bases.forEach((b) => params.append('bases', b));
    return request.get(`/api/backtest/compare?${params.toString()}`);
  },

  /** 获取交易股票列表（按交易次数降序） */
  async getTradeStocks(path: string, base: string = ''): Promise<TradeStocksResponse> {
    const params: Record<string, string> = { path, base };
    return request.get('/api/backtest/trade_stocks', { params });
  },

  /** 按股票获取交易记录（支持分页和模糊代码匹配） */
  async getTradesByStock(
    path: string,
    base: string = '',
    stockCode: string
  ): Promise<TradesByStockResponse> {
    const params: Record<string, string> = { path, base, stock_code: stockCode };
    return request.get('/api/backtest/trades_by_stock', { params });
  },
};
