<template>
  <Teleport to="body">
    <div
      class="modal-overlay"
      @click.self="emit('close')"
    >
      <div class="modal">
        <div class="modal__header">
          <h3>新建工作流</h3>
          <button
            class="modal__close"
            @click="emit('close')"
          >
            ×
          </button>
        </div>

        <div class="modal__body">
          <div class="form-field">
            <label class="form-field__label">名称</label>
            <input
              v-model="name"
              type="text"
              placeholder="My Workflow"
              class="form-field__input"
              @keyup.enter="handleCreate"
            >
          </div>

          <div class="form-field">
            <label class="form-field__label">描述</label>
            <input
              v-model="description"
              type="text"
              placeholder="可选描述"
              class="form-field__input"
              @keyup.enter="handleCreate"
            >
          </div>

          <div class="form-field">
            <label class="form-field__label">分类</label>
            <el-select
              v-model="category"
              placeholder="请选择分类"
              class="form-field__input"
            >
              <el-option
                v-for="opt in categoryOptions"
                :key="opt.value"
                :label="opt.label"
                :value="opt.value"
              />
            </el-select>
          </div>

          <div class="form-field">
            <label class="form-field__label">从模板创建</label>
            <div class="template-grid">
              <div
                class="template-card"
                :class="{ active: selectedTemplate === null }"
                @click="selectedTemplate = null"
              >
                <span class="template-card__icon">📄</span>
                <span class="template-card__name">空白工作流</span>
                <span class="template-card__desc">从零开始构建</span>
              </div>
              <div
                v-for="tpl in templates"
                :key="tpl.id"
                class="template-card"
                :class="{ active: selectedTemplate?.id === tpl.id }"
                @click="selectedTemplate = tpl"
              >
                <span class="template-card__icon">📋</span>
                <span class="template-card__name">{{ tpl.name }}</span>
                <span class="template-card__desc">{{ tpl.description }}</span>
              </div>
            </div>
          </div>
        </div>

        <div class="modal__footer">
          <button
            class="btn btn--secondary"
            @click="emit('close')"
          >
            取消
          </button>
          <button
            class="btn btn--primary"
            :disabled="!name.trim()"
            @click="handleCreate"
          >
            创建
          </button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import type { WorkflowTemplate } from '@/types/api'
import { workflowApi } from '@/api/workflow'

const emit = defineEmits<{
  (e: 'close'): void
  (e: 'create', body: {
    name: string
    description: string
    category: string
    steps: WorkflowTemplate['steps']
  }): void
}>()

const name = ref('')
const description = ref('')
const category = ref('factor')
const selectedTemplate = ref<WorkflowTemplate | null>(null)
const templates = ref<WorkflowTemplate[]>([])

const categoryOptions = [
  { label: '因子', value: 'factor' },
  { label: '选股', value: 'selection' },
  { label: '回测', value: 'backtest' },
  { label: '综合', value: 'composite' },
]

onMounted(async () => {
  try {
    const data = await workflowApi.listTemplates()
    templates.value = data.templates || []
  } catch {
    // templates remain empty
  }
})

function handleCreate() {
  if (!name.value.trim()) return

  const steps = selectedTemplate.value
    ? selectedTemplate.value.steps.map(s => ({
        ...s,
        id: `step_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      }))
    : []

  emit('create', {
    name: name.value.trim(),
    description: description.value,
    category: category.value,
    steps,
  })
}
</script>

<style scoped>
.modal-overlay {
  position: fixed;
  inset: 0;
  z-index: 500;
  background: rgba(0, 0, 0, 0.6);
  display: flex;
  align-items: center;
  justify-content: center;
}

.modal {
  background: var(--bg-secondary, #1e1e2e);
  border: 1px solid var(--border-color, #3a3a4a);
  border-radius: 12px;
  width: 520px;
  max-height: 80vh;
  overflow: hidden;
  display: flex;
  flex-direction: column;
}

.modal__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  border-bottom: 1px solid var(--border-color, #3a3a4a);
}

.modal__header h3 {
  margin: 0;
  font-size: 15px;
  font-weight: 600;
  color: var(--text-primary, #e0e0e0);
}

.modal__close {
  background: none;
  border: none;
  font-size: 20px;
  color: var(--text-muted, #888);
  cursor: pointer;
  padding: 0;
  line-height: 1;
}

.modal__close:hover {
  color: var(--text-primary, #e0e0e0);
}

.modal__body {
  flex: 1;
  overflow-y: auto;
  padding: 20px 24px;
}

.modal__footer {
  display: flex;
  justify-content: flex-end;
  gap: 8px;
  padding: 16px 24px;
  border-top: 1px solid var(--border-color, #3a3a4a);
}

.form-field {
  margin-bottom: 12px;
}

.form-field__label {
  display: block;
  font-size: 12px;
  color: var(--text-muted, #888);
  margin-bottom: 4px;
}

.form-field__input {
  width: 100%;
  padding: 7px 10px;
  background: var(--bg-primary, #181825);
  border: 1px solid var(--border-color, #3a3a4a);
  border-radius: 6px;
  color: var(--text-primary, #e0e0e0);
  font-size: 13px;
  box-sizing: border-box;
  outline: none;
}

.form-field__input:focus {
  border-color: var(--accent, #7c3aed);
}

.btn {
  padding: 6px 16px;
  border-radius: 6px;
  font-size: 13px;
  cursor: pointer;
  border: 1px solid transparent;
  display: inline-flex;
  align-items: center;
  gap: 4px;
  transition: all 0.15s;
}

.btn--primary {
  background: var(--accent, #7c3aed);
  color: white;
  border-color: var(--accent, #7c3aed);
}

.btn--primary:hover {
  opacity: 0.9;
}

.btn--primary:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn--secondary {
  background: var(--bg-tertiary, #2a2a3a);
  color: var(--text-secondary, #b0b0b0);
  border-color: var(--border-color, #3a3a4a);
}

.template-grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
}

.template-card {
  display: flex;
  flex-direction: column;
  gap: 4px;
  padding: 10px 12px;
  border: 1px solid var(--border-color, #3a3a4a);
  border-radius: 8px;
  cursor: pointer;
  transition: all 0.15s;
  background: var(--bg-primary, #181825);
}

.template-card:hover {
  border-color: var(--accent, #7c3aed);
}

.template-card.active {
  border-color: var(--accent, #7c3aed);
  background: var(--bg-tertiary, #2a2a3a);
}

.template-card__icon {
  font-size: 18px;
}

.template-card__name {
  font-size: 13px;
  font-weight: 500;
  color: var(--text-primary, #e0e0e0);
}

.template-card__desc {
  font-size: 11px;
  color: var(--text-muted, #888);
}
</style>
