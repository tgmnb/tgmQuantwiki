<template>
  <div
    ref="panelRef"
    class="log-panel"
    :style="{ maxHeight: panelHeight + 'px' }"
  >
    <div class="log-panel__toolbar">
      <div class="log-panel__toolbar-left">
        <span class="log-panel__title">日志</span>
        <span
          v-if="logCountInfo"
          class="log-panel__count"
        >{{ logCountInfo }}</span>
        <span
          v-if="currentStepName"
          class="log-panel__step"
        >· {{ currentStepName }}</span>
      </div>
      <div class="log-panel__toolbar-center">
        <div class="log-panel__filter">
          <span class="log-panel__search-icon">🔍</span>
          <input
            type="text"
            :value="logFilter"
            placeholder="过滤..."
            class="log-panel__filter-input"
            @input="emit('filterChange', ($event.target as HTMLInputElement).value)"
          >
          <span
            v-if="logFilter"
            class="log-panel__clear"
            @click="emit('filterChange', '')"
          >✕</span>
        </div>
        <select
          v-if="stepNames.length > 1"
          class="log-panel__select"
          :value="stepFilter"
          @change="emit('stepFilterChange', ($event.target as HTMLSelectElement).value)"
        >
          <option value="">
            全部步骤
          </option>
          <option
            v-for="name in stepNames"
            :key="name"
            :value="name"
          >
            {{ name }}
          </option>
        </select>
        <div class="log-panel__level-btns">
          <button
            v-for="lv in [{key:'',label:'全部'},{key:'error',label:'错误'},{key:'warn',label:'警告'},{key:'success',label:'成功'}]"
            :key="lv.key"
            class="log-panel__level-btn"
            :class="{ active: levelFilter === lv.key }"
            @click="emit('levelFilterChange', lv.key)"
          >
            {{ lv.label }}
          </button>
        </div>
      </div>
      <div class="log-panel__toolbar-right">
        <el-button
          link
          size="small"
          :icon="DocumentCopy"
          @click="handleCopy"
        />
        <el-button
          link
          size="small"
          :icon="Download"
          @click="handleExport"
        />
        <button
          class="btn btn--sm btn--ghost"
          @click="emit('clear')"
        >
          清空
        </button>
      </div>
    </div>

    <!-- Step execution summary bar -->
    <div
      v-if="summaryCounts.total > 0"
      class="log-summary"
    >
      <span class="log-summary__item log-summary__item--done">✓ {{ summaryCounts.done }}</span>
      <span class="log-summary__item log-summary__item--failed">✗ {{ summaryCounts.failed }}</span>
      <span class="log-summary__item log-summary__item--running">⟳ {{ summaryCounts.running }}</span>
      <span class="log-summary__item log-summary__item--pending">○ {{ summaryCounts.pending }}</span>
      <span class="log-summary__total">{{ summaryCounts.total }} 步骤</span>
    </div>

    <!-- Execution Results Summary -->
    <div
      v-if="hasCompletedSteps"
      class="exec-results"
    >
      <div
        class="exec-results__header"
        @click="execResultsExpanded = !execResultsExpanded"
      >
        <span class="exec-results__title">📊 执行结果</span>
        <span
          class="exec-results__overall-badge"
          :class="overallStatusClass"
        >{{ overallStatusLabel }}</span>
        <span class="exec-results__toggle">
          {{ execResultsExpanded ? '收起' : '展开' }}
        </span>
      </div>
      <div
        v-if="execResultsExpanded"
        class="exec-results__list"
      >
        <div
          v-for="result in completedStepResults"
          :key="result.id"
          class="exec-results__step"
          :class="{ 'exec-results__step--failed': result.status === 'failed' }"
        >
          <div class="exec-results__step-header">
            <span class="exec-results__step-icon">{{ result.status === 'done' ? '✓' : '✗' }}</span>
            <span class="exec-results__step-name">{{ result.name }}</span>
            <span
              v-if="result.duration"
              class="exec-results__step-duration"
            >{{ result.duration }}</span>
            <button
              class="exec-results__view-log"
              @click="scrollToStepLog(result.name)"
            >
              查看日志
            </button>
          </div>
          <div
            v-if="result.status === 'done'"
            class="exec-results__step-detail exec-results__step-detail--success"
          >
            执行成功
          </div>
          <div
            v-if="result.status === 'failed' && result.errorMsg"
            class="exec-results__step-detail exec-results__step-detail--error"
          >
            {{ result.errorMsg }}
          </div>
        </div>
      </div>
    </div>

    <div
      ref="logContainerRef"
      class="log-panel__content"
      @scroll="onScrollThrottled"
    >
      <div
        v-if="filteredLines.length === 0"
        class="log-panel__empty"
      >
        {{ running ? '等待输出...' : '点击运行按钮执行工作流，日志将实时显示在这里' }}
      </div>
      <div
        v-else
        :style="{ height: totalHeight + 'px', position: 'relative' }"
      >
        <div :style="{ transform: `translateY(${offsetY}px)`, position: 'absolute', left: 0, right: 0 }">
          <div
            v-for="(line, vi) in visibleLines"
            :key="startIndex + vi"
            class="log-panel__line"
            :class="getLineClass(line)"
          >
            <!-- 行号 -->
            <span class="log-panel__line-no">{{ String(startIndex + vi + 1).padStart(3, '0') }}</span>
            <div class="log-panel__line-meta">
              <span class="log-panel__timestamp">{{ formatTimeAgo(logTimestamps[startIndex + vi] || Date.now()) }}</span>
              <span
                v-if="getLogBadge(line)"
                class="badge"
                :class="getLogBadge(line)!.class"
              >{{ getLogBadge(line)!.text }}</span>
            </div>
            <span class="log-panel__line-text">{{ line }}</span>
          </div>
        </div>
      </div>

      <Transition name="scroll-btn">
        <button
          v-if="showScrollBottom"
          class="log-panel__scroll-bottom"
          @click="scrollToBottom"
        >
          <span class="log-panel__scroll-bottom-icon">↓</span>
          <span
            v-if="newLogCount > 0"
            class="log-panel__scroll-bottom-badge"
          >{{ newLogCount }}+</span>
        </button>
      </Transition>
    </div>

    <div
      class="log-panel__resize-handle"
      @mousedown="startResize"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, nextTick, onMounted, onUnmounted } from 'vue';
import { DocumentCopy, Download } from '@element-plus/icons-vue';
import type { WorkflowStep } from '@/types';

interface Props {
  logLines: string[];
  logFilter?: string;
  stepFilter?: string;
  levelFilter?: string;
  running?: boolean;
  currentStepName?: string;
  stepStatusMap?: Record<string, string>;
  steps?: WorkflowStep[];
}

const props = withDefaults(defineProps<Props>(), {
  logLines: () => [],
  logFilter: '',
  stepFilter: '',
  levelFilter: '',
  running: false,
  currentStepName: '',
  stepStatusMap: () => ({}),
  steps: () => [],
});

const emit = defineEmits<{
  (e: 'clear'): void;
  (e: 'filterChange', value: string): void;
  (e: 'stepFilterChange', value: string): void;
  (e: 'levelFilterChange', value: string): void;
}>();

const logContainerRef = ref<HTMLElement | null>(null);
const panelRef = ref<HTMLElement | null>(null);
const logTimestamps = ref<number[]>([]);
const panelHeight = ref(300);
const execResultsExpanded = ref(false);

const ANSI_RE = /\x1b\[[0-9;]*[a-zA-Z]/g; // eslint-disable-line no-control-regex

/** 进度行去重：相同 [step] + 相同 progress 格式 只保留最新一条 */
const PROGRESS_RE = /^\[([^\]]+)\]\s*(\d+(?:\.\d+)?%)\s*$/;

function deduplicateProgressLines(rawLines: string[]): string[] {
  const lastProgressStep = new Map<string, string>();
  const removedSet = new Set<number>();
  for (let i = rawLines.length - 1; i >= 0; i--) {
    const line = rawLines[i];
    const m = line.match(PROGRESS_RE);
    if (m) {
      const stepKey = m[1]; // e.g. "因子计算"
      const progress = m[2]; // e.g. "50%"
      const key = `${stepKey}:${progress}`;
      if (lastProgressStep.has(key)) {
        removedSet.add(i);
      }
      lastProgressStep.set(key, line);
    }
  }
  return rawLines.filter((_, idx) => !removedSet.has(idx));
}

const deduplicatedLines = computed(() => deduplicateProgressLines(props.logLines.map(line => line.replace(ANSI_RE, ''))));

const filteredLines = computed(() => {
  let lines = deduplicatedLines.value;
  if (props.stepFilter) {
    lines = lines.filter(line => line.includes(`[${props.stepFilter}]`));
  }
  if (props.levelFilter) {
    const filterMap: Record<string, (line: string) => boolean> = {
      'error': (line) => /ERROR|错误|❌|failed|Exception/i.test(line),
      'warn': (line) => /WARN|警告|Warning/i.test(line),
      'success': (line) => /SUCCESS|完成|✔|done|success/i.test(line),
    };
    const fn = filterMap[props.levelFilter];
    if (fn) lines = lines.filter(fn);
  }
  if (props.logFilter) {
    const q = props.logFilter.toLowerCase();
    lines = lines.filter(line => line.toLowerCase().includes(q));
  }
  return lines;
});

const logCountInfo = computed(() => {
  const total = props.logLines.length;
  const filtered = filteredLines.value.length;
  if (total === 0) return '';
  if (filtered === total) return `${total} 行`;
  return `${filtered}/${total} 行`;
});

const stepNames = computed(() => {
  const statusKeys = Object.keys(props.stepStatusMap)
  if (statusKeys.length > 0) return statusKeys
  const names = new Set<string>()
  const regex = /\[([^\]]+)\]/g
  for (const line of deduplicatedLines.value) {
    let match
    while ((match = regex.exec(line)) !== null) {
      names.add(match[1])
    }
  }
  return Array.from(names)
})

const summaryCounts = computed(() => {
  const map = props.stepStatusMap;
  let done = 0;
  let failed = 0;
  let running = 0;
  let pending = 0;
  for (const status of Object.values(map)) {
    if (status === 'done') done++;
    else if (status === 'failed') failed++;
    else if (status === 'running') running++;
    else pending++;
  }
  return { done, failed, running, pending, total: done + failed + running + pending };
});

const hasCompletedSteps = computed(() => {
  const map = props.stepStatusMap;
  return Object.values(map).some(s => s === 'done' || s === 'failed');
});

interface StepResult {
  id: string;
  name: string;
  status: string;
  duration: string;
  errorMsg: string;
}

const completedStepResults = computed<StepResult[]>(() => {
  const map = props.stepStatusMap;
  const results: StepResult[] = [];

  for (const [stepId, status] of Object.entries(map)) {
    if (status !== 'done' && status !== 'failed') continue;

    const step = props.steps.find(s => s.id === stepId);
    const name = step?.name || stepId;

    const duration = extractStepDuration(stepId, name);

    const errorMsg = status === 'failed' ? extractStepError(stepId, name) : '';

    results.push({ id: stepId, name, status, duration, errorMsg });
  }

  return results;
});

const overallStatusClass = computed(() => {
  const c = summaryCounts.value;
  if (c.failed > 0 && c.done === 0) return 'exec-results__overall-badge--failed';
  if (c.failed > 0 && c.done > 0) return 'exec-results__overall-badge--partial';
  return 'exec-results__overall-badge--success';
});

const overallStatusLabel = computed(() => {
  const c = summaryCounts.value;
  if (c.failed > 0 && c.done === 0) return '✗ 全部失败';
  if (c.failed > 0 && c.done > 0) return '⚠ 部分成功';
  if (c.done > 0 && c.running === 0 && c.pending === 0) return '✓ 全部完成';
  return '运行中...';
});

function extractStepDuration(stepId: string, stepName: string): string {
  const lines = deduplicatedLines.value;
  for (const line of lines) {
    if (!line.includes(stepName) && !line.includes(stepId)) continue;
    const match = line.match(/(?:耗时|duration|took|用时)\s*:?\s*([\d.]+\s*(?:s|ms|min|sec|秒|分钟))/i);
    if (match) return match[1];
  }
  return '';
}

function extractStepError(stepId: string, stepName: string): string {
  const lines = deduplicatedLines.value;
  const errorLines: string[] = [];
  let inStepSection = false;

  for (const line of lines) {
    if (line.includes(`[${stepName}]`) || line.includes(`[${stepId}]`)) {
      inStepSection = true;
    }
    const stepMatch = line.match(/\[([^\]]+)\]/);
    if (stepMatch && stepMatch[1] !== stepName && stepMatch[1] !== stepId) {
      inStepSection = false;
    }

    if (inStepSection && /ERROR|Error|错误|Exception|Traceback|失败|failed/i.test(line)) {
      const cleaned = line.replace(/^\[?[^\]]*\]\s*/, '').trim();
      if (cleaned) errorLines.push(cleaned);
    }
  }

  if (errorLines.length === 0) return '步骤执行失败';
  const last = errorLines[errorLines.length - 1];
  return last.length > 200 ? last.substring(0, 200) + '...' : last;
}

function scrollToStepLog(stepName: string): void {
  emit('stepFilterChange', stepName);
  nextTick(() => {
    if (logContainerRef.value) {
      logContainerRef.value.scrollTop = 0;
    }
  });
}

const BASE_LINE_HEIGHT = 24;
const CHARS_PER_LINE = 80;

function estimateLineHeight(line: string): number {
  const extraLines = Math.max(0, Math.ceil(line.length / CHARS_PER_LINE) - 1);
  return BASE_LINE_HEIGHT + extraLines * BASE_LINE_HEIGHT;
}

const scrollTop = ref(0);
const containerHeight = ref(300);

const lineHeights = computed(() => filteredLines.value.map(line => estimateLineHeight(line)));
const totalHeight = computed(() => lineHeights.value.reduce((sum, h) => sum + h, 0));

const startIndex = computed(() => {
  let accumulated = 0;
  for (let i = 0; i < lineHeights.value.length; i++) {
    if (accumulated >= scrollTop.value - 200) return Math.max(0, i - 5);
    accumulated += lineHeights.value[i];
  }
  return 0;
});

const endIndex = computed(() => {
  const heights = lineHeights.value;
  let accumulated = 0;
  for (let i = 0; i < heights.length; i++) {
    accumulated += heights[i];
    if (accumulated > scrollTop.value + containerHeight.value + 200) {
      return Math.min(heights.length, i + 5);
    }
  }
  return heights.length;
});

const visibleLines = computed(() => filteredLines.value.slice(startIndex.value, endIndex.value));
const offsetY = computed(() => {
  let offset = 0;
  for (let i = 0; i < startIndex.value; i++) {
    offset += lineHeights.value[i];
  }
  return offset;
});

const SCROLL_BOTTOM_THRESHOLD = 80;

const isNearBottom = ref(true);
const showScrollBottom = ref(false);
const newLogCount = ref(0);

function checkNearBottom(): boolean {
  const el = logContainerRef.value;
  if (!el) return true;
  return el.scrollHeight - el.scrollTop - el.clientHeight < SCROLL_BOTTOM_THRESHOLD;
}

let _rafId: number | null = null
function onScrollThrottled() {
  if (_rafId !== null) return
  _rafId = requestAnimationFrame(() => {
    _rafId = null
    if (logContainerRef.value) {
      scrollTop.value = logContainerRef.value.scrollTop
    }
    const near = checkNearBottom()
    isNearBottom.value = near
    showScrollBottom.value = !near && filteredLines.value.length > 0
    if (near) {
      newLogCount.value = 0
    }
  })
}

function scrollToBottom() {
  if (logContainerRef.value) {
    logContainerRef.value.scrollTop = logContainerRef.value.scrollHeight;
    isNearBottom.value = true;
    showScrollBottom.value = false;
    newLogCount.value = 0;
  }
}

let resizeObserver: ResizeObserver | null = null;

onMounted(() => {
  if (logContainerRef.value) {
    containerHeight.value = logContainerRef.value.clientHeight;
    resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        containerHeight.value = entry.contentRect.height;
      }
    });
    resizeObserver.observe(logContainerRef.value);
  }
});

onUnmounted(() => {
  if (resizeObserver) {
    resizeObserver.disconnect();
    resizeObserver = null;
  }
});

function getLineClass(line: string): string {
  if (/SyntaxError|ImportError|ModuleNotFoundError|Traceback|TypeError|ValueError|KeyError|AttributeError|\[ERROR\]|Error:|Exception|错误|失败|failed/i.test(line)) {
    return 'log-line--error';
  }
  if (/\[WARNING\]|Warning|警告|WARN/i.test(line)) return 'log-line--warn';
  if (/✔|完成|done|success|SUCCESS/i.test(line)) return 'log-line--success';
  return '';
}

function formatTimeAgo(ts: number): string {
  const diff = Math.floor((Date.now() - ts) / 1000);
  if (diff < 5) return '刚刚';
  if (diff < 60) return `${diff}秒前`;
  const date = new Date(ts);
  const h = String(date.getHours()).padStart(2, '0');
  const m = String(date.getMinutes()).padStart(2, '0');
  const s = String(date.getSeconds()).padStart(2, '0');
  return `${h}:${m}:${s}`;
}

interface LogBadge {
  text: string;
  class: string;
}

function getLogBadge(line: string): LogBadge | null {
  if (/SyntaxError/i.test(line)) {
    return { text: 'SYNTAX', class: 'badge--syntax-error' };
  }
  if (/ImportError|ModuleNotFoundError/i.test(line)) {
    return { text: 'IMPORT', class: 'badge--import-error' };
  }
  if (/Traceback|TypeError|ValueError|KeyError|AttributeError/i.test(line)) {
    return { text: 'ERR', class: 'badge--error-detail' };
  }
  if (/ERROR|错误|❌|failed|Exception/i.test(line)) {
    return { text: 'ERR', class: 'badge--error' };
  }
  if (/WARN|警告|Warning/i.test(line)) {
    return { text: 'WRN', class: 'badge--warn' };
  }
  if (/SUCCESS|完成|✔|done|success/i.test(line)) {
    return { text: 'OK', class: 'badge--success' };
  }
  return null;
}

function handleCopy(): void {
  navigator.clipboard.writeText(deduplicatedLines.value.join('\n')).then(() => {
    ElMessage.success('日志已复制');
  });
}

async function handleExport(): Promise<void> {
  try {
    const blob = new Blob([deduplicatedLines.value.join('\n')], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `workflow-logs-${Date.now()}.log`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    ElMessage.success('日志导出成功');
  } catch {
    ElMessage.error('日志导出失败');
  }
}

function startResize(e: MouseEvent): void {
  const startY = e.clientY;
  const startHeight = panelHeight.value;

  function onMouseMove(ev: MouseEvent): void {
    const deltaY = startY - ev.clientY;
    let newHeight = startHeight + deltaY;
    newHeight = Math.max(120, Math.min(600, newHeight));
    panelHeight.value = newHeight;
  }

  function onMouseUp(): void {
    window.removeEventListener('mousemove', onMouseMove);
    window.removeEventListener('mouseup', onMouseUp);
  }

  window.addEventListener('mousemove', onMouseMove);
  window.addEventListener('mouseup', onMouseUp);
}

watch(() => props.logLines.length, (newLen, oldLen) => {
  if (newLen > logTimestamps.value.length) {
    const now = Date.now();
    for (let i = logTimestamps.value.length; i < newLen; i++) {
      logTimestamps.value.push(now);
    }
  } else if (newLen === 0) {
    logTimestamps.value = [];
  }

  if (isNearBottom.value) {
    nextTick(() => {
      if (logContainerRef.value) {
        logContainerRef.value.scrollTop = logContainerRef.value.scrollHeight;
      }
    });
  } else {
    const added = newLen - (oldLen || 0);
    if (added > 0) {
      newLogCount.value += added;
      showScrollBottom.value = true;
    }
  }
});

watch(() => props.running, (isRunning) => {
  if (isRunning) {
    isNearBottom.value = true;
    newLogCount.value = 0;
    showScrollBottom.value = false;
  }
});
</script>

<style scoped>
.log-panel {
  width: 100%;
  flex-shrink: 0;
  border-top: 1px solid var(--border-color, #3a3a4a);
  display: flex;
  flex-direction: column;
  overflow: hidden;
  background: var(--bg-primary, #181825);
}

.log-panel__toolbar {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 6px 14px;
  border-bottom: 1px solid var(--border-color, #3a3a4a);
  flex-shrink: 0;
}

.log-panel__toolbar-left {
  display: flex;
  align-items: center;
  gap: 6px;
  flex-shrink: 0;
}

.log-panel__toolbar-center {
  display: flex;
  align-items: center;
  gap: 6px;
  flex: 1;
  min-width: 0;
  justify-content: center;
}

.log-panel__toolbar-right {
  display: flex;
  align-items: center;
  gap: 4px;
  flex-shrink: 0;
}

.log-panel__title {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-secondary, #b0b0b0);
}

.log-panel__count {
  font-size: 10px;
  font-weight: 500;
  color: var(--text-muted, #888);
  background: var(--bg-tertiary, #2a2a3a);
  padding: 1px 6px;
  border-radius: 8px;
}

.log-panel__step {
  color: var(--accent, #7c3aed);
}

.log-panel__filter {
  display: flex;
  align-items: center;
  gap: 4px;
  background: var(--bg-tertiary, #2a2a3a);
  border: 1px solid var(--border-color, #3a3a4a);
  border-radius: 4px;
  padding: 0 6px;
  height: 24px;
}

.log-panel__search-icon {
  font-size: 11px;
  opacity: 0.5;
}

.log-panel__filter-input {
  flex: 1;
  background: none;
  border: none;
  outline: none;
  color: var(--text-primary, #e0e0e0);
  font-size: 11px;
  font-family: var(--font-mono, monospace);
  min-width: 0;
}

.log-panel__filter-input::placeholder {
  color: var(--text-muted, #888);
}

.log-panel__clear {
  cursor: pointer;
  color: var(--text-muted, #888);
  font-size: 10px;
}

.log-panel__clear:hover {
  color: var(--text-primary, #e0e0e0);
}

.log-panel__select {
  height: 24px;
  padding: 0 6px;
  border: 1px solid var(--border-color, #3a3a4a);
  border-radius: 4px;
  background: var(--bg-tertiary, #2a2a3a);
  color: var(--text-primary, #e0e0e0);
  font-size: 11px;
  outline: none;
}

.log-panel__level-btns {
  display: flex;
  gap: 2px;
}

.log-panel__level-btn {
  padding: 2px 6px;
  border: 1px solid var(--border-color, #3a3a4a);
  border-radius: 3px;
  background: transparent;
  color: var(--text-muted, #888);
  font-size: 10px;
  cursor: pointer;
}

.log-panel__level-btn.active {
  background: var(--accent, #7c3aed);
  color: white;
  border-color: var(--accent, #7c3aed);
}

.log-panel__content {
  flex: 1;
  overflow-y: auto;
  padding: 10px 14px;
  font-family: var(--font-mono, monospace);
  font-size: 13px;
  line-height: 1.7;
  color: var(--text-secondary, #b0b0b0);
  position: relative;
}

.log-panel__empty {
  color: var(--text-muted, #888);
  padding: 8px 0;
}

.log-panel__line {
  display: flex;
  align-items: flex-start;
  gap: 8px;
  word-break: break-all;
}

.log-panel__line-meta {
  display: flex;
  align-items: center;
  flex-shrink: 0;
  gap: 4px;
}

.log-panel__timestamp {
  width: 56px;
  flex-shrink: 0;
  color: var(--text-muted, #888);
  font-size: 12px;
}

.log-panel__line-text {
  flex: 1;
}

/* 行号 */
.log-panel__line-no {
  width: 32px;
  flex-shrink: 0;
  color: var(--text-muted, #555);
  font-size: 11px;
  text-align: right;
  padding-right: 4px;
  user-select: none;
}

.log-line--error {
  color: #ef4444;
  font-weight: 600;
}

.log-line--warn {
  color: #f59e0b;
}

.log-line--success {
  color: #10b981;
}

.badge {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  min-width: 28px;
  height: 16px;
  border-radius: 4px;
  font-size: 10px;
  font-weight: 600;
}

.badge--error {
  background: rgba(239, 68, 68, 0.2);
  color: #ef4444;
}

.badge--syntax-error {
  background: rgba(239, 68, 68, 0.3);
  color: #f87171;
  border: 1px solid rgba(236, 72, 153, 0.5);
}

.badge--import-error {
  background: rgba(249, 115, 22, 0.2);
  color: #fb923c;
}

.badge--error-detail {
  background: rgba(220, 38, 38, 0.25);
  color: #fca5a5;
}

.badge--warn {
  background: rgba(245, 158, 11, 0.2);
  color: #f59e0b;
}

.badge--success {
  background: rgba(16, 185, 129, 0.2);
  color: #10b981;
}

.log-panel__scroll-bottom {
  position: sticky;
  bottom: 8px;
  float: right;
  display: flex;
  align-items: center;
  gap: 4px;
  padding: 4px 10px;
  border-radius: 16px;
  background: var(--accent, #7c3aed);
  color: #fff;
  border: none;
  cursor: pointer;
  font-size: 12px;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.3);
  transition: transform 0.15s, opacity 0.15s;
  z-index: 10;
}

.log-panel__scroll-bottom:hover {
  transform: scale(1.05);
}

.log-panel__scroll-bottom-icon {
  font-size: 14px;
  line-height: 1;
}

.log-panel__scroll-bottom-badge {
  font-size: 10px;
  background: rgba(255, 255, 255, 0.25);
  padding: 1px 5px;
  border-radius: 8px;
}

.scroll-btn-enter-active,
.scroll-btn-leave-active {
  transition: opacity 0.2s, transform 0.2s;
}

.scroll-btn-enter-from,
.scroll-btn-leave-to {
  opacity: 0;
  transform: translateY(8px);
}

/* ── Step execution summary bar ── */
.log-summary {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 6px 14px;
  background: var(--bg-tertiary, #2a2a3a);
  border-bottom: 1px solid var(--border-color, #3a3a4a);
  flex-shrink: 0;
}

.log-summary__item {
  display: inline-flex;
  align-items: center;
  gap: 2px;
  font-size: 11px;
  font-weight: 600;
}

.log-summary__item--done {
  color: #10b981;
}

.log-summary__item--failed {
  color: #ef4444;
}

.log-summary__item--running {
  color: #00d4ff;
}

.log-summary__item--pending {
  color: var(--text-muted, #888);
}

.log-summary__total {
  margin-left: auto;
  font-size: 11px;
  color: var(--text-muted, #888);
}

/* ── Execution Results Summary ── */
.exec-results {
  border-bottom: 1px solid var(--border-color, #3a3a4a);
  flex-shrink: 0;
  max-height: 240px;
  overflow-y: auto;
}

.exec-results__header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 14px 4px;
  cursor: pointer;
}

.exec-results__toggle {
  font-size: 10px;
  color: var(--text-muted, #888);
  padding: 1px 6px;
  border: 1px solid var(--border-color, #3a3a4a);
  border-radius: var(--radius-xs, 4px);
  cursor: pointer;
}

.exec-results__toggle:hover {
  color: var(--text-primary, #e0e0e0);
  border-color: var(--accent, #7c3aed);
}

.exec-results__title {
  font-size: 12px;
  font-weight: 600;
  color: var(--text-secondary, #b0b0b0);
}

.exec-results__overall-badge {
  display: inline-flex;
  align-items: center;
  padding: 2px 8px;
  border-radius: 10px;
  font-size: 11px;
  font-weight: 600;
}

.exec-results__overall-badge--success {
  background: rgba(16, 185, 129, 0.15);
  color: #10b981;
}

.exec-results__overall-badge--failed {
  background: rgba(239, 68, 68, 0.15);
  color: #ef4444;
}

.exec-results__overall-badge--partial {
  background: rgba(245, 158, 11, 0.15);
  color: #f59e0b;
}

.exec-results__list {
  padding: 0 14px 8px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.exec-results__step {
  background: var(--bg-tertiary, #2a2a3a);
  border: 1px solid var(--border-color, #3a3a4a);
  border-radius: 6px;
  padding: 6px 10px;
  transition: border-color 0.2s;
}

.exec-results__step:hover {
  border-color: var(--accent, #7c3aed);
}

.exec-results__step--failed {
  border-left: 3px solid #ef4444;
}

.exec-results__step-header {
  display: flex;
  align-items: center;
  gap: 6px;
}

.exec-results__step-icon {
  font-size: 12px;
  font-weight: 700;
  flex-shrink: 0;
}

.exec-results__step--failed .exec-results__step-icon {
  color: #ef4444;
}

.exec-results__step:not(.exec-results__step--failed) .exec-results__step-icon {
  color: #10b981;
}

.exec-results__step-name {
  font-size: 12px;
  font-weight: 500;
  color: var(--text-primary, #e0e0e0);
  flex: 1;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.exec-results__step-duration {
  font-size: 10px;
  color: var(--text-muted, #888);
  flex-shrink: 0;
}

.exec-results__view-log {
  padding: 1px 8px;
  border-radius: 3px;
  font-size: 10px;
  background: transparent;
  color: var(--accent, #7c3aed);
  border: 1px solid var(--accent, #7c3aed);
  cursor: pointer;
  flex-shrink: 0;
  transition: background 0.2s, color 0.2s;
}

.exec-results__view-log:hover {
  background: var(--accent, #7c3aed);
  color: #fff;
}

.exec-results__step-detail {
  margin-top: 4px;
  padding-left: 18px;
  font-size: 11px;
  line-height: 1.4;
}

.exec-results__step-detail--success {
  color: #10b981;
}

.exec-results__step-detail--error {
  color: #ef4444;
  word-break: break-all;
  opacity: 0.9;
  max-height: 60px;
  overflow-y: auto;
}

.log-panel__resize-handle {
  height: 4px;
  background: var(--border-hover);
  cursor: ns-resize;
  flex-shrink: 0;
}

.btn {
  padding: 4px 12px;
  border-radius: 4px;
  font-size: 11px;
  cursor: pointer;
  border: 1px solid transparent;
  display: inline-flex;
  align-items: center;
  gap: 4px;
}

.btn--ghost {
  background: transparent;
  color: var(--text-muted, #888);
  border-color: var(--border-color, #3a3a4a);
}

.btn--ghost:hover {
  color: var(--text-primary, #e0e0e0);
}

.btn--sm {
  padding: 2px 8px;
  height: 22px;
}
</style>
