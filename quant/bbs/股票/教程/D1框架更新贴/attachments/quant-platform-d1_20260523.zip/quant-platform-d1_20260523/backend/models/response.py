# -*- coding: utf-8 -*-
"""通用 API 响应模型"""
from __future__ import annotations

from typing import Any, Generic, Optional, TypeVar

from pydantic import BaseModel

T = TypeVar("T")


class ApiResponse(BaseModel, Generic[T]):
    """统一 API 响应格式

    前端期望的响应结构:
    - 成功: { data: T }
    - 失败: { detail: str } 或 { error: str }

    为了保持兼容性，FastAPI 的 HTTPException 仍返回 { detail: str }
    此模型用于显式包装成功响应。
    """
    data: Optional[T] = None
    detail: Optional[str] = None
    error: Optional[str] = None

    @classmethod
    def success(cls, data: Any = None) -> dict:
        """构造成功响应"""
        return {"data": data}

    @classmethod
    def error(cls, message: str, code: int = 400) -> dict:
        """构造错误响应（用于直接返回，非抛异常）"""
        return {"detail": message, "error": message}
