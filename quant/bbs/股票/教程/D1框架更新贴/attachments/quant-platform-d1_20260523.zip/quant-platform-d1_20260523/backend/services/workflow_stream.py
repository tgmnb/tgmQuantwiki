# -*- coding: utf-8 -*-
"""Workflow SSE stream module - push-based async event generation."""
from __future__ import annotations

import asyncio
import json
import logging
import time
import threading

logger = logging.getLogger("quant.workflow_stream")


async def generate_stream_events(wf_id, request):
    """Async generator for SSE stream events with push-based notification."""
    last_counts = {}
    sent_step_starts = set()
    sent_step_done = set()
    last_progress = {}
    last_heartbeat = time.time()

    from services.workflow_service import _run_states, _states_lock, _run_events

    try:
        while True:
            if await request.is_disconnected():
                return

            evt = _run_events.get(wf_id)
            wait_timeout = 1.0  # max wait
            if evt:
                # Use asyncio to wait for the threading.Event with a timeout
                try:
                    loop = asyncio.get_event_loop()
                    await asyncio.wait_for(
                        loop.run_in_executor(None, evt.wait if evt else lambda: None),
                        timeout=wait_timeout
                    )
                    if evt:
                        evt.clear()
                except asyncio.TimeoutError:
                    pass
                except Exception:
                    pass

            with _states_lock:
                state = _run_states.get(wf_id)
            if state is None:
                break

            if not state["running"] and not state.get("active_procs"):
                for step_id, status in state.get("step_status", {}).items():
                    if status == "done" and step_id not in sent_step_done:
                        timing = state.get("step_timings", {}).get(step_id, {})
                        step_name = state.get("step_names", {}).get(step_id, step_id)
                        payload = json.dumps({
                            "type": "step_done",
                            "step_id": step_id,
                            "step_name": step_name,
                            "duration": timing.get("duration", 0),
                        })
                        yield "data: " + payload + "\n\n"
                        sent_step_done.add(step_id)
                    elif status == "failed" and step_id not in sent_step_done:
                        timing = state.get("step_timings", {}).get(step_id, {})
                        step_name = state.get("step_names", {}).get(step_id, step_id)
                        payload = json.dumps({
                            "type": "step_failed",
                            "step_id": step_id,
                            "step_name": step_name,
                            "error": state.get("error", ""),
                            "duration": timing.get("duration", 0),
                        })
                        yield "data: " + payload + "\n\n"
                        sent_step_done.add(step_id)

                payload = json.dumps({"type": "done",
                                      "step_status": state.get("step_status", {}),
                                      "error": state.get("error")})
                yield "event: done\ndata: " + payload + "\n\n"
                return

            has_output = False

            for step_id, status in state.get("step_status", {}).items():
                if status == "running" and step_id not in sent_step_starts:
                    step_name = state.get("step_names", {}).get(step_id, step_id)
                    payload = json.dumps({"type": "step_start", "step_id": step_id, "step_name": step_name})
                    yield "data: " + payload + "\n\n"
                    sent_step_starts.add(step_id)
                    last_counts[step_id] = 0
                    has_output = True

                if status == "done" and step_id not in sent_step_done:
                    timing = state.get("step_timings", {}).get(step_id, {})
                    step_name = state.get("step_names", {}).get(step_id, step_id)
                    payload = json.dumps({
                        "type": "step_done",
                        "step_id": step_id,
                        "step_name": step_name,
                        "duration": timing.get("duration", 0),
                    })
                    yield "data: " + payload + "\n\n"
                    sent_step_done.add(step_id)
                    has_output = True

                elif status == "failed" and step_id not in sent_step_done:
                    timing = state.get("step_timings", {}).get(step_id, {})
                    step_name = state.get("step_names", {}).get(step_id, step_id)
                    step_outputs = state.get("step_outputs", {}).get(step_id, [])
                    error_lines = [l for l in step_outputs if l.startswith("[ERROR]")]
                    error = error_lines[-1] if error_lines else state.get("error", "")
                    payload = json.dumps({
                        "type": "step_failed",
                        "step_id": step_id,
                        "step_name": step_name,
                        "error": error,
                        "duration": timing.get("duration", 0),
                    })
                    yield "data: " + payload + "\n\n"
                    sent_step_done.add(step_id)
                    has_output = True

            for step_id, outputs in state.get("step_outputs", {}).items():
                start = last_counts.get(step_id, 0)
                if start < len(outputs):
                    recent = outputs[start:]
                    last_counts[step_id] = len(outputs)
                    step_name = state.get("step_names", {}).get(step_id, step_id)
                    payload = json.dumps({"type": "log", "step_id": step_id, "step_name": step_name, "lines": recent})
                    yield "data: " + payload + "\n\n"
                    has_output = True

            for step_id, progress in state.get("step_progress", {}).items():
                prev = last_progress.get(step_id, 0)
                if progress > prev + 5:
                    step_name = state.get("step_names", {}).get(step_id, step_id)
                    payload = json.dumps({
                        "type": "progress",
                        "step_id": step_id,
                        "step_name": step_name,
                        "progress": progress,
                    })
                    yield "data: " + payload + "\n\n"
                    last_progress[step_id] = progress
                    has_output = True

            # Heartbeat: send every 5 seconds when idle
            now_hb = time.time()
            if (now_hb - last_heartbeat) > 5:
                yield ": heartbeat\n\n"
                last_heartbeat = now_hb
    except asyncio.CancelledError:
        return
