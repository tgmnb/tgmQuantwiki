import { defineStore } from 'pinia'
import { ref } from 'vue'
import { simplifiedWorkflowApi, type SimplifiedWorkflow, type TaskInfo } from '@/api/simplifiedWorkflow'

const MAX_LOG_LINES = 500

export const useSimplifiedWorkflowStore = defineStore('simplifiedWorkflow', () => {
  const workflows = ref<SimplifiedWorkflow[]>([])
  /** config 参数的原始值（全部） */
  const configParams = ref<Record<string, unknown>>({})
  /** 当前选中的工作流 */
  const selectedWorkflow = ref<SimplifiedWorkflow | null>(null)
  /** 每个工作流的运行参数（key = workflow id） */
  const runParamsMap = ref<Record<string, Record<string, unknown>>>({})
  const running = ref(false)
  const runningTaskId = ref<string | null>(null)
  const runningWorkflowId = ref<string | null>(null)
  const logLines = ref<string[]>([])
  const tasks = ref<TaskInfo[]>([])
  const loading = ref(false)

  let _eventSource: EventSource | null = null
  let _retryTimer: ReturnType<typeof setTimeout> | undefined
  let _retryCount = 0
  const SSE_MAX_RETRIES = 5

  async function loadWorkflows() {
    loading.value = true
    try {
      const data = await simplifiedWorkflowApi.list()
      workflows.value = data.workflows || []
      configParams.value = data.config_params || {}
      // 初始化每个工作流的参数
      for (const wf of workflows.value) {
        if (!(wf.id in runParamsMap.value)) {
          runParamsMap.value[wf.id] = { ...wf.config_values }
        }
      }
    } catch {
      // error handled by interceptor
    } finally {
      loading.value = false
    }
  }

  async function loadTasks() {
    try {
      const data = await simplifiedWorkflowApi.listTasks()
      tasks.value = data.tasks || []
    } catch {
      // ignore
    }
  }

  function addLog(line: string) {
    const lines = logLines.value
    const isErrorType = line.includes('[ERROR_TYPE:')
    const timestamp = isErrorType ? `[${new Date().toLocaleTimeString()}] ` : ''
    const finalLine = isErrorType ? `${timestamp}⚠ ${line}` : line
    if (lines.length >= MAX_LOG_LINES) {
      logLines.value = [...lines.slice(lines.length - MAX_LOG_LINES + 1), finalLine]
    } else {
      lines.push(finalLine)
    }
  }

  function clearLogs() {
    logLines.value = []
  }

  function _closeSSE() {
    clearTimeout(_retryTimer)
    if (_eventSource) {
      _eventSource.close()
      _eventSource = null
    }
  }

  function _scheduleReconnect(streamUrl: string) {
    if (_retryCount >= SSE_MAX_RETRIES) {
      addLog(`❌ SSE 连接重试失败（已尝试 ${SSE_MAX_RETRIES} 次）`)
      running.value = false
      return
    }

    _retryCount++
    const delay = 1000 * Math.pow(2, _retryCount - 1)
    addLog(`⚠ SSE 连接断开，${(delay / 1000).toFixed(1)}s 后重连（第 ${_retryCount}/${SSE_MAX_RETRIES} 次）`)

    _retryTimer = setTimeout(() => {
      if (!running.value) return
      _connectSSE(streamUrl)
    }, delay)
  }

  function _connectSSE(streamUrl: string) {
    _closeSSE()

    const es = new EventSource(streamUrl)
    _eventSource = es

    es.onmessage = (event: MessageEvent) => {
      try {
        const msg = JSON.parse(event.data)
        _handleSSEMessage(msg)
      } catch {
        addLog(event.data)
      }
    }

    es.addEventListener('done', () => {
      addLog('✔ 工作流执行完成')
      running.value = false
      runningTaskId.value = null
      runningWorkflowId.value = null
      _closeSSE()
    })

    es.onerror = () => {
      if (running.value) {
        _eventSource = null
        _scheduleReconnect(streamUrl)
      } else {
        _closeSSE()
      }
    }
  }

  function _handleSSEMessage(msg: { type?: string; status?: string; new_lines?: string[]; progress?: number; error?: string }) {
    if (msg.type === 'progress' || msg.status === 'running') {
      const pct = msg.progress || 0
      if (pct > 0) {
        addLog(`⏳ 进度: ${pct}%`)
      }
    }

    if (msg.new_lines && msg.new_lines.length > 0) {
      for (const line of msg.new_lines) {
        if (line.trim()) {
          addLog(line)
        }
      }
    }

    // 即使进度事件没有 new_lines，也输出进度
    if (msg.progress !== undefined && msg.progress > 0) {
      // 仅在没有 new_lines 时才显示进度，避免重复
    }

    if (msg.error) {
      addLog(`❌ 错误: ${msg.error}`)
    }

    // 任务结束时（status !== running）刷新 running 状态
    if (msg.status && msg.status !== 'running' && running.value) {
      addLog(`✔ 工作流执行完成: ${msg.status}`)
      running.value = false
      runningTaskId.value = null
      runningWorkflowId.value = null
      _closeSSE()
    }
  }

  /** 运行指定工作流，使用该工作流对应的参数 */
  async function runWorkflow(workflowId: string, params: Record<string, unknown> = {}) {
    clearLogs()
    running.value = true
    runningWorkflowId.value = workflowId
    _retryCount = 0

    try {
      const result = await simplifiedWorkflowApi.run(workflowId, params)
      runningTaskId.value = result.task_id

      // 建立 SSE 连接
      const streamUrl = `/api/simplified-workflows/task/${result.task_id}/stream`
      _connectSSE(streamUrl)
    } catch (e) {
      running.value = false
      runningWorkflowId.value = null
      throw e
    }
  }

  async function stopWorkflow() {
    if (!runningTaskId.value) return

    _closeSSE()
    try {
      await simplifiedWorkflowApi.stopTask(runningTaskId.value)
      addLog('⏹ 工作流已停止')
    } catch {
      // ignore
    }
    running.value = false
    runningTaskId.value = null
    runningWorkflowId.value = null
  }

  function selectWorkflow(workflow: SimplifiedWorkflow | null) {
    selectedWorkflow.value = workflow
  }

  function updateParams(workflowId: string, params: Record<string, unknown>) {
    runParamsMap.value[workflowId] = { ...(runParamsMap.value[workflowId] || {}), ...params }
  }

  function getParams(workflowId: string) {
    return runParamsMap.value[workflowId] || {}
  }

  return {
    workflows,
    configParams,
    selectedWorkflow,
    runParamsMap,
    running,
    runningTaskId,
    runningWorkflowId,
    logLines,
    tasks,
    loading,
    loadWorkflows,
    loadTasks,
    runWorkflow,
    stopWorkflow,
    clearLogs,
    selectWorkflow,
    updateParams,
    getParams,
    addLog,
  }
})
