<template>
  <MetricBadge
    v-bind="$attrs"
    label="Sharpe"
    :value="sharpe"
    :thresholds="{ good: 1, warn: 0.5, invert: false }"
  />
</template>
<script setup lang="ts">
defineProps<{ sharpe: number | string }>();
</script>
