<template>
  <div class="library-split">
    <!-- Sidebar -->
    <div class="library-sidebar">
      <div class="library-sidebar__header">
        <div
          class="search-box"
          style="flex:1;"
        >
          <el-icon class="search-box__icon">
            <Search />
          </el-icon>
          <input
            v-model="search"
            type="text"
            placeholder="搜索因子..."
            class="search-box__input"
          >
          <button
            v-if="search"
            class="search-box__clear"
            @click="search = ''"
          >
            <el-icon :size="12">
              <Close />
            </el-icon>
          </button>
        </div>
        <button
          class="btn btn--ghost btn--sm"
          title="新建因子"
          @click="startCreate"
        >
          <el-icon :size="14">
            <Plus />
          </el-icon>
        </button>
      </div>
      <div class="library-sidebar__body scroll-auto">
        <div
          v-for="(files, cat) in filteredFactors"
          :key="cat"
          class="factor-group"
        >
          <div
            class="group-header"
            @click="toggleCat(cat)"
          >
            <span
              class="group-arrow"
              :style="{ transform: isCatExpanded(cat) ? 'rotate(90deg)' : '' }"
            >&#9654;</span>
            <span class="group-name">{{ cat }}</span>
            <span class="group-count">{{ files.length }}</span>
          </div>
          <div
            v-if="isCatExpanded(cat)"
            class="group-items"
          >
            <div
              v-for="(file, i) in files"
              :key="i"
              class="tree-item"
              :class="{ 'tree-item--active': selectedPath === file }"
              :title="file"
              @click="loadCode(file)"
            >
              {{ fileName(file) }}
            </div>
          </div>
        </div>
        <div
          v-if="Object.keys(filteredFactors).length === 0"
          class="empty-hint"
        >
          No factors found
        </div>
      </div>
    </div>

    <!-- Content -->
    <div class="library-content">
      <!-- Create Mode -->
      <template v-if="mode === 'create'">
        <div class="code-create-panel">
          <div class="form-group">
            <label class="form-label">文件名</label>
            <input
              v-model="newFileName"
              placeholder="my_factor.py"
              class="input"
            >
          </div>
          <div class="code-create-panel__editor">
            <CodeEditor
              v-model="editContent"
              language="python"
              height="100%"
            />
          </div>
          <div class="code-create-panel__actions">
            <button
              class="btn btn--primary"
              :disabled="saving || !newFileName"
              @click="doSave"
            >
              {{ saving ? '保存中...' : '保存' }}
            </button>
            <button
              class="btn btn--ghost"
              @click="mode = 'view'; selectedPath = ''"
            >
              取消
            </button>
          </div>
        </div>
      </template>

      <!-- View/Edit Mode -->
      <template v-else-if="selectedPath">
        <div class="code-panel">
          <div class="code-header">
            <div class="code-header__left">
              <el-icon class="code-header__icon">
                <Document />
              </el-icon>
              <span class="code-header__name">{{ fileName(selectedPath) }}</span>
            </div>
            <div class="code-header__actions">
              <template v-if="mode !== 'edit'">
                <button
                  class="btn btn--ghost btn--sm"
                  @click="startEdit"
                >
                  <el-icon :size="13">
                    <Edit />
                  </el-icon> 编辑
                </button>
                <button
                  class="btn btn--ghost btn--sm"
                  @click="copyCode"
                >
                  <el-icon :size="13">
                    <CopyDocument />
                  </el-icon> 复制
                </button>
                <button
                  class="btn btn--danger btn--sm"
                  @click="deleteFile"
                >
                  <el-icon :size="13">
                    <Delete />
                  </el-icon> 删除
                </button>
              </template>
              <template v-else>
                <button
                  class="btn btn--primary btn--sm"
                  :disabled="saving"
                  @click="doSave"
                >
                  <el-icon :size="13">
                    <Check />
                  </el-icon> {{ saving ? '...' : '保存' }}
                </button>
                <button
                  class="btn btn--ghost btn--sm"
                  @click="cancelEdit"
                >
                  取消
                </button>
              </template>
            </div>
          </div>
          <div class="code-body">
            <CodeEditor
              v-if="mode !== 'edit'"
              :model-value="codeDisplay"
              language="python"
              :readonly="true"
              :show-toolbar="false"
              height="100%"
            />
            <CodeEditor
              v-else
              v-model="editContent"
              language="python"
              height="100%"
            />
          </div>
        </div>
      </template>

      <!-- Loading -->
      <div
        v-else-if="loading"
        class="empty-state"
      >
        <Loading />
      </div>

      <!-- Empty State -->
      <div
        v-else
        class="empty-state"
      >
        <div class="empty-state__icon">
          <el-icon
            :size="48"
            color="var(--text-muted)"
            style="opacity:0.3"
          >
            <Document />
          </el-icon>
        </div>
        <div class="empty-state__title">
          选择一个因子查看代码
        </div>
        <div class="empty-state__desc">
          从左侧列表中选择一个因子文件，或点击新建按钮创建新因子
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import Loading from '@/components/common/Loading.vue';
import CodeEditor from '@/components/editor/CodeEditor.vue';

import { factorsApi } from '@/api/factors';

const search = ref('');
const factors = ref<Record<string, string[]>>({});
const selectedPath = ref('');
const codeLines = ref<string[]>([]);
const mode = ref<'view' | 'edit' | 'create'>('view');
const editContent = ref('');
const newFileName = ref('');
const saving = ref(false);
const expandedCats = ref<Record<string, boolean>>({});
const loading = ref(false);

const isCatExpanded = (cat: string) => {
  const searchActive = search.value.trim().length > 0;
  return searchActive || (expandedCats.value[cat] || false);
};

const filteredFactors = computed(() => {
  const q = search.value.toLowerCase();
  const result: Record<string, string[]> = {};
  for (const [cat, files] of Object.entries(factors.value)) {
    const filtered = files.filter(f => !q || f.toLowerCase().includes(q));
    if (filtered.length > 0) result[cat] = filtered;
  }
  return result;
});

const codeDisplay = computed(() => codeLines.value.join('\n'));

function fileName(path: string): string { return path.split('/').pop() || path; }

onMounted(() => { loadFactors(); });

async function loadFactors() {
  loading.value = true;
  try {
    const d: any = await factorsApi.list();
    factors.value = d.factors || {};
    const cats = Object.keys(d.factors || {});
    if (cats.length > 0) expandedCats.value = { [cats[0]]: true };
  } catch { ElMessage.error('加载因子列表失败'); }
  finally { loading.value = false; }
}

async function loadCode(path: string) {
  selectedPath.value = path; mode.value = 'view'; editContent.value = ''; codeLines.value = [];
  try { const d: any = await factorsApi.getContent(path); codeLines.value = d.lines || []; }
  catch { ElMessage.error('加载代码失败'); }
}

function toggleCat(cat: string) { expandedCats.value[cat] = !expandedCats.value[cat]; }
function startEdit() { editContent.value = codeLines.value.join('\n'); mode.value = 'edit'; }
function cancelEdit() { mode.value = 'view'; editContent.value = ''; }

function copyCode() {
  const code = codeLines.value.join('\n');
  navigator.clipboard.writeText(code).then(() => {
    ElMessage.success('已复制');
  }).catch(() => {
    ElMessage.error('复制失败');
  });
}
function startCreate() { selectedPath.value = ''; codeLines.value = []; editContent.value = ''; mode.value = 'create'; newFileName.value = ''; }

async function deleteFile() {
  if (!selectedPath.value) return;
  try {
    await ElMessageBox.confirm('删除 ' + fileName(selectedPath.value) + '?', '确认删除', { type: 'warning' });
    const res: any = await factorsApi.delete(selectedPath.value);
    if (res.success) {
      selectedPath.value = '';
      codeLines.value = [];
      mode.value = 'view';
      await loadFactors();
      ElMessage.success('已删除');
    } else {
      ElMessage.error(res.detail || '删除失败');
    }
  } catch (e: any) {
    if (e !== 'cancel') { ElMessage.error(e.message || '删除失败'); }
  }
}

async function doSave() {
  if (mode.value === 'create') {
    if (!newFileName.value.trim()) { ElMessage.warning('请输入文件名'); return; }
    const path = 'factor_calculate/factor_hub/' + newFileName.value.trim();
    saving.value = true;
    try {
      const res: any = await factorsApi.save(path, editContent.value);
      if (res.success) {
        mode.value = 'view'; selectedPath.value = path; codeLines.value = editContent.value.split('\n'); newFileName.value = ''; await loadFactors();
        ElMessage.success('已保存');
      } else { ElMessage.error(res.detail || '保存失败'); }
    } catch (e: any) { ElMessage.error(e.message || '保存失败'); }
    finally { saving.value = false; }
  } else {
    if (!selectedPath.value) return;
    saving.value = true;
    try {
      const res: any = await factorsApi.save(selectedPath.value, editContent.value);
      if (res.success) { codeLines.value = editContent.value.split('\n'); mode.value = 'view'; ElMessage.success('已保存'); }
      else { ElMessage.error(res.detail || '保存失败'); }
    } catch (e: any) { ElMessage.error(e.message || '保存失败'); }
    finally { saving.value = false; }
  }
}
</script>

<style scoped>
.library-split { display: flex; height: 100%; }
.library-sidebar { width: 260px; flex-shrink: 0; border-right: 1px solid var(--border-color); display: flex; flex-direction: column; overflow: hidden; background: var(--bg-secondary); }
.library-sidebar__header { display: flex; align-items: center; gap: 8px; padding: 10px; border-bottom: 1px solid var(--border-color); flex-shrink: 0; }
.library-sidebar__body { flex: 1; overflow-y: auto; padding: 4px 6px; }
.library-content { flex: 1; overflow: hidden; display: flex; flex-direction: column; }

.factor-group { margin-bottom: 4px; }

.code-panel { display: flex; flex-direction: column; height: 100%; overflow: hidden; }
.code-header { display: flex; align-items: center; padding: 10px 16px; border-bottom: 1px solid var(--border-color); flex-shrink: 0; gap: 8px; }
.code-header__left { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
.code-header__icon { color: var(--accent); font-size: 16px; }
.code-header__name { font-weight: 600; font-size: var(--font-md); color: var(--text-primary); }
.code-header__actions { display: flex; gap: 6px; margin-left: auto; }
.code-body { flex: 1; overflow: auto; padding: 0; }

.code-create-panel { display: flex; flex-direction: column; height: 100%; padding: 16px; overflow: hidden; gap: 12px; }
.code-create-panel__editor { flex: 1; overflow: auto; border: 1px solid var(--border-color); border-radius: var(--radius-md); }
.code-create-panel__actions { display: flex; gap: 8px; }

.empty-state { flex: 1; display: flex; flex-direction: column; align-items: center; justify-content: center; gap: 8px; color: var(--text-muted); font-size: var(--font-sm); }
.empty-state__title { color: var(--text-secondary); font-size: var(--font-md); font-weight: 500; }
.empty-state__desc { color: var(--text-muted); font-size: var(--font-xs); max-width: 300px; text-align: center; line-height: 1.5; }

.form-group { display: flex; flex-direction: column; gap: 6px; }
.form-label { font-size: var(--font-xs); color: var(--text-muted); font-weight: 500; }
.input { width: 100%; height: 32px; padding: 0 10px; background: var(--bg-primary); color: var(--text-primary); border: 1px solid var(--border-color); border-radius: var(--radius); font-size: var(--font-sm); font-family: inherit; outline: none; transition: border-color var(--transition), box-shadow var(--transition); }
.input:focus { border-color: var(--accent); box-shadow: 0 0 0 3px var(--accent-glow); }
.input::placeholder { color: var(--text-muted); }
</style>
