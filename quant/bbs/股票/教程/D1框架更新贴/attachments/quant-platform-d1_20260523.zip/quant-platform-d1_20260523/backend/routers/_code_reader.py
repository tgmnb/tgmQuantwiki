"""
通用代码读取工具 — selection.py 和 timing.py 的共享内容读取逻辑。
"""

from __future__ import annotations

from pathlib import Path

from fastapi.responses import JSONResponse


def read_code_file(
    root: Path,
    user_path: str,
    limit: int = 300,
) -> dict | JSONResponse:
    """安全读取 root 目录下的 Python 源码文件。

    Args:
        root: 允许访问的根目录
        user_path: 用户传入的相对路径
        limit: 最大返回行数

    Returns:
        成功时返回 {name, path, lines, total, truncated}
        失败时返回 JSONResponse(404/500)
    """
    target = (root / user_path).resolve()
    if not target.is_relative_to(root) or not target.exists() or not target.is_file():
        return JSONResponse(status_code=404, content={"detail": "文件不存在"})

    try:
        text = target.read_text(encoding="utf-8")
        lines = text.splitlines()
        return {
            "name": target.stem,
            "path": user_path,
            "lines": lines[:limit],
            "total": len(lines),
            "truncated": len(lines) > limit,
        }
    except (OSError, UnicodeDecodeError) as e:
        return JSONResponse(status_code=500, content={"detail": str(e)})
