# -*- coding: utf-8 -*-
"""后台任务管理 API（task_manager 持久化任务）

提供对通过 TaskManager 创建的子进程任务的查询能力，
与 /api/tasks（task_chain AI 任务链）区分。
"""

from fastapi import APIRouter, HTTPException, Query

from services import db_service as _db

router = APIRouter(prefix="/api/task-manager", tags=["task_manager"])


@router.get("/tasks")
async def list_task_manager_tasks(
    status: str | None = Query(None),
    limit: int = Query(100, ge=1, le=1000),
    offset: int = Query(0, ge=0),
):
    """分页查询后台任务历史，支持 status 过滤。

    Returns:
        {"tasks": list[dict], "total": int}
    """
    tasks = _db.list_tasks(status=status, limit=limit, offset=offset)
    return {"tasks": tasks, "total": len(tasks)}


@router.get("/tasks/{task_id}")
async def get_task_manager_task(task_id: str):
    """查询单个后台任务详情。

    Returns:
        任务字典，若不存在则 404。
    """
    task = _db.get_task_by_id(task_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"任务不存在: {task_id}")
    return task
