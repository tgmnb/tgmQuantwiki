"""
安全代码执行模块

使用 AST 检查 + 受限命名空间，防止代码注入攻击。
"""
import ast
import logging
from pathlib import Path
from typing import Any, Dict

_logger = logging.getLogger("quant.safe_exec")

# ---------------------------------------------------------------------------
# 安全策略配置
# ---------------------------------------------------------------------------

# 允许的模块白名单
ALLOWED_MODULES = {
    "pandas",
    "pandas.core.frame",
    "pandas.core.series",
    "numpy",
    "numpy as np",
    "polars",
    "datetime",
    "datetime.datetime",
    "time",
    "json",
    "math",
    "statistics",
    "typing",
    "collections",
    "itertools",
    "functools",
    "pathlib",
}

# 禁止的危险操作
FORBIDDEN_NODES = {
    ast.ImportFrom,  # 禁止动态导入（超出白名单的）
}

# 禁止调用的函数/方法
DANGEROUS_BUILTINS = {
    "eval",
    "exec",
    "compile",
    "__import__",
    "open",
    "input",
    "breakpoint",
}

DANGEROUS_MODULES = {
    "os",
    "sys",
    "subprocess",
    "shutil",
    "socket",
    "requests",
    "urllib",
    "http",
    "ftplib",
    "smtplib",
    "telnetlib",
    "code",
    "codeop",
}


class SafeExecError(Exception):
    """安全执行异常"""

    pass


# ---------------------------------------------------------------------------
# AST 安全检查
# ---------------------------------------------------------------------------


def validate_ast(tree: ast.AST) -> list[str]:
    """
    使用 AST 检查代码安全性。

    Args:
        tree: AST 语法树

    Returns:
        违规列表，空列表表示安全
    """
    errors = []

    for node in ast.walk(tree):
        # 检查 import 语句
        if isinstance(node, ast.Import):
            for alias in node.names:
                if alias.name not in ALLOWED_MODULES:
                    errors.append(f"禁止导入模块: {alias.name}")

        elif isinstance(node, ast.ImportFrom):
            if node.module and node.module not in ALLOWED_MODULES:
                errors.append(f"禁止从模块导入: {node.module}")

        # 检查危险内置函数调用
        elif isinstance(node, ast.Call):
            if isinstance(node.func, ast.Name):
                if node.func.id in DANGEROUS_BUILTINS:
                    errors.append(f"禁止调用函数: {node.func.id}")
            elif isinstance(node.func, ast.Attribute):
                if isinstance(node.func.value, ast.Name):
                    full_name = f"{node.func.value.id}.{node.func.attr}"
                    if full_name in DANGEROUS_MODULES:
                        errors.append(f"禁止调用方法: {full_name}")

        # 检查危险属性访问
        elif isinstance(node, ast.Attribute):
            if isinstance(node.value, ast.Name):
                if node.value.id in DANGEROUS_MODULES:
                    errors.append(f"禁止访问模块属性: {node.value.id}.{node.attr}")

    return errors


# ---------------------------------------------------------------------------
# 安全执行
# ---------------------------------------------------------------------------


def safe_exec(code: str, filename: str = "<string>") -> Dict[str, Any]:
    """
    安全执行 Python 代码，仅允许访问白名单模块。

    使用场景：
    - 执行策略配置文件（stg_config.py）
    - 执行量化项目 config.py

    Args:
        code: Python 代码字符串
        filename: 文件名（用于错误消息）

    Returns:
        执行后的命名空间字典（仅包含 dict 类型且非私有变量）

    Raises:
        SafeExecError: 代码不安全或执行失败
    """
    # 1. 解析 AST
    try:
        tree = ast.parse(code, filename=filename)
    except SyntaxError as e:
        raise SafeExecError(f"语法错误: {e}")

    # 2. AST 安全检查
    errors = validate_ast(tree)
    if errors:
        raise SafeExecError("\n".join(errors))

    # 3. 准备受限的全局命名空间
    safe_globals = {
        "__builtins__": {
            # 仅允许安全的内置函数
            "__import__": __import__,
            "dict": dict,
            "list": list,
            "tuple": tuple,
            "set": set,
            "frozenset": frozenset,
            "int": int,
            "float": float,
            "str": str,
            "bool": bool,
            "bytes": bytes,
            "type": type,
            "len": len,
            "range": range,
            "enumerate": enumerate,
            "zip": zip,
            "map": map,
            "filter": filter,
            "isinstance": isinstance,
            "hasattr": hasattr,
            "getattr": getattr,
            "setattr": setattr,
            "print": print,
            "abs": abs,
            "min": min,
            "max": max,
            "sum": sum,
            "sorted": sorted,
            "reversed": reversed,
            "round": round,
            "pow": pow,
            "divmod": divmod,
        },
        "__file__": filename,
        "__name__": "__main__",
    }

    # 4. 添加白名单模块
    try:
        import pandas as pd

        safe_globals["pd"] = pd
    except ImportError:
        pass

    try:
        import numpy as np

        safe_globals["np"] = np
    except ImportError:
        pass

    try:
        import polars as pl

        safe_globals["pl"] = pl
    except ImportError:
        pass

    import datetime

    safe_globals["datetime"] = datetime

    import json

    safe_globals["json"] = json

    import math

    safe_globals["math"] = math

    import statistics

    safe_globals["statistics"] = statistics

    import collections

    safe_globals["collections"] = collections

    import itertools

    safe_globals["itertools"] = itertools

    import functools

    safe_globals["functools"] = functools

    from pathlib import Path as _Path

    safe_globals["Path"] = _Path

    # 5. 执行代码
    namespace = {}
    try:
        exec(compile(code, filename, "exec"), safe_globals, namespace)
    except Exception as e:
        _logger.error("安全执行失败: %s - %s", filename, e)
        raise SafeExecError(f"代码执行失败: {e}")

    # 6. 过滤结果，仅返回 dict 类型（策略配置的常见格式）
    result = {
        k: v for k, v in namespace.items() if isinstance(v, dict) and not k.startswith("_")
    }

    return result


# ---------------------------------------------------------------------------
# 便捷函数
# ---------------------------------------------------------------------------


def safe_load_config(config_path: Path) -> Dict[str, Any]:
    """
    安全加载配置文件（.py 格式）。

    用于加载：
    - 策略配置（stg_config.py）

    Args:
        config_path: 配置文件路径

    Returns:
        配置字典

    Raises:
        FileNotFoundError: 文件不存在
        SafeExecError: 代码不安全或执行失败
    """
    if not config_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")

    code = config_path.read_text(encoding="utf-8")
    return safe_exec(code, str(config_path))


def load_project_config(config_path: Path) -> Dict[str, Any]:
    """
    加载受信任的项目配置文件（如 config.py）。

    与 safe_load_config 的区别：允许 os/os.path 用于路径构建，
    因为项目 config.py 是平台自身管理的受信任文件。
    仍只返回 dict 类型的配置值。

    Args:
        config_path: 配置文件路径

    Returns:
        配置字典

    Raises:
        FileNotFoundError: 文件不存在
        SafeExecError: 执行失败
    """
    import os as _os

    if not config_path.exists():
        raise FileNotFoundError(f"配置文件不存在: {config_path}")

    code = config_path.read_text(encoding="utf-8")

    # 受信任配置允许 os + pathlib，用于路径构建
    exec_globals = {
        "__builtins__": {
            "__import__": __import__,
            "dict": dict, "list": list, "tuple": tuple, "set": set,
            "int": int, "float": float, "str": str, "bool": bool,
            "len": len, "range": range, "isinstance": isinstance,
            "getattr": getattr, "hasattr": hasattr, "repr": repr,
            "True": True, "False": False, "None": None,
        },
        "__file__": str(config_path),
        "__name__": "__main__",
        "os": _os,
        "Path": Path,
    }

    namespace = {}
    try:
        exec(compile(code, str(config_path), "exec"), exec_globals, namespace)
    except Exception as e:
        _logger.error("项目配置执行失败: %s - %s", config_path, e)
        raise SafeExecError(f"配置执行失败: {e}")

    return {k: v for k, v in namespace.items() if not k.startswith("_") and isinstance(v, (dict, list, str, int, float, bool, tuple))}
