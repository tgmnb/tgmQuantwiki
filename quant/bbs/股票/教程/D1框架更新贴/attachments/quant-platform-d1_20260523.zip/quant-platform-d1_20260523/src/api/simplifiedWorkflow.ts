import { request } from './request'

/** 简化工作流定义 */
export interface SimplifiedWorkflow {
  id: string
  name: string
  script: string
  doc: string
  params: WorkflowParam[]
  /** 工作流需要的 config 参数 key 列表 */
  config_params: string[]
  /** config 参数的当前值 */
  config_values: Record<string, unknown>
}

export interface WorkflowParam {
  name: string
  type: string
  default: unknown
  required: boolean
}

export interface SimplifiedWorkflowResponse {
  workflows: SimplifiedWorkflow[]
  config_params: Record<string, unknown>
}

export interface TaskInfo {
  task_id: string
  status: string
  progress?: number
  error?: string
  start_time?: string
  [key: string]: unknown
}

export const simplifiedWorkflowApi = {
  /** 获取简化工作流列表 */
  async list(): Promise<SimplifiedWorkflowResponse> {
    return request.get('/api/simplified-workflows')
  },

  /** 运行工作流 */
  async run(workflowName: string, params?: Record<string, unknown>): Promise<{ task_id: string }> {
    return request.post(`/api/simplified-workflows/${workflowName}/run`, params || {})
  },

  /** 获取任务列表 */
  async listTasks(): Promise<{ tasks: TaskInfo[] }> {
    return request.get('/api/simplified-workflows/tasks')
  },

  /** 获取任务详情 */
  async getTask(taskId: string): Promise<TaskInfo> {
    return request.get(`/api/simplified-workflows/task/${taskId}`)
  },

  /** 停止任务 */
  async stopTask(taskId: string): Promise<{ task_id: string }> {
    return request.post(`/api/simplified-workflows/task/${taskId}/stop`)
  },
}
