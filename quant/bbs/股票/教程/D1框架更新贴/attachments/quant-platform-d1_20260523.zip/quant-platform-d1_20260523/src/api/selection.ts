import { request } from './request';

export const selectionApi = {
  async list() {
    return request.get('/api/selection/list');
  },

  async getContent(path: string) {
    return request.get('/api/selection/content', { params: { path } });
  },

  async save(path: string, content: string) {
    return request.post('/api/selection/save', { path, content });
  },

  async delete(path: string) {
    return request.post('/api/selection/delete', { path });
  },
};
