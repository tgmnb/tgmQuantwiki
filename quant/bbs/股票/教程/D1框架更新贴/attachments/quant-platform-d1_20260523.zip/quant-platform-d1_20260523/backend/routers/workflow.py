# -*- coding: utf-8 -*-
"""Workflow Router - CRUD + execution, business logic in workflow_service"""
import logging
import time
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException, Query, Request
from fastapi.responses import StreamingResponse

from schemas import CreateWorkflowReq, SaveWorkflowReq, RunWorkflowReq
from services.workflow_service import _run_states
from services.workflow_storage import _get_proj_dir

logger = logging.getLogger("quant.workflow")
router = APIRouter(prefix="/api/workflows", tags=["workflows"])


# ---- CRUD ----

@router.get("", summary="List all workflows")
async def list_workflows(category: Optional[str] = Query(None, description="Filter by category")):
    from services.workflow_service import list_workflows as svc, cleanup_run_state
    cleanup_run_state()
    return {"workflows": svc(category=category)}


@router.get("/nodes")
async def list_nodes():
    """返回所有可用工作流节点类型"""
    from services.nodes import list_all
    return {"nodes": list_all()}


@router.get("/templates")
async def list_templates():
    """返回预设工作流模板列表"""
    from services.workflow_storage import list_templates as svc
    return {"templates": svc()}


@router.post("", summary="Create workflow")
async def create_workflow(req: CreateWorkflowReq):
    from services.workflow_service import create_workflow as svc
    try:
        wf = svc(
            name=req.name,
            description=req.description,
            category=req.category or "",
            steps=req.steps,
            script=req.script or "",
            conda_env=req.conda_env or "quantpy312",
        )
        return {"workflow": wf}
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.get("/{wf_id}", summary="Get workflow detail")
async def get_workflow(wf_id: str):
    from services.workflow_service import get_workflow as svc
    wf = svc(wf_id)
    if not wf:
        raise HTTPException(status_code=404, detail="Workflow not found")
    return {"workflow": wf}


@router.put("/{wf_id}", summary="Update workflow")
async def save_workflow(wf_id: str, req: SaveWorkflowReq):
    from services.workflow_service import save_workflow as svc
    try:
        data: dict = {}
        if req.name is not None:
            data["name"] = req.name
        if req.description is not None:
            data["description"] = req.description
        if req.category is not None:
            data["category"] = req.category
        if req.steps is not None:
            data["steps"] = req.steps
        if req.script is not None:
            data["script"] = req.script
        if req.conda_env is not None:
            data["conda_env"] = req.conda_env
        wf = svc(wf_id, data)
        return {"workflow": wf}
    except RuntimeError as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.delete("/{wf_id}", summary="Delete workflow")
async def delete_workflow(wf_id: str):
    from services.workflow_service import delete_workflow as svc
    ok = svc(wf_id)
    if not ok:
        raise HTTPException(status_code=404, detail="Workflow not found")
    return {"ok": True}


# ---- Execution ----

@router.post("/{wf_id}/run", summary="Run workflow")
async def run_workflow(wf_id: str, req: RunWorkflowReq):
    from services.workflow_service import start_workflow_run
    try:
        start_workflow_run(wf_id, req.start_from_step, req.step_params)
    except ValueError as e:
        raise HTTPException(status_code=409, detail=str(e))
    return {"status": "started"}


@router.post("/{wf_id}/stop", summary="Stop workflow")
async def stop_workflow(wf_id: str):
    state = _run_states.get(wf_id)
    if not state:
        raise HTTPException(status_code=404, detail="Workflow not found")
    state["running"] = False
    for proc in list(state.get("active_procs", {}).values()):
        try:
            proc.kill()
            proc.wait(timeout=5)
        except Exception:
            pass
    state["active_procs"] = {}
    return {"status": "stopped"}


@router.get("/{wf_id}/status")
async def get_status(wf_id: str):
    from services.workflow_service import get_or_create_state
    state = get_or_create_state(wf_id)

    step_summary = {}
    for step_id, outputs in state.get("step_outputs", {}).items():
        error_lines = [l for l in outputs if "[ERROR]" in l]
        last_error = error_lines[-1] if error_lines else None
        step_summary[step_id] = {
            "status": state["step_status"].get(step_id),
            "error_count": len(error_lines),
            "last_error": last_error,
            "progress": state.get("step_progress", {}).get(step_id, 0)
        }

    return {
        "running": state["running"],
        "current_step": state["current_step"],
        "step_status": state["step_status"],
        "started_at": state["started_at"],
        "error": state["error"],
        "run_id": state.get("run_id"),
        "step_summary": step_summary,
    }


@router.get("/{wf_id}/stream")
async def stream_logs(wf_id: str, request: Request):
    from services.workflow_service import generate_stream_events
    return StreamingResponse(generate_stream_events(wf_id, request), media_type="text/event-stream")


@router.get("/{wf_id}/runs")
async def get_workflow_runs(wf_id: str):
    from services import db_service
    try:
        runs = db_service.list_workflow_runs(wf_id)
    except Exception as e:
        logger.exception("Failed to list workflow runs")
        raise HTTPException(status_code=500, detail=str(e))
    return {"runs": runs}


@router.get("/{wf_id}/runs/{run_id}/logs")
async def get_run_logs(wf_id: str, run_id: str):
    proj_dir = Path(_get_proj_dir())
    log_file = proj_dir / "workflow_logs" / f"{run_id}.log"
    if not log_file.exists():
        return {"lines": []}
    try:
        with open(log_file, "r", encoding="utf-8", errors="replace") as f:
            lines = [line.rstrip() for line in f]
        return {"lines": lines}
    except Exception as e:
        logger.exception("Failed to read run logs")
        raise HTTPException(status_code=500, detail=str(e))
