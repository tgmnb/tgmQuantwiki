/** API 响应基础结构 */
export interface ApiResponse<T = unknown> {
  data?: T;
  error?: string;
  detail?: string;
}

// ===== Backtest API 类型 =====

/** 策略列表项 */
export interface Strategy {
  name: string;
  path: string;
  base: string;
  group: string;
  type?: string;
  has_config?: boolean;
}

/** 策略列表响应 */
export interface StrategyListResponse {
  groups: Record<string, Strategy[]>;
  strategies?: Strategy[];
}

/** 净值数据 */
export interface NavData {
  headers: string[];
  rows: Record<string, string | number>[];
}

/** 交易记录 */
export interface TradeRecord {
  date: string;
  code: string;
  name: string;
  action: 'buy' | 'sell';
  price: number;
  amount: number;
  pnl?: number;
}

/** 绩效指标 */
export interface Metrics {
  [key: string]: number | string;
}

/** 回测详情 */
export interface BacktestDetail {
  name: string;
  path: string;
  base: string;
  metrics: Metrics;
  nav: NavData;
  trades: TradeRecord[];
}

export type BacktestDetailResponse = BacktestDetailData

// ===== Workflow API 类型 =====

/** Workflow 步骤状态 */
export type StepStatus = 'idle' | 'running' | 'done' | 'failed';

/** Workflow 步骤 */
export interface WorkflowStep {
  id: string;
  name: string;
  icon?: string;
  script?: string;
  conda_env?: string;
  node_type?: string;
  params?: Record<string, unknown>;
  retry?: number;
  _status?: StepStatus;
}

/** Workflow 数据结构 */
export interface Workflow {
  id: string;
  name: string;
  description?: string;
  category?: string;
  steps: WorkflowStep[];
  script?: string;
  conda_env?: string;
  icon?: string;
  created_at?: number;
  updated_at?: number;
}

/** Workflow 列表响应 */
export interface WorkflowListResponse {
  workflows: Workflow[];
}

/** 单个 Workflow 响应 */
export interface WorkflowResponse {
  workflow: Workflow;
}

// ===== Builder API 类型 =====

/** 策略配置 (getStrategyConfig 返回) */
export interface StrategyConfig {
  basic_config?: Record<string, unknown>;
  strategy_config?: Record<string, unknown>;
  selection_config?: {
    mode?: string;
    reference_strategy?: string;
  };
  timing_config?: {
    period?: string;
    stock?: {
      is_open?: boolean;
      signal?: string;
      signal_params?: Record<string, unknown>;
    };
    risk?: {
      is_open?: boolean;
      signal?: string;
    };
  };
  data_source?: Record<string, unknown>;
}

/** 策略配置响应 */
export interface StrategyConfigResponse {
  config: StrategyConfig;
}

/** 文件内容项 */
export interface FileContent {
  lines?: string[];
}

/** 文件列表响应 (getStrategyFiles / getFileContent 返回) */
export interface StrategyFilesResponse {
  files: Record<string, FileContent>;
}

/** 文件内容响应 */
export interface FileContentResponse {
  files?: Record<string, FileContent>;
  content?: string;
}

/** 保存文件响应 */
export interface SaveFileResponse {
  success: boolean;
  backup?: boolean;
  detail?: string;
}

/** 运行回测请求 */
export interface RunBacktestRequest {
  strategy_name: string;
  backtest_type: string;
  overrides?: Record<string, unknown>;
}

/** 运行回测响应 */
export interface RunBacktestResponse {
  task_id?: string;
  status?: string;
}

/** 创建策略响应 */
export interface CreateStrategyResponse {
  success?: boolean;
  strategy: Strategy;
}

/** 历史记录项 */
export interface HistoryItem {
  id: string;
  strategy_name: string;
  backtest_type: string;
  created_at: string;
  status: string;
}

/** 历史记录响应 */
export interface HistoryResponse {
  records: HistoryItem[];
  total?: number;
}

// ===== Node 节点类型 =====

export interface NodeSlot {
  id: string
  name: string
  type: string
  required?: boolean
  description?: string
}

export interface NodeParam {
  id: string
  name: string
  type: string
  default?: unknown
  required?: boolean
  options?: Array<{ value: string; label: string }>
  description?: string
  ui?: Record<string, unknown>
}

export interface NodeDefinition {
  id: string
  type: string
  name: string
  description?: string
  icon?: string
  category: string
  slots_in: NodeSlot[]
  slots_out: NodeSlot[]
  params: NodeParam[]
  script?: string
  func?: string
  conda_env?: string
  note?: string
}

export interface NodeListResponse {
  nodes: NodeDefinition[]
}

export interface WorkflowTemplate {
  id: string
  name: string
  description: string
  category: string
  icon?: string
  steps: WorkflowStep[]
}

export interface TemplateListResponse {
  templates: WorkflowTemplate[]
}

// ===== Workflow SSE 事件类型 =====

export type WorkflowSSEEvent =
  | { type: 'step_start'; step_id: string; step_name: string }
  | { type: 'step_done'; step_id: string; step_name: string; duration: number }
  | { type: 'step_failed'; step_id: string; step_name: string; error: string; duration: number }
  | { type: 'log'; step_id: string; step_name: string; lines: string[] }
  | { type: 'progress'; step_id: string; progress: number; message: string }
  | { type: 'done'; step_status: Record<string, string>; error?: string }

// ===== 通用 SSE 消息类型 =====
export interface SSEMessage {
  type: 'log' | 'status' | 'error' | 'done'
  data: string
  timestamp?: number
}

// ===== 回测详情增强类型（backtest-merge 新增）=====

/** 完整 12 项绩效指标 */
export interface FullMetrics {
  '累积净值'?: number | null;
  '年化收益率'?: number | null;    // 百分比, e.g. 15.2341
  '最大回撤'?: number | null;      // 百分比, 负数, e.g. -12.3456
  '年化波动率'?: number | null;    // 百分比, e.g. 18.7654
  'Sharpe比率'?: number | null;    // 比率, e.g. 0.8523
  'Sortino比率'?: number | null;   // 比率
  'Calmar比率'?: number | null;    // 比率
  '胜率'?: number | null;          // 百分比, e.g. 62.34
  '盈亏比'?: number | null;        // 比率, e.g. 1.5678
  '总交易次数'?: number | null;    // 整数
  '最大连续盈利'?: number | null;  // 金额或比率
  '最大连续亏损'?: number | null;  // 金额或比率（负数）
}

/** 净值数据点（用于图表绑定的精简格式） */
export interface NavDataPoint {
  date: string;   // "YYYY-MM-DD"
  value: number;
}

/** 净值数据（API 返回格式）— 修正版，增加 total / downsampled */
export interface NavData {
  headers: string[];
  rows: Record<string, string | number>[];
  total: number;
  downsampled?: boolean;
}

/** 分页交易记录（泛型） */
export interface PaginatedTrades<T = Record<string, unknown>> {
  headers: string[];
  rows: T[];
  total: number;
  page: number;
  page_size: number;
}

/** 回测详情数据 — 匹配后端实际返回格式 */
export interface BacktestDetailData {
  name: string;
  path: string;
  base: string;
  metrics: FullMetrics;
  nav: NavData;
  trades: PaginatedTrades;
  pnls: number[];           // PnL 分布图数据
}

/** 个股交易列表中的单只股票 */
export interface TradeStockItem {
  code: string;             // 股票代码
  name: string;             // 股票名称
  buy_count: number;        // 买入次数
  sell_count: number;       // 卖出次数
  trade_count: number;      // 总交易次数
}

/** 交易股票列表响应 — 修正：stocks 类型从 string[] 改为 TradeStockItem[] */
export interface TradeStocksResponse {
  stocks: TradeStockItem[];
}

/** 单笔买卖记录（trades_by_stock 返回） */
export interface StockTradeRecord {
  date: string;
  action: string;           // "买" / "卖"
  price: number;
  volume: number;
  amount: number;
  name?: string;
}

/** 个股交易记录响应 — 修正：增加分页和统计字段 */
export interface TradesByStockResponse {
  stock_code: string;
  trades: StockTradeRecord[];
  buy_count: number;
  sell_count: number;
  total?: number;
  page?: number;
  page_size?: number;
}

/** 多策略对比中的单个策略数据 */
export interface CompareStrategyItem {
  name: string;
  path: string;
  nav_data: NavDataPoint[];
  full_metrics: FullMetrics;
}

/** 多策略对比响应 — 修正：使用 CompareStrategyItem 替代旧类型 */
export interface CompareResponse {
  strategies: CompareStrategyItem[];
  skipped?: Array<{ path: string; reason: string }>;
}

/** SSE Progress 事件 payload */
export interface SSEProgressEvent {
  task_id: string;
  status: 'running';
  progress: number;         // 0-100
  error?: string;
  new_lines: string[];      // 新增日志行
}

/** SSE Done 事件 payload */
export interface SSEDoneEvent {
  task_id: string;
  status: 'completed' | 'failed' | 'stopped' | 'timeout';
  progress: number;
  error?: string;
  new_lines: string[];
}
