﻿# -*- coding: utf-8 -*-
"""
Settings & Config API - platform settings + quant-test-d1-pro config.py
"""
from __future__ import annotations

import importlib.util
import logging
import os
import re
from pathlib import Path

import config as _config
from fastapi import APIRouter, Body, HTTPException
from fastapi.responses import JSONResponse

_logger = logging.getLogger("quant.settings")
router = APIRouter(prefix="/api", tags=["settings"])

def require_quant_proj():
    qp = _config.QUANT_PROJ
    if not qp or not qp.exists():
        raise HTTPException(status_code=500, detail="quant_proj not configured or not a directory")
    return qp

def _get_proj_dir():
    qp = _config.QUANT_PROJ
    if not qp or not qp.exists():
        raise HTTPException(status_code=500, detail="quant_proj not configured")
    return qp

def _read_quant_config(proj_dir):
    cfg_file = proj_dir / "config.py"
    if not cfg_file.exists():
        return {"error": "config.py not found"}
    spec = importlib.util.spec_from_file_location("_qcfg", str(cfg_file))
    if spec is None or spec.loader is None:
        return {"error": "cannot load config.py"}
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as e:
        return {"error": str(e)}
    keys = [
        "date_start", "date_end", "boost", "batching_mode", "n_jobs",
        "exclude_stock_patterns", "fq_type",
        "data_dir", "data_source",
        "prepare_data_length", "index_code", "index_ids",
        "min_price_factor",
        "select_code_list", "strategy_name_list", "account_name_list",
        "ind_agg_daily_dict",
        "init_capital", "commission_ratio", "tax_ratio", "slippage_ratio",
        "factor_incremental", "factor_name_list", "exclude_factor_list",
    ]
    return {k: getattr(module, k, None) for k in keys}

def _write_quant_config_field(proj_dir, field, value):
    cfg_file = proj_dir / "config.py"
    if not cfg_file.exists():
        return {"error": "config.py not found"}
    with open(cfg_file, "r", encoding="utf-8") as f:
        lines = f.readlines()
    new_lines = []
    updated = False
    for line in lines:
        stripped = line.lstrip()
        if stripped and not stripped.startswith("#"):
            pattern = r'^(\s*)' + re.escape(field) + r'\s*='
            if re.match(pattern, line):
                indent = re.match(r'^(\s*)', line).group(1)
                if isinstance(value, list):
                    items = ", ".join(repr(str(v)) for v in value)
                    new_line = f"{indent}{field} = [{items}]\n"
                elif isinstance(value, bool):
                    new_line = f"{indent}{field} = {value}\n"
                elif isinstance(value, (int, float)):
                    new_line = f"{indent}{field} = {value!r}\n"
                elif value is None:
                    new_line = f"{indent}{field} = None\n"
                else:
                    new_line = f"{indent}{field} = {value!r}\n"
                new_lines.append(new_line)
                updated = True
                continue
        new_lines.append(line)
    if not updated:
        return {"error": f"Field not found: {field}"}
    with open(cfg_file, "w", encoding="utf-8") as f:
        f.writelines(new_lines)
    return {"ok": True}

@router.get("/settings")
async def get_settings():
    _raw = _config.load_settings()
    quant_proj_raw = _raw.get("quant_proj", "")
    qp = _config.QUANT_PROJ
    cfg_py = _config._CONFIG_PY
    dd = _config.DATA_DIR
    return {
        "quant_proj": quant_proj_raw,
        "quant_proj_exists": qp.exists() if qp else False,
        "quant_proj_has_config": cfg_py.exists() if (qp and cfg_py) else False,
        "data_dir": str(dd) if dd else "",
        "theme": _raw.get("theme", "dark"),
    }

@router.post("/settings")
async def update_settings(data: dict = Body(...)):
    current = _config.load_settings()
    quant_proj = data.get("quant_proj", "").strip()
    if quant_proj:
        p = Path(quant_proj)
        if not p.exists():
            return JSONResponse(status_code=400, content={"detail": "Path not found"})
        if not p.is_dir():
            return JSONResponse(status_code=400, content={"detail": "Not a directory"})
        _config.save_settings({"quant_proj": quant_proj})
        _config.apply_settings(quant_proj)
        has_config = _config._CONFIG_PY.exists() if _config._CONFIG_PY else False
    else:
        has_config = (_config._CONFIG_PY.exists() if _config._CONFIG_PY else False) if _config.QUANT_PROJ else False
    theme = data.get("theme")
    if theme is not None:
        _raw = _config.load_settings()
        _raw["theme"] = theme if theme in ("light", "dark") else "dark"
        _config.save_settings(_raw)
    return {
        "ok": True,
        "quant_proj": quant_proj or (_config.load_settings().get("quant_proj", "")),
        "quant_proj_has_config": has_config,
        "theme": _config.load_settings().get("theme", "dark"),
    }

@router.post("/settings/clear-cache")
async def clear_cache():
    from services.cache_service import invalidate_prefix
    import services.tree_service as _ts
    import routers.kline as _kl
    cleared = []
    invalidate_prefix("")
    cleared.append("cache_service")
    _ts._tree_cache.clear()
    cleared.append("tree_cache")
    if hasattr(_kl, "_daily_lf") and _kl._daily_lf is not None:
        _kl._daily_lf = None
        cleared.append("daily_lf")
    if hasattr(_kl, "_daily_codes"):
        _kl._daily_codes = None
        cleared.append("daily_codes")
    if hasattr(_kl, "_1h_files"):
        _kl._1h_files = None
        cleared.append("1h_files")
    _logger.info("Cache cleared: %s", cleared)
    return {"ok": True, "cleared": cleared}

@router.get("/settings/quant-config")
async def get_quant_config():
    try:
        proj_dir = _get_proj_dir()
    except HTTPException:
        return JSONResponse(status_code=500, content={"detail": "quant_proj not configured"})
    return _read_quant_config(proj_dir)

@router.patch("/settings/quant-config/{field}")
async def patch_quant_config(field: str, body: dict = Body(...)):
    try:
        proj_dir = _get_proj_dir()
    except HTTPException:
        return JSONResponse(status_code=500, content={"detail": "quant_proj not configured"})
    result = _write_quant_config_field(proj_dir, field, body.get("value"))
    if "error" in result:
        return JSONResponse(status_code=400, content={"detail": result["error"]})
    return result
