import { EditorView } from '@codemirror/view'
import { HighlightStyle } from '@codemirror/language'
import { tags } from '@lezer/highlight'

export const traeDarkTheme = EditorView.theme(
  {
    '&': { backgroundColor: '#17171f', color: '#e8e8ed' },
    '.cm-content': { caretColor: '#e8e8ed' },
    '.cm-cursor': { borderLeftColor: '#e8e8ed' },
    '.cm-activeLine': { backgroundColor: 'rgba(124, 110, 245, 0.06)' },
    '.cm-activeLineGutter': {
      backgroundColor: 'rgba(124, 110, 245, 0.08)',
    },
    '.cm-gutters': {
      backgroundColor: '#111118',
      borderRight: '1px solid rgba(255, 255, 255, 0.07)',
      color: '#5a5a6e',
    },
    '.cm-selectionBackground, &.cm-focused .cm-selectionBackground': {
      backgroundColor: 'rgba(124, 110, 245, 0.25) !important',
    },
  },
  { dark: true },
)

export const traeDarkHighlight = HighlightStyle.define([
  { tag: tags.comment, color: '#737780', fontStyle: 'italic' },
  { tag: tags.string, color: '#82D99F' },
  { tag: tags.number, color: '#F48CCA' },
  { tag: tags.bool, color: '#80BBFF' },
  { tag: tags.null, color: '#80BBFF' },
  { tag: tags.literal, color: '#80BBFF' },
  { tag: tags.keyword, color: '#B38CFF' },
  { tag: tags.controlKeyword, color: '#B38CFF' },
  { tag: tags.operatorKeyword, color: '#B38CFF' },
  { tag: tags.function(tags.variableName), color: '#F29D79' },
  { tag: tags.typeName, color: '#81CFE0' },
  { tag: tags.className, color: '#81CFE0' },
  { tag: tags.definition(tags.variableName), color: '#DED47E' },
  { tag: tags.variableName, color: '#DED47E' },
  { tag: tags.propertyName, color: '#E0E3EE' },
  { tag: tags.constant(tags.variableName), color: '#80BBFF' },
  { tag: tags.constant(tags.className), color: '#80BBFF' },
  { tag: tags.operator, color: '#D5D8E0' },
  { tag: tags.escape, color: '#80BBFF' },
  { tag: tags.regexp, color: '#82D99F' },
  { tag: tags.labelName, color: '#82D99F' },
  { tag: tags.invalid, color: '#CC4B53' },
  { tag: tags.deleted, color: '#F2858C' },
])

export const traeLightHighlight = HighlightStyle.define([
  { tag: tags.comment, color: '#8393A3', fontStyle: 'italic' },
  { tag: tags.string, color: '#4DA621' },
  { tag: tags.number, color: '#E54595' },
  { tag: tags.bool, color: '#175CE6' },
  { tag: tags.null, color: '#175CE6' },
  { tag: tags.literal, color: '#175CE6' },
  { tag: tags.keyword, color: '#5F36B2' },
  { tag: tags.controlKeyword, color: '#5F36B2' },
  { tag: tags.operatorKeyword, color: '#5F36B2' },
  { tag: tags.function(tags.variableName), color: '#4078F2' },
  { tag: tags.typeName, color: '#B15EF2' },
  { tag: tags.className, color: '#B15EF2' },
  { tag: tags.definition(tags.variableName), color: '#C99100' },
  { tag: tags.variableName, color: '#C99100' },
  { tag: tags.propertyName, color: '#17181A' },
  { tag: tags.constant(tags.variableName), color: '#986801' },
  { tag: tags.constant(tags.className), color: '#986801' },
  { tag: tags.operator, color: '#000000' },
  { tag: tags.escape, color: '#175CE6' },
  { tag: tags.regexp, color: '#4DA621' },
  { tag: tags.labelName, color: '#008880' },
  { tag: tags.invalid, color: '#cd3131' },
])

export const eyeCareHighlight = HighlightStyle.define([
  { tag: tags.comment, color: '#8a8378', fontStyle: 'italic' },
  { tag: tags.string, color: '#6b9a6b' },
  { tag: tags.number, color: '#b87070' },
  { tag: tags.bool, color: '#7a8ab5' },
  { tag: tags.null, color: '#7a8ab5' },
  { tag: tags.literal, color: '#7a8ab5' },
  { tag: tags.keyword, color: '#8b6fb0' },
  { tag: tags.controlKeyword, color: '#8b6fb0' },
  { tag: tags.operatorKeyword, color: '#8b6fb0' },
  { tag: tags.function(tags.variableName), color: '#c4855a' },
  { tag: tags.typeName, color: '#5a9a8a' },
  { tag: tags.className, color: '#5a9a8a' },
  { tag: tags.definition(tags.variableName), color: '#9a8545' },
  { tag: tags.variableName, color: '#9a8545' },
  { tag: tags.propertyName, color: '#4a453e' },
  { tag: tags.constant(tags.variableName), color: '#7a8ab5' },
  { tag: tags.constant(tags.className), color: '#7a8ab5' },
  { tag: tags.operator, color: '#6a655c' },
  { tag: tags.escape, color: '#7a8ab5' },
  { tag: tags.regexp, color: '#6b9a6b' },
  { tag: tags.labelName, color: '#6b9a6b' },
  { tag: tags.invalid, color: '#b56060' },
  { tag: tags.deleted, color: '#b56060' },
])

export const eyeCareTheme = EditorView.theme(
  {
    '&': { backgroundColor: '#f4f1ea', color: '#2d2a26' },
    '.cm-content': { caretColor: '#b8956a' },
    '.cm-cursor': { borderLeftColor: '#b8956a' },
    '.cm-activeLine': { backgroundColor: 'rgba(184, 149, 106, 0.08)' },
    '.cm-activeLineGutter': {
      backgroundColor: 'rgba(184, 149, 106, 0.12)',
    },
    '.cm-gutters': {
      backgroundColor: '#eae5dc',
      borderRight: '1px solid rgba(45, 42, 38, 0.08)',
      color: '#6a655c',
    },
    '.cm-selectionBackground, &.cm-focused .cm-selectionBackground': {
      backgroundColor: 'rgba(184, 149, 106, 0.25) !important',
    },
  },
  { dark: false },
)
