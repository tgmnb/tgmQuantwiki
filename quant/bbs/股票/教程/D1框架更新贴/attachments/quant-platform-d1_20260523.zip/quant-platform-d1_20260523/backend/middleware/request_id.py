# -*- coding: utf-8 -*-
"""请求 ID + 访问日志中间件（合并版）"""
from __future__ import annotations

import uuid
import logging
import time

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger("quant.access")


class RequestIDMiddleware(BaseHTTPMiddleware):
    """为每个请求附加 X-Request-ID + X-Process-Time，同时记录访问日志"""

    async def dispatch(self, request: Request, call_next):
        # 跳过静态资源请求
        if request.url.path.startswith(("/static", "/pages", "/favicon", "/assets")):
            return await call_next(request)

        request_id = request.headers.get("X-Request-ID", str(uuid.uuid4())[:16])
        request.state.request_id = request_id

        start_time = time.time()
        response = await call_next(request)
        process_time = (time.time() - start_time) * 1000

        response.headers["X-Request-ID"] = request_id
        response.headers["X-Process-Time"] = f"{process_time:.2f}ms"

        logger.info(
            "[%s] %s %s %d - %.2fms",
            request_id, request.method, request.url.path,
            response.status_code, process_time
        )
        return response
