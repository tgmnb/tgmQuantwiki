<template>
  <div
    id="app-root"
    :data-theme="theme"
  >
    <AppLayout />
  </div>
</template>

<script setup lang="ts">
import { useUIStore } from '@/stores/ui';
import AppLayout from '@/components/layout/AppLayout.vue';
import { computed, onMounted } from 'vue';

const uiStore = useUIStore();
const theme = computed(() => uiStore.theme);

// 初始化主题
onMounted(() => {
  document.documentElement.setAttribute('data-theme', uiStore.theme);
});
</script>

<style>
#app-root {
  width: 100%;
  height: 100vh;
  overflow: hidden;
}
</style>
