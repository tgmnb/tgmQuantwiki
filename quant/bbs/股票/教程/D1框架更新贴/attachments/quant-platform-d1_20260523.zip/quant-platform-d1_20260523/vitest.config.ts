import { defineConfig } from 'vitest/config';
import vue from '@vitejs/plugin-vue';
import { resolve } from 'path';

export default defineConfig({
  plugins: [vue()],
  test: {
    globals: true,
    environment: 'jsdom',
    exclude: ['node_modules', 'dist', '.idea', '.git', '.cache'],
    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html'],
      thresholds: {
        global: 60,
        statements: 60,
        branches: 50,
        functions: 60,
        lines: 60,
      },
    },
    // 别名配置，与 vite.config.ts 保持一致
    alias: {
      '@': resolve(__dirname, 'src'),
    },
  },
});
