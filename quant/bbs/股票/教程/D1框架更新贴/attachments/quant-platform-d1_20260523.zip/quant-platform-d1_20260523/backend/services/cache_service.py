"""
缓存服务 — 内存缓存

提供统一的缓存接口：
- get_cache(key)              获取缓存值
- set_cache(key, value, ttl)  设置缓存值（TTL 秒）
- delete_cache(key)           删除缓存
- invalidate_prefix(prefix)   按前缀批量删除
- get_stats()                 返回缓存统计信息
"""

from __future__ import annotations

import time
from typing import Any


class _MemoryCache:
    """线程安全的内存缓存，支持 TTL（秒）。"""

    def __init__(self) -> None:
        self._store: dict[str, tuple[float, Any]] = {}

    def get(self, key: str) -> Any | None:
        now = time.monotonic()
        entry = self._store.get(key)
        if entry is None:
            return None
        ts, value = entry
        if now > ts:
            self._store.pop(key, None)
            return None
        return value

    def set(self, key: str, value: Any, ttl: int) -> None:
        expire_at = time.monotonic() + ttl
        self._store[key] = (expire_at, value)

    def delete(self, key: str) -> None:
        self._store.pop(key, None)

    def invalidate_prefix(self, prefix: str) -> None:
        keys = [k for k in self._store if k.startswith(prefix)]
        for k in keys:
            self._store.pop(k, None)

    def stats(self) -> dict[str, Any]:
        now = time.monotonic()
        total = len(self._store)
        active = sum(1 for ts, _ in self._store.values() if ts > now)
        return {"total_entries": total, "active_entries": active, "backend": "memory"}


_memory_cache = _MemoryCache()


def get_cache(key: str) -> Any | None:
    """获取缓存值。"""
    return _memory_cache.get(key)


def set_cache(key: str, value: Any, ttl: int = 60) -> None:
    """设置缓存值，TTL 单位为秒。"""
    _memory_cache.set(key, value, ttl)


def delete_cache(key: str) -> None:
    """删除指定缓存。"""
    _memory_cache.delete(key)


def invalidate_prefix(prefix: str) -> None:
    """删除指定前缀的所有缓存。"""
    _memory_cache.invalidate_prefix(prefix)


def get_stats() -> dict[str, Any]:
    """返回缓存统计信息。"""
    return _memory_cache.stats()
