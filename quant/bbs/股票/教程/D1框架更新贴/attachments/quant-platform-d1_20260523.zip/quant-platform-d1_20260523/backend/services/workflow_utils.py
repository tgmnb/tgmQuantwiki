# -*- coding: utf-8 -*-
"""Workflow utility module - cleanup helpers."""
from __future__ import annotations

import logging
import threading
import time

logger = logging.getLogger("quant.workflow_utils")

_TASK_CLEANUP_TTL = 3600.0
_MAX_RUN_STATES = 200
_tasks_cleanup_stamp = 0.0
_tasks_lock = threading.Lock()


def cleanup_expired_tasks(_run_states: dict, _save_task_states) -> None:
    """Clean up expired tasks (TTL + max count limit)."""
    global _tasks_cleanup_stamp
    now = time.time()
    if now - _tasks_cleanup_stamp < 5.0:
        return
    _tasks_cleanup_stamp = now

    with _tasks_lock:
        expired = [
            wid for wid, state in _run_states.items()
            if not state.get("running") and state.get("started_at")
            and (now - state.get("started_at", 0)) >= _TASK_CLEANUP_TTL
        ]
        for wid in expired:
            del _run_states[wid]
            logger.info(f"清理过期任务: {wid}")

        if len(_run_states) > _MAX_RUN_STATES:
            finished = [
                (wid, _run_states[wid].get("started_at") or 0)
                for wid in list(_run_states)
                if not _run_states[wid].get("running")
            ]
            finished.sort(key=lambda x: x[1])
            for wid, _ in finished[:len(_run_states) - _MAX_RUN_STATES]:
                del _run_states[wid]
                logger.info(f"清理最老任务: {wid}")

        _save_task_states(_run_states)


def cleanup_run_state(wf_id=None, _run_states=None, _save_task_states=None):
    """Clean up run state (delegates to cleanup_expired_tasks)."""
    if _run_states is None or _save_task_states is None:
        # Lazy import from workflow_service
        from services.workflow_service import _run_states as rs, _save_task_states as sts
        cleanup_expired_tasks(rs, sts)
    else:
        cleanup_expired_tasks(_run_states, _save_task_states)
