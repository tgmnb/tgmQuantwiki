# -*- coding: utf-8 -*-
"""Platform status API — strategies, factors, signals overview."""
import time

import config as _config
from fastapi import APIRouter, HTTPException
from services.platform_context import PlatformContext

router = APIRouter(prefix="/api/platform", tags=["platform"])

# Global platform context (lazy init)
_pc: PlatformContext | None = None
_pc_build_time: float = 0
_PC_TTL = 300  # 5 minutes cache

def _get_pc() -> PlatformContext:
    global _pc
    if _pc is None:
        qp = _config.QUANT_PROJ
        if not qp:
            raise HTTPException(status_code=500, detail="quant_proj not configured")
        _pc = PlatformContext(qp)
    return _pc


def _get_status() -> dict:
    global _pc_build_time
    pc = _get_pc()
    now = time.time()
    # Rebuild if cache is stale or empty
    if _pc is None or (_pc._cache is None) or (now - _pc_build_time > _PC_TTL):
        pc.build()
        _pc_build_time = now
    ctx = pc._cache

    # Strategies summary
    strategies = ctx.get("strategies", {})
    by_type = {}
    for name, info in strategies.items():
        t = info.get("type", "unknown")
        by_type.setdefault(t, []).append({"name": name, "has_config": bool(info.get("config"))})

    # Factors summary
    factors = ctx.get("factors", {})
    factor_categories = {cat: len(files) for cat, files in factors.items()}

    # Signals
    sig = ctx.get("signals", {})
    timing_sigs = sig.get("timing", [])
    risk_sigs = sig.get("risk", [])

    # Backtest highlights
    bt_summary = pc._scan_backtest_summary()

    # Data source check
    data_dir = _config.DATA_DIR
    kline_ok = (data_dir / "stock-1h-trading-data-pro").exists() if data_dir else False
    daily_ok = (data_dir / "stock-trading-data-pro").exists() if data_dir else False

    return {
        "quant_proj": str(_config.QUANT_PROJ) if _config.QUANT_PROJ else None,
        "quant_proj_ready": (_config.QUANT_PROJ / "config.py").exists() if _config.QUANT_PROJ else False,
        "strategies": {
            "total": len(strategies),
            "by_type": {t: {"count": len(names), "examples": [n["name"] for n in names[:3]]}
                        for t, names in sorted(by_type.items())},
        },
        "factors": {
            "total": sum(len(v) for v in factors.values()),
            "categories": factor_categories,
        },
        "signals": {
            "timing": len(timing_sigs),
            "risk": len(risk_sigs),
        },
        "backtest": {
            "highlights": bt_summary,
        },
        "data_sources": {
            "kline_1h": kline_ok,
            "stock_daily": daily_ok,
        },
    }


@router.get("/status")
async def platform_status():
    """Platform overview: strategies, factors, signals, backtest highlights, data sources."""
    return _get_status()

@router.get("/summary")
async def platform_summary():
    """平台摘要信息（用于上下文注入）。"""
    pc = _get_pc()
    if pc._cache is None:
        pc.build()
    return {"summary": pc.get_summary()}


@router.post("/refresh")
async def platform_refresh():
    """Force-rebuild the platform context cache."""
    global _pc, _pc_build_time
    _pc = None
    _pc_build_time = 0
    return {"ok": True, "status": _get_status()}
