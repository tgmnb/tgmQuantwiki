import { generateId } from '../dag';
import { describe, it, expect } from 'vitest';

describe('DAG Utils', () => {
  describe('generateId', () => {
    it('should generate ID with default prefix', () => {
      const id = generateId();
      expect(id).toMatch(/^node_\d+_[a-z0-9]+$/);
    });

    it('should generate ID with custom prefix', () => {
      const id = generateId('step');
      expect(id).toMatch(/^step_\d+_[a-z0-9]+$/);
    });

    it('should generate unique IDs', () => {
      const id1 = generateId();
      const id2 = generateId();
      expect(id1).not.toBe(id2);
    });
  });
});
