# -*- coding: utf-8 -*-
"""
Comprehensive backend unit tests for workflow functionality.

Covers:
  - _topological_sort (cycle detection, layer grouping, disconnected nodes)
  - delete_workflow (non-existent / existing workflow)
  - list_workflows (returns expected fields)
  - NODE_REGISTRY validation
  - db_service workflow CRUD (create / update / list / delete workflow_runs)
  - _execute_step (mocked subprocess)
  - estimate_progress_from_log
"""

from __future__ import annotations

import importlib
import json
import logging
import os
import sqlite3
import sys
import time
import uuid
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ============================================================================
# Helper: import workflow_service with mocked config
# ============================================================================

def _import_workflow_service(proj_dir: Path | None = None):
    """Import workflow_service with a controlled config.

    Strategy: set sys.modules["config"] to a mock before the first import.
    On subsequent calls, we reload the already-imported module after patching
    its _config attribute.
    """
    backend_dir = Path(__file__).resolve().parent.parent
    if str(backend_dir) not in sys.path:
        sys.path.insert(0, str(backend_dir))

    mock_cfg = MagicMock()
    mock_cfg.QUANT_PROJ = proj_dir

    # Inject mock config before importing
    sys.modules["config"] = mock_cfg

    # Ensure the modules are importable
    if "services" not in sys.modules:
        import services  # noqa: F401
    if "services.workflow_service" not in sys.modules:
        from services import workflow_service  # noqa: F401

    # Now reload with fresh config
    ws = importlib.reload(sys.modules["services.workflow_service"])
    ws._config = mock_cfg

    # Re-initialize persistence dir based on config
    if proj_dir:
        ws._PERSISTENCE_DIR = proj_dir / "workflow_runs"
    else:
        import tempfile
        ws._PERSISTENCE_DIR = Path(tempfile.gettempdir()) / "workflow_runs"
    ws._PERSISTENCE_FILE = ws._PERSISTENCE_DIR / "task_states.json"

    return ws


def _import_workflow_nodes():
    backend_dir = Path(__file__).resolve().parent.parent
    if str(backend_dir) not in sys.path:
        sys.path.insert(0, str(backend_dir))

    mock_cfg = MagicMock()
    mock_cfg.QUANT_PROJ = None
    sys.modules["config"] = mock_cfg

    if "services" not in sys.modules:
        import services  # noqa: F401
    if "services.workflow_nodes" not in sys.modules:
        from services import workflow_nodes  # noqa: F401

    return sys.modules["services.workflow_nodes"]


# ============================================================================
# 1. Test _topological_sort
# ============================================================================


class TestTopologicalSort:
    """Tests for the _topological_sort function in workflow_service."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        self.ws = _import_workflow_service()

    def _sort(self, steps):
        return self.ws._topological_sort(steps)

    def test_empty_steps_returns_empty(self):
        """Empty steps list should return an empty list of layers."""
        result = self._sort([])
        assert result == []

    def test_single_step_no_deps(self):
        """A single step with no dependencies should yield one layer."""
        steps = [{"id": "A", "deps": []}]
        result = self._sort(steps)
        assert len(result) == 1
        assert result[0] == ["A"]

    def test_linear_chain_three_layers(self):
        """Linear chain A → B → C should produce 3 layers."""
        steps = [
            {"id": "A", "deps": []},
            {"id": "B", "deps": ["A"]},
            {"id": "C", "deps": ["B"]},
        ]
        result = self._sort(steps)
        assert len(result) == 3
        assert result[0] == ["A"]
        assert result[1] == ["B"]
        assert result[2] == ["C"]

    def test_diamond_shape_three_layers(self):
        """Diamond A → [B, C]; [B, C] → D should produce 3 layers."""
        steps = [
            {"id": "A", "deps": []},
            {"id": "B", "deps": ["A"]},
            {"id": "C", "deps": ["A"]},
            {"id": "D", "deps": ["B", "C"]},
        ]
        result = self._sort(steps)
        assert len(result) == 3
        assert result[0] == ["A"]
        assert set(result[1]) == {"B", "C"}
        assert result[2] == ["D"]

    def test_cycle_raises_value_error(self):
        """A cycle in the dependency graph should raise ValueError."""
        steps = [
            {"id": "A", "deps": ["B"]},
            {"id": "B", "deps": ["A"]},
        ]
        with pytest.raises(ValueError, match="cycle"):
            self._sort(steps)

    def test_three_node_cycle_raises_value_error(self):
        """Three-node cycle A→B→C→A should also be detected."""
        steps = [
            {"id": "A", "deps": ["C"]},
            {"id": "B", "deps": ["A"]},
            {"id": "C", "deps": ["B"]},
        ]
        with pytest.raises(ValueError):
            self._sort(steps)

    def test_disconnected_node_logs_warning(self, caplog):
        """A disconnected node (no deps, no dependents) in a multi-node graph
        should log a warning but not raise an error."""
        steps = [
            {"id": "A", "deps": [], "name": "Alpha"},
            {"id": "B", "deps": ["A"], "name": "Beta"},
            {"id": "X", "deps": [], "name": "Lonely"},  # disconnected
        ]
        with caplog.at_level(logging.WARNING, logger="quant.workflow_service"):
            result = self._sort(steps)
        # Should not raise
        assert len(result) >= 1
        # Should have logged a warning about the disconnected node
        assert any("disconnected" in r.message.lower() for r in caplog.records)

    def test_two_independent_nodes_one_layer(self):
        """Two nodes with no deps between them should be in the same layer."""
        steps = [
            {"id": "A", "deps": []},
            {"id": "B", "deps": []},
        ]
        result = self._sort(steps)
        assert len(result) == 1
        assert set(result[0]) == {"A", "B"}

    def test_dep_on_nonexistent_step_is_ignored(self):
        """A dep referencing a step not in the list should be silently ignored
        (the function only counts deps that are in step_map)."""
        steps = [
            {"id": "A", "deps": []},
            {"id": "B", "deps": ["A", "Z"]},  # Z doesn't exist
        ]
        result = self._sort(steps)
        assert len(result) == 2
        assert result[0] == ["A"]
        assert result[1] == ["B"]

    def test_missing_deps_key_treated_as_empty(self):
        """Steps without a 'deps' key should be treated as having no deps."""
        steps = [
            {"id": "A"},  # no deps key
            {"id": "B", "deps": ["A"]},
        ]
        result = self._sort(steps)
        assert len(result) == 2
        assert result[0] == ["A"]
        assert result[1] == ["B"]


# ============================================================================
# 2. Test delete_workflow
# ============================================================================


class TestDeleteWorkflow:
    """Tests for the delete_workflow function."""

    @pytest.fixture(autouse=True)
    def _setup(self, tmp_proj_dir):
        self.ws = _import_workflow_service(proj_dir=tmp_proj_dir)
        self.proj_dir = tmp_proj_dir
        self.wf_dir = tmp_proj_dir / "workflows"

    def test_delete_nonexistent_returns_false(self):
        """Deleting a workflow that doesn't exist should return False."""
        result = self.ws.delete_workflow("nonexistent_id")
        assert result is False

    def test_delete_existing_removes_file(self):
        """Deleting an existing workflow should remove the JSON file and return True."""
        wf_id = "test_wf_001"
        wf_data = {
            "id": wf_id,
            "name": "Test WF",
            "type": "atomic",
            "script": "workflow/test.py",
            "conda_env": "quantpy312",
            "created_at": time.time(),
            "updated_at": time.time(),
        }
        fpath = self.wf_dir / f"{wf_id}.json"
        fpath.write_text(json.dumps(wf_data), encoding="utf-8")
        assert fpath.exists()

        with patch.object(self.ws, "_get_proj_dir", return_value=self.proj_dir):
            result = self.ws.delete_workflow(wf_id)

        assert result is True
        assert not fpath.exists()

    def test_delete_no_proj_dir_returns_false(self):
        """If QUANT_PROJ is not configured, delete_workflow should return False."""
        ws = _import_workflow_service(proj_dir=None)
        result = ws.delete_workflow("anything")
        assert result is False

    def test_delete_cleans_up_run_states(self):
        """If the workflow had an in-memory run state, it should be removed."""
        wf_id = "test_wf_002"
        wf_data = {
            "id": wf_id,
            "name": "Cleanup Test",
            "type": "atomic",
            "script": "test.py",
            "created_at": 0,
            "updated_at": 0,
        }
        fpath = self.wf_dir / f"{wf_id}.json"
        fpath.write_text(json.dumps(wf_data), encoding="utf-8")

        # Create a run state
        self.ws._run_states[wf_id] = {"running": False}

        with patch.object(self.ws, "_get_proj_dir", return_value=self.proj_dir):
            self.ws.delete_workflow(wf_id)

        assert wf_id not in self.ws._run_states


# ============================================================================
# 3. Test list_workflows
# ============================================================================


class TestListWorkflows:
    """Tests for the list_workflows function."""

    @pytest.fixture(autouse=True)
    def _setup(self, tmp_proj_dir):
        self.ws = _import_workflow_service(proj_dir=tmp_proj_dir)
        self.proj_dir = tmp_proj_dir
        self.wf_dir = tmp_proj_dir / "workflows"

    def _create_wf_file(self, wf_id, name, wf_type="atomic", **extra):
        data = {
            "id": wf_id,
            "name": name,
            "description": f"Test workflow {name}",
            "type": wf_type,
            "created_at": time.time(),
            "updated_at": time.time(),
            **extra,
        }
        if wf_type == "atomic":
            data.setdefault("script", "workflow/test.py")
            data.setdefault("conda_env", "quantpy312")
            data.setdefault("steps", [])
        else:
            data.setdefault("steps", [])
        (self.wf_dir / f"{wf_id}.json").write_text(
            json.dumps(data), encoding="utf-8"
        )
        # Invalidate cache
        self.ws._wf_list_cache["data"] = None
        return data

    def test_returns_list_of_dicts(self):
        """list_workflows should return a list of dicts."""
        self._create_wf_file("wf1", "Alpha")
        result = self.ws.list_workflows()
        assert isinstance(result, list)
        assert len(result) >= 1
        assert all(isinstance(w, dict) for w in result)

    def test_expected_fields_present(self):
        """Each workflow summary should contain expected fields."""
        self._create_wf_file("wf2", "Beta")
        result = self.ws.list_workflows()
        wf = next(w for w in result if w["id"] == "wf2")
        for field in ("id", "name", "description", "type", "created_at", "updated_at"):
            assert field in wf, f"Missing field: {field}"

    def test_empty_dir_returns_defaults(self):
        """If no JSON files exist, list_workflows should return defaults."""
        result = self.ws.list_workflows()
        assert isinstance(result, list)
        assert len(result) > 0
        default_ids = [w["id"] for w in result]
        assert "factor" in default_ids
        assert "select" in default_ids

    def test_sorted_by_updated_at_desc(self):
        """Workflows should be sorted by updated_at descending."""
        t1 = time.time() - 100
        t2 = time.time() - 50
        t3 = time.time()
        self._create_wf_file("wf_a", "A", updated_at=t1)
        self._create_wf_file("wf_b", "B", updated_at=t3)
        self._create_wf_file("wf_c", "C", updated_at=t2)

        result = self.ws.list_workflows()
        custom = [w for w in result if w["id"] in ("wf_a", "wf_b", "wf_c")]
        assert [w["id"] for w in custom] == ["wf_b", "wf_c", "wf_a"]

    def test_no_proj_dir_returns_defaults(self):
        """Without a project dir, should return defaults."""
        ws = _import_workflow_service(proj_dir=None)
        result = ws.list_workflows()
        assert isinstance(result, list)
        assert len(result) > 0


# ============================================================================
# 4. Test NODE_REGISTRY validation
# ============================================================================


class TestNodeRegistry:
    """Tests for the NODE_REGISTRY in workflow_nodes.py."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        self.nodes = _import_workflow_nodes()

    def test_registry_is_dict(self):
        assert isinstance(self.nodes.NODE_REGISTRY, dict)

    def test_expected_node_types_present(self):
        """NODE_REGISTRY should contain all expected node types."""
        registry = self.nodes.NODE_REGISTRY
        expected = [
            "get_select_targets_from_account_list",
            "get_select_targets_from_strategy_list",
            "stock_select",
            "factor_compute",
            "factor_financial",
            "sector_factor",
            "backtest_daily_single",
            "backtest_daily_account",
            "backtest_hourly_single",
            "backtest_hourly_account",
            "index_synthesis",
        ]
        for node_id in expected:
            assert node_id in registry, f"Missing node type: {node_id}"

    def test_each_node_has_required_fields(self):
        """Every node in NODE_REGISTRY should have name, category, params, script."""
        required_fields = ("name", "category", "params", "script")
        for node_id, node_def in self.nodes.NODE_REGISTRY.items():
            for field in required_fields:
                assert field in node_def, (
                    f"Node '{node_id}' is missing required field '{field}'"
                )

    def test_script_field_is_nonempty_string(self):
        """Every node's script field should be a non-empty string."""
        for node_id, node_def in self.nodes.NODE_REGISTRY.items():
            script = node_def["script"]
            assert isinstance(script, str) and len(script) > 0, (
                f"Node '{node_id}' has invalid script: {script!r}"
            )

    def test_params_is_list(self):
        """Each node's params field should be a list."""
        for node_id, node_def in self.nodes.NODE_REGISTRY.items():
            assert isinstance(node_def["params"], list), (
                f"Node '{node_id}' params is not a list"
            )

    def test_each_param_has_id(self):
        """Each param dict should have at least an 'id' field."""
        for node_id, node_def in self.nodes.NODE_REGISTRY.items():
            for p in node_def["params"]:
                assert "id" in p, f"Node '{node_id}' has a param without 'id': {p}"

    def test_slots_in_and_out_are_lists(self):
        """slots_in and slots_out should be lists when present."""
        for node_id, node_def in self.nodes.NODE_REGISTRY.items():
            for slot_key in ("slots_in", "slots_out"):
                if slot_key in node_def:
                    assert isinstance(node_def[slot_key], list), (
                        f"Node '{node_id}' {slot_key} is not a list"
                    )

    def test_get_node_returns_correct_definition(self):
        """get_node should return the correct node or None."""
        registry = self.nodes.NODE_REGISTRY
        first_key = next(iter(registry))
        assert self.nodes.get_node(first_key) == registry[first_key]
        assert self.nodes.get_node("__nonexistent__") is None

    def test_list_nodes_excludes_tools(self):
        """list_nodes should not include tool-type nodes."""
        nodes = self.nodes.list_nodes()
        for n in nodes:
            assert n.get("type") != "tool"

    def test_list_tools_only_tools(self):
        """list_tools should only include tool-type nodes."""
        tools = self.nodes.list_tools()
        for t in tools:
            assert t.get("type") == "tool"

    def test_list_all_includes_everything(self):
        """list_all should include all nodes."""
        all_nodes = self.nodes.list_all()
        assert len(all_nodes) == len(self.nodes.NODE_REGISTRY)


# ============================================================================
# 5. Test db_service workflow functions
# ============================================================================


class TestWorkflowDB:
    """Tests for db_service workflow_runs CRUD operations.

    Uses an in-memory SQLite database with the workflow_runs table.
    Patches get_db() to yield our in-memory connection.
    """

    @pytest.fixture(autouse=True)
    def _setup(self, in_memory_db):
        self.conn = in_memory_db

        backend_dir = Path(__file__).resolve().parent.parent
        if str(backend_dir) not in sys.path:
            sys.path.insert(0, str(backend_dir))

        mock_cfg = MagicMock()
        mock_cfg.QUANT_PROJ = None
        sys.modules["config"] = mock_cfg

        if "services" not in sys.modules:
            import services  # noqa: F401
        if "services.db_service" not in sys.modules:
            from services import db_service  # noqa: F401

        self.db = sys.modules["services.db_service"]

        # Patch get_db to yield our in-memory connection
        self._get_db_patcher = patch.object(self.db, "get_db", self._mock_get_db)
        self._get_db_patcher.start()
        yield
        self._get_db_patcher.stop()

    def _mock_get_db(self):
        """Context manager that yields the in-memory connection."""
        class _Ctx:
            def __enter__(self_inner):
                return self.conn
            def __exit__(self_inner, *args):
                pass
        return _Ctx()

    def test_create_workflow_run_inserts_record(self):
        """create_workflow_run should insert a row with the given fields."""
        run_id = uuid.uuid4().hex[:12]
        wf_id = "test_wf_001"
        now = time.time()
        self.db.create_workflow_run(run_id, wf_id, "running", started_at=now)

        row = self.conn.execute(
            "SELECT * FROM workflow_runs WHERE run_id = ?", (run_id,)
        ).fetchone()
        assert row is not None
        assert row["wf_id"] == wf_id
        assert row["status"] == "running"
        assert row["started_at"] == now

    def test_update_workflow_run_changes_status(self):
        """update_workflow_run should update status and other fields."""
        run_id = uuid.uuid4().hex[:12]
        self.db.create_workflow_run(run_id, "wf_x", "running", started_at=time.time())

        ended = time.time()
        step_json = json.dumps({"step1": "done"})
        self.db.update_workflow_run(
            run_id, "completed", ended_at=ended, step_status_json=step_json
        )

        row = self.conn.execute(
            "SELECT * FROM workflow_runs WHERE run_id = ?", (run_id,)
        ).fetchone()
        assert row["status"] == "completed"
        assert row["ended_at"] == ended
        assert row["step_status_json"] == step_json

    def test_update_workflow_run_with_error(self):
        """update_workflow_run should record error message."""
        run_id = uuid.uuid4().hex[:12]
        self.db.create_workflow_run(run_id, "wf_y", "running", started_at=time.time())

        self.db.update_workflow_run(run_id, "failed", error="Something went wrong")

        row = self.conn.execute(
            "SELECT * FROM workflow_runs WHERE run_id = ?", (run_id,)
        ).fetchone()
        assert row["status"] == "failed"
        assert row["error"] == "Something went wrong"

    def test_list_workflow_runs_returns_correct_count(self):
        """list_workflow_runs should return records for a given wf_id."""
        wf_id = "wf_list_test"
        for i in range(3):
            rid = f"run_{i}"
            self.db.create_workflow_run(rid, wf_id, "completed", started_at=time.time() - i)

        runs = self.db.list_workflow_runs(wf_id, limit=10)
        assert len(runs) == 3
        # All records should belong to the correct wf_id
        for run in runs:
            assert run["wf_id"] == wf_id

    def test_list_workflow_runs_includes_duration(self):
        """list_workflow_runs should compute duration_seconds."""
        wf_id = "wf_dur"
        run_id = "run_dur"
        started = time.time() - 60
        ended = time.time() - 10
        self.db.create_workflow_run(run_id, wf_id, "completed", started_at=started)
        self.db.update_workflow_run(run_id, "completed", ended_at=ended)

        runs = self.db.list_workflow_runs(wf_id)
        assert len(runs) == 1
        assert runs[0]["duration_seconds"] is not None
        assert abs(runs[0]["duration_seconds"] - 50.0) < 2.0

    def test_list_workflow_runs_respects_limit(self):
        """list_workflow_runs should respect the limit parameter."""
        wf_id = "wf_limit"
        for i in range(5):
            self.db.create_workflow_run(
                f"run_l{i}", wf_id, "completed", started_at=time.time()
            )

        runs = self.db.list_workflow_runs(wf_id, limit=2)
        assert len(runs) == 2

    def test_delete_workflow_runs_removes_all(self):
        """delete_workflow_runs should remove all records for a workflow."""
        wf_id = "wf_del"
        self.db.create_workflow_run("r1", wf_id, "completed", started_at=time.time())
        self.db.create_workflow_run("r2", wf_id, "running", started_at=time.time())
        self.db.create_workflow_run("r3", "other_wf", "completed", started_at=time.time())

        self.db.delete_workflow_runs(wf_id)

        remaining = self.conn.execute(
            "SELECT * FROM workflow_runs WHERE wf_id = ?", (wf_id,)
        ).fetchall()
        assert len(remaining) == 0

        # Other workflow should be untouched
        other = self.conn.execute(
            "SELECT * FROM workflow_runs WHERE wf_id = ?", ("other_wf",)
        ).fetchall()
        assert len(other) == 1

    def test_get_workflow_run_returns_record(self):
        """get_workflow_run should return a single record dict."""
        run_id = "run_get"
        self.db.create_workflow_run(run_id, "wf_get", "running", started_at=time.time())

        record = self.db.get_workflow_run(run_id)
        assert record is not None
        assert record["run_id"] == run_id
        assert record["wf_id"] == "wf_get"

    def test_get_workflow_run_returns_none_for_missing(self):
        """get_workflow_run should return None for non-existent run_id."""
        assert self.db.get_workflow_run("no_such_run") is None


# ============================================================================
# 6. Test _execute_step (with mocked subprocess)
# ============================================================================


class TestExecuteStep:
    """Tests for the _execute_step function using mocked subprocess."""

    @pytest.fixture(autouse=True)
    def _setup(self, tmp_path):
        self.ws = _import_workflow_service(proj_dir=tmp_path)
        self.proj_dir = tmp_path

    def _make_state(self):
        return {
            "running": True,
            "pid": None,
            "step_outputs": {},
            "step_status": {},
            "current_step": None,
            "active_procs": {},
            "error": None,
        }

    def test_successful_step_returns_true(self, tmp_path):
        """A step whose subprocess exits with code 0 should return True."""
        state = self._make_state()
        script = tmp_path / "workflow" / "test.py"
        script.parent.mkdir(parents=True, exist_ok=True)
        script.write_text("print('hello')")

        step_info = {
            "step_id": "step1",
            "full_wf": {"script": "workflow/test.py", "conda_env": "test_env"},
            "step_name": "Test Step",
            "retry": 0,
        }

        mock_proc = MagicMock()
        mock_proc.stdout = iter(["line 1", "line 2"])
        mock_proc.poll.return_value = 0
        mock_proc.returncode = 0
        mock_proc.wait.return_value = 0

        log_file = tmp_path / "test.log"

        with patch.object(self.ws.subprocess, "Popen", return_value=mock_proc):
            result = self.ws._execute_step(
                state, step_info, tmp_path, str(log_file)
            )

        assert result is True
        assert state["step_status"]["step1"] == "done"

    def test_failed_step_returns_false(self, tmp_path):
        """A step whose subprocess exits with non-zero code should return False."""
        state = self._make_state()
        script = tmp_path / "workflow" / "fail.py"
        script.parent.mkdir(parents=True, exist_ok=True)
        script.write_text("raise SystemExit(1)")

        step_info = {
            "step_id": "step_fail",
            "full_wf": {"script": "workflow/fail.py", "conda_env": "test_env"},
            "step_name": "Failing Step",
            "retry": 0,
        }

        mock_proc = MagicMock()
        mock_proc.stdout = iter(["error output"])
        mock_proc.poll.return_value = 1
        mock_proc.returncode = 1
        mock_proc.wait.return_value = 1

        log_file = tmp_path / "test.log"

        with patch.object(self.ws.subprocess, "Popen", return_value=mock_proc):
            result = self.ws._execute_step(
                state, step_info, tmp_path, str(log_file)
            )

        assert result is False
        assert state["step_status"]["step_fail"] == "failed"

    def test_missing_script_returns_false(self, tmp_path):
        """If the script file doesn't exist, _execute_step should return False."""
        state = self._make_state()
        step_info = {
            "step_id": "step_missing",
            "full_wf": {"script": "workflow/nonexistent.py", "conda_env": "test"},
            "step_name": "Missing Script",
        }

        log_file = tmp_path / "test.log"
        result = self.ws._execute_step(state, step_info, tmp_path, str(log_file))
        assert result is False
        assert state["step_status"]["step_missing"] == "failed"

    def test_path_escape_returns_false(self, tmp_path):
        """If the script path escapes the project dir, _execute_step should return False."""
        state = self._make_state()
        step_info = {
            "step_id": "step_escape",
            "full_wf": {"script": "../../etc/passwd", "conda_env": "test"},
            "step_name": "Path Escape",
        }

        log_file = tmp_path / "test.log"
        result = self.ws._execute_step(state, step_info, tmp_path, str(log_file))
        assert result is False
        assert state["step_status"]["step_escape"] == "failed"


# ============================================================================
# 7. Test estimate_progress_from_log (bonus)
# ============================================================================


class TestEstimateProgress:
    """Tests for the estimate_progress_from_log helper in workflow_nodes."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        self.nodes = _import_workflow_nodes()

    def test_empty_log_returns_zero(self):
        assert self.nodes.estimate_progress_from_log("") == 0.0

    def test_none_log_returns_zero(self):
        assert self.nodes.estimate_progress_from_log(None) == 0.0

    def test_initialization_keyword(self):
        """初始化 alone should give 5.0 (not matched by 完成)."""
        result = self.nodes.estimate_progress_from_log("开始初始化系统")
        assert result == 5.0

    def test_initialization_complete_gives_100(self):
        """初始化完成 matches both '初始化' (5) and '完成' (100), so result is 100."""
        result = self.nodes.estimate_progress_from_log("初始化完成")
        assert result == 100.0

    def test_completion_keyword(self):
        result = self.nodes.estimate_progress_from_log("任务完成")
        assert result == 100.0

    def test_multiple_keywords_returns_max(self):
        """When multiple keywords match, should return the highest progress."""
        log = "初始化开始\n因子计算中\n回测完成"
        result = self.nodes.estimate_progress_from_log(log)
        assert result == 100.0  # "完成" maps to 100


# ============================================================================
# 8. Test data passing helpers (_write_step_output / _get_upstream_inputs)
# ============================================================================


class TestDataPassing:
    """Tests for inter-node data passing functions."""

    @pytest.fixture(autouse=True)
    def _setup(self, tmp_path):
        self.ws = _import_workflow_service(proj_dir=tmp_path)
        self.proj_dir = tmp_path

    def test_write_step_output_creates_manifest(self):
        """_write_step_output should create output.json with correct structure."""
        run_id = "run_001"
        step_id = "step_A"
        outputs = ["line1", "line2", "line3"]

        self.ws._write_step_output(self.proj_dir, run_id, step_id, outputs)

        manifest_path = self.proj_dir / "workflow_data" / run_id / step_id / "output.json"
        assert manifest_path.exists()

        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        assert manifest["step_id"] == step_id
        assert isinstance(manifest["output_lines"], list)
        assert manifest["output_lines"] == outputs
        assert "output_dir" in manifest
        assert step_id in manifest["output_dir"]

    def test_write_step_output_truncates_long_outputs(self):
        """_write_step_output should keep only the last 50 lines."""
        run_id = "run_trunc"
        step_id = "step_long"
        outputs = [f"line_{i}" for i in range(100)]

        self.ws._write_step_output(self.proj_dir, run_id, step_id, outputs)

        manifest_path = self.proj_dir / "workflow_data" / run_id / step_id / "output.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        assert len(manifest["output_lines"]) == 50
        assert manifest["output_lines"][0] == "line_50"
        assert manifest["output_lines"][-1] == "line_99"

    def test_get_upstream_inputs_empty_when_no_deps(self):
        """_get_upstream_inputs should return empty dict when deps list is empty."""
        result = self.ws._get_upstream_inputs(self.proj_dir, "run_002", [])
        assert result == {}

    def test_get_upstream_inputs_returns_existing(self):
        """After writing output for dep A, _get_upstream_inputs should return its path."""
        run_id = "run_003"
        # Write output for step A
        self.ws._write_step_output(self.proj_dir, run_id, "step_A", ["output_A"])

        # Step B depends on A
        result = self.ws._get_upstream_inputs(self.proj_dir, run_id, ["step_A"])
        assert "step_A" in result
        expected_dir = str(self.proj_dir / "workflow_data" / run_id / "step_A")
        assert result["step_A"] == expected_dir

    def test_get_upstream_inputs_skips_missing(self):
        """If a dep has no output manifest, it should not appear in the result."""
        run_id = "run_004"
        # Write output for A only
        self.ws._write_step_output(self.proj_dir, run_id, "step_A", ["out"])

        # Request deps A, B, C — only A has output
        result = self.ws._get_upstream_inputs(
            self.proj_dir, run_id, ["step_A", "step_B", "step_C"]
        )
        assert "step_A" in result
        assert "step_B" not in result
        assert "step_C" not in result

    def test_data_passing_env_vars(self, tmp_path):
        """_execute_step should set WF_INPUT_FILES and WF_DATA_DIR env vars
        when _upstream_inputs and _data_dir are present in step_info."""
        state = {
            "running": True,
            "pid": None,
            "step_outputs": {},
            "step_status": {},
            "current_step": None,
            "active_procs": {},
            "error": None,
        }

        # Create a test script that prints env vars
        script = tmp_path / "workflow" / "env_check.py"
        script.parent.mkdir(parents=True, exist_ok=True)
        script.write_text(
            "import os, json\n"
            "print('WF_INPUT_FILES=' + os.environ.get('WF_INPUT_FILES', 'NOT_SET'))\n"
            "print('WF_DATA_DIR=' + os.environ.get('WF_DATA_DIR', 'NOT_SET'))\n"
        )

        upstream_inputs = {"step_A": "/some/path/A"}
        data_dir = str(tmp_path / "workflow_data" / "run_env" / "step_B")

        step_info = {
            "step_id": "step_B",
            "full_wf": {"script": "workflow/env_check.py", "conda_env": "test_env"},
            "step_name": "Env Check",
            "retry": 0,
            "_upstream_inputs": upstream_inputs,
            "_data_dir": data_dir,
        }

        log_file = tmp_path / "test.log"

        captured_env = {}

        def fake_popen(cmd, **kwargs):
            env = kwargs.get("env", {})
            captured_env.update(env)
            mock_proc = MagicMock()
            mock_proc.stdout = iter(["line1"])
            mock_proc.poll.return_value = 0
            mock_proc.returncode = 0
            mock_proc.wait.return_value = 0
            return mock_proc

        with patch.object(self.ws.subprocess, "Popen", side_effect=fake_popen):
            self.ws._execute_step(
                state, step_info, tmp_path, str(log_file), run_id="run_env"
            )

        assert "WF_INPUT_FILES" in captured_env
        assert json.loads(captured_env["WF_INPUT_FILES"]) == upstream_inputs
        assert "WF_DATA_DIR" in captured_env
        assert captured_env["WF_DATA_DIR"] == data_dir


# ============================================================================
# 9. Additional TestNodeRegistry tests (data source + output nodes)
# ============================================================================


class TestNodeRegistryDataAndOutput:
    """Tests for specific data-source and output node types in NODE_REGISTRY."""

    @pytest.fixture(autouse=True)
    def _setup(self):
        self.nodes = _import_workflow_nodes()

    def test_data_source_node_exists(self):
        """fetch_market_data should exist in NODE_REGISTRY as a data-source node."""
        registry = self.nodes.NODE_REGISTRY
        assert "fetch_market_data" in registry, (
            "NODE_REGISTRY missing 'fetch_market_data' node"
        )
        node = registry["fetch_market_data"]
        assert node["name"]  # non-empty name
        assert node["category"] == "数据源"
        assert isinstance(node["params"], list)
        assert isinstance(node.get("slots_out", []), list)

    def test_output_node_exists(self):
        """export_results should exist in NODE_REGISTRY as an output node."""
        registry = self.nodes.NODE_REGISTRY
        assert "export_results" in registry, (
            "NODE_REGISTRY missing 'export_results' node"
        )
        node = registry["export_results"]
        assert node["name"]  # non-empty name
        assert isinstance(node["params"], list)
        assert isinstance(node.get("slots_in", []), list)
