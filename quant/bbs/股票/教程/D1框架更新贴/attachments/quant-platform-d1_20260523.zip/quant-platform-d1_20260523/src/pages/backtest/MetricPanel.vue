<template>
  <div class="metric-panel">
    <div class="metric-grid">
      <div
        v-for="item in metricItems"
        :key="item.key"
        class="metric-card"
      >
        <div class="mc-label">
          {{ item.label }}
        </div>
        <div class="mc-value">
          {{ item.display }}
        </div>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';

const props = defineProps<{
  metrics: Record<string, any>;
}>();

type MetricCategory = 'pct' | 'decimal' | 'int' | 'nav' | 'money';

/** 指标分类映射，决定数值格式化方式 */
const CATEGORY_MAP: Record<string, MetricCategory> = {
  // 百分比（后端已乘100，直接加%即可）
  年化收益率: 'pct',
  年化收益: 'pct',
  最大回撤: 'pct',
  年化波动率: 'pct',
  胜率: 'pct',
  // 纯小数比率
  Sharpe比率: 'decimal',
  Sortino比率: 'decimal',
  Calmar比率: 'decimal',
  盈亏比: 'decimal',
  盈亏收益比: 'decimal',
  '年化收益/回撤比': 'decimal',
  收益回撤比: 'decimal',
  // 整数
  总交易次数: 'int',
  盈利次数: 'int',
  亏损次数: 'int',
  // 净值
  累积净值: 'nav',
  净值: 'nav',
  // 金额
  最大连续亏损: 'money',
  最大连续盈利: 'money',
};

const LABEL_MAP: Record<string, string> = {
  年化收益率: '年化收益率',
  年化收益: '年化收益',
  累积净值: '累积净值',
  净值: '净值',
  Sharpe比率: 'Sharpe',
  Sortino比率: 'Sortino',
  Calmar比率: 'Calmar',
  最大回撤: '最大回撤',
  年化波动率: '年化波动率',
  胜率: '胜率',
  盈亏比: '盈亏比',
  盈亏收益比: '盈亏收益比',
  '年化收益/回撤比': '收益回撤比',
  收益回撤比: '收益回撤比',
  总交易次数: '总交易次数',
  盈利次数: '盈利次数',
  亏损次数: '亏损次数',
  最大连续亏损: '最大连续亏损',
  最大连续盈利: '最大连续盈利',
};

function formatMetric(key: string, value: any): { display: string } {
  const n = parseFloat(value);
  if (isNaN(n)) {
    return { display: String(value ?? '--') };
  }

  const category = CATEGORY_MAP[key];

  switch (category) {
    case 'pct': {
      const sign = n > 0 && !key.includes('回撤') ? '+' : '';
      return { display: `${sign}${n.toFixed(2)}%` };
    }
    case 'nav': {
      return { display: n.toFixed(4) };
    }
    case 'int': {
      return { display: String(Math.round(n)) };
    }
    case 'decimal': {
      return { display: n.toFixed(2) };
    }
    case 'money': {
      const sign = n > 0 ? '+' : '';
      return { display: `${sign}${n.toFixed(2)}` };
    }
    default: {
      const abs = Math.abs(n);
      const display = abs < 100 ? n.toFixed(2) : n.toFixed(1);
      return { display };
    }
  }
}

const metricItems = computed(() => {
  const m = props.metrics || {};
  return Object.entries(m)
    .filter(([, v]) => v !== null && v !== undefined && v !== '')
    .map(([key, value]) => {
      const label = LABEL_MAP[key] || key.replace(/_/g, ' ');
      const { display } = formatMetric(key, value);
      return { key, label, display };
    });
});
</script>

<style scoped>
.metric-panel { margin-bottom: 14px; }
.metric-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(140px, 1fr));
  gap: 10px;
}
.metric-card {
  position: relative;
  overflow: hidden;
  background: var(--bg-secondary);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: 12px 14px;
  display: flex;
  flex-direction: column;
  gap: 5px;
  transition: border-color var(--transition), box-shadow var(--transition);
}
.metric-card::before {
  content: '';
  position: absolute;
  top: 0; left: 0; right: 0;
  height: 2px;
  background: linear-gradient(90deg, var(--accent), #a78bfa);
  opacity: 0;
  transition: opacity 0.2s;
}
.metric-card:hover {
  border-color: var(--border2);
  box-shadow: var(--shadow-sm);
}
.metric-card:hover::before { opacity: 1; }
.mc-label {
  font-size: var(--font-2xs);
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: var(--space-2);
  font-weight: 500;
}
.mc-value {
  font-size: var(--font-2xl);
  font-weight: 700;
  font-family: var(--font-mono);
  color: var(--text-primary);
  line-height: 1.2;
  letter-spacing: -0.3px;
}
.mc-value.up   { color: var(--up); }
.mc-value.down { color: var(--down); }
.mc-value.accent { color: var(--accent); }
</style>
