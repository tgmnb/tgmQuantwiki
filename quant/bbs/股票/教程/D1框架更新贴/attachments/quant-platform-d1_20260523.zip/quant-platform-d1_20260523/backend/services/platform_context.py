# -*- coding: utf-8 -*-
"""PlatformContext - 平台上下文情报中心

扫描量化项目目录，收集策略/因子/信号统一知识图谱。"""
from __future__ import annotations

import logging
from pathlib import Path
from typing import Any

_logger = logging.getLogger("quant.platform_context")

# 扫描路径配置
_STRATEGIES_REL = "backtest/strategies"
_FACTORS_REL = "factor_calculate/factor_hub"
_SIGNALS_REL = "signal_hub"


class PlatformContext:
    """扫描量化项目的目录结构，收集策略、因子、信号等信息。

    内部缓存：build() 只在会话启动时执行扫描，
    而 refresh() 可随时强制重新扫描。
    """

    def __init__(self, quant_proj: str | Path | None = None) -> None:
        self._quant_proj = Path(quant_proj) if quant_proj else None
        self._cache: dict[str, Any] | None = None

    def refresh(self, quant_proj: str | Path | None = None) -> None:
        """刷新缓存，可选传入新的 quant_proj 路径。

        如未指定 quant_proj 且当前未初始化，自动从 config.QUANT_PROJ 读取。
        """
        self._cache = None
        if quant_proj is not None:
            self._quant_proj = Path(quant_proj)
        elif self._quant_proj is None:
            from config import QUANT_PROJ
            if QUANT_PROJ:
                self._quant_proj = Path(QUANT_PROJ)

    def build(self) -> dict[str, Any]:
        """构建平台上下文情报。

        Returns:
            {
                "strategies": {策略名: {"type": str, "has_config": bool, "path": str}},
                "factors": {目录名: [文件列表]},
                "signals": {"timing": [...], "risk": [...]}
            }
        """
        if self._cache is not None:
            return self._cache

        # Fallback：如未指定 quant_proj，从 config 获取
        if self._quant_proj is None:
            from config import QUANT_PROJ
            if QUANT_PROJ:
                self._quant_proj = Path(QUANT_PROJ)

        strategies = self._scan_strategies()
        factors = self._scan_factors()
        signals = self._scan_signals()

        self._cache = {
            "strategies": strategies,
            "factors": factors,
            "signals": signals,
        }
        return self._cache

    # ------------------------------------------------------------------
    # 内部扫描方法
    # ------------------------------------------------------------------


    def get_summary(self):
        """平台概述（用于上下文注入）。"""
        if self._cache is None:
            self.build()
        lines = []
        ctx = self._cache

        # Strategies
        strategies = ctx.get("strategies", {})
        if strategies:
            by_type = {}
            for name, info in strategies.items():
                t = info.get("type", "unknown")
                by_type.setdefault(t, []).append(name)
            lines.append("Strategies (%d):" % len(strategies))
            for t, names in sorted(by_type.items()):
                s = names[:4]
                suf = " (+%d more)" % (len(names) - 4) if len(names) > 4 else ""
                lines.append("  [%s] %s%s" % (t, ", ".join(s), suf))
        else:
            lines.append("Strategies: none")

        # Factors
        factors = ctx.get("factors", {})
        if factors:
            total = sum(len(v) for v in factors.values())
            lines.append("Factors (%d):" % total)
            for cat, files in sorted(factors.items()):
                s = files[:3]
                suf = " (+%d more)" % (len(files) - 3) if len(files) > 3 else ""
                lines.append("  %s: %s%s" % (cat, ", ".join(s), suf))

        # Signals
        sig = ctx.get("signals", {})
        t_sig = sig.get("timing", [])
        r_sig = sig.get("risk", [])
        lines.append("Timing: %d | Risk: %d" % (len(t_sig), len(r_sig)))

        # Backtest summary
        bt_summary = self._scan_backtest_summary()
        if bt_summary:
            lines.append("Recent Backtests: " + bt_summary)

        return "\n".join(lines)


    def _scan_backtest_summary(self):
        """Scans backtest result files for performance highlights."""
        import csv
        if not self._quant_proj or not self._quant_proj.exists():
            return ""
        bt_root = self._quant_proj / "backtest"
        results = []

        # Scan param_sweep_results/summary_*.csv (most recent)
        psr = bt_root / "data" / "param_sweep_results"
        if psr.exists():
            csv_files = sorted([f for f in psr.glob("summary_*.csv")],
                               key=lambda x: x.stat().st_mtime, reverse=True)
            for f in csv_files[:4]:
                try:
                    with open(f, "r", encoding="utf-8-sig") as fp:
                        reader = csv.DictReader(fp)
                        rows = sorted(reader,
                                      key=lambda r: float(r.get("annual_return", 0) or 0),
                                      reverse=True)
                        for row in rows[:2]:
                            name = f.stem[:30]
                            ann = row.get("annual_return", "?")
                            mdd = row.get("max_drawdown", "?")
                            calmar = row.get("calmar_ratio", "?")
                            sw = row.get("short_window", "?")
                            lw = row.get("long_window", "?")
                            results.append(
                                f"{name}: ret={ann}, mdd={mdd}, calmar={calmar} (W={sw}/{lw})"
                            )
                except Exception:
                    pass

        # Also scan result_summary.json files
        strat_root = bt_root / "strategies"
        if strat_root.exists():
            import json
            for sf in strat_root.rglob("result_summary.json"):
                try:
                    data = json.loads(sf.read_text(encoding="utf-8"))
                    name = sf.parent.name[:30]
                    annual = data.get("annualized_return") or data.get("annual_return")
                    max_dd = data.get("max_drawdown")
                    sharpe = data.get("sharpe_ratio")
                    if annual is not None:
                        parts = [f"{name}: ann={annual*100:.0f}%"]
                        if max_dd:
                            parts.append(f"dd={max_dd*100:.0f}%")
                        if sharpe:
                            parts.append(f"sr={sharpe:.1f}")
                        results.append(" ".join(parts))
                except Exception:
                    pass

        return "; ".join(results[:6])

    def _scan_strategies(self) -> dict[str, dict[str, Any]]:
        """扫描 backtest/strategies/ 下的目录结构。

        目录格式: {backtest_type}/{strategy_name}/stg_config.py
        """
        result: dict[str, dict[str, Any]] = {}
        if not self._quant_proj or not self._quant_proj.exists():
            return result

        strategies_root = self._quant_proj / _STRATEGIES_REL
        if not strategies_root.exists():
            return result

        for backtest_type_dir in sorted(strategies_root.iterdir()):
            if not backtest_type_dir.is_dir():
                continue
            backtest_type = backtest_type_dir.name
            for strategy_dir in sorted(backtest_type_dir.iterdir()):
                if not strategy_dir.is_dir():
                    continue
                strategy_name = strategy_dir.name
                has_config = (strategy_dir / "stg_config.py").exists()
                rel_path = str(strategy_dir.relative_to(self._quant_proj).as_posix())
                result[strategy_name] = {
                    "type": backtest_type,
                    "has_config": has_config,
                    "path": rel_path,
                }
        return result

    def _scan_factors(self) -> dict[str, list[str]]:
        """扫描 factor_calculate/factor_hub/ 下的目录结构。

        返回: {分类: [因子文件列表]}
        """
        result: dict[str, list[str]] = {}
        if not self._quant_proj or not self._quant_proj.exists():
            return result

        factors_root = self._quant_proj / _FACTORS_REL
        if not factors_root.exists():
            return result

        for cat_dir in sorted(factors_root.iterdir()):
            if not cat_dir.is_dir():
                continue
            category = cat_dir.name
            files = sorted([
                f.name for f in cat_dir.iterdir()
                if f.is_file() and f.suffix == ".py" and f.name != "__init__.py"
            ])
            result[category] = files
        return result

    def _scan_signals(self) -> dict[str, list[str]]:
        """扫描 signal_hub/ 目录结构。

        返回: {"timing": [...], "risk": [...]}
        """
        result: dict[str, list[str]] = {"timing": [], "risk": []}
        if not self._quant_proj or not self._quant_proj.exists():
            return result

        sig_root = self._quant_proj / _SIGNALS_REL
        if not sig_root.exists():
            return result

        timing = []
        risk = []
        for item in sig_root.iterdir():
            if item.is_dir():
                if item.name == "择时信号":
                    timing.extend([i.name for i in item.iterdir() if i.is_file()])
                elif item.name == "风险信号":
                    risk.extend([i.name for i in item.iterdir() if i.is_file()])

        return {"timing": timing, "risk": risk}
