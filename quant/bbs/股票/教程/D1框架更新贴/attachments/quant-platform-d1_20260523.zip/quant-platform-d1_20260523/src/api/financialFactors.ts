import { request } from './request';

export const financialFactorsApi = {
  async list() {
    return request.get('/api/financial_factors/list');
  },

  async getContent(module: string, limit?: number) {
    return request.get('/api/financial_factors/content', { params: { module, limit } });
  },

  async save(module: string, content: string) {
    return request.post('/api/financial_factors/save', { module, content });
  },

  async deleteModule(module: string) {
    return request.post('/api/financial_factors/delete', { module });
  },
};
