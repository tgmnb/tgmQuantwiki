<template>
  <button
    class="btn"
    :class="[
      `btn--${type}`,
      `btn--${size}`,
      {
        'btn--disabled': disabled,
        'btn--loading': loading,
      },
    ]"
    :disabled="disabled || loading"
    @click="handleClick"
  >
    <span
      v-if="loading"
      class="btn__spinner"
    />
    <span
      v-if="$slots.icon && !loading"
      class="btn__icon"
    >
      <slot name="icon" />
    </span>
    <span class="btn__text">
      <slot />
    </span>
  </button>
</template>

<script setup lang="ts">
type ButtonType = 'primary' | 'secondary' | 'danger' | 'success' | 'warning' | 'info' | 'ghost';
type ButtonSize = 'xs' | 'sm' | 'md' | 'lg';

interface Props {
  type?: ButtonType;
  size?: ButtonSize;
  disabled?: boolean;
  loading?: boolean;
}

const props = withDefaults(defineProps<Props>(), {
  type: 'primary',
  size: 'md',
  disabled: false,
  loading: false,
});

const emit = defineEmits<{
  (e: 'click', event: MouseEvent): void;
}>();

const handleClick = (event: MouseEvent) => {
  if (props.disabled || props.loading) return;
  emit('click', event);
};
</script>

<style scoped>
.btn {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-2);
  padding: 0 var(--space-5);
  border-radius: var(--radius);
  font-size: var(--font-sm);
  cursor: pointer;
  border: 1px solid transparent;
  font-weight: 500;
  transition: all var(--transition);
  white-space: nowrap;
  font-family: inherit;
  line-height: 1;
  height: var(--h-md);
  position: relative;
  overflow: hidden;
}

.btn::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(180deg, rgba(255,255,255,0.08) 0%, transparent 100%);
  opacity: 0;
  transition: opacity var(--transition);
  pointer-events: none;
}

.btn:hover::after {
  opacity: 1;
}

.btn:active {
  transform: scale(0.97);
  transition-duration: 0.05s;
}

.btn--disabled,
.btn:disabled {
  opacity: 0.4;
  cursor: not-allowed;
  pointer-events: none;
}

.btn--primary {
  background: var(--accent);
  color: #fff;
  border-color: transparent;
  font-weight: 600;
}
.btn--primary:hover {
  background: var(--accent-hover);
  box-shadow: var(--shadow-accent);
}

.btn--secondary {
  background: var(--bg-tertiary);
  color: var(--text-primary);
  border-color: var(--border2);
}
.btn--secondary:hover {
  background: var(--bg-hover);
  border-color: var(--border-hover);
}

.btn--ghost {
  background: transparent;
  border-color: var(--border-color);
  color: var(--text-secondary);
}
.btn--ghost:hover {
  background: var(--bg-hover);
  color: var(--text-primary);
  border-color: var(--border2);
}

.btn--danger {
  background: var(--down);
  color: #fff;
  border-color: transparent;
}
.btn--danger:hover {
  background: #e6434f;
  box-shadow: 0 4px 16px rgba(255, 77, 94, 0.3);
}

.btn--success {
  background: var(--up);
  color: #fff;
  border-color: transparent;
}
.btn--success:hover {
  background: #00b86e;
  box-shadow: 0 4px 16px rgba(0, 200, 122, 0.3);
}

.btn--warning {
  background: var(--warning);
  color: #fff;
  border-color: transparent;
}
.btn--warning:hover {
  background: #e0941c;
}

.btn--info {
  background: var(--bg-tertiary);
  color: var(--text-secondary);
  border-color: var(--border2);
}
.btn--info:hover {
  background: var(--bg-hover);
  color: var(--text-primary);
}

.btn--xs {
  padding: 0 var(--space-3);
  font-size: var(--font-2xs);
  height: var(--h-sm);
  border-radius: var(--radius-xs);
}
.btn--sm {
  padding: 0 var(--space-4);
  font-size: var(--font-xs);
  height: 28px;
}
.btn--md {
  padding: 0 var(--space-5);
  font-size: var(--font-sm);
  height: var(--h-md);
}
.btn--lg {
  padding: 0 var(--space-7);
  font-size: var(--font-md);
  height: var(--h-lg);
}

.btn__spinner {
  width: 14px;
  height: 14px;
  border: 2px solid currentColor;
  border-top-color: transparent;
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

.btn--loading .btn__text {
  opacity: 0.7;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}
</style>
