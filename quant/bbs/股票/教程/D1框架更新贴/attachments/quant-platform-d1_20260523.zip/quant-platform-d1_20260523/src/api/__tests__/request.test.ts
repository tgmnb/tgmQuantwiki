import { describe, it, expect, vi, beforeEach } from 'vitest';

const mockState = vi.hoisted(() => ({
  responseOnFulfilled: undefined as any,
  responseOnRejected: undefined as any,
  fns: {
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    delete: vi.fn(),
    patch: vi.fn(),
  },
}));

vi.mock('axios', () => ({
  default: {
    create: vi.fn(() => ({
      get: mockState.fns.get,
      post: mockState.fns.post,
      put: mockState.fns.put,
      delete: mockState.fns.delete,
      patch: mockState.fns.patch,
      interceptors: {
        response: {
          use: vi.fn((onFulfilled, onRejected) => {
            mockState.responseOnFulfilled = onFulfilled;
            mockState.responseOnRejected = onRejected;
          }),
        },
      },
    })),
    isAxiosError: vi.fn((err: any) => err && err.isAxiosError),
  },
}));

import { ApiError, setErrorHandler, request } from '../request';

describe('ApiError', () => {
  it('should create ApiError with all fields', () => {
    const err = new ApiError('CODE', 'msg', 400, { detail: 'd' });
    expect(err.code).toBe('CODE');
    expect(err.message).toBe('msg');
    expect(err.statusCode).toBe(400);
    expect(err.detail).toEqual({ detail: 'd' });
    expect(err.name).toBe('ApiError');
  });

  it('fromResponse should extract code, detail and statusCode', () => {
    const err = ApiError.fromResponse({ code: 'ERR', message: 'hello' }, 500);
    expect(err.code).toBe('ERR');
    expect(err.message).toBe('hello');
    expect(err.statusCode).toBe(500);
    expect(err.detail).toEqual({ code: 'ERR', message: 'hello' });
  });

  it('fromResponse should use defaults when fields missing', () => {
    const err = ApiError.fromResponse(null, 500);
    expect(err.code).toBe('UNKNOWN_ERROR');
    expect(err.message).toBe('Request failed');
    expect(err.statusCode).toBe(500);
  });

  it('fromResponse should fallback to detail when message missing', () => {
    const err = ApiError.fromResponse({ detail: 'detailed info' }, 422);
    expect(err.message).toBe('detailed info');
  });

  it('networkError should wrap original error', () => {
    const original = new Error('network down');
    const err = ApiError.networkError(original);
    expect(err.code).toBe('NETWORK_ERROR');
    expect(err.message).toBe('network down');
  });

  it('timeoutError should return timeout ApiError', () => {
    const err = ApiError.timeoutError();
    expect(err.code).toBe('TIMEOUT');
    expect(err.message).toBe('Request timeout');
  });
});

describe('request interceptors', () => {
  beforeEach(() => {
    vi.clearAllMocks();
    setErrorHandler(null as any);
  });

  it('should unwrap response data on success', () => {
    const response = { data: { foo: 'bar' } };
    const result = mockState.responseOnFulfilled(response);
    expect(result).toEqual({ foo: 'bar' });
  });

  it('should handle server error response', async () => {
    const handler = vi.fn();
    setErrorHandler(handler);

    const error = {
      isAxiosError: true,
      response: {
        status: 500,
        data: { code: 'SERVER_ERR', detail: 'server broken' },
      },
    };

    await expect(mockState.responseOnRejected(error)).rejects.toBeInstanceOf(ApiError);
    try {
      await mockState.responseOnRejected(error);
    } catch (e: any) {
      expect(e.code).toBe('SERVER_ERR');
      expect(e.message).toBe('server broken');
      expect(e.statusCode).toBe(500);
    }
    expect(handler).toHaveBeenCalledWith('server broken');
  });

  it('should handle timeout error (ECONNABORTED)', async () => {
    const handler = vi.fn();
    setErrorHandler(handler);

    const error = {
      isAxiosError: true,
      code: 'ECONNABORTED',
      message: 'timeout',
    };

    await expect(mockState.responseOnRejected(error)).rejects.toBeInstanceOf(ApiError);
    try {
      await mockState.responseOnRejected(error);
    } catch (e: any) {
      expect(e.code).toBe('TIMEOUT');
      expect(e.message).toBe('Request timeout');
    }
    expect(handler).toHaveBeenCalledWith('Request timeout');
  });

  it('should handle network error', async () => {
    const handler = vi.fn();
    setErrorHandler(handler);

    const error = {
      isAxiosError: true,
      message: 'Network Error',
    };

    await expect(mockState.responseOnRejected(error)).rejects.toBeInstanceOf(ApiError);
    try {
      await mockState.responseOnRejected(error);
    } catch (e: any) {
      expect(e.code).toBe('NETWORK_ERROR');
      expect(e.message).toBe('Network Error');
    }
    expect(handler).toHaveBeenCalledWith('Network Error');
  });

  it('should handle non-axios error', async () => {
    const handler = vi.fn();
    setErrorHandler(handler);

    const error = new Error('random failure');

    await expect(mockState.responseOnRejected(error)).rejects.toBeInstanceOf(ApiError);
    try {
      await mockState.responseOnRejected(error);
    } catch (e: any) {
      expect(e.code).toBe('UNKNOWN');
      expect(e.message).toBe('random failure');
    }
    expect(handler).toHaveBeenCalledWith('random failure');
  });

  it('should call error handler if set', async () => {
    const handler = vi.fn();
    setErrorHandler(handler);

    const error = {
      isAxiosError: true,
      response: {
        status: 400,
        data: { code: 'BAD_REQUEST', detail: 'bad' },
      },
    };

    try {
      await mockState.responseOnRejected(error);
    } catch {
      // ignore
    }

    expect(handler).toHaveBeenCalledTimes(1);
    expect(handler).toHaveBeenCalledWith('bad');
  });

  it('should not throw if error handler is not set', async () => {
    setErrorHandler(null as any);

    const error = {
      isAxiosError: true,
      response: {
        status: 400,
        data: { code: 'BAD_REQUEST' },
      },
    };

    await expect(mockState.responseOnRejected(error)).rejects.toBeInstanceOf(ApiError);
  });
});

describe('request methods', () => {
  it('should call get', () => {
    request.get('/test');
    expect(mockState.fns.get).toHaveBeenCalledWith('/test', undefined);
  });

  it('should call post', () => {
    request.post('/test', { a: 1 });
    expect(mockState.fns.post).toHaveBeenCalledWith('/test', { a: 1 }, undefined);
  });

  it('should call put', () => {
    request.put('/test', { a: 1 });
    expect(mockState.fns.put).toHaveBeenCalledWith('/test', { a: 1 }, undefined);
  });

  it('should call delete', () => {
    request.delete('/test');
    expect(mockState.fns.delete).toHaveBeenCalledWith('/test', undefined);
  });

  it('should call patch', () => {
    request.patch('/test', { a: 1 });
    expect(mockState.fns.patch).toHaveBeenCalledWith('/test', { a: 1 }, undefined);
  });
});
