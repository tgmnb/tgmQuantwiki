<template>
  <el-dialog
    :model-value="visible"
    width="640px"
    :show-close="false"
    @close="emit('update:visible', false)"
  >
    <template #header>
      <span class="node-picker__title">添加节点</span>
    </template>

    <div class="node-picker">
      <input
        v-model="searchQuery"
        type="text"
        placeholder="搜索节点..."
        class="node-picker__search"
      >

      <div class="node-picker__categories">
        <button
          v-for="cat in categories"
          :key="cat.value"
          class="node-picker__cat-btn"
          :class="{ 'node-picker__cat-btn--active': activeCategory === cat.value }"
          @click="activeCategory = cat.value"
        >
          {{ cat.label }}
        </button>
      </div>

      <div class="node-picker__grid">
        <div
          v-for="node in filteredNodes"
          :key="node.id"
          class="node-picker__card"
          @click="handleSelect(node)"
        >
          <span class="node-picker__card-icon">{{ getCategoryIcon(node.category) }}</span>
          <div class="node-picker__card-body">
            <span class="node-picker__card-name">{{ node.name }}</span>
            <span class="node-picker__card-desc">{{ node.description || '' }}</span>
          </div>
        </div>
        <div
          v-if="filteredNodes.length === 0"
          class="node-picker__empty"
        >
          没有找到匹配的节点
        </div>
      </div>
    </div>
  </el-dialog>
</template>

<script setup lang="ts">
import { ref, computed, watch } from 'vue'
import type { NodeDefinition } from '@/types'
import { useWorkflowStore } from '@/stores/workflow'

const props = defineProps<{
  visible: boolean
}>()

const emit = defineEmits<{
  (e: 'update:visible', value: boolean): void
  (e: 'select', node: NodeDefinition): void
}>()

const workflowStore = useWorkflowStore()
const searchQuery = ref('')
const activeCategory = ref('all')

const categories = [
  { label: '全部', value: 'all' },
  { label: '数据源', value: '数据源' },
  { label: '因子', value: '因子' },
  { label: '选股', value: '选股' },
  { label: '回测', value: '回测' },
  { label: '输出', value: '输出' },
  { label: '工具', value: 'tool' },
  { label: '其他', value: '其他' },
]

const iconMap: Record<string, string> = {
  '数据源': '📊',
  '因子': '🧪',
  '选股': '🎯',
  '回测': '📈',
  '输出': '📤',
  'tool': '🔧',
  '其他': '📦',
}

function getCategoryIcon(category: string): string {
  return iconMap[category] || '📦'
}

const filteredNodes = computed(() => {
  let nodes = workflowStore.nodeDefinitions

  if (activeCategory.value !== 'all') {
    nodes = nodes.filter(n => n.category === activeCategory.value)
  }

  if (searchQuery.value.trim()) {
    const q = searchQuery.value.trim().toLowerCase()
    nodes = nodes.filter(
      n =>
        n.name.toLowerCase().includes(q) ||
        n.id.toLowerCase().includes(q) ||
        (n.description || '').toLowerCase().includes(q),
    )
  }

  return nodes
})

function handleSelect(node: NodeDefinition) {
  emit('select', node)
  emit('update:visible', false)
}

watch(
  () => props.visible,
  val => {
    if (val) {
      searchQuery.value = ''
      activeCategory.value = 'all'
      workflowStore.loadNodes()
    }
  },
)
</script>

<style scoped>
.node-picker__title {
  font-size: var(--font-md, 15px);
  font-weight: 600;
  color: var(--text-primary);
}

.node-picker {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.node-picker__search {
  width: 100%;
  padding: 7px 10px;
  background: var(--bg-primary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-sm, 6px);
  color: var(--text-primary);
  font-size: var(--font-xs, 13px);
  outline: none;
  box-sizing: border-box;
}

.node-picker__search:focus {
  border-color: var(--accent);
}

.node-picker__categories {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.node-picker__cat-btn {
  padding: 4px 12px;
  border-radius: var(--radius-sm, 6px);
  font-size: var(--font-2xs, 12px);
  cursor: pointer;
  border: 1px solid var(--border-color);
  background: var(--bg-tertiary);
  color: var(--text-secondary);
  transition: all var(--transition, 0.15s ease);
}

.node-picker__cat-btn:hover {
  border-color: var(--border-hover);
  color: var(--text-primary);
}

.node-picker__cat-btn--active {
  background: var(--accent-dim);
  border-color: var(--accent);
  color: var(--accent);
}

.node-picker__grid {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 8px;
  max-height: 360px;
  overflow-y: auto;
  padding: 2px;
}

.node-picker__card {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  padding: 10px 12px;
  background: var(--bg-tertiary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius, 8px);
  cursor: pointer;
  transition: all var(--transition, 0.15s ease);
}

.node-picker__card:hover {
  border-color: var(--accent);
  background: var(--accent-dim);
}

.node-picker__card-icon {
  font-size: 20px;
  line-height: 1;
  flex-shrink: 0;
  margin-top: 2px;
}

.node-picker__card-body {
  display: flex;
  flex-direction: column;
  gap: 2px;
  min-width: 0;
}

.node-picker__card-name {
  font-size: var(--font-xs, 13px);
  font-weight: 500;
  color: var(--text-primary);
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.node-picker__card-desc {
  font-size: var(--font-2xs, 12px);
  color: var(--text-muted);
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.node-picker__empty {
  grid-column: 1 / -1;
  text-align: center;
  padding: 32px 0;
  color: var(--text-muted);
  font-size: var(--font-xs, 13px);
}
</style>
