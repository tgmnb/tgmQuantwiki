# -*- coding: utf-8 -*-
"""全局异常处理中间件"""
from __future__ import annotations

import logging
import os
import traceback

from fastapi import Request, status
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger("quant.middleware")


class ExceptionMiddleware(BaseHTTPMiddleware):
    """捕获未处理异常，返回统一格式的错误响应"""

    async def dispatch(self, request: Request, call_next):
        try:
            return await call_next(request)
        except Exception as exc:
            request_id = getattr(request.state, "request_id", "unknown")
            logger.exception("[%s] Unhandled exception: %s", request_id, exc)
            debug = os.environ.get("DEBUG", "").lower() == "true"
            if debug:
                content = {
                    "detail": f"服务器内部错误: {str(exc)}",
                    "error": str(exc),
                    "request_id": request_id,
                }
            else:
                content = {
                    "detail": "服务器内部错误",
                    "request_id": request_id,
                }
            return JSONResponse(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                content=content,
            )
