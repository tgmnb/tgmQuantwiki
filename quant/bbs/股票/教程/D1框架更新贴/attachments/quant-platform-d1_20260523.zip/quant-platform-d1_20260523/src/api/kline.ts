/**
 * K线数据 API（对接后端 /api/kline 路由）
 * 后端路由: kline.py
 */

import { request } from './request';

export interface KlineSource {
  name: string;
  path: string;
  label: string;
  format: string;
  columns: string[];
  count?: number;
  estimated_total?: boolean;
  estimated?: boolean;
  note?: string;
}

export interface KLineItem {
  date: string;
  code: string;
  open: number;
  high: number;
  low: number;
  close: number;
  volume: number;
}

export const klineApi = {
  /** 列出可用数据源 */
  getSources(): Promise<{ sources: KlineSource[] }> {
    return request.get('/api/kline/sources');
  },

  /** 列出数据源下的股票列表 */
  getStocks(source: string, limit = 5000): Promise<{
    source: string;
    total: number;
    stocks: Array<{ code: string; name: string; path: string }>;
    truncated: boolean;
  }> {
    return request.get('/api/kline/stocks', { params: { source, limit } });
  },

  /** 获取 K线 OHLCV 数据 */
  getData(
    source: string,
    code: string,
    limit = 8000,
    sample: 'day' | 'week' | 'month' = 'day'
  ): Promise<{ data: KLineItem[]; total: number; sample: string }> {
    return request.get('/api/kline/data', { params: { source, code, limit, sample } });
  },
};
