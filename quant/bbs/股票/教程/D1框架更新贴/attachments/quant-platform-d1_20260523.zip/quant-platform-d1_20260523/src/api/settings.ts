import { request } from './request';

export interface PlatformSettings {
  quant_proj: string;
  quant_proj_exists: boolean;
  quant_proj_has_config: boolean;
  theme?: string;
}

export interface QuantConfig {
  [key: string]: any;
}

export const settingsApi = {
  async getPlatformSettings(): Promise<PlatformSettings> {
    return request.get('/api/settings');
  },

  async savePlatformSettings(quantProj: string, theme?: string): Promise<any> {
    const body: Record<string, string> = { quant_proj: quantProj };
    if (theme !== undefined) body.theme = theme;
    return request.post('/api/settings', body);
  },

  async clearServerCache(): Promise<any> {
    return request.post('/api/settings/clear-cache', {});
  },

  async getQuantConfig(): Promise<QuantConfig> {
    return request.get('/api/settings/quant-config');
  },

  async saveQuantConfigField(key: string, value: any): Promise<any> {
    return request.patch(`/api/settings/quant-config/${encodeURIComponent(key)}`, { value });
  },
};
