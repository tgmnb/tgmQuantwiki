<template>
  <div class="pnl-bar-wrap">
    <div class="pnl-bar-track">
      <div
        :class="['pnl-bar-fill', isPos ? 'pnl-bar-fill--up' : 'pnl-bar-fill--down']"
        :style="{ width: barWidth + '%' }"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';

const props = defineProps<{
  val: number | string | null;
  maxAbs: number;
}>();

const numVal = computed(() => {
  if (props.val === null || props.val === undefined || props.val === '') return NaN;
  return parseFloat(String(props.val));
});

const isPos = computed(() => !isNaN(numVal.value) && numVal.value >= 0);

const barWidth = computed(() => {
  if (isNaN(numVal.value) || props.maxAbs === 0) return 0;
  return (Math.abs(numVal.value) / Math.abs(props.maxAbs)) * 50;
});
</script>

<style scoped>
.pnl-bar-wrap { display: flex; align-items: center; }
.pnl-bar-track {
  position: relative;
  width: 60px;
  height: 6px;
  background: var(--bg-tertiary);
  border-radius: 3px;
  overflow: hidden;
}
.pnl-bar-fill {
  position: absolute;
  top: 0;
  height: 100%;
  border-radius: 3px;
  transition: width 0.2s;
}
.pnl-bar-fill--up { background: var(--up); left: 50%; }
.pnl-bar-fill--down { background: var(--down); right: 50%; }
</style>
