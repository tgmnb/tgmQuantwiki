<template>
  <Transition
    name="loading-fade"
    mode="out-in"
  >
    <div
      v-if="visible"
      class="loading"
      :class="`loading--${size}`"
    >
      <div class="loading__spinner-wrapper">
        <div class="loading__spinner" />
        <div class="loading__spinner-ring" />
      </div>
      <p
        v-if="text"
        class="loading__text"
      >
        {{ text }}
      </p>
    </div>
  </Transition>
</template>

<script setup lang="ts">
interface Props {
  visible?: boolean;
  text?: string;
  size?: 'sm' | 'md' | 'lg';
}

withDefaults(defineProps<Props>(), {
  visible: true,
  text: '加载中...',
  size: 'md',
});
</script>

<style scoped>
.loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  color: var(--text-secondary);
}

.loading--sm {
  padding: 16px;
}
.loading--sm .loading__spinner-wrapper {
  width: 24px;
  height: 24px;
}
.loading--sm .loading__spinner,
.loading--sm .loading__spinner-ring {
  width: 24px;
  height: 24px;
  border-width: 2px;
}
.loading--sm .loading__text {
  font-size: var(--font-xs);
  margin-top: 8px;
}

.loading--md {
  padding: 40px;
}
.loading--md .loading__spinner-wrapper {
  width: 40px;
  height: 40px;
}
.loading--md .loading__spinner,
.loading--md .loading__spinner-ring {
  width: 40px;
  height: 40px;
  border-width: 3px;
}
.loading--md .loading__text {
  font-size: var(--font-sm);
  margin-top: 12px;
}

.loading--lg {
  padding: 60px;
}
.loading--lg .loading__spinner-wrapper {
  width: 56px;
  height: 56px;
}
.loading--lg .loading__spinner,
.loading--lg .loading__spinner-ring {
  width: 56px;
  height: 56px;
  border-width: 3px;
}
.loading--lg .loading__text {
  font-size: var(--font-md);
  margin-top: 16px;
}

.loading__spinner-wrapper {
  position: relative;
  display: flex;
  align-items: center;
  justify-content: center;
}

.loading__spinner {
  position: absolute;
  border: 3px solid var(--bg-tertiary);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

.loading__spinner-ring {
  position: absolute;
  border: 3px solid transparent;
  border-bottom-color: var(--accent-light);
  border-radius: 50%;
  animation: spin-reverse 1.2s linear infinite;
}

.loading__text {
  margin: 0;
  color: var(--text-muted);
  font-weight: 500;
}

@keyframes spin {
  to {
    transform: rotate(360deg);
  }
}

@keyframes spin-reverse {
  to {
    transform: rotate(-360deg);
  }
}

.loading-fade-enter-active,
.loading-fade-leave-active {
  transition: opacity 0.2s ease, transform 0.2s ease;
}
.loading-fade-enter-from,
.loading-fade-leave-to {
  opacity: 0;
  transform: scale(0.95);
}
</style>
