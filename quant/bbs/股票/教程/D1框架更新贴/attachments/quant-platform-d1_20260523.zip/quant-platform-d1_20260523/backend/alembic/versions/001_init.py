"""init

Revision ID: 001
Revises:
Create Date: 2026-05-10 23:00:00.000000

"""
from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision = '001'
down_revision = None
branch_labels = None
depends_on = None


def upgrade() -> None:
    op.create_table(
        'backtest_cache',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('strategy_name', sa.String(), nullable=False),
        sa.Column('type_name', sa.String(), nullable=False),
        sa.Column('nav_file', sa.String(), nullable=True),
        sa.Column('metrics_json', sa.Text(), nullable=True),
        sa.Column('created_at', sa.Float(), nullable=False),
        sa.Column('updated_at', sa.Float(), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('strategy_name', 'type_name')
    )
    op.create_table(
        'scan_meta',
        sa.Column('key', sa.String(), nullable=False),
        sa.Column('value', sa.String(), nullable=False),
        sa.Column('updated_at', sa.Float(), nullable=False),
        sa.PrimaryKeyConstraint('key')
    )
    op.create_table(
        'tasks',
        sa.Column('id', sa.Integer(), nullable=False),
        sa.Column('task_id', sa.String(), nullable=False),
        sa.Column('name', sa.String(), nullable=True),
        sa.Column('status', sa.String(), nullable=True),
        sa.Column('pid', sa.Integer(), nullable=True),
        sa.Column('start_time', sa.Float(), nullable=True),
        sa.Column('end_time', sa.Float(), nullable=True),
        sa.Column('progress', sa.Float(), nullable=True),
        sa.Column('error', sa.Text(), nullable=True),
        sa.Column('script_path', sa.String(), nullable=True),
        sa.Column('log_path', sa.String(), nullable=True),
        sa.Column('created_at', sa.Float(), nullable=False),
        sa.Column('updated_at', sa.Float(), nullable=False),
        sa.PrimaryKeyConstraint('id'),
        sa.UniqueConstraint('task_id')
    )


def downgrade() -> None:
    op.drop_table('tasks')
    op.drop_table('scan_meta')
    op.drop_table('backtest_cache')
