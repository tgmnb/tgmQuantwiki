<script setup lang="ts">
interface Props {
  rows?: number
  avatar?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  rows: 3,
  avatar: false,
})

const lineWidths = computed(() =>
  Array.from({ length: props.rows }, (_, i) => `${Math.max(30, 100 - i * 20)}%`)
)
</script>

<template>
  <div class="skeleton-card">
    <div
      v-if="avatar"
      class="skeleton-avatar shimmer"
    />
    <div class="skeleton-lines">
      <div
        v-for="(width, i) in lineWidths"
        :key="i"
        class="skeleton-line shimmer"
        :style="{ width }"
      />
    </div>
  </div>
</template>

<style scoped>
.skeleton-card {
  display: flex;
  align-items: flex-start;
  gap: var(--space-4, 10px);
  padding: var(--space-5, 12px);
  background: var(--bg-secondary);
  border-radius: var(--radius, 8px);
}

.skeleton-avatar {
  flex-shrink: 0;
  width: 40px;
  height: 40px;
  border-radius: 50%;
}

.skeleton-lines {
  display: flex;
  flex-direction: column;
  gap: var(--space-3, 8px);
  flex: 1;
  min-width: 0;
}

.skeleton-line {
  height: 12px;
  border-radius: 6px;
}

.shimmer {
  background: linear-gradient(
    90deg,
    var(--bg-hover) 25%,
    color-mix(in srgb, var(--bg-hover), white 10%) 50%,
    var(--bg-hover) 75%
  );
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
}

@keyframes shimmer {
  0% {
    background-position: 100% 0;
  }
  100% {
    background-position: -100% 0;
  }
}
</style>
