<template>
  <div
    ref="editorContainer"
    class="code-editor"
  >
    <CodeToolbar
      v-if="showToolbar"
      :file-name="fileName"
      :language="language"
      :readonly="readonly"
      :copyable="copyable"
      :code="modelValue"
    />
    <Codemirror
      v-model="code"
      :extensions="extensions"
      @change="handleChange"
    />
  </div>
</template>

<script setup lang="ts">
import { Codemirror } from 'vue-codemirror'
import { python } from '@codemirror/lang-python'
import { useUIStore } from '@/stores/ui'
import CodeToolbar from './CodeToolbar.vue'
import {
  crosshairCursor,
  highlightActiveLine,
  highlightActiveLineGutter,
  keymap,
  lineNumbers,
  rectangularSelection,
} from '@codemirror/view'
import {
  foldGutter,
  bracketMatching,
  indentOnInput,
  syntaxHighlighting,
} from '@codemirror/language'
import {
  traeDarkTheme,
  traeDarkHighlight,
  traeLightHighlight,
  eyeCareHighlight,
  eyeCareTheme,
} from '@/utils/editor-themes'
import { indentWithTab } from '@codemirror/commands'
import {
  autocompletion,
  closeBrackets,
  closeBracketsKeymap,
  completionKeymap,
} from '@codemirror/autocomplete'
import {
  highlightSelectionMatches,
  searchKeymap,
} from '@codemirror/search'
import { EditorState } from '@codemirror/state'

interface Props {
  modelValue?: string
  language?: string
  readonly?: boolean
  height?: string
  showToolbar?: boolean
  fileName?: string
  copyable?: boolean
}

const props = withDefaults(defineProps<Props>(), {
  modelValue: '',
  language: 'python',
  readonly: false,
  height: '400px',
  showToolbar: false,
  fileName: '',
  copyable: true,
})

const emit = defineEmits<{
  (e: 'update:modelValue', value: string): void
  (e: 'change', value: string): void
  (e: 'save', value: string): void
}>()

const uiStore = useUIStore()

const themeExtensions = computed(() => {
  const t = uiStore.theme
  if (t === 'dark') return [traeDarkTheme, syntaxHighlighting(traeDarkHighlight)]
  if (t === 'eye-care') return [eyeCareTheme, syntaxHighlighting(eyeCareHighlight)]
  return [syntaxHighlighting(traeLightHighlight)]
})

const code = ref(props.modelValue)

const extensions = computed(() => {
  const exts = [
    lineNumbers(),
    foldGutter(),
    indentOnInput(),
    bracketMatching(),
    closeBrackets(),
    autocompletion(),
    rectangularSelection(),
    crosshairCursor(),
    highlightActiveLine(),
    highlightActiveLineGutter(),
    highlightSelectionMatches(),
    EditorState.allowMultipleSelections.of(true),
    keymap.of([
      indentWithTab,
      ...closeBracketsKeymap,
      ...completionKeymap,
      ...searchKeymap,
      {
        key: 'Mod-s',
        run: (_view: any) => {
          emit('save', code.value)
          return true
        },
      },
    ]),
  ]
  if (props.readonly) {
    exts.push(EditorState.readOnly.of(true))
  }
  if (props.language === 'python') {
    exts.push(python())
  }
  exts.push(...themeExtensions.value)
  return exts
})

function handleChange(value: string) {
  emit('update:modelValue', value)
  emit('change', value)
}

watch(
  () => props.modelValue,
  (newVal) => {
    if (newVal !== code.value) {
      code.value = newVal || ''
    }
  },
)
</script>

<style>
/* Base editor container - no borders when embedded in code-body */
.code-editor {
  width: 100%;
  border-radius: 6px;
  overflow: hidden;
}

/* Focused state */
.code-editor:focus-within {
  outline: none;
  box-shadow: 0 0 0 1px var(--accent), 0 0 0 3px var(--accent-glow);
  border-radius: 6px;
}

/* Editor height */
.code-editor .cm-editor {
  height: v-bind(height);
  font-size: 14px;
  font-family: 'Fira Code', 'Cascadia Code', 'JetBrains Mono', Consolas, 'Monaco', monospace;
}

.code-editor .cm-editor.cm-focused {
  outline: none;
}

.code-editor .cm-scroller {
  overflow: auto;
  font-family: inherit;
}

/* Content area */
.code-editor .cm-content {
  padding: 8px 0;
}

.code-editor .cm-line {
  padding: 0 16px;
}

/* Cursor — accent color across all themes */
.code-editor .cm-cursor {
  border-left-width: 2px !important;
}

/* Line numbers gutter — base layout, let theme set colors */
.code-editor .cm-gutters {
  border-right: 1px solid var(--border-color) !important;
}

.code-editor .cm-lineNumbers .cm-gutterElement {
  padding: 0 16px 0 8px;
  min-width: 45px;
  font-size: 13px;
}

/* Fold gutter */
.code-editor .cm-foldGutter .cm-gutterElement {
  padding: 0 4px;
  cursor: pointer;
}

/* Matching brackets */
.code-editor .cm-matchingBracket {
  color: inherit !important;
  border-radius: 2px;
}

/* Autocomplete dropdown — base layout */
.code-editor .cm-tooltip-autocomplete {
  border-radius: 6px !important;
  overflow: hidden;
  padding: 4px 0;
}

.code-editor .cm-tooltip-autocomplete > ul {
  font-family: 'Fira Code', monospace;
  font-size: 13px;
  margin: 0;
  padding: 0;
}

.code-editor .cm-tooltip-autocomplete > ul > li {
  padding: 6px 16px;
  margin: 0;
}

/* Scrollbar */
.code-editor .cm-scroller::-webkit-scrollbar {
  width: 10px;
  height: 10px;
}

.code-editor .cm-scroller::-webkit-scrollbar-track {
  background: transparent;
}

.code-editor .cm-scroller::-webkit-scrollbar-thumb {
  background-color: rgba(128, 128, 128, 0.4);
  border-radius: 5px;
  border: 2px solid transparent;
  background-clip: padding-box;
}

.code-editor .cm-scroller::-webkit-scrollbar-thumb:hover {
  background-color: rgba(128, 128, 128, 0.6);
}

.code-editor .cm-scroller::-webkit-scrollbar-corner {
  background-color: transparent;
}

/* ---- Dark theme accent overrides ---- */
/* Custom dark theme handles syntax colors; we only tweak interactive elements */
.code-editor .cm-cursor {
  border-left-color: var(--accent) !important;
}

.code-editor .cm-activeLineGutter {
  background-color: rgba(124, 110, 245, 0.08) !important;
}

.code-editor .cm-foldGutter .cm-gutterElement:hover,
.code-editor .cm-lineNumbers .cm-gutterElement:hover {
  color: #c8c8d4;
}

.code-editor .cm-tooltip-autocomplete > ul > li[aria-selected] {
  background-color: rgba(124, 110, 245, 0.2) !important;
}

/* ---- Light theme ---- */
[data-theme='light'] .code-editor .cm-cursor {
  border-left-color: #6366f1 !important;
}

[data-theme='light'] .code-editor .cm-activeLine {
  background-color: rgba(99, 102, 241, 0.06) !important;
}

[data-theme='light'] .code-editor .cm-activeLineGutter {
  background-color: rgba(99, 102, 241, 0.1) !important;
}

[data-theme='light'] .code-editor .cm-gutters {
  background-color: transparent !important;
  border-right-color: rgba(0, 0, 0, 0.08) !important;
  color: #9e9e9e;
}

[data-theme='light'] .code-editor .cm-lineNumbers .cm-gutterElement:hover {
  color: #666;
}

[data-theme='light'] .code-editor .cm-editor .cm-selectionBackground,
[data-theme='light'] .code-editor .cm-focused .cm-selectionBackground {
  background-color: rgba(99, 102, 241, 0.25) !important;
}

[data-theme='light'] .code-editor .cm-matchingBracket {
  background-color: rgba(99, 102, 241, 0.25) !important;
}

[data-theme='light'] .code-editor .cm-searchMatch {
  background-color: rgba(245, 166, 35, 0.35) !important;
}

[data-theme='light'] .code-editor .cm-searchMatch.cm-searchMatch-selected {
  background-color: rgba(245, 166, 35, 0.6) !important;
}

[data-theme='light'] .code-editor .cm-nonmatchingBracket {
  background-color: rgba(220, 38, 38, 0.25) !important;
}

[data-theme='light'] .code-editor .cm-tooltip-autocomplete {
  background-color: #ffffff !important;
  border: 1px solid rgba(0, 0, 0, 0.12) !important;
  box-shadow: 0 4px 16px rgba(0, 0, 0, 0.12) !important;
}

[data-theme='light'] .code-editor .cm-tooltip-autocomplete > ul > li {
  color: #383a42;
}

[data-theme='light'] .code-editor .cm-tooltip-autocomplete > ul > li[aria-selected] {
  background-color: rgba(99, 102, 241, 0.12) !important;
}

/* ---- Eye-care theme ---- */
[data-theme='eye-care'] .code-editor .cm-cursor {
  border-left-color: #b8956a !important;
}

[data-theme='eye-care'] .code-editor .cm-activeLine {
  background-color: rgba(184, 149, 106, 0.08) !important;
}

[data-theme='eye-care'] .code-editor .cm-activeLineGutter {
  background-color: rgba(184, 149, 106, 0.12) !important;
}

[data-theme='eye-care'] .code-editor .cm-gutters {
  background-color: #eae5dc !important;
  border-right-color: rgba(45, 42, 38, 0.08) !important;
  color: #6a655c;
}

[data-theme='eye-care'] .code-editor .cm-lineNumbers .cm-gutterElement:hover {
  color: #8a8378;
}

[data-theme='eye-care'] .code-editor .cm-editor .cm-selectionBackground,
[data-theme='eye-care'] .code-editor .cm-focused .cm-selectionBackground {
  background-color: rgba(184, 149, 106, 0.25) !important;
}

[data-theme='eye-care'] .code-editor .cm-matchingBracket {
  background-color: rgba(184, 149, 106, 0.3) !important;
}

[data-theme='eye-care'] .code-editor .cm-searchMatch {
  background-color: rgba(201, 162, 39, 0.35) !important;
}

[data-theme='eye-care'] .code-editor .cm-searchMatch.cm-searchMatch-selected {
  background-color: rgba(201, 162, 39, 0.55) !important;
}

[data-theme='eye-care'] .code-editor .cm-nonmatchingBracket {
  background-color: rgba(196, 92, 92, 0.25) !important;
}

[data-theme='eye-care'] .code-editor .cm-tooltip-autocomplete {
  background-color: #f4f1ea !important;
  border: 1px solid rgba(45, 42, 38, 0.12) !important;
  box-shadow: 0 4px 16px rgba(45, 42, 38, 0.12) !important;
}

[data-theme='eye-care'] .code-editor .cm-tooltip-autocomplete > ul > li {
  color: #2d2a26;
}

[data-theme='eye-care'] .code-editor .cm-tooltip-autocomplete > ul > li[aria-selected] {
  background-color: rgba(184, 149, 106, 0.2) !important;
}
</style>
