from __future__ import annotations

import copy
import importlib
import logging
import pkgutil
from typing import Optional

logger = logging.getLogger("quant.nodes")

NODE_REGISTRY: dict[str, dict] = {}


def register_node(node_def: dict):
    node_id = node_def.get("id")
    if not node_id:
        raise ValueError("Node definition must have 'id'")
    if node_id in NODE_REGISTRY:
        raise ValueError(f"Duplicate node id: {node_id}")
    NODE_REGISTRY[node_id] = node_def


def _auto_discover():
    for _, name, _ in pkgutil.iter_modules(__path__):
        try:
            importlib.import_module(f".{name}", __package__)
        except Exception as e:
            logger.error("Failed to load node module %s: %s", name, e)


_auto_discover()


def get_node(type_id: str) -> Optional[dict]:
    node = NODE_REGISTRY.get(type_id)
    return copy.deepcopy(node) if node else None


def list_nodes() -> list[dict]:
    return [
        copy.deepcopy({**v, "id": k})
        for k, v in NODE_REGISTRY.items()
        if v.get("type") != "tool"
    ]


def list_tools() -> list[dict]:
    return [
        copy.deepcopy({**v, "id": k})
        for k, v in NODE_REGISTRY.items()
        if v.get("type") == "tool"
    ]


def list_all() -> list[dict]:
    return [copy.deepcopy({**v, "id": k}) for k, v in NODE_REGISTRY.items()]


PROGRESS_KEYWORDS = [
    ("\u521d\u59cb\u5316", 5),
    ("\u52a0\u8f7d", 15),
    ("\u9884\u5904\u7406", 25),
    ("\u56e0\u5b50", 40),
    ("\u9009\u80a1", 55),
    ("\u62e9\u65f6", 70),
    ("\u56de\u6d4b", 80),
    ("\u6536\u76ca", 90),
    ("\u5b8c\u6210", 100),
]


def estimate_progress_from_log(log_text: str) -> float:
    if not log_text:
        return 0.0

    max_progress = 0.0
    for keyword, progress in PROGRESS_KEYWORDS:
        if keyword in log_text:
            max_progress = max(max_progress, progress)

    return max_progress
