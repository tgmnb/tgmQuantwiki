﻿# -*- coding: utf-8 -*-
"""日志中间件 - 记录请求/响应详情"""
from __future__ import annotations

import logging
import time

from fastapi import Request
from starlette.middleware.base import BaseHTTPMiddleware

logger = logging.getLogger("quant.access")


class LoggingMiddleware(BaseHTTPMiddleware):
    """记录所有 API 请求的访问日志"""

    async def dispatch(self, request: Request, call_next):
        # 跳过静态资源请求
        if request.url.path.startswith(("/static", "/pages", "/favicon")):
            return await call_next(request)

        start_time = time.time()
        request_id = getattr(request.state, "request_id", "unknown")

        logger.info("[%s] -> %s %s", request_id, request.method, request.url.path)

        try:
            response = await call_next(request)
            process_time = (time.time() - start_time) * 1000
            logger.info(
                "[%s] <- %s %s %d - %.2fms",
                request_id, request.method, request.url.path,
                response.status_code, process_time
            )
            return response
        except Exception:
            process_time = (time.time() - start_time) * 1000
            logger.error(
                "[%s] <- %s %s ERROR - %.2fms",
                request_id, request.method, request.url.path, process_time
            )
            raise
