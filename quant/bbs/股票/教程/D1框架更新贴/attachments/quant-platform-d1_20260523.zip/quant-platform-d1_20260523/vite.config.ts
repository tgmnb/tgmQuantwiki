import { defineConfig } from 'vite';
import vue from '@vitejs/plugin-vue';
import AutoImport from 'unplugin-auto-import/vite';
import Components from 'unplugin-vue-components/vite';
import { ElementPlusResolver } from 'unplugin-vue-components/resolvers';
import path from 'node:path';

export default defineConfig({
  plugins: [
    vue(),

    AutoImport({
      resolvers: [ElementPlusResolver()],
      imports: ['vue', 'vue-router', 'pinia'],
      dts: 'src/types/auto-imports.d.ts',
    }),

    Components({
      resolvers: [ElementPlusResolver()],
      dts: 'src/types/components.d.ts',
    }),
  ],

  resolve: {
    alias: {
      '@': path.resolve(__dirname, 'src'),
    },
  },

  server: {
    host: '0.0.0.0',
    port: 5173,
    proxy: {
      '/api': {
        target: 'http://localhost:5180',
        changeOrigin: true,
        ws: true,
      },
    },
  },

  optimizeDeps: {
    include: [
      'vue',
      'vue-router',
      'pinia',
      'element-plus',
      'echarts/core',
      'echarts/charts',
      'echarts/components',
      'echarts/renderers',
    ],
  },

  build: {
    target: 'es2022',
    outDir: 'dist',
    reportCompressedSize: true,
    rollupOptions: {
      output: {
        manualChunks(id) {
          // echarts 按需导入子模块拆分
          if (id.includes('echarts/core') || id.includes('echarts/charts') ||
              id.includes('echarts/components') || id.includes('echarts/renderers')) {
            return 'vendor-echarts-core';
          }
          if (id.includes('zrender')) {
            return 'vendor-zrender';
          }
          // 第三方库按类型拆分
          if (id.includes('node_modules')) {
            if (/[\\/]node_modules[\\/]vue[\\/]/.test(id) && !id.includes('@vue')) {
              return 'vendor-vue-runtime';
            }
            if (id.includes('@vue')) {
              return 'vendor-vue-platform';
            }
            if (id.includes('pinia')) {
              return 'vendor-pinia';
            }
            if (id.includes('vue-router')) {
              return 'vendor-vue-router';
            }
            if (id.includes('element-plus')) {
              return 'vendor-element';
            }
            if (id.includes('codemirror') || id.includes('@codemirror') || id.includes('vue-codemirror')) {
              return 'vendor-codemirror';
            }
            if (id.includes('@xterm') || id.includes('xterm')) {
              return 'vendor-xterm';
            }

          }
        },
      },
    },
  },

});
