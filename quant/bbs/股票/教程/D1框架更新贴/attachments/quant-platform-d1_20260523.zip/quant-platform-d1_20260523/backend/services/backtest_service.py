"""
回测执行服务层 —— 通过 subprocess 调用 quant-test-d1-pro 回测框架

复用通用任务管理器（task_manager.py）：
- 内存级任务状态存储（重启丢失）
- 临时脚本注入参数（不修改原工具代码）
- 日志进度解析
- Polars 读取 CSV 结果
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path

import config as _config
from services.task_manager import TaskManager

_logger = logging.getLogger("quant.backtest_service")

# ---------------------------------------------------------------------------
# 任务管理器实例（串行执行，不允许并行）
# ---------------------------------------------------------------------------

_task_manager = TaskManager(
    tmp_subfolder="quant_backtest",
    python_path=_config.QUANT_PYTHON_PATH,
    task_prefix="backtest",
    timeout_minutes=60,
    max_file_age_hours=24,
    allow_parallel=False,
)


# ---------------------------------------------------------------------------
# 脚本生成
# ---------------------------------------------------------------------------

def _generate_backtest_script(
    quant_proj: str,
    strategy_name: str,
    backtest_type: str,
    asset_type: str,
    date_start: str | None,
    date_end: str | None,
) -> str:
    """生成临时 Python 脚本内容，用于在 quantpy312 环境中执行回测。"""
    date_start_repr = repr(date_start) if date_start else "None"
    date_end_repr = repr(date_end) if date_end else "None"
    return f'''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""自动生成的回测脚本 —— 由回测执行服务派发"""
import sys
import os
os.chdir(r"{quant_proj}")
sys.path.insert(0, r"{quant_proj}")

# 导入配置（确保 config.py 存在）
try:
    import config
except ImportError:
    import config_common as config

# 覆盖日期范围（如果提供）
if "{date_start}" != "None":
    config.date_start = "{date_start}"
if "{date_end}" != "None":
    config.date_end = {date_end_repr}

# 调用回测入口
from backtest.main_strategy import run_strategy_backtest
from backtest.core.enums import BacktestType, AssetType

# 映射回测类型
type_map = {{
    "stock_daily": BacktestType.STOCK_DAILY,
    "stock_1h": BacktestType.STOCK_1H,
    "stock_minute": BacktestType.STOCK_MINUTE,
    "future": BacktestType.FUTURE,
}}
asset_map = {{
    "stock": AssetType.STOCK,
    "future": AssetType.FUTURE,
}}

run_strategy_backtest(
    strategy_name_list=["{strategy_name}"],
    backtest_type=type_map.get("{backtest_type}", BacktestType.STOCK_DAILY),
    asset_type=asset_map.get("{asset_type}", AssetType.STOCK),
)
sys.stdout.write("BACKTEST_DONE\n")
sys.stdout.flush()
'''


# ---------------------------------------------------------------------------
# 任务操作接口
# ---------------------------------------------------------------------------

def create_task(
    strategy_name: str,
    backtest_type: str = "stock_daily",
    asset_type: str = "stock",
    date_start: str | None = None,
    date_end: str | None = None,
) -> dict:
    """创建并启动回测任务。

    Args:
        strategy_name: 策略名称（需与 backtest/strategies/ 下的目录名一致）
        backtest_type: 回测类型（stock_daily / stock_1h / stock_minute / future）
        asset_type: 资产类型（stock / future）
        date_start: 开始日期，None 则使用 config.py 中的默认值
        date_end: 结束日期，None 则使用 config.py 中的默认值（最近交易日）

    Returns:
        {"task_id": str, "status": str}
    """
    quant_proj = str(_config.QUANT_PROJ)
    if not _config.QUANT_PROJ or not _config.QUANT_PROJ.exists():
        raise RuntimeError(f"量化项目路径未配置或不存在: {_config.QUANT_PROJ}")

    script_content = _generate_backtest_script(
        quant_proj=quant_proj,
        strategy_name=strategy_name,
        backtest_type=backtest_type,
        asset_type=asset_type,
        date_start=date_start,
        date_end=date_end,
    )

    result = _task_manager.create_task(
        script_generator=lambda: script_content,
        script_filename="backtest_run",
        cwd=_config.QUANT_PROJ,
        task_metadata={
            "name": f"回测_{strategy_name}",
            "strategy_name": strategy_name,
            "backtest_type": backtest_type,
            "asset_type": asset_type,
            "date_start": date_start,
            "date_end": date_end,
            "success_marker": "BACKTEST_DONE",
        },
    )

    _logger.info(
        "回测任务已提交: task_id=%s, strategy=%s, type=%s",
        result["task_id"],
        strategy_name,
        backtest_type,
    )
    return result


def get_task(task_id: str) -> dict | None:
    """获取任务状态，自动刷新。"""
    return _task_manager.get_task(task_id)


def get_task_with_log(task_id: str) -> dict:
    """获取任务状态和最近日志。

    Returns:
        {"task": dict, "log_tail": str}
    """
    result = _task_manager.get_task_with_log(task_id, log_lines=200)
    if result is None:
        raise ValueError(f"任务不存在: {task_id}")
    return result


def stop_task(task_id: str) -> dict:
    """终止运行中的回测任务。"""
    try:
        result = _task_manager.stop_task(task_id)
    except ValueError:
        raise ValueError(f"任务不存在: {task_id}")
    return result


def list_tasks(status: str | None = None) -> list[dict]:
    """列出所有回测任务。"""
    return _task_manager.list_tasks(status)


def get_running_task() -> dict | None:
    """返回当前正在运行的任务。"""
    return _task_manager.get_running_task()
