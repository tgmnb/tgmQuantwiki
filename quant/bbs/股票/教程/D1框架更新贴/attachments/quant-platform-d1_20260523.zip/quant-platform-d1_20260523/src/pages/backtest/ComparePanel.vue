<template>
  <div class="compare-wrap">
    <div class="compare-header">
      <h3 class="compare-title">
        对比分析
      </h3>
      <span class="compare-count">{{ (data.strategies || []).length }} 个策略</span>
    </div>

    <!-- NAV Chart -->
    <div class="bt-section">
      <div class="bt-section__header">
        <span class="bt-section__title">净值曲线对比</span>
      </div>
      <div style="padding:12px 14px 8px;">
        <CompareChart :data="data" />
      </div>
    </div>

    <!-- Metrics Table -->
    <div class="bt-section">
      <div class="bt-section__header">
        <span class="bt-section__title">绩效指标对比</span>
      </div>
      <div style="overflow-x:auto;">
        <table class="bt-compare-table">
          <thead>
            <tr>
              <th class="bt-compare-th">
                指标
              </th>
              <th
                v-for="(s, i) in (data.strategies || [])"
                :key="i"
                class="bt-compare-th"
                :style="{ color: COLORS[i % COLORS.length] }"
              >
                {{ s.name }}
              </th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="key in metricKeys"
              :key="key"
              class="bt-compare-row"
            >
              <td class="bt-compare-label">
                {{ key }}
              </td>
              <td
                v-for="(s, i) in (data.strategies || [])"
                :key="i"
                :class="getMetricClass(s.full_metrics?.[key])"
              >
                {{ formatMetricValue(s.full_metrics?.[key]) }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import CompareChart from './CompareChart.vue';

interface CompareData {
  strategies?: Array<{
    name: string;
    nav_data?: Array<{ date: string; value: number }>;
    full_metrics?: Record<string, any>;
  }>;
}

defineProps({ data: { type: Object as PropType<CompareData>, required: true } });

const COLORS = ['#6366f1', '#ef4444', '#22c55e', '#f59e0b', '#8b5cf6', '#06b6d4', '#ec4899'];


const metricKeys = [
  '年化收益', 'Sharpe', '最大回撤', '胜率', '盈亏比',
  'Calmar', 'Sortino', '年化波动率', '累计收益', '总交易次数',
];

function getMetricClass(val: any): string {
  const n = parseFloat(val);
  if (isNaN(n)) return '';
  if (n > 0) return 'cell--up';
  if (n < 0) return 'cell--down';
  return '';
}

function formatMetricValue(val: any): string {
  if (val === undefined || val === null) return '--';
  const n = parseFloat(val);
  if (isNaN(n)) return String(val);
  // Percentage keys
  if (Math.abs(n) < 10 && String(val).includes('%') === false && String(val).includes('rate') === false && String(val).includes('return') === false && String(val).includes('drawdown') === false) {
    // might be a ratio or percentage in decimal form
  }
  if (Math.abs(n) < 1 && Math.abs(n) > 0.0001) {
    // Likely a decimal ratio (e.g. 0.24 for 24%)
    const pct = (n * 100).toFixed(2);
    const sign = n > 0 ? '+' : '';
    return `${sign}${pct}%`;
  }
  if (Math.abs(n) >= 100 || Math.abs(n) < 0.0001) {
    return n.toLocaleString('en-US', { maximumFractionDigits: 2 });
  }
  const sign = n > 0 ? '+' : '';
  return `${sign}${n.toFixed(2)}`;
}
</script>

<style scoped>
.compare-wrap { display:flex; flex-direction:column; gap:12px; flex:1; overflow-y:auto; min-height:0; padding:16px; }
.compare-header { display:flex; align-items:center; gap:12px; padding-bottom:12px; border-bottom:1px solid var(--border); }
.compare-title { margin:0; font-size:16px; font-weight:600; color:var(--text-primary); }
.compare-count { font-size:12px; color:var(--text-muted); margin-left:auto; }

.bt-section { border:1px solid var(--border); border-radius:var(--radius,8px); overflow:hidden; margin-bottom:0; }
.bt-section__header { display:flex; align-items:center; padding:10px 14px; background:var(--bg-secondary); border-bottom:1px solid var(--border); }
.bt-section__title { font-size:13px; font-weight:600; color:var(--text-primary); }

.bt-compare-table { width:100%; border-collapse:collapse; font-size:12px; }
.bt-compare-th { padding:8px 12px; text-align:left; font-weight:600; color:var(--text-secondary); background:var(--bg-secondary); border-bottom:1px solid var(--border); white-space:nowrap; }
.bt-compare-row { border-bottom:1px solid var(--border); }
.bt-compare-row:last-child { border-bottom:none; }
.bt-compare-row:hover { background:var(--bg-hover); }
.bt-compare-label { padding:6px 12px; font-weight:500; color:var(--text-secondary); white-space:nowrap; }
.bt-compare-table td { padding:6px 12px; color:var(--text-primary); font-variant-numeric:tabular-nums; }
.cell--up { color:var(--up) !important; }
.cell--down { color:var(--down) !important; }
</style>
