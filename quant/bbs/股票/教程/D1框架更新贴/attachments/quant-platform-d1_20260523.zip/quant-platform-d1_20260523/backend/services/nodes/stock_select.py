from . import register_node

register_node({
    "id": "stock_select",
    "type": "atomic",
    "name": "\u9009\u80a1",
    "description": "\u8fd0\u884c\u9009\u80a1\u7b56\u7565\uff0c\u8f93\u51fa\u9009\u80a1\u7ed3\u679c\uff08\u80a1\u7968\u4ee3\u7801\u5217\u8868\uff09",
    "icon": "icon-strategy",
    "category": "\u9009\u80a1",
    "slots_in": [
        {
            "id": "factor_data",
            "name": "\u56e0\u5b50\u6570\u636e",
            "type": "file",
            "required": False,
            "description": "\u53ef\u9009\uff1a\u56e0\u5b50\u6570\u636e\uff0c\u7528\u4e8e\u9009\u80a1\u53c2\u8003",
        },
    ],
    "slots_out": [
        {"id": "select_result", "name": "\u9009\u80a1\u7ed3\u679c", "type": "file"},
    ],
    "params": [
        {
            "id": "select_code_list_override",
            "name": "\u9009\u80a1\u4ee3\u7801\u5217\u8868",
            "type": "list[str]",
            "default": None,
            "required": False,
            "description": "\u76f4\u63a5\u6307\u5b9a\u9009\u80a1\u4ee3\u7801\u5217\u8868\uff08\u8986\u76d6\u914d\u7f6e\u6587\u4ef6\uff09",
            "ui": {"widget": "tag_input", "placeholder": "\u8f93\u5165\u80a1\u7968\u4ee3\u7801"},
        },
    ],
    "script": "workflow/\u9009\u80a1.py",
    "func": "\u9009\u80a1",
    "conda_env": "quantpy312",
})
