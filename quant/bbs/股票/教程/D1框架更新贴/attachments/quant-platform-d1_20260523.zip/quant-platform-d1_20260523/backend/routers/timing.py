"""
择时/风控代码管理 API
"""

from __future__ import annotations

import hashlib

import config as _config
from fastapi import APIRouter, Query, Request
from fastapi.responses import JSONResponse, Response

from services.tree_service import safe_resolve, to_posix_path

router = APIRouter(prefix="/api/timing", tags=["timing"])


@router.get("/signals")
async def get_timing_signals():
    """返回 {signals: [...]} 格式，供前端 TimingPage 使用（合并择时 + 风控）。"""
    all_signals = []
    stg_base = _config.QUANT_PROJ / "backtest"

    # 择时信号: signal_hub/stock/hour
    d = stg_base / "signal_hub" / "stock" / "hour"
    if d.exists():
        for p in sorted(d.iterdir()):
            if p.suffix == ".py" and p.name not in ("__init__.py",):
                all_signals.append({
                    "name": p.stem,
                    "path": to_posix_path(p, _config.QUANT_PROJ),
                    "type": "timing",
                    "freq": "hour",
                })

    # 风控: signal_hub/risk/daily + risk/hour
    for freq in ("daily", "hour"):
        d = stg_base / "signal_hub" / "risk" / freq
        if d.exists():
            for p in sorted(d.iterdir()):
                if p.suffix == ".py" and p.name not in ("__init__.py",):
                    all_signals.append({
                        "name": p.stem,
                        "path": to_posix_path(p, _config.QUANT_PROJ),
                        "type": "risk",
                        "freq": freq,
                    })

    return {"signals": all_signals}


@router.get("/list")
async def list_timing_codes():
    """列出 signal_hub 下的择时和风控 Python 代码，按类型和频率分类。"""
    result: dict = {
        "timing_daily": [],
        "timing_hour": [],
        "risk_daily": [],
        "risk_hour": [],
    }

    stg_base = _config.QUANT_PROJ / "backtest"

    # 个股择时: signal_hub/stock/daily + signal_hub/stock/hour
    for freq in ("daily", "hour"):
        d = stg_base / "signal_hub" / "stock" / freq
        if d.exists():
            for p in sorted(d.iterdir()):
                if p.suffix == ".py" and p.name not in ("__init__.py",):
                    key = f"timing_{freq}"
                    result[key].append({
                        "name": p.stem,
                        "path": to_posix_path(p, _config.QUANT_PROJ),
                        "freq": freq,
                    })

    # 风控: signal_hub/risk/daily + risk/hour
    for freq in ("daily", "hour"):
        d = stg_base / "signal_hub" / "risk" / freq
        if d.exists():
            for p in sorted(d.iterdir()):
                if p.suffix == ".py" and p.name not in ("__init__.py",):
                    key = f"risk_{freq}"
                    result[key].append({
                        "name": p.stem,
                        "path": to_posix_path(p, _config.QUANT_PROJ),
                        "freq": freq,
                    })

    return result


@router.get("/content")
async def get_timing_content(path: str = Query(...), limit: int = Query(300), request: Request = None):
    """读取择时/风控 Python 代码内容，支持 ETag 缓存。"""
    try:
        code_file = safe_resolve(_config.QUANT_PROJ, path)
    except ValueError:
        return JSONResponse(status_code=403, content={"detail": "路径越界"})
    if not code_file.exists() or not code_file.is_file():
        return JSONResponse(status_code=404, content={"detail": "文件不存在"})

    # ETag: 基于文件 mtime + size
    stat = code_file.stat()
    etag = f'"{hashlib.md5(f"{stat.st_mtime}:{stat.st_size}".encode()).hexdigest()}"'
    if request and request.headers.get("if-none-match") == etag:
        return Response(status_code=304)

    code_text = code_file.read_text(encoding="utf-8")
    lines = code_text.splitlines()[:limit]

    result = {
        "name": code_file.name,
        "path": path,
        "total": len(code_text.splitlines()),
        "lines": lines,
        "truncated": len(code_text.splitlines()) > limit,
    }
    resp = JSONResponse(content=result)
    resp.headers["ETag"] = etag
    resp.headers["Cache-Control"] = "max-age=120"
    return resp


@router.post("/save")
async def save_timing_code(data: dict):
    """保存择时/风控 Python 代码。"""
    from fastapi.responses import JSONResponse

    path = data.get("path", "")
    content = data.get("content", "")
    target = _config.QUANT_PROJ / path
    timing_root = _config.QUANT_PROJ / "backtest" / "signal_hub"
    try:
        if not target.resolve().is_relative_to(timing_root.resolve()):
            return JSONResponse(status_code=403, content={"success": False, "detail": "只能保存到 backtest/signal_hub 目录下"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"success": False, "detail": "路径校验失败"})
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return {"success": True}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "detail": str(e)})


@router.post("/delete")
async def delete_timing_code(data: dict):
    """删除择时/风控 Python 代码文件。"""
    path = data.get("path", "")
    target = _config.QUANT_PROJ / path
    timing_root = _config.QUANT_PROJ / "backtest" / "signal_hub"
    try:
        if not target.resolve().is_relative_to(timing_root.resolve()):
            return JSONResponse(status_code=403, content={"success": False, "detail": "只能删除 backtest/signal_hub 目录下的文件"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"success": False, "detail": "路径校验失败"})

    if not target.exists():
        return JSONResponse(status_code=404, content={"success": False, "detail": "文件不存在"})

    try:
        target.unlink()
        return {"success": True}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "detail": str(e)})


