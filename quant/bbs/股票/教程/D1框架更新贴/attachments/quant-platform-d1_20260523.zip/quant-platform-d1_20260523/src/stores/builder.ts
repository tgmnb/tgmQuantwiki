import { defineStore } from 'pinia';
import { ref } from 'vue';
import type { Strategy } from '@/types';
import { builderApi } from '@/api/builder';

// ── 策略参数类型 ──────────────────────────────────────
interface StopConfig { is_open: boolean; ratio: number }
interface StrategyParams {
  day_buy_num_max: number;
  cap_amount?: number;
  hold_period?: number;
  swap_time?: string;
  stop_win?: StopConfig;
  stop_lose?: StopConfig;
  moving_win?: StopConfig;
  sell_mode?: number;
}

function defaultParams(isHour: boolean): StrategyParams {
  if (isHour) {
    return { day_buy_num_max: 5 };
  }
  return {
    day_buy_num_max: 3,
    cap_amount: 3,
    hold_period: 2,
    swap_time: 'open-close',
    stop_win: { is_open: false, ratio: 0.15 },
    stop_lose: { is_open: false, ratio: -0.15 },
    moving_win: { is_open: false, ratio: 0.2 },
    sell_mode: 1,
  };
}

export const useBuilderStore = defineStore('builder', () => {
  // ── 策略列表 ──────────────────────────────────────────
  const strategies = ref<Strategy[]>([]);
  const loading = ref(false);

  // ── 当前选中的策略 ─────────────────────────────────────
  const currentStrategy = ref<Strategy | null>(null);
  const modules = ref<any>({ selections: [], timing: { timing: [], risk: [] } });
  const loadingModules = ref(false);

  // ── 模式 ──────────────────────────────────────────────
  const mode = ref<'visual' | 'code'>('visual');

  // isNew=true  → 向导式构建（step 1~5 wizard）
  // isNew=false → 已有策略查看/编辑（摘要视图 + 编辑按钮）
  const isNew = ref(false);

  // ── Wizard 状态（仅 isNew=true 时使用）────────────────
  const visualStep = ref(1);
  const strategyName = ref('');
  const backtestType = ref('stock_daily');

  // ── 选股 / 择时 / 风控模块 ──────────────────────────────
  const selectedSelection = ref<any>(null);
  const selectedTiming = ref<any>(null);
  const selectedRisk = ref<any>(null);

  // ── 策略参数 ──────────────────────────────────────────
  const strategyParams = ref<StrategyParams>(defaultParams(false));

  // ── 配置保存版本（每次保存递增，CodeMode watch 此值来刷新文件内容）──
  const configSaveVersion = ref(0);

  // ── 清空已选模块和参数 ─────────────────────────────────
  function clearSelections() {
    selectedSelection.value = null;
    selectedTiming.value = null;
    selectedRisk.value = null;
    strategyParams.value = defaultParams(backtestType.value === 'stock_1h');
  }

  // ── 策略列表加载 ───────────────────────────────────────
  async function loadStrategies() {
    loading.value = true;
    try {
      const d = await builderApi.listStrategies();
      const s = d.strategies;
      if (Array.isArray(s)) {
        strategies.value = s;
      } else if (s && typeof s === 'object') {
        strategies.value = Object.entries(s).flatMap(([type, items]) =>
          (items as any[]).map((item) => ({ ...item, type }))
        );
      } else {
        strategies.value = [];
      }
    } catch {
      strategies.value = [];
    } finally {
      loading.value = false;
    }
  }

  // ── 选中策略 → 查看模式 ────────────────────────────────
  async function selectStrategy(strategy: Strategy | null) {
    if (!strategy) {
      currentStrategy.value = null;
      strategyName.value = '';
      isNew.value = false;
      visualStep.value = 1;
      modules.value = { selections: [], timing: { timing: [], risk: [] } };
      selectedSelection.value = null;
      selectedTiming.value = null;
      selectedRisk.value = null;
      return;
    }
    currentStrategy.value = strategy;
    strategyName.value = strategy.name || '';
    backtestType.value = strategy.type || 'stock_daily';
    isNew.value = false;
    visualStep.value = 1;

    // 加载模块列表
    try {
      const d = await builderApi.getModules(backtestType.value);
      modules.value = d;
    } catch { /* ignore */ }

    // 从 stg_config 恢复已选模块
    if (strategy.has_config) {
      await _loadStrategyModules();
    } else {
      selectedSelection.value = null;
      selectedTiming.value = null;
      selectedRisk.value = null;
    }
  }

  // ── 创建新策略 → 向导模式 ─────────────────────────────
  async function startNewStrategy(name: string, type: string) {
    await builderApi.createStrategy(name, type);
    await loadStrategies();

    const created = strategies.value.find(
      (s: any) => s.name === name && s.type === type
    );
    if (!created) {
      throw new Error('策略创建成功但列表中未找到，请刷新页面重试');
    }
    currentStrategy.value = created;
    strategyName.value = name;
    backtestType.value = type;
    isNew.value = true;
    visualStep.value = 1;
    selectedSelection.value = null;
    selectedTiming.value = null;
    selectedRisk.value = null;

    try {
      const d = await builderApi.getModules(type);
      modules.value = d;
    } catch { /* ignore */ }
  }

  async function _loadStrategyModules() {
    if (!currentStrategy.value) return;
    try {
      const d = await builderApi.getStrategyConfig(
        backtestType.value,
        currentStrategy.value.name
      );
      const cfg = d.config || {};
      const sc = cfg.strategy_config || {};
      const tc = cfg.timing_config || {};

      // 恢复选股模块
      const allSelections = modules.value.selections || [];
      const selectTarget = sc.select_target || '';
      if (selectTarget) {
        const f = allSelections.find(
          (s: any) => s.name === selectTarget
        );
        selectedSelection.value = f || null;
      } else {
        selectedSelection.value = null;
      }

      // 恢复择时模块
      const allTiming = [
        ...(modules.value.timing?.timing || []),
        ...(modules.value.timing?.risk || []),
      ];
      const tcStock = tc.stock || {};
      if (tcStock.is_open && tcStock.signal) {
        const f = allTiming.find(
          (t: any) => t.name === tcStock.signal
        );
        selectedTiming.value = f || null;
      } else {
        selectedTiming.value = null;
      }

      // 恢复风控模块
      const rc = tc.risk || {};
      if (rc.is_open && rc.signal) {
        const f = allTiming.find(
          (t: any) => t.name === rc.signal
        );
        selectedRisk.value = f || null;
      } else {
        selectedRisk.value = null;
      }

      // 恢复策略参数
      const isHour = backtestType.value === 'stock_1h';
      const restored: StrategyParams = defaultParams(isHour);
      const paramKeys = isHour
        ? ['day_buy_num_max'] as const
        : ['day_buy_num_max', 'cap_amount', 'hold_period', 'swap_time', 'stop_win', 'stop_lose', 'moving_win', 'sell_mode'] as const;
      for (const key of paramKeys) {
        if (sc[key] !== undefined) {
          (restored as any)[key] = sc[key];
        }
      }
      strategyParams.value = restored;
    } catch {
      selectedSelection.value = null;
      selectedTiming.value = null;
      selectedRisk.value = null;
      strategyParams.value = defaultParams(backtestType.value === 'stock_1h');
    }
  }

  // ── 切换回测类型（清空模块选择 + 重置参数） ─────────────
  async function setBacktestType(type: string) {
    backtestType.value = type;
    selectedSelection.value = null;
    selectedTiming.value = null;
    selectedRisk.value = null;
    strategyParams.value = defaultParams(type === 'stock_1h');
    try {
      const d = await builderApi.getModules(type);
      modules.value = d;
    } catch { /* ignore */ }
  }

  // ── 保存策略配置 ────────────────────────────────────────
  async function saveStrategy() {
    if (!currentStrategy.value || !strategyName.value.trim()) return;

    const isHour = backtestType.value === 'stock_1h';
    const params = strategyParams.value;

    const strategy_config: any = { ...params };
    if (selectedSelection.value) {
      strategy_config.select_target = selectedSelection.value.name;
    }

    const timing_config: any = {
      period: isHour ? 'hour' : 'daily',
      stock: { is_open: false },
      risk: { is_open: false },
    };
    if (selectedTiming.value) {
      timing_config.stock = { is_open: true, signal: selectedTiming.value.name };
    }
    if (selectedRisk.value) {
      timing_config.risk = { is_open: true, signal: selectedRisk.value.name };
    }

    const payload: any = {
      strategy_name: strategyName.value,
      backtest_type: backtestType.value,
      strategy_config,
      timing_config,
    };

    await builderApi.saveStrategyConfig(payload);
    configSaveVersion.value++;
  }

  // ── 进入 wizard 编辑已有策略 ─────────────────────────
  async function startEdit() {
    if (!currentStrategy.value) return;
    isNew.value = true;
    visualStep.value = 1;
    // 加载模块列表 + 从已保存配置恢复选择状态（必须等待完成）
    await _loadStrategyModules_full();
  }

  async function _loadStrategyModules_full() {
    loadingModules.value = true;
    try {
      const d = await builderApi.getModules(backtestType.value);
      modules.value = d;
    } catch { /* ignore */ }
    await _loadStrategyModules();
    loadingModules.value = false;
  }

  // ── 退出 wizard → 返回查看模式 ───────────────────────
  async function cancelEdit() {
    if (!currentStrategy.value) return;
    isNew.value = false;
    visualStep.value = 1;
    // 加载模块列表 + 从已保存配置恢复选择状态（必须等待完成）
    await _loadStrategyModules_full();
  }

  // ── Wizard 导航 ───────────────────────────────────────
  function wizardNext() {
    if (visualStep.value < 5) visualStep.value++;
  }

  function wizardPrev() {
    if (visualStep.value > 1) visualStep.value--;
  }

  function wizardGoto(step: number) {
    visualStep.value = step;
  }

  return {
    // ── 状态 ──────────────────────────────────────────────
    mode,
    strategies,
    loading,
    currentStrategy,
    modules,
    isNew,
    visualStep,
    strategyName,
    backtestType,
    selectedSelection,
    selectedTiming,
    selectedRisk,
    strategyParams,
    configSaveVersion,
    // ── Actions ───────────────────────────────────────────
    loadStrategies,
    clearSelections,
    selectStrategy,
    startNewStrategy,
    setBacktestType,
    saveStrategy,
    startEdit,
    cancelEdit,
    loadingModules,
    wizardNext,
    wizardPrev,
    wizardGoto,
  };
});
