<template>
  <div class="workflow-list">
    <div class="workflow-list__header">
      <el-button
        type="primary"
        size="small"
        @click="emit('create')"
      >
        <el-icon><Plus /></el-icon>
        新建
      </el-button>
    </div>

    <div class="workflow-list__filter">
      <el-input
        v-model="searchQuery"
        placeholder="搜索工作流..."
        size="small"
        clearable
      >
        <template #prefix>
          <el-icon><Search /></el-icon>
        </template>
      </el-input>
    </div>

    <div class="workflow-list__categories">
      <button
        v-for="cat in categories"
        :key="cat"
        class="workflow-list__category-tag"
        :class="{ 'workflow-list__category-tag--active': activeCategory === cat }"
        @click="activeCategory = cat"
      >
        {{ cat }}
      </button>
    </div>

    <div class="workflow-list__items">
      <template v-if="loading && filteredWorkflows.length === 0">
        <SkeletonCard
          v-for="i in 5"
          :key="`skeleton-${i}`"
          :rows="2"
          :avatar="true"
        />
      </template>

      <template v-else-if="filteredWorkflows.length > 0">
        <div
          v-for="wf in filteredWorkflows"
          :key="wf.id"
          class="workflow-list__item"
          :class="{
            'workflow-list__item--active': currentWorkflowId === wf.id,
            'workflow-list__item--running': runningWorkflowId === wf.id,
          }"
          :style="{ '--cat-color': getCategoryColor(wf.category) }"
          @click="emit('select', wf.id)"
          @contextmenu.prevent="handleContextMenu($event, wf)"
        >
          <!-- 左侧色条 -->
          <div class="workflow-list__item-accent" />

          <div class="workflow-list__item-body">
            <div class="workflow-list__item-top">
              <span class="workflow-list__item-name">{{ wf.name }}</span>
              <span
                v-if="stepCountMap[wf.id]"
                class="workflow-list__item-steps"
              >
                {{ stepCountMap[wf.id] }}步
              </span>
              <el-tag
                v-if="wf.category"
                size="small"
                :color="getCategoryColor(wf.category)"
                effect="dark"
                style="border: none; font-size: 10px"
              >
                {{ categoryLabelMap[wf.category] || wf.category }}
              </el-tag>
            </div>
            <div class="workflow-list__item-bottom">
              <span
                v-if="wf.description"
                class="workflow-list__item-desc"
              >{{ wf.description }}</span>
              <span class="workflow-list__item-time">{{ formatTime(wf.updated_at) }}</span>
            </div>
            <div class="workflow-list__item-actions">
              <el-button
                link
                size="small"
                @click.stop="emit('run', wf.id)"
              >
                <el-icon><VideoPlay /></el-icon>
              </el-button>
              <el-button
                link
                size="small"
                @click.stop="emit('rename', wf)"
              >
                <el-icon><Edit /></el-icon>
              </el-button>
              <el-button
                link
                size="small"
                type="danger"
                @click.stop="emit('delete', wf.id)"
              >
                <el-icon><Delete /></el-icon>
              </el-button>
            </div>
          </div>

          <div
            v-if="runningWorkflowId === wf.id"
            class="workflow-list__item-spinner"
          >
            <el-icon class="is-loading">
              <Loading />
            </el-icon>
          </div>
        </div>
      </template>

      <EmptyState
        v-else
        title="暂无工作流"
        description="创建工作流以自动化您的量化策略执行流程"
        action-text="创建工作流"
        @action="() => emit('create')"
      />
    </div>

    <div
      v-show="contextMenuVisible"
      class="workflow-list__context-menu"
      :style="{
        left: `${contextMenuPosition.x}px`,
        top: `${contextMenuPosition.y}px`,
      }"
    >
      <div
        class="workflow-list__context-menu-item"
        @click="handleMenuAction('run')"
      >
        <el-icon><VideoPlay /></el-icon>
        <span>运行</span>
      </div>
      <div
        class="workflow-list__context-menu-item"
        @click="handleMenuAction('rename')"
      >
        <el-icon><Edit /></el-icon>
        <span>重命名</span>
      </div>
      <div
        class="workflow-list__context-menu-item workflow-list__context-menu-item--danger"
        @click="handleMenuAction('delete')"
      >
        <el-icon><Delete /></el-icon>
        <span>删除</span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted } from 'vue'
import {
  Search,
  Plus,
  VideoPlay,
  Delete,
  Edit,
  Loading,
} from '@element-plus/icons-vue'
import type { Workflow } from '@/types'
import EmptyState from '@/components/common/EmptyState.vue'
import SkeletonCard from '@/components/common/SkeletonCard.vue'

interface Props {
  workflows: Workflow[]
  currentWorkflowId?: string
  runningWorkflowId?: string
  loading?: boolean
  stepCountMap?: Record<string, number>
}

const props = withDefaults(defineProps<Props>(), {
  currentWorkflowId: '',
  runningWorkflowId: '',
  loading: false,
  stepCountMap: () => ({}),
})

const emit = defineEmits<{
  (e: 'select', id: string): void
  (e: 'create'): void
  (e: 'delete', id: string): void
  (e: 'run', id: string): void
  (e: 'rename', workflow: Workflow): void
}>()

const categoryColorMap: Record<string, string> = {
  factor: 'var(--accent)',
  selection: '#3b82f6',
  backtest: '#10b981',
  composite: '#f59e0b',
}
const categoryLabelMap: Record<string, string> = {
  factor: '因子',
  selection: '选股',
  backtest: '回测',
  composite: '综合',
}
function getCategoryColor(category?: string): string {
  return categoryColorMap[category || ''] || 'var(--text-muted)'
}

const categories = ['全部', '因子', '选股', '回测', '综合']
const activeCategory = ref('全部')
const searchQuery = ref('')

const contextMenuVisible = ref(false)
const contextMenuPosition = ref({ x: 0, y: 0 })
const contextMenuWorkflow = ref<Workflow | null>(null)

const filteredWorkflows = computed(() => {
  let result = props.workflows
  if (activeCategory.value !== '全部') {
    result = result.filter(w => w.category === activeCategory.value)
  }
  if (searchQuery.value) {
    const query = searchQuery.value.toLowerCase()
    result = result.filter(w => w.name.toLowerCase().includes(query))
  }
  return result
})

function handleContextMenu(event: MouseEvent, wf: Workflow) {
  const rect = (event.currentTarget as HTMLElement)
    .closest('.workflow-list')
    ?.getBoundingClientRect()
  if (!rect) return
  contextMenuPosition.value = {
    x: event.clientX - rect.left,
    y: event.clientY - rect.top,
  }
  contextMenuWorkflow.value = wf
  contextMenuVisible.value = true
}

function closeContextMenu() {
  contextMenuVisible.value = false
  contextMenuWorkflow.value = null
}

function handleMenuAction(action: 'run' | 'rename' | 'delete') {
  const wf = contextMenuWorkflow.value
  if (!wf) return
  closeContextMenu()
  if (action === 'run') emit('run', wf.id)
  else if (action === 'rename') emit('rename', wf)
  else if (action === 'delete') emit('delete', wf.id)
}

const formatTime = (timestamp: string | number | undefined): string => {
  if (!timestamp || timestamp === 0) return ''
  const date = new Date(typeof timestamp === 'number' ? timestamp * 1000 : timestamp)
  if (isNaN(date.getTime())) return ''

  const now = new Date()
  const diffMs = now.getTime() - date.getTime()
  const diffSec = Math.floor(diffMs / 1000)
  const diffMin = Math.floor(diffSec / 60)
  const diffHour = Math.floor(diffMin / 60)
  const diffDay = Math.floor(diffHour / 24)

  if (diffSec < 60) return '刚刚'
  if (diffMin < 60) return `${diffMin}分钟前`
  if (diffHour < 24) return `${diffHour}小时前`
  if (diffDay < 30) return `${diffDay}天前`

  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  if (year === now.getFullYear()) return `${month}-${day}`
  return `${year}-${month}-${day}`
}

onMounted(() => {
  document.addEventListener('click', closeContextMenu)
})

onUnmounted(() => {
  document.removeEventListener('click', closeContextMenu)
})
</script>

<style scoped>
.workflow-list {
  position: relative;
  height: 100%;
  display: flex;
  flex-direction: column;
  background-color: var(--bg-primary);
}

.workflow-list__header {
  padding: 16px;
  display: flex;
  justify-content: flex-end;
  align-items: center;
  border-bottom: 1px solid var(--border-color);
}

.workflow-list__filter {
  padding: 12px 16px;
  border-bottom: 1px solid var(--border-color);
}

.workflow-list__categories {
  display: flex;
  gap: 6px;
  padding: 8px 16px;
  border-bottom: 1px solid var(--border-color);
  overflow-x: auto;
  flex-shrink: 0;
}

.workflow-list__category-tag {
  padding: 4px 12px;
  border-radius: 12px;
  border: 1px solid var(--border-color);
  background: var(--bg-secondary);
  color: var(--text-secondary);
  font-size: 12px;
  cursor: pointer;
  white-space: nowrap;
  transition: all 0.2s;
}

.workflow-list__category-tag:hover {
  border-color: var(--accent);
  color: var(--text-primary);
}

.workflow-list__category-tag--active {
  background: var(--accent);
  border-color: var(--accent);
  color: white;
}

.workflow-list__items {
  flex: 1;
  overflow-y: auto;
  padding: 8px;
}

.workflow-list__item {
  display: flex;
  align-items: stretch;
  gap: 0;
  margin-bottom: 6px;
  border-radius: var(--radius);
  background-color: var(--bg-secondary);
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
  overflow: hidden;
}

.workflow-list__item:hover {
  background-color: var(--bg-hover);
}

.workflow-list__item:hover .workflow-list__item-actions {
  opacity: 1;
}

.workflow-list__item--active {
  background: var(--bg-hover);
}

.workflow-list__item--active .workflow-list__item-accent {
  opacity: 1;
}

.workflow-list__item--active .workflow-list__item-name {
  color: var(--text-primary);
}

.workflow-list__item--running .workflow-list__item-accent {
  opacity: 1;
}

.workflow-list__item-accent {
  width: 3px;
  flex-shrink: 0;
  background: var(--cat-color, var(--text-muted));
  opacity: 0;
  transition: opacity 0.2s ease;
}

.workflow-list__item:hover .workflow-list__item-accent {
  opacity: 0.6;
}

.workflow-list__item-body {
  flex: 1;
  min-width: 0;
  padding: 10px 12px;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.workflow-list__item-top {
  display: flex;
  align-items: center;
  gap: 6px;
}

.workflow-list__item-name {
  font-size: 13px;
  color: var(--text-primary);
  font-weight: 500;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
  min-width: 0;
}

.workflow-list__item-steps {
  font-size: 10px;
  color: var(--text-muted);
  background: var(--bg-tertiary);
  padding: 1px 6px;
  border-radius: 8px;
  flex-shrink: 0;
}

.workflow-list__item-bottom {
  display: flex;
  align-items: center;
  gap: 6px;
}

.workflow-list__item-desc {
  font-size: 11px;
  color: var(--text-muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  flex: 1;
  min-width: 0;
}

.workflow-list__item-time {
  font-size: 10px;
  color: var(--text-muted);
  white-space: nowrap;
  flex-shrink: 0;
}

.workflow-list__item-actions {
  display: flex;
  gap: 2px;
  opacity: 0;
  transition: opacity 0.2s ease;
  flex-shrink: 0;
  position: absolute;
  right: 8px;
  top: 50%;
  transform: translateY(-50%);
  background: var(--bg-secondary);
  border-radius: var(--radius-sm);
  padding: 2px 4px;
}

.workflow-list__item:hover .workflow-list__item-actions {
  background: var(--bg-hover);
}

.workflow-list__item-spinner {
  display: flex;
  align-items: center;
  padding-right: 10px;
  color: var(--accent);
  font-size: 14px;
}

.workflow-list__context-menu {
  position: absolute;
  z-index: 2000;
  min-width: 140px;
  padding: 4px 0;
  background: var(--bg-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius);
  box-shadow: var(--shadow-md);
}

.workflow-list__context-menu-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  font-size: 13px;
  color: var(--text-primary);
  cursor: pointer;
  transition: background-color 0.2s;
}

.workflow-list__context-menu-item:hover {
  background-color: var(--bg-hover);
}

.workflow-list__context-menu-item--danger {
  color: var(--error);
}

.workflow-list__context-menu-item--danger:hover {
  background-color: rgba(255, 77, 94, 0.15);
}
</style>
