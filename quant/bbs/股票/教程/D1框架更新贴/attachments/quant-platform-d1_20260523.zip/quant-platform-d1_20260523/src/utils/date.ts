/**
 * 将各种日期输入统一格式化为 YYYY-MM-DD 字符串
 * 兼容 YYYYMMDD（如 20240102）、YYYY-MM-DD、YYYY/MM/DD 等格式
 */
export function normalizeDate(date: unknown): string {
  if (!date) return '';
  const s = String(date).trim();
  // 统一分隔符：/ → -
  const normalized = s.replace(/\//g, '-');
  // YYYYMMDD → YYYY-MM-DD
  if (/^\d{8}$/.test(normalized)) {
    return `${normalized.slice(0, 4)}-${normalized.slice(4, 6)}-${normalized.slice(6, 8)}`;
  }
  return normalized.slice(0, 10);
}

/**
 * 给日期字符串加减天数，返回 YYYY-MM-DD
 */
export function addDays(dateStr: string, days: number): string {
  const ts = new Date(dateStr).getTime() + days * 86400000;
  return new Date(ts).toISOString().slice(0, 10);
}

/**
 * 在 dateIndex 中查找与 dateStr 最近的日期索引
 * @param dateStr   目标日期 YYYY-MM-DD
 * @param dateIndex 日期 -> 索引 的映射表
 * @param maxOffset 最大搜索偏移天数，默认 5
 * @returns 找到的索引，未找到返回 undefined
 */
export function findNearestDateIndex(
  dateStr: string,
  dateIndex: Record<string, number>,
  maxOffset = 5
): number | undefined {
  const idx = dateIndex[dateStr];
  if (idx !== undefined) return idx;

  for (let offset = 1; offset <= maxOffset; offset++) {
    const dtPrev = addDays(dateStr, -offset);
    const dtNext = addDays(dateStr, offset);
    if (dtPrev in dateIndex) return dateIndex[dtPrev];
    if (dtNext in dateIndex) return dateIndex[dtNext];
  }

  return undefined;
}
