import { defineStore } from 'pinia';
import { ref, computed } from 'vue';

export type Theme = 'dark' | 'light' | 'eye-care';

const VALID_THEMES: Theme[] = ['dark', 'light', 'eye-care'];
const THEME_STORAGE_KEY = 'd1-theme';

function isValidTheme(t: string): t is Theme {
  return VALID_THEMES.includes(t as Theme);
}

/**
 * UI Store - 管理 UI 状态（主题）
 */
export const useUIStore = defineStore('ui', () => {
  // ===== 主题状态 =====
  const stored = localStorage.getItem(THEME_STORAGE_KEY);
  const theme = ref<Theme>(isValidTheme(stored || '') ? (stored as Theme) : 'dark');
  const isDark = computed(() => theme.value === 'dark');
  const isEyeCare = computed(() => theme.value === 'eye-care');

  // ===== 主题操作 =====
  function setTheme(newTheme: string) {
    const t: Theme = isValidTheme(newTheme) ? newTheme : 'dark';
    theme.value = t;
    document.documentElement.setAttribute('data-theme', t);
    localStorage.setItem(THEME_STORAGE_KEY, t);
  }

  function toggleTheme() {
    const order: Theme[] = ['dark', 'light', 'eye-care'];
    const idx = order.indexOf(theme.value);
    const next = order[(idx + 1) % order.length];
    setTheme(next);
  }

  function initTheme() {
    document.documentElement.setAttribute('data-theme', theme.value);
  }

  return {
    // 主题
    theme,
    isDark,
    isEyeCare,
    setTheme,
    toggleTheme,
    initTheme,
  };
});
