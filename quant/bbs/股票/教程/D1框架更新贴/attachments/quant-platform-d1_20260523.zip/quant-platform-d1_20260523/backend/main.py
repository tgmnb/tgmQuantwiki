# -*- coding: utf-8 -*-
"""
D1 Quant Platform - 后端入口

轻量级 FastAPI 应用，路由/服务已拆分至 routers/ 和 services/ 目录
"""

from __future__ import annotations

import asyncio
import atexit
import logging
import os
import time
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from services.log_service import setup_logging, get_recent_logs
from services.db_service import init_db

# ---- 日志初始化 ----
logger = setup_logging("quant")

# ---- 数据库初始化 ----
init_db()

# ---------------------------------------------------------------------------
# 应用创建
# ---------------------------------------------------------------------------


class _ShutdownLogFilter(logging.Filter):
    """屏蔽 uvicorn 在进程关闭时打印的 CancelledError/KeyboardInterrupt traceback。"""

    def filter(self, record: logging.LogRecord) -> bool:
        if record.exc_info and record.exc_info[0] is not None:
            try:
                if issubclass(record.exc_info[0], (asyncio.CancelledError, KeyboardInterrupt)):
                    return False
            except TypeError:
                pass
        return True


logging.getLogger("uvicorn.error").addFilter(_ShutdownLogFilter())


def _shutdown_all_tasks():
    """通过全局注册表终止所有 TaskManager 的运行中子进程。"""
    from services.task_manager import shutdown_all
    shutdown_all()


atexit.register(_shutdown_all_tasks)


@asynccontextmanager
async def lifespan(app: FastAPI):
    try:
        yield
    except asyncio.CancelledError:
        pass
    finally:
        _shutdown_all_tasks()


app = FastAPI(
    title="D1 Quant Platform API",
    description="量化投资平台后端 API",
    version="1.1.0",
    docs_url="/docs",
    redoc_url="/redoc",
    lifespan=lifespan,
)

# ---- CORS ----
app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:5173",
        "http://127.0.0.1:5173",
        "http://localhost:5180",
        "http://127.0.0.1:5180",
    ],
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------------------------
# 全局异常处理器（兜底）
# ---------------------------------------------------------------------------
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.exception("Unhandled exception on %s %s", request.method, request.url.path)
    debug = os.environ.get("DEBUG", "").lower() == "true"
    if debug:
        content = {
            "detail": f"服务器内部错误: {str(exc)}",
            "error": str(exc),
        }
    else:
        content = {
            "detail": "服务器内部错误",
        }
    return JSONResponse(
        status_code=500,
        content=content,
    )

# ---------------------------------------------------------------------------
# 加载静态文件 (Vue 3 SPA)
# ---------------------------------------------------------------------------
STATIC_DIR = Path(__file__).resolve().parent
DIST_DIR = STATIC_DIR.parent / "dist"
app.mount("/assets", StaticFiles(directory=str(DIST_DIR / "assets"), html=False), name="assets")

@app.get("/")
async def serve_index():
    return FileResponse(str(DIST_DIR / "index.html"))

@app.get("/favicon.ico")
async def serve_favicon():
    favicon = DIST_DIR / "favicon.ico"
    return FileResponse(str(favicon))

# ---------------------------------------------------------------------------
# 健康检查
# ---------------------------------------------------------------------------
@app.get("/api/health")
async def health_check():
    from services.db_service import get_db_status
    from services.data_service import get_fs_cache_stats
    import config as _config

    return {
        "status": "ok",
        "version": "1.1.0",
        "time": time.strftime("%Y-%m-%d %H:%M:%S"),
        "quant_proj": str(_config.QUANT_PROJ) if _config.QUANT_PROJ else None,
        "quant_proj_exists": _config.QUANT_PROJ.exists() if _config.QUANT_PROJ else False,
        "data_dir": str(_config.DATA_DIR) if _config.DATA_DIR else None,
        "db": get_db_status(),
        "fs_cache": get_fs_cache_stats(),
    }

# ---------------------------------------------------------------------------
# 注册路由模块（仅注册前端有对应页面的核心模块）
# ---------------------------------------------------------------------------
from routers import (
    backtest,
    builder,
    factors,
    financial_factors,
    kline,
    platform,
    selection,
    settings,
    strategies,
    terminal,
    timing,
    workflow,
    simplified_workflow,
)

app.include_router(settings.router)
app.include_router(kline.router)
app.include_router(backtest.router)
app.include_router(builder.router)
app.include_router(factors.router)
app.include_router(financial_factors.router)
app.include_router(timing.router)
app.include_router(selection.router)
app.include_router(platform.router)
app.include_router(strategies.router)
app.include_router(workflow.router)
app.include_router(simplified_workflow.router)
app.include_router(terminal.router)

# ---------------------------------------------------------------------------
# 日志查询 API
# ---------------------------------------------------------------------------
from fastapi import Query

@app.get("/api/logs")
async def get_logs(
    limit: int = Query(50, ge=1, le=500),
    level: str = Query("", description="DEBUG|INFO|WARNING|ERROR"),
    search: str = Query("", description="模糊搜索消息内容"),
):
    return get_recent_logs(limit=limit, level=level or None, search=search or None)

logger.info("D1 Quant Platform API initialized - %d routes loaded", len(app.routes))

# ---------------------------------------------------------------------------
# SPA fallback
# ---------------------------------------------------------------------------
@app.get("/{path:path}")
async def serve_spa(path: str):
    """SPA fallback: return index.html for all non-API, non-static routes."""
    return FileResponse(str(DIST_DIR / "index.html"))

# ---------------------------------------------------------------------------
# 启动
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import uvicorn
    try:
        uvicorn.run("main:app", host="0.0.0.0", port=5180, reload=False)
    except (KeyboardInterrupt, SystemExit):
        logger.info("服务器已停止")
