"""
目录树服务 — 文件系统扫描与缓存

从原 main.py 的 _build_tree / _get_cached_tree 迁移。
"""

from __future__ import annotations

import os
import time
from pathlib import Path

import config as _config

# ---------------------------------------------------------------------------
# 常量
# ---------------------------------------------------------------------------
MAX_FILES_SHOWN = 100  # 单目录最大展示文件数

# 缓存: {cache_key: (monotonic_time, result_dict)}
_tree_cache: dict[str, tuple[float, dict]] = {}
_CACHE_TTL = 30.0  # 秒（原为5秒，目录变化频率低，适当放宽）


def safe_resolve(base: Path, user_path: str) -> Path:
    """安全解析用户路径，确保不越出 base 目录。"""
    # 拒绝绝对路径（防止直接传入 /etc/passwd 等）
    if Path(user_path).is_absolute():
        raise ValueError(f"不允许绝对路径: {user_path}")

    candidate = (base / user_path).resolve()
    # resolve 后必须仍在 base 目录内
    if not candidate.is_relative_to(base):
        raise ValueError(f"路径越界: {user_path}")
    return candidate


def safe_resolve_backtest(user_path: str) -> Path:
    """安全解析回测路径，基于 _config._BACKTEST_PROJ_DIR 目录。"""
    base = _config._BACKTEST_PROJ_DIR or _config.DATA_DIR
    return safe_resolve(base, user_path)


def to_posix_path(path: Path, base: Path) -> str:
    """将路径转为 POSIX 风格的相对字符串。"""
    return str(path.relative_to(base)).replace("\\", "/")


# ---------------------------------------------------------------------------
# 核心构建逻辑
# ---------------------------------------------------------------------------

def build_tree(
    target: Path,
    current_depth: int,
    max_depth: int,
    base: Path,
) -> tuple[list[dict], list[dict]]:
    """递归构建目录树。

    返回 (dirs_list, files_list)，大目录截断并标记 truncated。
    """
    dirs, files = [], []
    try:
        entries = list(os.scandir(target))
    except PermissionError:
        return [], []

    # 排序：目录在前，按名称排列
    entries_dirs = sorted((e for e in entries if e.is_dir()), key=lambda e: e.name)
    entries_files_raw = [e for e in entries if e.is_file()]
    total_file_count = len(entries_files_raw)

    # 只取 .csv/.pkl 文件，限制数量避免大目录卡顿
    entries_files = [
        e for e in entries_files_raw
        if e.name.lower().endswith((".csv", ".pkl"))
    ][:MAX_FILES_SHOWN]
    entries = entries_dirs + entries_files

    for entry in entries:
        rel = to_posix_path(Path(entry.path), base)

        if entry.is_dir():
            item: dict = {"name": entry.name, "path": rel}
            if current_depth < max_depth:
                sub_dirs, sub_files = build_tree(
                    Path(entry.path), current_depth + 1, max_depth, base
                )
                item["children"] = {"dirs": sub_dirs, "files": sub_files}
            dirs.append(item)

        elif entry.is_file() and entry.name.lower().endswith((".csv", ".pkl")):
            try:
                size = entry.stat().st_size
            except OSError:
                size = 0
            files.append({
                "name": entry.name,
                "path": rel,
                "size": size,
            })

    # 大目录截断提示
    if total_file_count > MAX_FILES_SHOWN and len(files) == MAX_FILES_SHOWN:
        files.append({
            "name": f"… 还有 {total_file_count - MAX_FILES_SHOWN} 个文件（未显示）",
            "path": "",
            "size": 0,
            "truncated": True,
        })

    return dirs, files


# ---------------------------------------------------------------------------
# 缓存包装
# ---------------------------------------------------------------------------

def get_cached_tree(path: str, depth: int) -> dict:
    """获取目录树（优先缓存）。"""
    cache_key = f"{path}:{depth}"
    now = time.monotonic()

    if cache_key in _tree_cache:
        ts, result = _tree_cache[cache_key]
        if now - ts < _CACHE_TTL:
            return result

    target = safe_resolve(_config.DATA_DIR, path) if path else _config.DATA_DIR
    depth = max(1, min(depth, 3))
    dirs, files = build_tree(target, 1, depth, _config.DATA_DIR)
    current = (
        to_posix_path(target, _config.DATA_DIR)
        if target != _config.DATA_DIR
        else ""
    )
    result = {"dirs": dirs, "files": files, "current": current}
    _tree_cache[cache_key] = (now, result)
    return result
