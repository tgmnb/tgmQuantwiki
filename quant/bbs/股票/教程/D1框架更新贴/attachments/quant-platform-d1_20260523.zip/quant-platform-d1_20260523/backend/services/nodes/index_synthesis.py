from . import register_node

register_node({
    "id": "index_synthesis",
    "type": "atomic",
    "name": "\u6307\u6570\u5408\u6210",
    "description": "\u5408\u6210\u6307\u6570",
    "icon": "icon-chart",
    "category": "\u5176\u4ed6",
    "slots_in": [
        {"id": "factor_data", "name": "\u56e0\u5b50\u6570\u636e", "type": "file", "required": False},
    ],
    "slots_out": [
        {"id": "index_data", "name": "\u6307\u6570\u6570\u636e", "type": "file"},
    ],
    "params": [
        {
            "id": "ind_agg_daily_dict",
            "name": "\u65e5\u9891\u6307\u6570\u914d\u7f6e",
            "type": "dict",
            "default": {},
            "ui": {"widget": "json_editor", "placeholder": "\u8f93\u5165 JSON \u914d\u7f6e"},
        },
        {
            "id": "ind_agg_1h_dict",
            "name": "\u5c0f\u65f6\u9891\u6307\u6570\u914d\u7f6e",
            "type": "dict",
            "default": {},
            "ui": {"widget": "json_editor", "placeholder": "\u8f93\u5165 JSON \u914d\u7f6e"},
        },
    ],
    "script": "workflow/\u6307\u6570\u5408\u6210.py",
    "func": "\u6307\u6570\u5408\u6210",
    "conda_env": "quantpy312",
})
