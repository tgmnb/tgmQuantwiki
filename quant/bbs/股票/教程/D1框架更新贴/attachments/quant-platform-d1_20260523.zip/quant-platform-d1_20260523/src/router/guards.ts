import type { Router } from 'vue-router';

/**
 * 设置路由守卫
 */
export function setupRouterGuards(router: Router) {
  router.beforeEach((to, _from, next) => {
    const title = to.meta?.title as string;
    document.title = title ? `${title} - 量化交易平台` : '量化交易平台';
    next();
  });
}
