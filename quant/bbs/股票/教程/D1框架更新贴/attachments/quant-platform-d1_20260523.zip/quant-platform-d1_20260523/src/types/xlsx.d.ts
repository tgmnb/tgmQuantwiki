/**
 * xlsx 类型声明补充
 * 修复 @types/xlsx 中缺失或错误的类型定义
 */

declare module 'xlsx' {
  interface IUtils {
    /** 将 JSON 数据转换为 worksheet */
    json_to_sheet<T>(data: T[], opts?: any): any;
    
    /** 将 worksheet 附加到 workbook */
    book_append_sheet(wb: any, ws: any, name?: string): void;
  }
  
  /** 创建新的 workbook */
  export function book_new(): any;
  
  /** 将 workbook 写入数据 */
  export function write(wb: any, opts: any): any;
  
  export const utils: IUtils;
}
