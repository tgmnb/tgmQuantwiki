from . import register_node

register_node({
    "id": "backtest_hourly_single",
    "type": "atomic",
    "name": "\u5c0f\u65f6\u5355\u7b56\u7565\u56de\u6d4b",
    "description": "\u5c0f\u65f6\u7ea7\u522b\u5355\u7b56\u7565\u56de\u6d4b",
    "icon": "icon-chart",
    "category": "\u56de\u6d4b",
    "slots_in": [
        {"id": "factor_data", "name": "\u56e0\u5b50\u6570\u636e", "type": "file", "required": False},
        {"id": "select_result", "name": "\u9009\u80a1\u7ed3\u679c", "type": "file", "required": False},
    ],
    "slots_out": [
        {"id": "backtest_result", "name": "\u56de\u6d4b\u7ed3\u679c", "type": "file"},
    ],
    "params": [
        {
            "id": "strategy_name_list",
            "name": "\u7b56\u7565\u540d\u79f0\u5217\u8868",
            "type": "list[str]",
            "default": [],
            "required": True,
            "ui": {"widget": "tag_input", "placeholder": "\u8f93\u5165\u7b56\u7565\u540d\u79f0"},
        },
    ],
    "script": "workflow/\u5c0f\u65f6\u9891\u7b56\u7565\u56de\u6d4b.py",
    "func": "\u56de\u6d4b",
    "conda_env": "quantpy312",
})
