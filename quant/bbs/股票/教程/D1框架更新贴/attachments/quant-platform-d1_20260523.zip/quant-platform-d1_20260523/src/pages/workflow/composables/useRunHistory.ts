import { ref } from 'vue';
import { useWorkflowStore } from '@/stores/workflow';

export function useRunHistory() {
  const workflowStore = useWorkflowStore();

  const viewingHistory = ref(false);
  const historyRunId = ref('');
  const historyStartTime = ref('');

  function formatRunTime(ts: number | undefined): string {
    if (!ts) return '';
    const d = new Date(ts * 1000);
    const pad = (n: number) => n.toString().padStart(2, '0');
    return `${pad(d.getMonth() + 1)}-${pad(d.getDate())} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
  }

  function formatDuration(seconds: number | undefined): string {
    if (seconds == null) return '';
    if (seconds < 60) return `${seconds}s`;
    const m = Math.floor(seconds / 60);
    const s = Math.round(seconds % 60);
    return `${m}m${s}s`;
  }

  function getStatusIcon(status: string): string {
    switch (status) {
      case 'running': return '⏳';
      case 'completed': return '✔';
      case 'failed': return '❌';
      case 'stopped': return '⏹';
      default: return '•';
    }
  }

  function getStatusColor(status: string): string {
    switch (status) {
      case 'running': return '#3b82f6';
      case 'completed': return '#10b981';
      case 'failed': return '#ef4444';
      case 'stopped': return '#f59e0b';
      default: return '#888';
    }
  }

  async function handleViewHistory(run: any) {
    if (!workflowStore.currentWorkflow) return;
    const wfId = workflowStore.currentWorkflow.id;
    workflowStore.backupRealtimeLogs();
    viewingHistory.value = true;
    historyRunId.value = run.run_id;
    historyStartTime.value = formatRunTime(run.started_at);
    const logs = await workflowStore.loadRunLogs(wfId, run.run_id);
    workflowStore.logLines = logs;
  }

  function handleBackToRealtime() {
    viewingHistory.value = false;
    historyRunId.value = '';
    historyStartTime.value = '';
    workflowStore.restoreRealtimeLogs();
  }

  return {
    viewingHistory,
    historyRunId,
    historyStartTime,
    formatRunTime,
    formatDuration,
    getStatusIcon,
    getStatusColor,
    handleViewHistory,
    handleBackToRealtime,
  };
}
