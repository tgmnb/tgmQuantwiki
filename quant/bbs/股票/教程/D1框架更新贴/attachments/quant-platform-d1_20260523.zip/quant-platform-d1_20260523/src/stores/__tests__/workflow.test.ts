import { describe, it, expect, beforeEach, vi } from 'vitest';
import { createPinia, setActivePinia } from 'pinia';
import { useWorkflowStore } from '../workflow';
import { workflowApi } from '@/api/workflow';

class MockEventSource {
  close = vi.fn();
  onmessage: ((event: MessageEvent) => void) | null = null;
  onopen: (() => void) | null = null;
  onerror: ((event: Event) => void) | null = null;
  addEventListener = vi.fn();
  constructor(public url: string) {}
}

Object.assign(globalThis, { EventSource: MockEventSource });

vi.mock('@/api/workflow', () => ({
  workflowApi: {
    list: vi.fn(),
    get: vi.fn(),
    create: vi.fn(),
    update: vi.fn(),
    delete: vi.fn(),
    run: vi.fn(async () => {}),
    stop: vi.fn(async () => {}),
    listRuns: vi.fn(),
    getRunLogs: vi.fn(),
  },
}));

describe('Workflow Store', () => {
  beforeEach(() => {
    setActivePinia(createPinia());
    vi.clearAllMocks();
  });

  it('should initialize with default state', () => {
    const store = useWorkflowStore();
    expect(store.workflows).toEqual([]);
    expect(store.currentWorkflow).toBeNull();
    expect(store.loading).toBe(false);
    expect(store.saving).toBe(false);
    expect(store.running).toBe(false);
    expect(store.runningId).toBeNull();
    expect(store.logLines).toEqual([]);
    expect(store.stepStatusMap).toEqual({});
    expect(store.currentStepName).toBe('');
    expect(store.workflows).toEqual([]);
    expect(store.currentSteps).toEqual([]);
  });

  it('should load workflows', async () => {
    const mockWorkflows = [
      { id: '1', name: 'wf1', steps: [] },
      { id: '2', name: 'wf2', steps: [] },
    ];
    (workflowApi.list as any).mockResolvedValue({ workflows: mockWorkflows });

    const store = useWorkflowStore();
    await store.loadWorkflows();

    expect(workflowApi.list).toHaveBeenCalled();
    expect(store.workflows).toEqual(mockWorkflows);
    expect(store.loading).toBe(false);
  });

  it('should load a single workflow', async () => {
    const wf = { id: '1', name: 'wf1', steps: [{ id: 's1' }] };
    (workflowApi.get as any).mockResolvedValue({ workflow: wf });

    const store = useWorkflowStore();
    await store.loadWorkflow('1');

    expect(workflowApi.get).toHaveBeenCalledWith('1');
    expect(store.currentWorkflow).toEqual(wf);
    expect(store.loading).toBe(false);
  });

  it('should create workflow and append to list', async () => {
    const wf = { id: '3', name: 'wf3' };
    (workflowApi.create as any).mockResolvedValue({ workflow: wf });

    const store = useWorkflowStore();
    store.workflows = [];
    const result = await store.createWorkflow({ name: 'wf3' });

    expect(workflowApi.create).toHaveBeenCalledWith({ name: 'wf3' });
    expect(result).toEqual(wf);
    expect(store.workflows).toContainEqual(wf);
    expect(store.saving).toBe(false);
  });

  it('should update workflow in list and currentWorkflow', async () => {
    const wf = { id: '1', name: 'updated' };
    (workflowApi.update as any).mockResolvedValue({ workflow: wf });

    const store = useWorkflowStore();
    store.workflows = [{ id: '1', name: 'old' } as any];
    store.currentWorkflow = { id: '1', name: 'old' } as any;

    await store.updateWorkflow('1', { name: 'updated' });

    expect(workflowApi.update).toHaveBeenCalledWith('1', { name: 'updated' });
    expect(store.workflows[0].name).toBe('updated');
    expect(store.currentWorkflow!.name).toBe('updated');
    expect(store.saving).toBe(false);
  });

  it('should not update currentWorkflow if id does not match', async () => {
    const wf = { id: '1', name: 'updated' };
    (workflowApi.update as any).mockResolvedValue({ workflow: wf });

    const store = useWorkflowStore();
    store.workflows = [{ id: '1', name: 'old' } as any];
    store.currentWorkflow = { id: '2', name: 'other' } as any;

    await store.updateWorkflow('1', { name: 'updated' });

    expect(store.currentWorkflow!.name).toBe('other');
  });

  it('should delete workflow from list and clear currentWorkflow', async () => {
    (workflowApi.delete as any).mockResolvedValue({});

    const store = useWorkflowStore();
    store.workflows = [{ id: '1', name: 'wf1' } as any];
    store.currentWorkflow = { id: '1', name: 'wf1' } as any;

    await store.deleteWorkflow('1');

    expect(workflowApi.delete).toHaveBeenCalledWith('1');
    expect(store.workflows).toEqual([]);
    expect(store.currentWorkflow).toBeNull();
    expect(store.loading).toBe(false);
  });

  it('should add log lines and limit to MAX_LOG_LINES', () => {
    const store = useWorkflowStore();
    for (let i = 0; i < 510; i++) {
      store.addLog(`line ${i}`);
    }
    expect(store.logLines.length).toBe(500);
    expect(store.logLines[0]).toBe('line 10');
  });

  it('should clear logs', () => {
    const store = useWorkflowStore();
    store.addLog('test');
    store.clearLogs();
    expect(store.logLines).toEqual([]);
  });

  it('should set and clear step status', () => {
    const store = useWorkflowStore();
    store.setStepStatus('s1', 'running');
    expect(store.stepStatusMap).toEqual({ s1: 'running' });

    store.clearStepStatus();
    expect(store.stepStatusMap).toEqual({});
    expect(store.currentStepName).toBe('');
  });

  it('should run workflow and set running state', async () => {
    const store = useWorkflowStore();
    await store.runWorkflow('1');
    expect(store.running).toBe(true);
    expect(store.runningId).toBe('1');
    expect(store.logLines).toEqual([]);
    // Clean up
    store.stopWorkflow();
  });

  it('should stop workflow', async () => {
    const store = useWorkflowStore();
    await store.runWorkflow('1');
    await store.stopWorkflow();
    expect(store.running).toBe(false);
  });

  it('should stop a running workflow and reset state', async () => {
    const store = useWorkflowStore();
    await store.runWorkflow('wf-1');
    expect(store.running).toBe(true);
    expect(store.runningId).toBe('wf-1');

    await store.stopWorkflow();
    expect(store.running).toBe(false);
    expect(store.runningId).toBeNull();
    expect(workflowApi.stop).toHaveBeenCalledWith('wf-1');
  });

  it('should add and clear log lines', () => {
    const store = useWorkflowStore();
    store.addLog('line 1');
    store.addLog('line 2');
    expect(store.logLines).toEqual(['line 1', 'line 2']);
    store.clearLogs();
    expect(store.logLines).toEqual([]);
  });

  it('should update step status map', () => {
    const store = useWorkflowStore();
    store.setStepStatus('step-1', 'running');
    expect(store.stepStatusMap).toEqual({ 'step-1': 'running' });
    store.setStepStatus('step-1', 'done');
    expect(store.stepStatusMap).toEqual({ 'step-1': 'done' });
  });

  it('should handle loadWorkflow setting currentWorkflow', async () => {
    const wf = { id: '1', name: 'test', steps: [] };
    (workflowApi.get as any).mockResolvedValue({ workflow: wf });

    const store = useWorkflowStore();
    await store.loadWorkflow('1');

    expect(store.currentWorkflow).toEqual(wf);
  });

  it('should handle loadWorkflows error gracefully', async () => {
    (workflowApi.list as any).mockRejectedValue(new Error('Network error'));
    const store = useWorkflowStore();
    await store.loadWorkflows();
    expect(store.loading).toBe(false);
    expect(store.workflows).toEqual([]);
  });
});
