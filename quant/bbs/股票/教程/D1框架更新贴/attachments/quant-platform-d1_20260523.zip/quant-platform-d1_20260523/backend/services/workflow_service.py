# -*- coding: utf-8 -*-
"""
Workflow Service - Facade module

Provides a unified API surface while delegating to specialized modules:
- workflow_storage: JSON CRUD, caching, lookup
- workflow_executor: linear sequential execution engine
- workflow_stream: SSE event generation
- workflow_utils: cleanup helpers

Each workflow is stored as quant_proj/workflows/{id}.json
Each step: id, name, icon, description, deps[], script, conda_env, enabled
"""
from __future__ import annotations

import json
import logging
import os
import threading
import time
import uuid
from pathlib import Path
from typing import Optional

import config as _config
import tempfile

logger = logging.getLogger("quant.workflow_service")

# ── Persistence config ──────────────────────────────────────
if _config.QUANT_PROJ:
    _PERSISTENCE_DIR = _config.QUANT_PROJ / "workflow_runs"
else:
    _PERSISTENCE_DIR = Path(tempfile.gettempdir()) / "workflow_runs"
_PERSISTENCE_FILE = _PERSISTENCE_DIR / "task_states.json"
_PERSISTENCE_ENABLED = True

if _PERSISTENCE_ENABLED:
    _PERSISTENCE_DIR.mkdir(parents=True, exist_ok=True)

_persistence_lock = threading.Lock()

# ── Shared run state (imported by executor and stream) ──────
_run_states: dict = {}
_states_lock = threading.RLock()
# SSE notification events for push-based streaming
_run_events: dict[str, threading.Event] = {}

# ── Workflow concurrency locks ───────────────────────────────
_run_locks: dict = {}
_run_locks_lock = threading.Lock()


def _save_task_states(states: dict) -> None:
    """Save task states to file."""
    if not _PERSISTENCE_ENABLED:
        return
    try:
        with _persistence_lock:
            persist_states = {}
            for wid, state in states.items():
                if state.get("running") is True or state.get("started_at") is not None:
                    persist_states[wid] = {
                        "running": state.get("running"),
                        "pid": state.get("pid"),
                        "started_at": state.get("started_at"),
                        "step_names": state.get("step_names", {}),
                        "step_status": state.get("step_status", {}),
                        "step_outputs": state.get("step_outputs", {}),
                        "step_timings": state.get("step_timings", {}),
                        "step_progress": state.get("step_progress", {}),
                        "current_step": state.get("current_step"),
                        "error": state.get("error"),
                        "active_procs": state.get("active_procs", {}),
                        "run_id": state.get("run_id"),
                    }
            tmp_file = _PERSISTENCE_FILE.with_suffix(".tmp")
            with open(tmp_file, "w", encoding="utf-8") as f:
                json.dump(persist_states, f, indent=2, ensure_ascii=False)
            os.replace(tmp_file, _PERSISTENCE_FILE)
    except Exception as e:
        logger.error("保存任务状态失败: %s", e)


def _load_task_states() -> dict:
    """Load task states from file."""
    if not _PERSISTENCE_ENABLED or not _PERSISTENCE_FILE.exists():
        return {}
    try:
        with open(_PERSISTENCE_FILE, "r", encoding="utf-8") as f:
            states = json.load(f)
        recovered = 0
        for wid, state in states.items():
            if state.get("running") is True:
                state["running"] = False
                recovered += 1
        if recovered > 0:
            logger.info(f"恢复 {recovered} 个运行中的任务为待运行状态")
        return states
    except Exception as e:
        logger.error(f"加载任务状态失败: {e}")
        return {}


# Load persisted states on startup
_run_states.update(_load_task_states())


def get_or_create_state(wf_id: str) -> dict:
    """Get or create run state."""
    with _states_lock:
        if wf_id not in _run_states:
            _run_states[wf_id] = {
                "running": False, "pid": None, "started_at": None,
                "step_outputs": {}, "step_status": {}, "current_step": None,
                "error": None, "active_procs": {}, "run_id": None,
            }
        return _run_states[wf_id]


def _notify_state_change(wf_id: str) -> None:
    """Notify SSE listeners that state changed (call after step_outputs/status update)."""
    evt = _run_events.get(wf_id)
    if evt:
        evt.set()


def _get_workflow_lock(wf_id: str):
    """Get workflow-specific lock (thread-safe)."""
    with _run_locks_lock:
        if wf_id not in _run_locks:
            _run_locks[wf_id] = threading.Lock()
        return _run_locks[wf_id]


def start_workflow_run(wf_id: str, start_from_step: int = None, step_params=None):
    """Start workflow run (thread-safe, called by router layer)."""
    lock = _get_workflow_lock(wf_id)
    with lock:
        state = get_or_create_state(wf_id)
        if state["running"]:
            raise ValueError("工作流已在运行中")
        state["running"] = True
        _run_events[wf_id] = threading.Event()
    from services.workflow_executor import run_background
    thread = threading.Thread(target=run_background, args=(wf_id, start_from_step), kwargs={"step_params": step_params}, daemon=True)
    thread.start()


# ── Re-exports from sub-modules ─────────────────────────────

# From workflow_storage
from services.workflow_storage import (
    list_workflows,
    get_workflow,
    get_workflows_batch,
    create_workflow,
    save_workflow,
    delete_workflow,
)

# From workflow_executor
from services.workflow_executor import (
    run_background,
    _finalize_run,
)

# From workflow_stream
from services.workflow_stream import generate_stream_events

# From workflow_utils
from services.workflow_utils import cleanup_expired_tasks, cleanup_run_state
