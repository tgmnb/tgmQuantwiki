<template>
  <div class="library-split">
    <div class="library-sidebar">
      <div class="library-sidebar__header">
        <div
          class="search-box"
          style="flex:1;"
        >
          <el-icon class="search-box__icon">
            <Search />
          </el-icon>
          <input
            v-model="search"
            type="text"
            placeholder="搜索择时策略..."
            class="search-box__input"
          >
          <button
            v-if="search"
            class="search-box__clear"
            @click="search = ''"
          >
            <el-icon :size="12">
              <Close />
            </el-icon>
          </button>
        </div>
        <button
          class="btn btn--ghost btn--sm"
          title="新建择时策略"
          @click="startCreate"
        >
          <el-icon :size="14">
            <Plus />
          </el-icon>
        </button>
      </div>
      <div class="library-sidebar__body scroll-auto">
        <template
          v-for="(group, gKey) in filteredGroups"
          :key="gKey"
        >
          <div
            v-if="group.length > 0"
            class="factor-group"
          >
            <div
              class="group-header"
              @click="toggleGroup(gKey as string)"
            >
              <span
                class="group-arrow"
                :style="{ transform: isGroupExpanded(gKey as string) ? 'rotate(90deg)' : '' }"
              >&#9654;</span>
              <span class="group-name">{{ groupLabel(gKey as string) }}</span>
              <span class="group-count">{{ group.length }}</span>
            </div>
            <div
              v-if="isGroupExpanded(gKey as string)"
              class="group-items"
            >
              <div
                v-for="item in group"
                :key="item.path"
                class="tree-item"
                :class="{ 'tree-item--active': selected?.path === item.path }"
                @click="loadCode(item)"
              >
                {{ item.name }}
              </div>
            </div>
          </div>
        </template>
        <div
          v-if="totalItems === 0"
          class="empty-hint"
        >
          暂无择时策略
        </div>
      </div>
    </div>
    <div class="library-content">
      <template v-if="selected || mode === 'create'">
        <div class="code-panel">
          <div class="code-header">
            <div class="code-header__left">
              <el-icon class="code-header__icon">
                <TrendCharts />
              </el-icon>
              <span class="code-header__name">{{ mode === 'create' ? '新建择时/风控策略' : selected?.name }}</span>
            </div>
            <div class="code-header__actions">
              <template v-if="isView">
                <button
                  class="btn btn--ghost btn--sm"
                  @click="startEdit"
                >
                  <el-icon :size="13">
                    <Edit />
                  </el-icon> 编辑
                </button>
                <button
                  class="btn btn--ghost btn--sm"
                  @click="copyFile"
                >
                  <el-icon :size="13">
                    <CopyDocument />
                  </el-icon> 复制
                </button>
                <button
                  class="btn btn--danger btn--sm"
                  @click="deleteFile"
                >
                  <el-icon :size="13">
                    <Delete />
                  </el-icon> 删除
                </button>
              </template>
              <template v-else>
                <button
                  class="btn btn--primary btn--sm"
                  :disabled="isSaving"
                  @click="saveEdit"
                >
                  {{ isSaving ? '...' : '保存' }}
                </button>
                <button
                  class="btn btn--ghost btn--sm"
                  @click="cancelEdit"
                >
                  取消
                </button>
              </template>
            </div>
          </div>
          <div class="code-body">
            <template v-if="isView">
              <div
                v-if="mode === 'create'"
                class="code-create-form"
              >
                <input
                  v-model="newFileName"
                  placeholder="文件名"
                  class="lib-input"
                >
              </div>
              <CodeEditor
                :model-value="codeDisplay"
                language="python"
                :readonly="true"
                :show-toolbar="false"
                height="100%"
              />
            </template>
            <CodeEditor
              v-else
              v-model="editContent"
              language="python"
              height="100%"
            />
          </div>
        </div>
      </template>
      <div
        v-else-if="loading"
        class="library-empty"
      >
        <Loading />
      </div>
      <div
        v-else
        class="library-empty"
      >
        <el-icon
          :size="48"
          color="var(--text-muted)"
          style="opacity:0.3"
        >
          <TrendCharts />
        </el-icon>
        <div class="library-empty__title">
          选择左侧择时/风控策略或点击新建
        </div>
        <button
          class="btn btn--secondary btn--sm"
          style="margin-top:8px;"
          @click="startCreate"
        >
          <el-icon :size="14">
            <Plus />
          </el-icon> 新建
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import Loading from '@/components/common/Loading.vue';

import CodeEditor from '@/components/editor/CodeEditor.vue';
import { timingApi } from '@/api/timing';

const GROUP_LABELS: Record<string, string> = {
  timing_daily: '个股择时 · 日频',
  timing_hour: '个股择时 · 小时频',
  risk_daily: '风控 · 日频',
  risk_hour: '风控 · 小时频',
};

const search = ref('');
const timings = ref<Record<string, any[]>>({});
const expandedGroups = ref<Record<string, boolean>>({});
const selected = ref<{ name: string; path: string } | null>(null);
const codeContent = ref<{ lines?: string[] }>({});
const mode = ref<'view' | 'edit' | 'create'>('view');
const editContent = ref('');
const isSaving = ref(false);
const saveMsg = ref<{ type: string; text: string } | null>(null);
const isModified = ref(false);
const newFileName = ref('');
const newFolderPath = ref('backtest/signal_hub/stock/daily');
const loading = ref(false);

function groupLabel(key: string) { return GROUP_LABELS[key] || key; }

const isGroupExpanded = (group: string) => {
  const searchActive = search.value.trim().length > 0;
  return searchActive || (expandedGroups.value[group] || false);
};

const codeDisplay = computed(() => (codeContent.value.lines || []).join('\n'));
const isView = computed(() => mode.value === 'view');

function toggleGroup(group: string) {
  expandedGroups.value[group] = !expandedGroups.value[group];
}

const filteredGroups = computed(() => {
  const q = search.value.toLowerCase();
  const result: Record<string, any[]> = {};
  for (const [group, items] of Object.entries(timings.value)) {
    result[group] = (items as any[]).filter(i => !q || i.name?.toLowerCase().includes(q));
  }
  return result;
});

const totalItems = computed(() => {
  let n = 0;
  for (const items of Object.values(filteredGroups.value)) n += items.length;
  return n;
});

onMounted(async () => {
  loading.value = true;
  try {
    const d: any = await timingApi.list();
    timings.value = {
      timing_daily: d.timing_daily || [],
      timing_hour: d.timing_hour || [],
      risk_daily: d.risk_daily || [],
      risk_hour: d.risk_hour || [],
    };
    expandedGroups.value = { timing_daily: true, timing_hour: true, risk_daily: true, risk_hour: true };
  } catch (e) { console.error('加载择时模块失败:', e); }
  finally { loading.value = false; }
});

async function loadCode(item: any) {
  selected.value = { name: item.name, path: item.path };
  codeContent.value = {};
  mode.value = 'view';
  isModified.value = false;
  editContent.value = '';
  saveMsg.value = null;
  newFileName.value = '';
  try {
    const d: any = await timingApi.getContent(item.path);
    codeContent.value = d;
  } catch { ElMessage.error('加载代码失败'); }
}

function startEdit() {
  if (!selected.value || !codeContent.value) return;
  editContent.value = (codeContent.value.lines || []).join('\n');
  isModified.value = false;
  mode.value = 'edit';
  saveMsg.value = null;
}

function startCreate() {
  codeContent.value = { lines: [] };
  editContent.value = '';
  isModified.value = false;
  mode.value = 'create';
  saveMsg.value = null;
  newFileName.value = '';
  newFolderPath.value = 'backtest/signal_hub/stock/daily';
}

function cancelEdit() {
  mode.value = 'view';
  editContent.value = '';
  isModified.value = false;
  saveMsg.value = null;
  newFileName.value = '';
}

async function saveEdit() {
  if (mode.value === 'create') {
    const fileName = newFileName.value.trim();
    if (!fileName) { ElMessage.warning('请输入文件名'); return; }
    const path = `${newFolderPath.value}/${fileName}`;
    isSaving.value = true;
    saveMsg.value = null;
    try {
      const res: any = await timingApi.save(path, editContent.value);
      if (res.success) {
        saveMsg.value = { type: 'success', text: '已保存' };
        isModified.value = false;
        mode.value = 'view';
        selected.value = { name: fileName.replace(/\.py$/, ''), path };
        newFileName.value = '';
        const d: any = await timingApi.list();
        timings.value = {
          timing_daily: d.timing_daily || [],
          timing_hour: d.timing_hour || [],
          risk_daily: d.risk_daily || [],
          risk_hour: d.risk_hour || [],
        };
      } else {
        saveMsg.value = { type: 'error', text: res.detail || '保存失败' };
      }
    } catch (e: any) { saveMsg.value = { type: 'error', text: '保存失败: ' + (e.message || e) }; }
    finally { isSaving.value = false; }
  } else {
    if (!selected.value) return;
    isSaving.value = true;
    saveMsg.value = null;
    try {
      const res: any = await timingApi.save(selected.value.path, editContent.value);
      if (res.success) {
        saveMsg.value = { type: 'success', text: '已保存' };
        isModified.value = false;
        mode.value = 'view';
        const d: any = await timingApi.getContent(selected.value.path);
        codeContent.value = d;
      } else {
        saveMsg.value = { type: 'error', text: res.detail || '保存失败' };
      }
    } catch (e: any) { saveMsg.value = { type: 'error', text: '保存失败: ' + (e.message || e) }; }
    finally { isSaving.value = false; }
  }
}

async function deleteFile() {
  if (!selected.value) return;
  try {
    await ElMessageBox.confirm('删除 ' + selected.value.name + '?', '确认删除', { type: 'warning' });
    const res: any = await timingApi.delete(selected.value.path);
    if (res.success) {
      selected.value = null;
      codeContent.value = {};
      mode.value = 'view';
      const d: any = await timingApi.list();
      timings.value = {
        timing_daily: d.timing_daily || [],
        timing_hour: d.timing_hour || [],
        risk_daily: d.risk_daily || [],
        risk_hour: d.risk_hour || [],
      };
      ElMessage.success('已删除');
    }
  } catch { /* ignore */ }
}

async function copyFile() {
  if (!selected.value) return;
  const nameWithoutExt = selected.value.name.replace(/\.py$/, '');
  const newName = nameWithoutExt + '_copy.py';
  const pathParts = selected.value.path.split('/');
  pathParts[pathParts.length - 1] = newName;
  const newPath = pathParts.join('/');
  try {
    const content = (codeContent.value.lines || []).join('\n');
    const res: any = await timingApi.save(newPath, content);
    if (res.success) {
      ElMessage.success('已复制');
      const d: any = await timingApi.list();
      timings.value = {
        timing_daily: d.timing_daily || [],
        timing_hour: d.timing_hour || [],
        risk_daily: d.risk_daily || [],
        risk_hour: d.risk_hour || [],
      };
    } else {
      ElMessage.error(res.detail || '复制失败');
    }
  } catch (e: any) { ElMessage.error(e.message || '复制失败'); }
}
</script>

<style scoped>
.factor-group { margin-bottom: 4px; }
.code-panel { display: flex; flex-direction: column; height: 100%; overflow: hidden; }
.code-header { display: flex; align-items: center; padding: 10px 16px; border-bottom: 1px solid var(--border-color); flex-shrink: 0; gap: 8px; }
.code-header__left { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
.code-header__icon { color: var(--accent); font-size: 16px; }
.code-header__name { font-weight: 600; font-size: var(--font-md); color: var(--text-primary); }
.code-header__actions { display: flex; gap: 6px; margin-left: auto; }
.code-body { flex: 1; overflow: auto; padding: 0; }
.code-create-form { display: flex; gap: 8px; margin-bottom: 12px; }
</style>
