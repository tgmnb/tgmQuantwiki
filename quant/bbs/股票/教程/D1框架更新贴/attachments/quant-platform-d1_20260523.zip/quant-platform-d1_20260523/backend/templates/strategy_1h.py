from backtest.strategies.templates.stock_1h_base import (
    init_config, init_risk_signals,
    run_period, handle_data
)
from backtest.core.context import Context


def initialize(context: Context):
    init_config(context)
    init_risk_signals(context)
