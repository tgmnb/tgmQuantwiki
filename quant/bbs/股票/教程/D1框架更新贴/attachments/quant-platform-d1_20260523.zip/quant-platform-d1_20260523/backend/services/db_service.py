# -*- coding: utf-8 -*-
"""
SQLite 连接池管理器

提供线程级连接池（最大连接数 5），用于缓存回测扫描结果等场景。
所有表在首次访问时自动创建。
"""

from __future__ import annotations

import json
import logging
import sqlite3
import threading
import time
from contextlib import contextmanager
from datetime import datetime
from pathlib import Path
from queue import Empty, Full, Queue
from typing import Any

_logger = logging.getLogger("quant.db")

# ---------------------------------------------------------------------------
# 连接池状态
# ---------------------------------------------------------------------------
_db_path: Path | None = None
_pool: Queue | None = None
_pool_lock = threading.Lock()
_max_connections = 5
_connection_count = 0
_local = threading.local()


# ---------------------------------------------------------------------------
# 内部方法
# ---------------------------------------------------------------------------

def _create_connection() -> sqlite3.Connection:
    """创建一个新的 SQLite 连接（含 WAL 配置）。"""
    conn = sqlite3.connect(str(_db_path), check_same_thread=False, timeout=30.0)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA busy_timeout=30000")
    conn.row_factory = sqlite3.Row
    return conn


def _get_conn() -> sqlite3.Connection:
    """从连接池获取连接：优先线程本地复用，其次空闲池，最后创建新连接。"""
    global _connection_count
    # 1) 线程本地已持有连接则直接复用
    local_conn = getattr(_local, "conn", None)
    if local_conn is not None:
        return local_conn

    # 2) 尝试从空闲池获取
    try:
        conn = _pool.get(block=False)
        _local.conn = conn
        return conn
    except Empty:
        pass

    # 3) 池空且未达最大连接数时创建新连接
    with _pool_lock:
        if _connection_count < _max_connections:
            conn = _create_connection()
            _connection_count += 1
            _local.conn = conn
            return conn

    # 4) 已达上限，阻塞等待其他线程归还
    try:
        conn = _pool.get(block=True, timeout=30.0)
        _local.conn = conn
        return conn
    except Empty:
        raise RuntimeError("数据库连接池已满，无法获取连接")


# ---------------------------------------------------------------------------
# 初始化
# ---------------------------------------------------------------------------

def init_db(db_path: str | Path | None = None) -> None:
    """初始化 SQLite 数据库路径与连接池（应用启动时调用一次）。"""
    global _db_path, _pool, _connection_count
    with _pool_lock:
        _db_path = (
            Path(db_path)
            if db_path
            else Path(__file__).parent.parent / "data" / "quant_platform.db"
        )
        _db_path.parent.mkdir(parents=True, exist_ok=True)
        _pool = Queue(maxsize=_max_connections)
        conn = _create_connection()
        _init_tables_unlock(conn)
        _pool.put(conn)
        _connection_count = 1
        _logger.info("SQLite 数据库初始化完成: %s", _db_path)


# ---------------------------------------------------------------------------
# 连接访问器
# ---------------------------------------------------------------------------

@contextmanager
def get_db():
    """线程安全的数据库连接上下文管理器（自动归还连接）。"""
    conn = _get_conn()
    try:
        yield conn
    except Exception:
        conn.rollback()
        raise
    finally:
        if conn is not None:
            try:
                _pool.put(conn, block=False)
            except Full:
                conn.close()
                with _pool_lock:
                    _connection_count -= 1
            _local.conn = None


# ---------------------------------------------------------------------------
# 表初始化
# ---------------------------------------------------------------------------

def _init_tables_unlock(conn: sqlite3.Connection) -> None:
    """初始化所有表。必须在持有连接时调用。"""
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS backtest_cache (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            strategy_name TEXT NOT NULL,
            type_name    TEXT NOT NULL,
            nav_file     TEXT,
            metrics_json TEXT,
            created_at   REAL NOT NULL,
            updated_at   REAL NOT NULL,
            UNIQUE(strategy_name, type_name)
        );

        CREATE TABLE IF NOT EXISTS scan_meta (
            key          TEXT PRIMARY KEY,
            value        TEXT NOT NULL,
            updated_at   REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS tasks (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            task_id     TEXT UNIQUE NOT NULL,
            name        TEXT,
            status      TEXT,
            pid         INTEGER,
            start_time  REAL,
            end_time    REAL,
            progress    REAL,
            error       TEXT,
            script_path TEXT,
            log_path    TEXT,
            created_at  REAL NOT NULL,
            updated_at  REAL NOT NULL
        );

        CREATE TABLE IF NOT EXISTS workflow_runs (
            run_id           TEXT PRIMARY KEY,
            wf_id            TEXT NOT NULL,
            status           TEXT NOT NULL,
            started_at       REAL NOT NULL,
            ended_at         REAL,
            step_status_json TEXT,
            error            TEXT,
            created_at       REAL NOT NULL,
            updated_at       REAL NOT NULL
        );

        CREATE INDEX IF NOT EXISTS idx_workflow_runs_wf_id ON workflow_runs(wf_id);
        """
    )
    conn.commit()


def init_tasks_table() -> None:
    """在现有数据库上创建 tasks 表（向后兼容）。"""
    with get_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS tasks (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                task_id     TEXT UNIQUE NOT NULL,
                name        TEXT,
                status      TEXT,
                pid         INTEGER,
                start_time  REAL,
                end_time    REAL,
                progress    REAL,
                error       TEXT,
                script_path TEXT,
                log_path    TEXT,
                created_at  REAL NOT NULL,
                updated_at  REAL NOT NULL
            );
            """
        )
        conn.commit()
        _logger.info("tasks 表初始化完成")


# ---------------------------------------------------------------------------
# 回测缓存读写
# ---------------------------------------------------------------------------

def upsert_backtest(
    strategy_name: str, type_name: str, nav_file: str, metrics: dict
) -> None:
    """插入或更新一条回测缓存记录。"""
    now = time.time()
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO backtest_cache (strategy_name, type_name, nav_file, metrics_json, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?)
            ON CONFLICT(strategy_name, type_name)
            DO UPDATE SET
                nav_file = excluded.nav_file,
                metrics_json = excluded.metrics_json,
                updated_at = excluded.updated_at
        """,
            (
                strategy_name,
                type_name,
                nav_file,
                json.dumps(metrics, ensure_ascii=False),
                now,
                now,
            ),
        )


def get_backtest_cache(strategy_name: str, type_name: str) -> dict | None:
    """查询单条回测缓存记录。"""
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM backtest_cache WHERE strategy_name=? AND type_name=?",
            (strategy_name, type_name),
        ).fetchone()
        if row:
            return dict(row)
    return None


def get_all_backtest_cache() -> list[dict]:
    """返回所有回测缓存记录。"""
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM backtest_cache ORDER BY updated_at DESC"
        ).fetchall()
        return [dict(r) for r in rows]


def clear_backtest_cache() -> int:
    """清空所有回测缓存，返回删除行数。"""
    with get_db() as conn:
        n = conn.execute("DELETE FROM backtest_cache").rowcount
        conn.commit()
        return n


def delete_backtest_cache(strategy_name: str, type_name: str) -> None:
    """删除单条缓存。"""
    with get_db() as conn:
        conn.execute(
            "DELETE FROM backtest_cache WHERE strategy_name=? AND type_name=?",
            (strategy_name, type_name),
        )
        conn.commit()


# ---------------------------------------------------------------------------
# 扫描元数据
# ---------------------------------------------------------------------------

def set_scan_meta(key: str, value: str) -> None:
    """存储扫描元数据（如最后扫描时间）。"""
    now = time.time()
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO scan_meta (key, value, updated_at)
            VALUES (?, ?, ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at
        """,
            (key, value, now),
        )


def get_scan_meta(key: str) -> str | None:
    """读取扫描元数据。"""
    with get_db() as conn:
        row = conn.execute("SELECT value FROM scan_meta WHERE key=?", (key,)).fetchone()
        return row["value"] if row else None


# ---------------------------------------------------------------------------
# 时间格式转换（内部）
# ---------------------------------------------------------------------------

def _iso_to_timestamp(iso_str: str | None) -> float | None:
    """将 ISO 格式时间字符串转为 Unix 时间戳。"""
    if not iso_str:
        return None
    try:
        return datetime.fromisoformat(iso_str).timestamp()
    except Exception:
        return None


def _timestamp_to_iso(ts: float | None) -> str | None:
    """将 Unix 时间戳转为 ISO 格式时间字符串。"""
    if ts is None:
        return None
    try:
        return datetime.fromtimestamp(ts).isoformat()
    except Exception:
        return None


def _row_to_task(row: dict) -> dict:
    """将数据库行转为任务字典（与 task_manager 格式兼容）。"""
    return {
        "task_id": row.get("task_id"),
        "name": row.get("name"),
        "status": row.get("status"),
        "pid": row.get("pid"),
        "start_time": _timestamp_to_iso(row.get("start_time")),
        "end_time": _timestamp_to_iso(row.get("end_time")),
        "progress": row.get("progress"),
        "error": row.get("error"),
        "script_path": row.get("script_path"),
        "log_path": row.get("log_path"),
    }


def create_workflow_run(run_id: str, wf_id: str, status: str, started_at: float | None = None) -> None:
    """插入一条 workflow_run 记录。"""
    now = time.time()
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO workflow_runs (run_id, wf_id, status, started_at, ended_at, step_status_json, error, created_at, updated_at)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (run_id, wf_id, status, started_at, None, None, None, now, now),
        )
        conn.commit()


def update_workflow_run(
    run_id: str,
    status: str,
    ended_at: float | None = None,
    step_status_json: str | None = None,
    error: str | None = None,
) -> None:
    """更新 workflow_run 记录。"""
    now = time.time()
    with get_db() as conn:
        fields = ["status = ?", "updated_at = ?"]
        params: list[Any] = [status, now]
        if ended_at is not None:
            fields.append("ended_at = ?")
            params.append(ended_at)
        if step_status_json is not None:
            fields.append("step_status_json = ?")
            params.append(step_status_json)
        if error is not None:
            fields.append("error = ?")
            params.append(error)
        params.append(run_id)
        conn.execute(
            f"UPDATE workflow_runs SET {', '.join(fields)} WHERE run_id = ?",
            tuple(params),
        )
        conn.commit()


def list_workflow_runs(wf_id: str, limit: int = 20) -> list[dict]:
    """查询某工作流的运行记录，按 created_at DESC，并计算 duration_seconds。"""
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM workflow_runs WHERE wf_id = ? ORDER BY created_at DESC LIMIT ?",
            (wf_id, limit),
        ).fetchall()
        result = []
        for r in rows:
            d = dict(r)
            started = d.get("started_at")
            ended = d.get("ended_at")
            if started is not None:
                end_ts = ended if ended is not None else time.time()
                d["duration_seconds"] = round(end_ts - started, 2)
            else:
                d["duration_seconds"] = None
            result.append(d)
        return result


def get_workflow_run(run_id: str) -> dict | None:
    """查询单条 workflow_run 记录。"""
    with get_db() as conn:
        row = conn.execute("SELECT * FROM workflow_runs WHERE run_id = ?", (run_id,)).fetchone()
        if row:
            return dict(row)
    return None


def delete_workflow_runs(wf_id: str) -> None:
    """删除指定工作流的所有运行记录。"""
    with get_db() as conn:
        conn.execute("DELETE FROM workflow_runs WHERE wf_id = ?", (wf_id,))
        conn.commit()


def init_workflow_runs_table() -> None:
    """在现有数据库上创建 workflow_runs 表（向后兼容）。"""
    with get_db() as conn:
        conn.execute(
            """
            CREATE TABLE IF NOT EXISTS workflow_runs (
                id          INTEGER PRIMARY KEY AUTOINCREMENT,
                run_id      TEXT UNIQUE NOT NULL,
                wf_id       TEXT NOT NULL,
                status      TEXT NOT NULL,
                started_at  REAL,
                ended_at    REAL,
                step_status_json TEXT,
                error       TEXT,
                created_at  REAL NOT NULL,
                updated_at  REAL NOT NULL
            );
            """
        )
        conn.commit()
        _logger.info("workflow_runs 表初始化完成")


# ---------------------------------------------------------------------------
# 任务记录读写
# ---------------------------------------------------------------------------

def create_task_record(task: dict) -> None:
    """插入一条任务记录。"""
    now = time.time()
    start_ts = _iso_to_timestamp(task.get("start_time")) or now
    with get_db() as conn:
        conn.execute(
            """
            INSERT INTO tasks (
                task_id, name, status, pid, start_time, end_time,
                progress, error, script_path, log_path, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """,
            (
                task.get("task_id"),
                task.get("name"),
                task.get("status"),
                task.get("pid"),
                start_ts,
                _iso_to_timestamp(task.get("end_time")),
                task.get("progress"),
                task.get("error"),
                task.get("script_path"),
                task.get("log_path"),
                now,
                now,
            ),
        )
        conn.commit()


def update_task_status(
    task_id: str,
    status: str,
    end_time: str | None = None,
    error: str | None = None,
    progress: int | None = None,
) -> None:
    """更新任务状态及可选字段。"""
    now = time.time()
    end_ts = _iso_to_timestamp(end_time)
    with get_db() as conn:
        fields = ["status = ?", "updated_at = ?"]
        params: list[Any] = [status, now]
        if end_ts is not None:
            fields.append("end_time = ?")
            params.append(end_ts)
        if error is not None:
            fields.append("error = ?")
            params.append(error)
        if progress is not None:
            fields.append("progress = ?")
            params.append(progress)
        params.append(task_id)
        conn.execute(
            f"UPDATE tasks SET {', '.join(fields)} WHERE task_id = ?",
            tuple(params),
        )
        conn.commit()


def get_task_by_id(task_id: str) -> dict | None:
    """根据 task_id 查询单条任务记录。"""
    with get_db() as conn:
        row = conn.execute(
            "SELECT * FROM tasks WHERE task_id = ?", (task_id,)
        ).fetchone()
        if row:
            return _row_to_task(dict(row))
    return None


def list_tasks(
    status: str | None = None, limit: int = 100, offset: int = 0
) -> list[dict]:
    """分页查询任务列表，支持按状态过滤。"""
    with get_db() as conn:
        if status:
            rows = conn.execute(
                "SELECT * FROM tasks WHERE status = ? ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (status, limit, offset),
            ).fetchall()
        else:
            rows = conn.execute(
                "SELECT * FROM tasks ORDER BY created_at DESC LIMIT ? OFFSET ?",
                (limit, offset),
            ).fetchall()
        return [_row_to_task(dict(r)) for r in rows]


def get_unfinished_tasks() -> list[dict]:
    """查询所有 running / pending 状态的任务。"""
    with get_db() as conn:
        rows = conn.execute(
            "SELECT * FROM tasks WHERE status IN ('running', 'pending') ORDER BY created_at DESC"
        ).fetchall()
        return [_row_to_task(dict(r)) for r in rows]


# ---------------------------------------------------------------------------
# 健康检查
# ---------------------------------------------------------------------------

def get_db_status() -> dict[str, Any]:
    """返回数据库健康状态。"""
    try:
        with get_db() as conn:
            bt_count = conn.execute(
                "SELECT COUNT(*) FROM backtest_cache"
            ).fetchone()[0]
            return {
                "db_path": str(_db_path) if _db_path else None,
                "connected": True,
                "backtest_cache_count": bt_count,
            }
    except Exception as e:
        return {
            "db_path": str(_db_path) if _db_path else None,
            "connected": False,
            "error": str(e),
        }
