<template>
  <div class="section">
    <div
      class="section__header"
      @click="toggle"
    >
      <div class="section__title-row">
        <span class="section__title-text">{{ title }}</span>
        <span
          v-if="badge"
          class="section__badge"
        >{{ badge }}</span>
      </div>
      <span
        class="section__toggle"
        :style="{ transform: isOpen ? 'rotate(0deg)' : 'rotate(-90deg)' }"
      >&#x25BC;</span>
    </div>
    <div
      v-if="isOpen"
      class="section__body"
    >
      <slot />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, watch } from "vue";

const props = defineProps({
  title: { type: String, required: true },
  badge: { type: String, default: "" },
  defaultOpen: { type: Boolean, default: true },
});

const isOpen = ref(props.defaultOpen);

watch(() => props.defaultOpen, (v) => { isOpen.value = v; });
function toggle() { isOpen.value = !isOpen.value; }
</script>
