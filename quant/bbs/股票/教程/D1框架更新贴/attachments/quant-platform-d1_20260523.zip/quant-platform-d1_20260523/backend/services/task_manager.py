"""
通用任务管理模块

提供统一的任务创建、查询、停止、刷新、清理逻辑，
供 factor_analysis_service、builder、simplified_workflow 等模块复用。
"""

from __future__ import annotations

import hashlib
import logging
import os
import re
import shutil
import subprocess
import sys
import tempfile
import threading
import time
import uuid
from datetime import datetime
from pathlib import Path
from typing import Callable, Any, AsyncGenerator

from services import db_service as _db

_logger = logging.getLogger("quant.task_manager")

# ---------------------------------------------------------------------------
# 全局注册表 —— 所有 TaskManager 实例自动注册，shutdown_all() 统一关闭
# ---------------------------------------------------------------------------

_registry: list[TaskManager] = []
_registry_lock = threading.Lock()


def shutdown_all() -> None:
    """终止所有已注册 TaskManager 的运行中任务。"""
    with _registry_lock:
        managers = list(_registry)
    for tm in managers:
        try:
            tm.shutdown()
        except Exception:
            pass


# ---------------------------------------------------------------------------
# Windows / 跨平台进程管理
# ---------------------------------------------------------------------------

_IS_WIN = sys.platform == "win32"

if _IS_WIN:
    import ctypes

    _kernel32 = ctypes.windll.kernel32

    def _terminate_pid(pid: int) -> None:
        """Windows: 通过 OpenProcess + TerminateProcess 终止进程。"""
        PROCESS_TERMINATE = 1
        handle = _kernel32.OpenProcess(PROCESS_TERMINATE, False, pid)
        if handle:
            _kernel32.TerminateProcess(handle, 1)
            _kernel32.CloseHandle(handle)

    def _is_pid_alive(pid: int) -> bool:
        """Windows: 检查进程是否存活。"""
        SYNCHRONIZE = 0x100000
        handle = _kernel32.OpenProcess(SYNCHRONIZE, False, pid)
        if not handle:
            return False
        # WaitForSingleObject(0) 非阻塞检查进程是否已退出
        WAIT_TIMEOUT = 0x102
        result = _kernel32.WaitForSingleObject(handle, 0)
        _kernel32.CloseHandle(handle)
        return result == WAIT_TIMEOUT

else:

    def _terminate_pid(pid: int) -> None:
        import signal as _sig
        os.kill(pid, _sig.SIGTERM)

    def _is_pid_alive(pid: int) -> bool:
        try:
            os.kill(pid, 0)
            return True
        except (OSError, ProcessLookupError):
            return False


def _subprocess_creationflags() -> int:
    """Windows 下用 CREATE_NEW_PROCESS_GROUP 隔离子进程，防止 Ctrl+C 传播。"""
    if _IS_WIN:
        return subprocess.CREATE_NEW_PROCESS_GROUP  # type: ignore[attr-defined]
    return 0


# ---------------------------------------------------------------------------
# 进度解析配置
# ---------------------------------------------------------------------------

_PROGRESS_RE = re.compile(r"(\d+)%")


def parse_progress_from_log(log_path: Path) -> int:
    """从日志文件中解析 tqdm 进度百分比，返回 0-100 的整数。"""
    if not log_path.exists():
        return 0
    try:
        with open(log_path, "rb") as f:
            f.seek(0, 2)
            size = f.tell()
            if size == 0:
                return 0
            chunk_size = min(8192, size)
            f.seek(size - chunk_size)
            text = f.read(chunk_size).decode("utf-8", errors="ignore")
            for line in reversed(text.splitlines()):
                m = _PROGRESS_RE.search(line)
                if m:
                    return int(m.group(1))
    except Exception:
        pass
    return 0


# ---------------------------------------------------------------------------
# 临时文件管理
# ---------------------------------------------------------------------------

class TempFileManager:
    """临时文件管理器，支持自动清理过期文件。"""

    def __init__(self, subfolder: str, max_age_hours: int = 24):
        self.tmp_dir = Path(tempfile.gettempdir()) / subfolder
        self.max_age_hours = max_age_hours

    def get_tmp_dir(self) -> Path:
        self.tmp_dir.mkdir(parents=True, exist_ok=True)
        return self.tmp_dir

    def cleanup(self, max_age_hours: int | None = None) -> dict[str, int]:
        if not self.tmp_dir.exists():
            return {"cleaned": 0, "errors": 0}

        cutoff = time.time() - (max_age_hours or self.max_age_hours) * 3600
        cleaned = 0
        errors = 0

        try:
            for f in self.tmp_dir.iterdir():
                try:
                    if f.stat().st_mtime < cutoff:
                        if f.is_file():
                            f.unlink()
                        elif f.is_dir():
                            shutil.rmtree(f, ignore_errors=True)
                        cleaned += 1
                except Exception as exc:
                    errors += 1
                    _logger.warning("清理文件失败: %s, 错误: %s", f, exc)
        except Exception as exc:
            _logger.error("清理临时文件失败: %s", exc)
            errors += 1

        return {"cleaned": cleaned, "errors": errors}


# ---------------------------------------------------------------------------
# 任务管理器
# ---------------------------------------------------------------------------

_MAX_TASK_STORE = 200


class TaskManager:
    """通用任务管理器。"""

    def __init__(
        self,
        tmp_subfolder: str,
        python_path: Path | None,
        task_prefix: str = "task",
        timeout_minutes: int = 30,
        max_file_age_hours: int = 24,
        allow_parallel: bool = False,
    ):
        self.task_store: dict[str, dict] = {}
        self._procs: dict[str, subprocess.Popen] = {}
        self.task_lock = threading.Lock()
        self.python_path = python_path
        self.task_prefix = task_prefix
        self.timeout_minutes = timeout_minutes
        self.allow_parallel = allow_parallel

        self.temp_manager = TempFileManager(tmp_subfolder, max_file_age_hours)

        try:
            self.temp_manager.cleanup()
        except Exception:
            pass

        self._restore_unfinished_tasks()

        # 自动注册到全局表
        with _registry_lock:
            _registry.append(self)

    # ---- 内部工具 ----

    def _restore_unfinished_tasks(self) -> None:
        try:
            unfinished = _db.get_unfinished_tasks()
            restored_count = 0
            tmp_marker = str(self.temp_manager.tmp_dir.name)
            for task in unfinished:
                script_path = task.get("script_path", "")
                log_path = task.get("log_path", "")
                if tmp_marker not in script_path and tmp_marker not in log_path:
                    continue

                task_id = task["task_id"]
                now = datetime.now().isoformat()
                _db.update_task_status(
                    task_id=task_id,
                    status="failed",
                    end_time=now,
                    error="服务重启，任务中断",
                )

                task["status"] = "failed"
                task["end_time"] = now
                task["error"] = "服务重启，任务中断"

                with self.task_lock:
                    self.task_store[task_id] = task

                restored_count += 1

            if restored_count > 0:
                _logger.info(
                    "从数据库恢复 %d 个未完成任务（已标记为 failed）: %s",
                    restored_count,
                    tmp_marker,
                )
        except Exception as exc:
            _logger.warning("恢复未完成任务失败: %s", exc)

    def _generate_task_id(self, *identifiers: str) -> str:
        ident_str = ":".join(str(i) for i in identifiers)
        return hashlib.md5(
            f"{self.task_prefix}:{ident_str}:{time.time()}:{uuid.uuid4()}".encode()
        ).hexdigest()[:16]

    def _trim_store(self) -> None:
        """保留最近 _MAX_TASK_STORE 条已完成任务，防止内存无限增长。"""
        if len(self.task_store) <= _MAX_TASK_STORE:
            return
        finished = sorted(
            [(tid, t) for tid, t in self.task_store.items() if t["status"] != "running"],
            key=lambda x: x[1].get("end_time") or x[1].get("start_time", ""),
        )
        to_remove = len(self.task_store) - _MAX_TASK_STORE
        for tid, _ in finished[:to_remove]:
            self.task_store.pop(tid, None)

    def _terminate_task_process(self, task: dict) -> None:
        """终止任务对应的子进程（跨平台）。"""
        pid = task.get("pid")
        if not pid:
            return
        # 优先用 Popen 对象（可 .terminate() / .kill()）
        task_id = task["task_id"]
        proc = self._procs.pop(task_id, None)
        if proc is not None:
            try:
                proc.terminate()
                proc.wait(timeout=5)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass
            return
        # 降级：用 pid 直接终止
        try:
            _terminate_pid(pid)
        except Exception:
            pass

    # ---- 公共 API ----

    def get_running_task(self) -> dict | None:
        for task in self.task_store.values():
            if task["status"] == "running":
                return task
        return None

    def check_timeout(self, task: dict) -> bool:
        if task["status"] != "running":
            return False
        start_time_str = task.get("start_time")
        if not start_time_str:
            return False
        try:
            start_time = datetime.fromisoformat(start_time_str)
            elapsed = (datetime.now() - start_time).total_seconds()
            return elapsed > self.timeout_minutes * 60
        except Exception:
            return False

    def create_task(
        self,
        script_generator: Callable[[], str],
        script_filename: str,
        cwd: Path,
        task_metadata: dict[str, Any],
    ) -> dict:
        if not self.python_path:
            raise RuntimeError("Python 解释器路径未配置，无法创建任务")

        if not self.python_path.exists():
            raise RuntimeError(f"Python 解释器路径不存在: {self.python_path}")

        if not self.allow_parallel:
            running = self.get_running_task()
            if running:
                raise RuntimeError(
                    f"已有任务正在运行（task_id={running['task_id']}），请等待完成后再提交"
                )

        task_id = self._generate_task_id(task_metadata.get("name", ""), str(time.time()))

        script_content = script_generator()
        tmp_dir = self.temp_manager.get_tmp_dir()
        script_path = tmp_dir / f"{script_filename}_{task_id}.py"
        script_path.write_text(script_content, encoding="utf-8")

        log_path = tmp_dir / f"{script_filename}_{task_id}.log"
        try:
            log_f = open(log_path, "wb")
            sub_env = os.environ.copy()
            sub_env["PYTHONIOENCODING"] = "utf-8"
            proc = subprocess.Popen(
                [str(self.python_path), "-u", str(script_path)],
                stdout=log_f,
                stderr=subprocess.STDOUT,
                cwd=str(cwd),
                env=sub_env,
                creationflags=_subprocess_creationflags(),
            )
        except Exception as exc:
            log_f.close() if 'log_f' in dir() else None
            _logger.error("启动任务进程失败: %s", exc)
            raise RuntimeError(f"启动任务进程失败: {exc}") from exc

        task = {
            "task_id": task_id,
            "status": "running",
            "pid": proc.pid,
            "start_time": datetime.now().isoformat(),
            "end_time": None,
            "script_path": str(script_path),
            "log_path": str(log_path),
            "error": None,
            "progress": 0,
            **task_metadata,
        }

        with self.task_lock:
            self.task_store[task_id] = task
            self._procs[task_id] = proc

        try:
            _db.create_task_record(task)
        except Exception as exc:
            _logger.warning("任务创建后写入数据库失败: %s", exc)

        _logger.info("任务已创建: task_id=%s, pid=%d", task_id, proc.pid)
        return {"task_id": task_id, "status": "running"}

    def get_task(self, task_id: str) -> dict | None:
        self.refresh_task(task_id)
        return self.task_store.get(task_id)

    def get_task_with_log(self, task_id: str, log_lines: int = 200) -> dict | None:
        task = self.get_task(task_id)
        if not task:
            return None

        log_tail = ""
        log_path = Path(task.get("log_path", ""))
        if log_path.exists():
            try:
                lines = log_path.read_text(encoding="utf-8").splitlines()
                log_tail = "\n".join(lines[-log_lines:])
            except Exception:
                pass

        return {"task": task, "log_tail": log_tail}

    def stop_task(self, task_id: str) -> dict:
        if task_id not in self.task_store:
            raise ValueError(f"任务不存在: {task_id}")

        task = self.task_store[task_id]
        if task["status"] != "running":
            return {
                "task_id": task_id,
                "status": task["status"],
                "message": "任务已不在运行中"
            }

        self._terminate_task_process(task)
        task["status"] = "stopped"
        task["end_time"] = datetime.now().isoformat()

        try:
            _db.update_task_status(
                task_id=task_id,
                status="stopped",
                end_time=task["end_time"],
            )
        except Exception as exc:
            _logger.warning("任务终止状态写入数据库失败: %s", exc)

        _logger.info("任务已终止: task_id=%s", task_id)
        return {"task_id": task_id, "status": "stopped"}

    def refresh_task(self, task_id: str) -> None:
        task = self.task_store.get(task_id)
        if not task:
            return

        if task["status"] == "running":
            if self.check_timeout(task):
                with self.task_lock:
                    if task["status"] == "running":
                        task["status"] = "timeout"
                        task["error"] = f"任务超时（{self.timeout_minutes}分钟）"
                        task["end_time"] = datetime.now().isoformat()
                        task["progress"] = None
                        self._terminate_task_process(task)
                try:
                    _db.update_task_status(
                        task_id=task_id,
                        status="timeout",
                        end_time=task["end_time"],
                        error=task["error"],
                    )
                except Exception as exc:
                    _logger.warning("任务超时状态写入数据库失败: %s", exc)
                _logger.warning("任务超时: task_id=%s", task_id)
                return

            log_path = Path(task.get("log_path", ""))
            progress = parse_progress_from_log(log_path)
            with self.task_lock:
                if task["status"] == "running":
                    task["progress"] = progress
        else:
            task["progress"] = None

        if task["status"] != "running":
            return

        # 检查进程是否仍在运行
        if _is_pid_alive(task["pid"]):
            return

        # 进程已结束
        with self.task_lock:
            if task["status"] != "running":
                return

            log_path = Path(task.get("log_path", ""))
            if log_path.exists():
                try:
                    log_text = log_path.read_text(encoding="utf-8", errors="replace")
                    success_marker = task.get("success_marker", "DONE")
                    if success_marker in log_text:
                        task["status"] = "completed"
                    else:
                        if "Traceback" in log_text or "Error" in log_text:
                            task["status"] = "failed"
                            for line in reversed(log_text.splitlines()):
                                if line.strip():
                                    task["error"] = line.strip()
                                    break
                        else:
                            task["status"] = "completed"
                except Exception:
                    task["status"] = "completed"

            task["end_time"] = datetime.now().isoformat()
            task["progress"] = 100
            self._procs.pop(task_id, None)
            self._trim_store()

        try:
            _db.update_task_status(
                task_id=task_id,
                status=task["status"],
                end_time=task["end_time"],
                error=task.get("error"),
                progress=task["progress"],
            )
        except Exception as exc:
            _logger.warning("任务结束状态写入数据库失败: %s", exc)

        _logger.info("任务结束: task_id=%s, status=%s", task_id, task["status"])

    def refresh_all(self) -> None:
        for tid in list(self.task_store.keys()):
            self.refresh_task(tid)

    def shutdown(self) -> None:
        """优雅关闭：终止所有运行中的任务子进程。"""
        stopped = []
        for task_id, task in list(self.task_store.items()):
            if task.get("status") != "running":
                continue
            self._terminate_task_process(task)
            task["status"] = "stopped"
            task["end_time"] = datetime.now().isoformat()
            task["error"] = "服务器关闭，任务中断"
            stopped.append(task_id)
        if stopped:
            _logger.info("优雅关闭：已终止 %d 个运行中任务: %s", len(stopped), stopped)

    def cleanup_temp_files(self, max_age_hours: int | None = None) -> dict[str, int]:
        return self.temp_manager.cleanup(max_age_hours)

    def list_tasks(self, status: str | None = None) -> list[dict]:
        tasks = list(self.task_store.values())
        if status:
            tasks = [t for t in tasks if t["status"] == status]
        return tasks

    # ---- SSE 流式推送（公共方法，路由复用） ----

    async def stream_events(
        self,
        task_id: str,
        *,
        request: Any = None,
        poll_interval: float = 0.3,
    ) -> AsyncGenerator[str, None]:
        """生成 SSE 事件流，供路由直接 yield。

        Args:
            task_id: 任务 ID
            request: FastAPI Request（可选，用于检测客户端断开）
            poll_interval: 轮询间隔（秒）
        """
        import asyncio
        import json

        _logger.info(f"[SSE] stream_events 开始: task_id={task_id}")
        last_log_pos = 0
        try:
            while True:
                if request and await request.is_disconnected():
                    _logger.info(f"[SSE] 客户端断开: task_id={task_id}")
                    break

                self.refresh_task(task_id)
                task = self.task_store.get(task_id)
                if not task:
                    _logger.warning(f"[SSE] 任务不存在: task_id={task_id}")
                    yield "data: " + json.dumps({"error": "Task not found"}) + "\n\n"
                    break

                status = task.get("status", "unknown")
                new_lines = []
                log_path = Path(task.get("log_path", ""))
                if log_path.exists():
                    try:
                        size = log_path.stat().st_size
                        if last_log_pos < size:
                            with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                                f.seek(last_log_pos)
                                new_text = f.read()
                                new_lines = new_text.splitlines()
                                last_log_pos = size
                                if new_lines:
                                    _logger.info(f"[SSE] 读取 {len(new_lines)} 行日志, 位置 {last_log_pos}: {new_lines[0][:80]}")
                    except Exception as e:
                        _logger.warning(f"[SSE] 读取日志失败: {e}")

                payload = json.dumps({
                    "task_id": task_id,
                    "status": status,
                    "progress": task.get("progress", 0),
                    "error": task.get("error"),
                    "new_lines": new_lines,
                }, ensure_ascii=False)

                if status == "running":
                    yield "data: " + payload + "\n\n"
                    await asyncio.sleep(poll_interval)
                else:
                    # 任务已结束，读取最终日志后再退出
                    _logger.info(f"[SSE] 任务结束 status={status}，读取最终日志")
                    if log_path.exists() and last_log_pos < log_path.stat().st_size:
                        try:
                            with open(log_path, "r", encoding="utf-8", errors="ignore") as f:
                                f.seek(last_log_pos)
                                final_lines = f.read().splitlines()
                                if final_lines:
                                    _logger.info(f"[SSE] 最终日志 {len(final_lines)} 行")
                                    done_payload = json.dumps({
                                        "task_id": task_id,
                                        "status": status,
                                        "progress": task.get("progress", 100),
                                        "error": task.get("error"),
                                        "new_lines": final_lines,
                                    }, ensure_ascii=False)
                                    yield "data: " + done_payload + "\n\n"
                                    return
                        except Exception as e:
                            _logger.warning(f"[SSE] 读取最终日志失败: {e}")
                    yield "data: " + payload + "\n\n"
                    break
        except asyncio.CancelledError:
            _logger.info(f"[SSE] 连接取消: task_id={task_id}")
            return
