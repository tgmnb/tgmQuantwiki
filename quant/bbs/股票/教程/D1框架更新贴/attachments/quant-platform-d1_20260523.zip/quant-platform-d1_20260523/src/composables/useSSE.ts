import { ref, onUnmounted, getCurrentInstance } from 'vue';
import type { Ref } from 'vue';

/**
 * SSE 组合式函数
 * 用于管理 Server-Sent Events 连接
 */
export interface SSEOptions {
  onMessage?: (data: unknown) => void;
  onError?: (error: Event) => void;
  onOpen?: () => void;
  retryInterval?: number;
}

export function useSSE(url: Ref<string>, options: SSEOptions = {}) {
  const eventSource = ref<EventSource | null>(null);
  const connected = ref(false);
  const error = ref<Event | null>(null);
  let retryTimer: ReturnType<typeof setTimeout> | undefined;

  /**
   * 连接 SSE
   */
  function connect() {
    disconnect();

    const fullUrl = url.value;
    if (!fullUrl) return;

    try {
      const es = new EventSource(fullUrl);
      eventSource.value = es;

      es.onopen = () => {
        connected.value = true;
        error.value = null;
        options.onOpen?.();
      };

      es.onmessage = (event: MessageEvent) => {
        try {
          const data = JSON.parse(event.data);
          options.onMessage?.(data);
        } catch (err) {
          console.error('[SSE] Parse error:', err);
        }
      };

      es.onerror = (err: Event) => {
        connected.value = false;
        error.value = err;
        options.onError?.(err);

        // 自动重连
        if (options.retryInterval && es.readyState === EventSource.CLOSED) {
          retryTimer = setTimeout(() => {
            if (!connected.value) {
              connect();
            }
          }, options.retryInterval);
        }
      };
    } catch (err) {
      console.error('[SSE] Connection error:', err);
      error.value = err as Event;
    }
  }

  /**
   * 断开 SSE 连接
   */
  function disconnect() {
    clearTimeout(retryTimer);
    if (eventSource.value) {
      eventSource.value.close();
      eventSource.value = null;
      connected.value = false;
    }
  }

  // 组件卸载时自动断开连接（仅在组件上下文中）
  if (getCurrentInstance()) {
    onUnmounted(() => {
      disconnect();
    });
  }

  return {
    eventSource,
    connected,
    error,
    connect,
    disconnect,
  };
}
