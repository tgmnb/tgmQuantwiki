# -*- coding: utf-8 -*-
"""Workflow executor module - linear sequential execution engine."""
from __future__ import annotations

import json
import logging
import os
import subprocess
import threading
import time
import uuid
from pathlib import Path

import config as _config

logger = logging.getLogger("quant.workflow_executor")


def _notify_state_change(wf_id: str) -> None:
    """Notify SSE listeners that state changed."""
    from services.workflow_service import _run_events
    evt = _run_events.get(wf_id)
    if evt:
        evt.set()

_log_lock = threading.Lock()
MAX_STEP_OUTPUT_LINES = 500

_ERROR_PATTERNS = [
    ("SYNTAXERROR", "SyntaxError"), ("IMPORTERROR", "ImportError"),
    ("RUNTIMEERROR", "RuntimeError"), ("VALUEERROR", "ValueError"),
    ("TYPEERROR", "TypeError"), ("KEYERROR", "KeyError"),
    ("INDEXERROR", "IndexError"), ("ATTRIBUTEERROR", "AttributeError"),
    ("FILENOTFOUNDERROR", "FileNotFoundError"), ("TIMEOUTERROR", "TimeoutError"),
]


def _write_log(log_file, line, wf_id=None):
    try:
        with _log_lock:
            with open(log_file, "a", encoding="utf-8") as f:
                f.write(line + "\n")
                f.flush()
    except Exception:
        logger.warning("Failed to write log to %s", log_file, exc_info=True)
    if wf_id:
        _notify_state_change(wf_id)


def _write_step_output(proj_dir, run_id, step_id, step_outputs, error_type=None, error_context=None):
    """Write a manifest of what this step produced, so downstream nodes can consume it."""
    data_dir = proj_dir / "workflow_data" / run_id / step_id
    data_dir.mkdir(parents=True, exist_ok=True)
    manifest = {
        "step_id": step_id,
        "output_lines": step_outputs[-50:],
        "output_dir": str(data_dir),
    }
    if error_type:
        manifest["error_type"] = error_type
    if error_context:
        manifest["error_context"] = error_context
    manifest_file = data_dir / "output.json"
    with open(manifest_file, "w", encoding="utf-8") as f:
        json.dump(manifest, f, ensure_ascii=False, indent=2)


def _get_upstream_inputs(proj_dir, run_id, deps):
    """Return a dict mapping dep_id -> output_dir for each upstream dep that has output."""
    inputs = {}
    for dep_id in deps:
        dep_dir = proj_dir / "workflow_data" / run_id / dep_id
        manifest = dep_dir / "output.json"
        if manifest.exists():
            inputs[dep_id] = str(dep_dir)
    return inputs


def _build_step_env(proj_dir, step_info, step_params, run_id=None):
    env = os.environ.copy()
    env["PYTHONPATH"] = str(proj_dir)
    env["PYTHONIOENCODING"] = "utf-8"
    if step_params:
        for k, v in step_params.items():
            env[f"WF_PARAM_{k.upper()}"] = str(v)
    upstream_inputs = step_info.get("_upstream_inputs", {})
    if upstream_inputs:
        env["WF_INPUT_FILES"] = json.dumps(upstream_inputs, ensure_ascii=False)
    data_dir = step_info.get("_data_dir")
    if data_dir:
        env["WF_DATA_DIR"] = str(data_dir)
    return env


def _execute_step(state, step_info, proj_dir, log_file, step_params=None, run_id=None, wf_id=None):
    from services.nodes import estimate_progress_from_log

    step_id = step_info["step_id"]
    full_wf = step_info["full_wf"]
    step_name = step_info.get("step_name", step_id)
    retry_count = step_info.get("retry", 0)
    attempt = step_info.get("_attempt", 1)
    effective_wf_id = wf_id or full_wf.get("id") or step_id

    while True:
        state["current_step"] = step_id
        state["step_status"][step_id] = "running"
        if step_id not in state["step_outputs"]:
            state["step_outputs"][step_id] = []

        step_start = time.time()
        state.setdefault("step_timings", {})[step_id] = {"started_at": step_start}
        state.setdefault("step_progress", {})[step_id] = 0.0

        script = proj_dir / full_wf["script"]

        try:
            resolved = script.resolve()
            proj_resolved = proj_dir.resolve()
            resolved.relative_to(proj_resolved)
        except ValueError:
            msg = "[ERROR] Script path escapes project: " + str(script) + " [ERROR_TYPE:PathTraversal]"
            state["step_outputs"][step_id].append(msg)
            _write_log(log_file, msg, effective_wf_id)
            state["step_status"][step_id] = "failed"
            return False
        except Exception as e:
            msg = "[ERROR] Invalid script path: " + str(e) + " [ERROR_TYPE:PathTraversal]"
            state["step_outputs"][step_id].append(msg)
            _write_log(log_file, msg, effective_wf_id)
            state["step_status"][step_id] = "failed"
            return False

        if not script.exists():
            msg = "[ERROR] Script not found: " + str(script) + " [ERROR_TYPE:ScriptNotFound]"
            state["step_outputs"][step_id].append(msg)
            _write_log(log_file, msg, effective_wf_id)
            state["step_status"][step_id] = "failed"
            return False

        python_path = _config.QUANT_PYTHON_PATH
        if not python_path or not python_path.exists():
            msg = "[ERROR] Python interpreter not found (QUANT_PYTHON_PATH) [ERROR_TYPE:PythonNotFound]"
            state["step_outputs"][step_id].append(msg)
            _write_log(log_file, msg, effective_wf_id)
            state["step_status"][step_id] = "failed"
            return False

        cmd = [str(python_path), str(script)]
        env = _build_step_env(proj_dir, step_info, step_params, run_id)

        logger.info("[workflow] Running: " + step_name)
        proc = subprocess.Popen(
            cmd, cwd=str(proj_dir),
            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
            text=True, encoding="utf-8", errors="replace", env=env)
        state["active_procs"][step_id] = proc

        line_count = 0
        try:
            for line in proc.stdout:
                if line.strip():
                    clean = line.rstrip()
                    state["step_outputs"][step_id].append(clean)
                    if len(state["step_outputs"][step_id]) > MAX_STEP_OUTPUT_LINES:
                        state["step_outputs"][step_id] = state["step_outputs"][step_id][-MAX_STEP_OUTPUT_LINES:]
                    _write_log(log_file, clean, effective_wf_id)
                    line_count += 1
                    if line_count % 50 == 0:
                        recent_text = "\n".join(state["step_outputs"][step_id][-100:])
                        state["step_progress"][step_id] = estimate_progress_from_log(recent_text)
                if not state["running"]:
                    proc.kill()
                    break
        finally:
            if proc.poll() is None:
                proc.kill()
            proc.wait()
            if step_id in state.get("active_procs", {}):
                del state["active_procs"][step_id]

        step_end = time.time()
        state["step_timings"][step_id]["ended_at"] = step_end
        state["step_timings"][step_id]["duration"] = round(step_end - step_start, 2)

        if proc.returncode != 0 and state["running"] and retry_count > 0 and attempt < retry_count:
            msg = f"[WARN] {step_name} failed (attempt {attempt}/{retry_count}), retrying..."
            state["step_outputs"][step_id].append(msg)
            _write_log(log_file, msg, effective_wf_id)
            attempt += 1
            step_info["_attempt"] = attempt
            continue

        if proc.returncode == 0 and state["running"]:
            state["step_status"][step_id] = "done"
            state["step_progress"][step_id] = 100.0
            if run_id:
                _write_step_output(proj_dir, run_id, step_id,
                                   state["step_outputs"].get(step_id, []))
            return True
        else:
            state["step_status"][step_id] = "failed"
            step_outputs = state["step_outputs"].get(step_id, [])
            last_lines = step_outputs[-20:] if step_outputs else []
            error_type = None
            error_context_lines = []
            for line in last_lines:
                line_upper = line.upper()
                if any(err in line_upper for err in ["ERROR", "EXCEPTION", "TRACEBACK"]):
                    if not error_context_lines:
                        for prev_line in last_lines:
                            prev_upper = prev_line.upper()
                            if any(err in prev_upper for err in ["ERROR", "EXCEPTION", "TRACEBACK"]):
                                error_context_lines.append(prev_line)
                                if len(error_context_lines) >= 5:
                                    break
                    for pattern, name in _ERROR_PATTERNS:
                        if pattern in line_upper:
                            error_type = name
                            break
                    else:
                        if "ERROR" in line_upper or "EXCEPTION" in line_upper:
                            error_type = error_type or "ExecutionError"
                    break
            if error_type is None:
                error_type = "ExecutionError"
            if not error_context_lines:
                error_context_lines = last_lines[-5:] if last_lines else []
            error_msg = f"[ERROR] {step_name} exited with code {proc.returncode} [ERROR_TYPE:{error_type}]"
            state["step_outputs"][step_id].append(error_msg)
            _write_log(log_file, error_msg, effective_wf_id)
            if run_id:
                _write_step_output(proj_dir, run_id, step_id,
                                   step_outputs, error_type=error_type,
                                   error_context=error_context_lines)
            if not state["running"]:
                state["error"] = step_name + " stopped"
            else:
                state["error"] = step_name + " exited with code " + str(proc.returncode) + f" ({error_type})"
            return False


def _finalize_run(state, run_id, status, wf_id=None):
    state["running"] = False
    state["current_step"] = None
    for proc in list(state.get("active_procs", {}).values()):
        try:
            proc.kill()
            proc.wait(timeout=5)
        except Exception:
            pass
    state["active_procs"] = {}
    ended_at = time.time()
    step_status_json = json.dumps(state.get("step_status", {}), ensure_ascii=False)
    error = state.get("error")
    try:
        from services import db_service
        db_service.update_workflow_run(run_id, status, ended_at, step_status_json, error)
    except Exception:
        logger.exception("Failed to finalize workflow run")
    if wf_id:
        _notify_state_change(wf_id)


def run_background(wf_id, start_from_step=None, run_id=None, step_params=None):
    """Background thread for linear workflow execution."""
    from services.workflow_service import (
        get_or_create_state, _run_states, _states_lock,
        get_workflow, get_workflows_batch,
    )
    from services.workflow_storage import _get_proj_dir

    state = get_or_create_state(wf_id)
    proj_dir = Path(_get_proj_dir())
    wf = get_workflow(wf_id)
    if not wf:
        state["error"] = "Workflow not found"
        state["running"] = False
        return

    run_id = run_id or uuid.uuid4().hex[:12]
    state["run_id"] = run_id

    log_dir = proj_dir / "workflow_logs"
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"{run_id}.log"

    try:
        from services import db_service
        db_service.create_workflow_run(run_id, wf_id, "running", time.time())
    except Exception:
        logger.exception("Failed to create workflow run record")

    steps = wf.get("steps", [])
    if not steps:
        # 单步工作流（原 atomic），把自身作为一个步骤
        steps = [{
            "id": wf_id,
            "name": wf.get("name", wf_id),
            "node_type": wf.get("node_type", ""),
            "script": wf.get("script", ""),
            "conda_env": wf.get("conda_env", "quantpy312"),
            "params": {},
        }]

    # Build full workflow map for step details
    step_ids = [s["id"] for s in steps]
    batch_results = get_workflows_batch(step_ids)

    state["step_names"] = {}
    state["step_status"] = {}
    state["step_outputs"] = {}
    for step in steps:
        sid = step["id"]
        state["step_names"][sid] = step.get("name", sid)
        state["step_status"][sid] = "idle"
        state["step_outputs"][sid] = []

    if not state.get("running", False):
        _finalize_run(state, run_id, "stopped")
        return
    state["started_at"] = time.time()
    state["current_step"] = None
    state["error"] = None
    state["active_procs"] = {}

    start_index = 0
    if start_from_step is not None and isinstance(start_from_step, int):
        start_index = start_from_step

    try:
        for i, step in enumerate(steps):
            if i < start_index:
                state["step_status"][step["id"]] = "done"
                continue
            if not state["running"]:
                for remaining in steps[i:]:
                    state["step_status"][remaining["id"]] = "skipped"
                _finalize_run(state, run_id, "stopped", wf_id)
                return

            sid = step["id"]
            # Resolve full workflow for this step
            full_wf = batch_results.get(sid)
            if full_wf:
                step_info = {
                    "step_id": sid,
                    "full_wf": full_wf,
                    "step_name": state["step_names"].get(sid, sid),
                    "retry": step.get("retry", 0),
                    "_upstream_inputs": _get_upstream_inputs(proj_dir, run_id, [steps[i-1]["id"]] if i > 0 else []),
                    "_data_dir": str(proj_dir / "workflow_data" / run_id / sid),
                }
            else:
                # Step is self-contained (has script)
                step_info = {
                    "step_id": sid,
                    "full_wf": step,
                    "step_name": state["step_names"].get(sid, sid),
                    "retry": step.get("retry", 0),
                    "_upstream_inputs": _get_upstream_inputs(proj_dir, run_id, [steps[i-1]["id"]] if i > 0 else []),
                    "_data_dir": str(proj_dir / "workflow_data" / run_id / sid),
                }

            data_dir = proj_dir / "workflow_data" / run_id / sid
            data_dir.mkdir(parents=True, exist_ok=True)

            success = _execute_step(state, step_info, proj_dir, log_file, step_params=step_params, run_id=run_id, wf_id=wf_id)
            if not success:
                # Mark remaining steps as skipped
                for remaining in steps[i+1:]:
                    state["step_status"][remaining["id"]] = "skipped"
                    if remaining["id"] not in state["step_outputs"]:
                        state["step_outputs"][remaining["id"]] = []
                    state["step_outputs"][remaining["id"]].append("[ERROR] 上游步骤失败，跳过")
                _finalize_run(state, run_id, "failed", wf_id)
                return

        _finalize_run(state, run_id, "completed", wf_id)
    except Exception as e:
        logger.exception("Workflow run error")
        state["error"] = str(e)
        _finalize_run(state, run_id, "failed")
