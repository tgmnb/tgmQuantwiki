# -*- coding: utf-8 -*-
"""D1 Quant Platform - Financial Factors Router"""

from pathlib import Path
from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse

import config

router = APIRouter(prefix="/api/financial_factors")

_FINA_FACTOR_DIR = "factor_calculate/fina_factor_hub"


def require_quant_proj() -> Path:
    if not config.QUANT_PROJ or not config.QUANT_PROJ.exists():
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail="QUANT_PROJ not configured")
    return config.QUANT_PROJ


@router.get("/list")
async def list_financial_factors(quant_proj: Path = Depends(require_quant_proj)):
    """List all financial factor modules from fina_factor_hub."""
    fina_dir = quant_proj / _FINA_FACTOR_DIR
    if not fina_dir.exists():
        return {"modules": {}}

    modules = {}
    for f in fina_dir.iterdir():
        if f.suffix == '.py' and f.stem not in ('__init__', '__pycache__'):
            modules[f.stem] = []
    return {"modules": modules}


@router.get("/content")
async def get_factor_content(module: str = Query(...), quant_proj: Path = Depends(require_quant_proj), limit: int = Query(300)):
    """读取财务因子 Python 代码内容。"""
    import re
    from fastapi import HTTPException
    from routers._code_reader import read_code_file

    if any(c in '/\\:*?"<>|\x00' for c in module):
        raise HTTPException(status_code=400, detail="Invalid module name")

    path = f"{_FINA_FACTOR_DIR}/{module}.py"
    result = read_code_file(quant_proj, path, limit)
    if isinstance(result, JSONResponse):
        return result
    result["path"] = path
    return result


@router.post("/save")
async def save_factor_code(data: dict, quant_proj: Path = Depends(require_quant_proj)):
    """保存财务因子 Python 代码。"""
    from fastapi.responses import JSONResponse
    import re

    module = data.get("module", "")
    content = data.get("content", "")

    if any(c in '/\\:*?"<>|\x00' for c in module):
        return JSONResponse(status_code=400, content={"success": False, "detail": "Invalid module name"})

    target = quant_proj / _FINA_FACTOR_DIR / f"{module}.py"
    if not target.is_relative_to(quant_proj):
        return JSONResponse(status_code=403, content={"success": False, "detail": "路径越界"})
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return {"success": True}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "detail": str(e)})


@router.post("/delete")
async def delete_financial_factor(data: dict, quant_proj: Path = Depends(require_quant_proj)):
    """删除财务因子 Python 代码文件。"""
    import re

    module = data.get("module", "")
    if any(c in '/\\:*?"<>|\x00' for c in module):
        return JSONResponse(status_code=400, content={"success": False, "detail": "Invalid module name"})

    target = quant_proj / _FINA_FACTOR_DIR / f"{module}.py"
    fina_root = quant_proj / _FINA_FACTOR_DIR
    try:
        if not target.resolve().is_relative_to(fina_root.resolve()):
            return JSONResponse(status_code=403, content={"success": False, "detail": "只能删除 factor_calculate/fina_factor_hub 目录下的文件"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"success": False, "detail": "路径校验失败"})

    if not target.exists():
        return JSONResponse(status_code=404, content={"success": False, "detail": "文件不存在"})

    try:
        target.unlink()
        return {"success": True}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "detail": str(e)})