"""
数据服务 - CSV/文件读取工具

将原 main.py 中的 _load_csv 拆分出来：
  - detect_encoding()  : 编码检测
  - find_header_row()  : 表头行定位（跳过注释/元数据）
  - load_csv()         : 完整 CSV 转 list[dict]
"""

from __future__ import annotations

import csv
import io
from pathlib import Path
from typing import Any

from services.cache_service import get_cache, set_cache, delete_cache, invalidate_prefix, get_stats

# ---------------------------------------------------------------------------
# CSV 读取缓存（TTL 10s，按文件路径+mtime 作为 key）
# ---------------------------------------------------------------------------
_CSV_CACHE_TTL = 10.0

# ---------------------------------------------------------------------------
# 文件系统扫描缓存（TTL 60s，按路径作为 key）
# ---------------------------------------------------------------------------
_FS_CACHE_TTL = 60.0

# 已知的 CSV 表头关键词（用于定位真正的表头行）
_KNOWN_HEADER_KEYWORDS = [
    "股票代码", "日期", "时间", "交易日期", "代码",
    "open", "close", "volume", "买", "卖", "开", "高", "低",
]


def detect_encoding(path: Path) -> str | None:
    """按 utf-8 -> utf-8-sig -> gbk 顺序尝试解码，返回成功时的原始文本。
    全部失败返回 None。
    """
    for enc in ("utf-8", "utf-8-sig", "gbk"):
        try:
            return path.read_text(encoding=enc)
        except (OSError, UnicodeDecodeError):
            continue
    return None


def detect_encoding_name(path: Path) -> str | None:
    """按 utf-8 -> utf-8-sig -> gbk -> gb18030 顺序尝试解码，返回成功时的编码名称。
    全部失败返回 None。
    用于 Polars.read_csv 等需要编码名称的场景。
    """
    for enc in ("utf-8", "utf-8-sig", "gbk", "gb18030"):
        try:
            # 只测试能否读取前 1KB
            with open(path, "r", encoding=enc) as f:
                f.read(1024)
            return enc
        except (OSError, UnicodeDecodeError):
            continue
    return None


def find_header_row(lines: list[str]) -> int:
    """在原始行列表中定位 CSV 表头行的索引。
    跳过空行和非逗号行，遇到包含已知关键词的逗号行即为表头。
    若始终未匹配，默认返回第0行。
    """
    header_idx = 0
    for i, line in enumerate(lines):
        stripped = line.strip()
        if not stripped:
            continue
        if "," in line and any(kw in stripped for kw in _KNOWN_HEADER_KEYWORDS):
            return i
        # 有逗号但无已知关键词？当作元数据行，推进候选表头到下一行
        if "," in line:
            header_idx = i + 1
    return header_idx


def parse_csv_rows(raw: str) -> list[dict]:
    """将原始文本解析为 dict 列表。
    处理 BOM、规范化换行，用 csv.DictReader 解析。
    返回空列表表示无有效数据。
    """
    # Strip BOM
    raw = raw.lstrip("\ufeff")
    lines = raw.splitlines()

    # 定位表头
    hidx = find_header_row(lines)
    if hidx >= len(lines):
        return []
    lines = lines[hidx:]
    raw_clean = "\n".join(lines)

    reader = csv.DictReader(io.StringIO(raw_clean))
    rows = list(reader)

    if not rows:
        return []

    # Guard: 如果首行全是 None（只有 header 无数据行），视为空
    if all(v is None for v in rows[0].values()):
        return []

    # 清理所有 header/value 中的 BOM 干扰
    def _clean_key(k: str | None) -> str:
        if k is None:
            return ""
        return k.lstrip("\ufeff")

    fixed = [{_clean_key(k): v for k, v in rows[0].items()}]
    for r in rows[1:]:
        fixed.append({_clean_key(k): v for k, v in r.items()})

    return fixed


def load_csv(
    path: Path,
    *,
    header_only: bool = False,
) -> list[dict]:
    """Load CSV as list of dicts, with simple TTL cache.

    TODO: 对于超大 CSV (>1MB)，考虑流式/分页读取避免全量加载内存。
    当前数据规模（回测结果）在内存中处理可接受。
    """
    # 缓存 key: 路径 + mtime（文件变更后自动失效）
    try:
        mtime = path.stat().st_mtime
    except OSError:
        return []
    cache_key = f"{path}:{mtime}:{header_only}"

    cached_rows = get_cache(cache_key)
    if cached_rows is not None:
        return cached_rows

    raw = detect_encoding(path)
    if raw is None:
        return []

    if header_only:
        lines = raw.splitlines()
        if lines:
            lines = lines[1:]
        raw = "\n".join(lines)

    rows = parse_csv_rows(raw)
    set_cache(cache_key, rows, ttl=int(_CSV_CACHE_TTL))

    return rows


# ---------------------------------------------------------------------------
# 文件系统扫描缓存（TTL 60s）
# ---------------------------------------------------------------------------


def get_cached(path: str, scanner_fn, *args, **kwargs) -> Any:
    """带 TTL 的文件系统扫描缓存。

    Args:
        path:       缓存 key（通常是目录路径）
        scanner_fn: 实际扫描函数（无缓存时调用）
        *args, **kwargs: 传递给 scanner_fn 的额外参数

    Returns:
        缓存或新扫描的结果
    """
    cached = get_cache(path)
    if cached is not None:
        return cached

    # 缓存未命中或已过期，执行扫描
    result = scanner_fn(*args, **kwargs)
    set_cache(path, result, ttl=int(_FS_CACHE_TTL))

    return result


def invalidate_scan_cache(path: str | None = None) -> None:
    """使扫描缓存失效。

    Args:
        path: 指定路径（仅使该路径缓存失效）；为 None 时清空全部
    """
    if path is None:
        invalidate_prefix("")
    else:
        delete_cache(path)


def get_fs_cache_stats() -> dict[str, Any]:
    """返回文件系统缓存统计信息（用于健康检查）。"""
    stats = get_stats()
    stats["ttl_seconds"] = _FS_CACHE_TTL
    return stats


def load_csv_page(
    path: Path,
    offset: int = 0,
    limit: int = 100,
    *,
    header_only: bool = False,
) -> tuple[list[dict], int]:
    """加载 CSV 文件的指定分页数据。

    Args:
        path: CSV 文件路径。
        offset: 起始行偏移（0 表示从第一行数据开始）。
        limit: 最大返回行数。
        header_only: 是否跳过首行（元信息行）。

    Returns:
        (rows, total) 元组 — rows 为分页后的数据行列表，total 为总数据行数。
        文件不存在或读取失败时返回 ([], 0)，不抛出异常。
    """
    raw = detect_encoding(path)
    if raw is None:
        return [], 0

    if header_only:
        lines = raw.splitlines()
        if lines:
            lines = lines[1:]
        raw = "\n".join(lines)

    # 定位表头
    lines = raw.splitlines()
    hidx = find_header_row(lines)
    if hidx >= len(lines):
        return [], 0

    data_lines = lines[hidx:]
    total = len(data_lines)

    # 分页切片
    page_lines = data_lines[offset : offset + limit]
    page_raw = "\n".join(page_lines)

    return parse_csv_rows(page_raw), total
