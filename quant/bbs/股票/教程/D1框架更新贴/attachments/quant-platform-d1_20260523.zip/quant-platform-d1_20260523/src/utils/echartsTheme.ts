/**
 * ECharts 主题工具函数
 * 根据当前 dark/light 主题返回 ECharts 配色方案
 */
export function getEChartsTheme() {
  const isDark = document.documentElement.getAttribute('data-theme') === 'dark'
  return {
    bgColor: isDark ? '#0f0f14' : '#ffffff',
    textColor: isDark ? '#a1a1aa' : '#52525b',
    gridColor: isDark ? '#1f1f2e' : '#e5e7eb',
    lineColors: ['#6366f1', '#22c55e', '#f59e0b', '#ef4444', '#14b8a6', '#a855f7'],
  }
}

/**
 * ECharts 全局默认配色（用于多系列对比图等）
 */
export const ECHARTS_COLORS = [
  '#6366f1', '#22c55e', '#f59e0b', '#ef4444',
  '#14b8a6', '#a855f7', '#f97316', '#3b82f6',
]
