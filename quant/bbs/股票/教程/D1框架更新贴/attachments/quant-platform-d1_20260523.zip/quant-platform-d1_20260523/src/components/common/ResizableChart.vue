<template>
  <div style="position:relative;">
    <div :style="{ height: height + 'px', width: '100%' }">
      <slot />
    </div>
    <!-- Drag handle -->
    <div
      class="resize-handle"
      title="拖拽调节高度"
      @mousedown.prevent="onMouseDown"
    >
      <div class="resize-dots" />
    </div>
  </div>
</template>

<script setup lang="ts">
import { onUnmounted, ref } from 'vue';

const props = withDefaults(
  defineProps<{
    defaultHeight?: number;
    minHeight?: number;
    maxHeight?: number;
  }>(),
  {
    defaultHeight: 320,
    minHeight: 180,
    maxHeight: 500,
  }
);

const height = ref(props.defaultHeight);

let dragging = false;
let startY = 0;
let startH = 0;

function onMouseDown(e: MouseEvent) {
  dragging = true;
  startY = e.clientY;
  startH = height.value;
  document.body.style.userSelect = 'none';
  document.body.style.cursor = 'ns-resize';
  window.addEventListener('mousemove', onMouseMove);
  window.addEventListener('mouseup', onMouseUp);
}

function onMouseMove(e: MouseEvent) {
  if (!dragging) return;
  const delta = e.clientY - startY;
  height.value = Math.min(props.maxHeight, Math.max(props.minHeight, startH + delta));
}

function onMouseUp() {
  if (!dragging) return;
  dragging = false;
  document.body.style.userSelect = '';
  document.body.style.cursor = '';
  window.removeEventListener('mousemove', onMouseMove);
  window.removeEventListener('mouseup', onMouseUp);
}

onUnmounted(() => {
  if (dragging) {
    window.removeEventListener('mousemove', onMouseMove);
    window.removeEventListener('mouseup', onMouseUp);
    document.body.style.userSelect = '';
    document.body.style.cursor = '';
    dragging = false;
  }
});
</script>

<style scoped>
.resize-handle {
  height: 8px;
  cursor: ns-resize;
  display: flex;
  align-items: center;
  justify-content: center;
  margin-top: 2px;
}
.resize-dots {
  width: 36px;
  height: 3px;
  border-radius: 2px;
  background: var(--border-color);
  transition: background 0.15s;
}
.resize-handle:hover .resize-dots {
  background: var(--accent);
}
</style>
