<template>
  <div class="library-split">
    <div class="library-sidebar">
      <div class="library-sidebar__header">
        <div
          class="search-box"
          style="flex:1;"
        >
          <el-icon class="search-box__icon">
            <Search />
          </el-icon>
          <input
            v-model="search"
            type="text"
            placeholder="搜索财务因子..."
            class="search-box__input"
          >
          <button
            v-if="search"
            class="search-box__clear"
            @click="search = ''"
          >
            <el-icon :size="12">
              <Close />
            </el-icon>
          </button>
        </div>
        <button
          class="btn btn--ghost btn--sm"
          title="新建财务因子"
          @click="startCreate"
        >
          <el-icon :size="14">
            <Plus />
          </el-icon>
        </button>
      </div>
      <div class="library-sidebar__body scroll-auto">
        <div
          v-for="item in filteredItems"
          :key="item.name"
          class="tree-item"
          :class="{ 'tree-item--active': selected?.name === item.name }"
          @click="loadCode(item)"
        >
          {{ item.name }}.py
        </div>
        <div
          v-if="filteredItems.length === 0"
          class="empty-hint"
        >
          暂无财务因子
        </div>
      </div>
    </div>
    <div class="library-content">
      <template v-if="selected || mode === 'create'">
        <div class="code-panel">
          <div class="code-header">
            <div class="code-header__left">
              <el-icon class="code-header__icon">
                <Coin />
              </el-icon>
              <span class="code-header__name">{{ mode === 'create' ? '新建财务因子' : (selected?.name + '.py') }}</span>
            </div>
            <div class="code-header__actions">
              <template v-if="isView">
                <button
                  class="btn btn--ghost btn--sm"
                  @click="startEdit"
                >
                  <el-icon :size="13">
                    <Edit />
                  </el-icon> 编辑
                </button>
                <button
                  class="btn btn--ghost btn--sm"
                  @click="copyFile"
                >
                  <el-icon :size="13">
                    <CopyDocument />
                  </el-icon> 复制
                </button>
                <button
                  class="btn btn--danger btn--sm"
                  @click="deleteFile"
                >
                  <el-icon :size="13">
                    <Delete />
                  </el-icon> 删除
                </button>
              </template>
              <template v-else>
                <button
                  class="btn btn--primary btn--sm"
                  :disabled="isSaving"
                  @click="saveEdit"
                >
                  {{ isSaving ? '...' : '保存' }}
                </button>
                <button
                  class="btn btn--ghost btn--sm"
                  @click="cancelEdit"
                >
                  取消
                </button>
              </template>
            </div>
          </div>
          <div class="code-body">
            <template v-if="isView">
              <div
                v-if="mode === 'create'"
                class="code-create-form"
              >
                <input
                  v-model="newFileName"
                  placeholder="模块名（不含 .py）"
                  class="lib-input"
                >
              </div>
              <CodeEditor
                :model-value="codeDisplay"
                language="python"
                :readonly="true"
                :show-toolbar="false"
                height="100%"
              />
            </template>
            <CodeEditor
              v-else
              v-model="editContent"
              language="python"
              height="100%"
            />
          </div>
        </div>
      </template>
      <div
        v-else-if="loading"
        class="library-empty"
      >
        <Loading />
      </div>
      <div
        v-else
        class="library-empty"
      >
        <el-icon
          :size="48"
          color="var(--text-muted)"
          style="opacity:0.3"
        >
          <Coin />
        </el-icon>
        <div class="library-empty__title">
          选择左侧财务因子或点击新建
        </div>
        <button
          class="btn btn--secondary btn--sm"
          style="margin-top:8px;"
          @click="startCreate"
        >
          <el-icon :size="14">
            <Plus />
          </el-icon> 新建
        </button>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import Loading from '@/components/common/Loading.vue';

import CodeEditor from '@/components/editor/CodeEditor.vue';
import { financialFactorsApi } from '@/api/financialFactors';

const search = ref('');
const allFactors = ref<{ name: string; module: string; path: string }[]>([]);
const selected = ref<{ name: string; module: string; path: string } | null>(null);
const codeContent = ref<{ lines?: string[]; total?: number }>({});
const mode = ref<'view' | 'edit' | 'create'>('view');
const editContent = ref('');
const isSaving = ref(false);
const saveMsg = ref<{ type: string; text: string } | null>(null);
const isModified = ref(false);
const newFileName = ref('');
const loading = ref(false);

const filteredItems = computed(() => {
  const q = search.value.toLowerCase();
  if (!q) return allFactors.value;
  return allFactors.value.filter(f => (f.name || '').toLowerCase().includes(q));
});

const codeDisplay = computed(() => (codeContent.value.lines || []).join('\n'));
const isView = computed(() => mode.value === 'view');

onMounted(async () => {
  loading.value = true;
  try {
    const d: any = await financialFactorsApi.list();
    const modules = d.modules || {};
    allFactors.value = Object.keys(modules)
      .filter(name => name && name !== '__init__')
      .sort()
      .map(name => ({ name, module: name, path: name }));
  } catch (e) { console.error('Failed to load financial factors:', e); }
  finally { loading.value = false; }
});

async function loadCode(item: { name: string; module: string; path: string }) {
  selected.value = item;
  codeContent.value = {};
  mode.value = 'view';
  isModified.value = false;
  editContent.value = '';
  saveMsg.value = null;
  newFileName.value = '';
  try {
    const d: any = await financialFactorsApi.getContent(item.module || item.name, 99999);
    codeContent.value = d;
  } catch { ElMessage.error('加载代码失败'); }
}

function startEdit() {
  if (!selected.value || !codeContent.value) return;
  editContent.value = (codeContent.value.lines || []).join('\n');
  isModified.value = false;
  mode.value = 'edit';
  saveMsg.value = null;
}

function startCreate() {
  selected.value = null;
  codeContent.value = { lines: [] };
  editContent.value = '';
  isModified.value = false;
  mode.value = 'create';
  saveMsg.value = null;
  newFileName.value = '';
}

function cancelEdit() {
  mode.value = 'view';
  editContent.value = '';
  isModified.value = false;
  saveMsg.value = null;
  newFileName.value = '';
}

async function saveEdit() {
  const isCreate = mode.value === 'create';
  const moduleName = isCreate
    ? newFileName.value.trim().replace(/\.py$/, '')
    : (selected.value?.module || selected.value?.name || '');
  if (!moduleName) { ElMessage.warning('请输入模块名'); return; }
  isSaving.value = true;
  saveMsg.value = null;
  try {
    const res: any = await financialFactorsApi.save(moduleName, editContent.value);
    if (res.success) {
      saveMsg.value = { type: 'success', text: '已保存' };
      isModified.value = false;
      mode.value = 'view';
      if (isCreate) {
        selected.value = { name: moduleName, module: moduleName, path: moduleName };
        newFileName.value = '';
        const d: any = await financialFactorsApi.list();
        const modules = d.modules || {};
        allFactors.value = Object.keys(modules)
          .filter(name => name && name !== '__init__')
          .sort()
          .map(name => ({ name, module: name, path: name }));
      } else {
        const d: any = await financialFactorsApi.getContent(moduleName);
        codeContent.value = d;
      }
    } else {
      saveMsg.value = { type: 'error', text: res.detail || '保存失败' };
    }
  } catch (e: any) {
    saveMsg.value = { type: 'error', text: '保存失败: ' + (e.message || e) };
  } finally {
    isSaving.value = false;
  }
}

async function deleteFile() {
  if (!selected.value) return;
  try {
    await ElMessageBox.confirm('删除 ' + selected.value.name + '.py?', '确认删除', { type: 'warning' });
    const res: any = await financialFactorsApi.deleteModule(selected.value.module || selected.value.name);
    if (res.success) {
      selected.value = null;
      codeContent.value = {};
      mode.value = 'view';
      const d: any = await financialFactorsApi.list();
      const modules = d.modules || {};
      allFactors.value = Object.keys(modules)
        .filter(name => name && name !== '__init__')
        .sort()
        .map(name => ({ name, module: name, path: name }));
      ElMessage.success('已删除');
    }
  } catch { /* ignore */ }
}

async function copyFile() {
  if (!selected.value) return;
  const newModule = selected.value.module + '_copy';
  try {
    const content = (codeContent.value.lines || []).join('\n');
    const res: any = await financialFactorsApi.save(newModule, content);
    if (res.success) {
      ElMessage.success('已复制');
      const d: any = await financialFactorsApi.list();
      const modules = d.modules || {};
      allFactors.value = Object.keys(modules)
        .filter(name => name && name !== '__init__')
        .sort()
        .map(name => ({ name, module: name, path: name }));
    } else {
      ElMessage.error(res.detail || '复制失败');
    }
  } catch (e: any) { ElMessage.error(e.message || '复制失败'); }
}
</script>

<style scoped>
/* styles inherited from global.css */
.code-panel { display: flex; flex-direction: column; height: 100%; overflow: hidden; }
.code-header { display: flex; align-items: center; padding: 10px 16px; border-bottom: 1px solid var(--border-color); flex-shrink: 0; gap: 8px; }
.code-header__left { display: flex; align-items: center; gap: 8px; flex: 1; min-width: 0; }
.code-header__icon { color: var(--accent); font-size: 16px; }
.code-header__name { font-weight: 600; font-size: var(--font-md); color: var(--text-primary); }
.code-header__actions { display: flex; gap: 6px; margin-left: auto; }
.code-body { flex: 1; overflow: auto; padding: 0; }
.code-create-form { display: flex; gap: 8px; margin-bottom: 12px; }
</style>
