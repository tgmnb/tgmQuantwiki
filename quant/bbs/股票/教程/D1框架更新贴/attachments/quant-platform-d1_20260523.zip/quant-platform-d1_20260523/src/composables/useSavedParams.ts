import { ref, watch, type Ref } from 'vue'

export function useBacktestParams<T extends Record<string, unknown>>(
  key: string,
  defaultValue: T,
): { params: Ref<T>; resetParams: () => void; clearParams: () => void } {
  const storageKey = `backtest_params_${key}`

  function loadFromStorage(): T {
    try {
      const saved = localStorage.getItem(storageKey)
      if (saved) {
        return { ...defaultValue, ...JSON.parse(saved) }
      }
    } catch (e) {
      console.warn('Failed to load backtest params:', e)
    }
    return { ...defaultValue }
  }

  const params = ref<T>(loadFromStorage()) as Ref<T>

  let saveTimer: ReturnType<typeof setTimeout> | undefined

  watch(
    params,
    (newValue) => {
      clearTimeout(saveTimer)
      saveTimer = setTimeout(() => {
        try {
          localStorage.setItem(storageKey, JSON.stringify(newValue))
        } catch (e) {
          console.warn('Failed to save backtest params:', e)
        }
      }, 300)
    },
    { deep: true },
  )

  function resetParams() {
    params.value = { ...defaultValue }
  }

  function clearParams() {
    localStorage.removeItem(storageKey)
    params.value = { ...defaultValue }
  }

  return {
    params,
    resetParams,
    clearParams,
  }
}

export function useSavedParams<T extends Record<string, unknown>>(
  key: string,
  defaultValue: T,
): { params: Ref<T>; resetParams: () => void; clearParams: () => void } {
  return useBacktestParams(key, defaultValue)
}
