<template>
  <div
    class="metric-card"
    :class="{ 'metric-card--compact': compact }"
  >
    <div class="metric-card-label">
      {{ label }}
    </div>
    <div
      class="metric-card-value"
      :class="valueClass"
    >
      <Transition
        name="value-change"
        mode="out-in"
      >
        <span :key="displayValue">{{ displayValue }}</span>
      </Transition>
    </div>
    <div
      v-if="sub"
      class="metric-card-sub"
    >
      {{ sub }}
    </div>
    <div class="metric-card__accent-line" />
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';

const props = defineProps<{
  label: string;
  value: number | string;
  sub?: string;
  trend?: 'up' | 'down';
  compact?: boolean;
  precision?: number;
}>();

const p = computed(() => props.precision ?? 2);

const displayValue = computed(() => {
  const v = props.value;
  if (typeof v === 'string') return v;
  if (typeof v === 'number') {
    const abs = Math.abs(v);
    if (Number.isInteger(v) || abs >= 1000) return v.toLocaleString('en-US', { maximumFractionDigits: 2 });
    if (abs >= 1) return v.toFixed(p.value);
    return v.toFixed(4);
  }
  return String(v);
});

const valueClass = computed(() => {
  if (typeof props.value !== 'number') return '';
  if (props.value > 0) return 'value--up';
  if (props.value < 0) return 'value--down';
  return '';
});
</script>

<style scoped>
.metric-card {
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: var(--radius-md);
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
  gap: 4px;
  transition: all var(--transition);
  cursor: default;
  position: relative;
  overflow: hidden;
}

.metric-card:hover {
  border-color: var(--border2);
  box-shadow: var(--shadow-sm);
  transform: translateY(-1px);
}

.metric-card--compact {
  padding: 10px 12px;
}

.metric-card-label {
  font-size: var(--font-2xs);
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  font-weight: 600;
}

.metric-card-value {
  font-size: 22px;
  font-weight: 700;
  color: var(--text-primary);
  line-height: 1.2;
  font-variant-numeric: tabular-nums;
  font-family: var(--font-mono);
  letter-spacing: -0.5px;
}

.value--up {
  color: var(--up);
}
.value--down {
  color: var(--down);
}

.metric-card-sub {
  font-size: var(--font-xs);
  color: var(--text-muted);
}

.metric-card__accent-line {
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: linear-gradient(90deg, var(--accent), #a78bfa);
  opacity: 0;
  transition: opacity 0.2s;
}

.metric-card:hover .metric-card__accent-line {
  opacity: 1;
}

/* Value change transition */
.value-change-enter-active,
.value-change-leave-active {
  transition: all 0.2s ease;
}
.value-change-enter-from {
  opacity: 0;
  transform: translateY(-4px);
}
.value-change-leave-to {
  opacity: 0;
  transform: translateY(4px);
}
</style>
