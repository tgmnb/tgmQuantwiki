"""
因子分析服务层 —— 通过 subprocess 调用 quant-test-d1-pro 单因子分析工具

复用通用任务管理器（task_manager.py）：
- 内存级任务状态存储（重启丢失）
- 临时脚本注入参数（不修改原工具代码）
- 日志进度解析
- Polars 读取 CSV 结果
"""

from __future__ import annotations

import json
import logging
import sys
from pathlib import Path

import polars as pl

import config as _config
from services.data_service import detect_encoding_name
from services.task_manager import TaskManager

_logger = logging.getLogger("quant.factor_analysis")

# ---------------------------------------------------------------------------
# 单因子分析工具目录（相对于 quant_proj）
# ---------------------------------------------------------------------------

_TOOL_REL_PATH = "tools_platform/apps/单因子分析"

# ---------------------------------------------------------------------------
# 任务管理器实例（串行执行，不允许并行）
# ---------------------------------------------------------------------------

_task_manager = TaskManager(
    tmp_subfolder="quant_factor_analysis",
    python_path=_config.QUANT_PYTHON_PATH,
    task_prefix="factor_analysis",
    timeout_minutes=30,
    max_file_age_hours=24,
    allow_parallel=False,
)


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------

def _get_tool_dir(quant_proj: Path | None = None) -> Path:
    """获取单因子分析工具绝对目录。"""
    proj = quant_proj or _config.QUANT_PROJ
    return Path(proj) / _TOOL_REL_PATH


def _generate_factor_analysis_script(
    tool_dir: str,
    quant_proj: str,
    factor_params: dict,
    domain_mode: str,
    swap_mode: str,
    date_start: str,
    date_end: str | None,
    bins: int,
) -> str:
    """生成临时 Python 脚本内容，用于在 quantpy312 环境中执行单因子分析。"""
    overrides_json = json.dumps(factor_params, ensure_ascii=False)
    date_end_repr = repr(date_end) if date_end is not None else "None"
    return f'''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""自动生成的单因子分析脚本 —— 由因子分析服务派发"""
import sys
import json
sys.path.insert(0, r"{tool_dir}")
sys.path.insert(0, r"{quant_proj}")

import tool_config

# 覆盖配置参数
tool_config.factor_params = json.loads(r\'\'\'{overrides_json}\'\'\')
tool_config.domain_mode = {repr(domain_mode)}
tool_config.swap_mode = {repr(swap_mode)}
tool_config.date_start = {repr(date_start)}
tool_config.date_end = {date_end_repr}
tool_config.bins = {bins}

# 确保 RESULTS_DIR 指向正确的结果目录
from pathlib import Path
actual_project_dir = Path(r"{tool_dir}")
tool_config.PROJECT_DIR = actual_project_dir
tool_config.RESULTS_DIR = actual_project_dir / "results"
tool_config.RESULTS_DIR.mkdir(parents=True, exist_ok=True)

# 导入并执行分析
import main
main.factor_analyze()
sys.stdout.write("FACTOR_ANALYSIS_DONE\n")
sys.stdout.flush()
'''


# ---------------------------------------------------------------------------
# 创建任务
# ---------------------------------------------------------------------------

def create_task(
    factor_params: dict[str, list[str]],
    domain_mode: str = "全A选股",
    swap_mode: str = "open-close",
    date_start: str = "2018-01-01",
    date_end: str | None = None,
    bins: int = 10,
) -> dict:
    """创建并启动单因子分析任务。

    Args:
        factor_params: 因子参数字典，如 {"涨跌幅相关因子": ["pct_chg_1", ...]}
        domain_mode: 分域模式，如 "全A选股"
        swap_mode: 调仓模式，如 "open-close"
        date_start: 开始日期，如 "2018-01-01"
        date_end: 结束日期，None 表示最新数据
        bins: 分组数量

    Returns:
        {"task_id": str, "status": str}
    """
    quant_proj = _config.QUANT_PROJ
    tool_dir = _get_tool_dir(quant_proj)

    if not tool_dir.exists():
        raise RuntimeError(f"单因子分析工具目录不存在: {tool_dir}")

    # 生成脚本内容
    script_content = _generate_factor_analysis_script(
        tool_dir=str(tool_dir).replace("\\", "/"),
        quant_proj=str(quant_proj).replace("\\", "/"),
        factor_params=factor_params,
        domain_mode=domain_mode,
        swap_mode=swap_mode,
        date_start=date_start,
        date_end=date_end,
        bins=bins,
    )

    # 使用任务管理器创建任务
    result = _task_manager.create_task(
        script_generator=lambda: script_content,
        script_filename="factor_analysis",
        cwd=tool_dir,
        task_metadata={
            "name": f"{domain_mode}_因子分析",
            "factor_params": factor_params,
            "domain_mode": domain_mode,
            "swap_mode": swap_mode,
            "date_start": date_start,
            "date_end": date_end,
            "bins": bins,
            "success_marker": "FACTOR_ANALYSIS_DONE",
        },
    )

    _logger.info(
        "因子分析任务已提交: task_id=%s, domain_mode=%s",
        result["task_id"],
        domain_mode,
    )
    return result


def get_task(task_id: str) -> dict | None:
    """获取任务状态，自动刷新。"""
    return _task_manager.get_task(task_id)


def get_task_with_log(task_id: str) -> dict:
    """获取任务状态和最近日志。

    Returns:
        {"task": dict, "log_tail": str}
    """
    result = _task_manager.get_task_with_log(task_id, log_lines=200)
    if result is None:
        raise ValueError(f"任务不存在: {task_id}")
    return result


def stop_task(task_id: str) -> dict:
    """终止运行中的因子分析任务。"""
    try:
        result = _task_manager.stop_task(task_id)
    except ValueError:
        raise ValueError(f"任务不存在: {task_id}")
    return result


def cleanup_old_tasks(max_age_hours: int = 24) -> dict[str, int]:
    """清理超过指定时间的任务临时文件。

    Args:
        max_age_hours: 文件保留时间（小时），默认 24 小时

    Returns:
        清理统计信息：{"cleaned": int, "errors": int}
    """
    return _task_manager.cleanup_temp_files(max_age_hours)


# ---------------------------------------------------------------------------
# 解析分析结果
# ---------------------------------------------------------------------------

def parse_result(task_id: str) -> dict:
    """解析因子分析结果，读取 因子分析记录表.csv 获取 IC 统计指标。

    Returns:
        {"task_id": str, "results": list[dict]}
    """
    task = _task_manager.get_task(task_id)
    if task is None:
        raise ValueError(f"任务不存在: {task_id}")
    tool_dir = _get_tool_dir()
    result_csv = tool_dir / "results" / "因子分析记录表.csv"

    if not result_csv.exists():
        return {"task_id": task_id, "results": []}

    try:
        # 自动检测编码
        encoding = detect_encoding_name(result_csv)
        if encoding is None:
            raise RuntimeError("无法检测 CSV 文件编码（尝试了 utf-8/utf-8-sig/gbk）")

        df = pl.read_csv(result_csv, encoding=encoding, infer_schema_length=0)
    except Exception as exc:
        _logger.error("读取因子分析记录表失败: %s", exc)
        raise RuntimeError(f"读取结果文件失败: {exc}") from exc

    if df.is_empty():
        return {"task_id": task_id, "results": []}

    # 统一第一列名为 name_index
    first_col = df.columns[0] if df.columns else "name_index"
    if first_col != "name_index":
        df = df.rename({first_col: "name_index"})

    # 构造目标 name_index 列表
    target_names = []
    factor_params = task.get("factor_params", {})
    domain_mode = task.get("domain_mode", "")
    for factor_class, factor_name_list in factor_params.items():
        for factor_name in factor_name_list:
            target_names.append(f"{domain_mode}_{factor_class}_{factor_name}")

    if not target_names:
        return {"task_id": task_id, "results": []}

    filtered = df.filter(pl.col("name_index").is_in(target_names))

    results = []
    for row in filtered.iter_rows(named=True):
        results.append(
            {
                "name_index": row.get("name_index"),
                "开始时间": row.get("开始时间"),
                "结束时间": row.get("结束时间"),
                "IC均值": row.get("IC均值"),
                "IC标准差": row.get("IC标准差"),
                "ICIR": row.get("ICIR"),
                "IC_t值": row.get("IC_t值"),
                "IC胜率": row.get("IC胜率"),
                "IC自相关": row.get("IC自相关"),
                "第1组净值": row.get("第1组净值"),
                "最后1组净值": row.get("最后1组净值"),
                "多空净值": row.get("多空净值"),
            }
        )

    return {"task_id": task_id, "results": results}
