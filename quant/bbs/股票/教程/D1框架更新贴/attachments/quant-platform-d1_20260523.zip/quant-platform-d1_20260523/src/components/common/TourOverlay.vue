<template>
  <Teleport to="body">
    <div
      v-if="currentStep"
      class="tour-overlay"
    >
      <div
        class="tour-mask tour-mask-top"
        :style="{ height: rect.top + 'px' }"
      />
      <div
        class="tour-mask tour-mask-bottom"
        :style="{ top: rect.bottom + 'px' }"
      />
      <div
        class="tour-mask tour-mask-left"
        :style="{ top: rect.top + 'px', height: rect.height + 'px', width: rect.left + 'px' }"
      />
      <div
        class="tour-mask tour-mask-right"
        :style="{ top: rect.top + 'px', height: rect.height + 'px', left: rect.right + 'px' }"
      />
      <div
        class="tour-highlight"
        :style="{
          top: rect.top + 'px',
          left: rect.left + 'px',
          width: rect.width + 'px',
          height: rect.height + 'px',
        }"
      />
      <div
        ref="cardRef"
        class="tour-card"
        :style="cardStyle"
      >
        <div class="tour-card__header">
          <span class="tour-card__step">{{ currentIndex + 1 }} / {{ props.steps.length }}</span>
          <h4 class="tour-card__title">
            {{ currentStep.title }}
          </h4>
        </div>
        <p class="tour-card__content">
          {{ currentStep.content }}
        </p>
        <div class="tour-card__footer">
          <el-button
            type="info"
            text
            size="small"
            @click="handleSkip"
          >
            跳过
          </el-button>
          <el-button
            type="primary"
            size="small"
            @click="handleNext"
          >
            {{ isLastStep ? '完成' : '下一步' }}
          </el-button>
        </div>
      </div>
    </div>
  </Teleport>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted, onUnmounted, nextTick } from 'vue';

type Placement = 'top' | 'bottom' | 'left' | 'right';

interface TourStep {
  targetSelector: string;
  title: string;
  content: string;
  placement?: Placement;
}

interface Props {
  steps: TourStep[];
  onFinish?: () => void;
  onSkip?: () => void;
}

const props = defineProps<Props>();

const currentIndex = ref(0);
const rect = ref({ top: 0, left: 0, right: 0, bottom: 0, width: 0, height: 0 });
const cardRef = ref<HTMLElement | null>(null);
const cardPos = ref({ top: 0, left: 0 });

const currentStep = computed(() => props.steps[currentIndex.value] ?? null);
const isLastStep = computed(() => currentIndex.value === props.steps.length - 1);

const cardStyle = computed(() => ({
  top: `${cardPos.value.top}px`,
  left: `${cardPos.value.left}px`,
}));

function updatePosition() {
  const step = currentStep.value;
  if (!step) return;

  const el = document.querySelector(step.targetSelector);
  if (!el) {
    rect.value = { top: 0, left: 0, right: 0, bottom: 0, width: 0, height: 0 };
    return;
  }

  const r = el.getBoundingClientRect();
  rect.value = {
    top: r.top,
    left: r.left,
    right: r.right,
    bottom: r.bottom,
    width: r.width,
    height: r.height,
  };

  nextTick(() => {
    computeCardPosition(step.placement || 'bottom');
  });
}

function computeCardPosition(placement: Placement) {
  const card = cardRef.value;
  const vw = window.innerWidth;
  const vh = window.innerHeight;
  const cardWidth = card?.offsetWidth ?? 280;
  const cardHeight = card?.offsetHeight ?? 140;
  const gap = 12;
  const pad = 16;

  let top = 0;
  let left = 0;

  switch (placement) {
    case 'top':
      top = rect.value.top - cardHeight - gap;
      left = rect.value.left + rect.value.width / 2 - cardWidth / 2;
      break;
    case 'bottom':
      top = rect.value.bottom + gap;
      left = rect.value.left + rect.value.width / 2 - cardWidth / 2;
      break;
    case 'left':
      top = rect.value.top + rect.value.height / 2 - cardHeight / 2;
      left = rect.value.left - cardWidth - gap;
      break;
    case 'right':
      top = rect.value.top + rect.value.height / 2 - cardHeight / 2;
      left = rect.value.right + gap;
      break;
  }

  if (left < pad) left = pad;
  if (left + cardWidth > vw - pad) left = vw - cardWidth - pad;
  if (top < pad) top = pad;
  if (top + cardHeight > vh - pad) top = vh - cardHeight - pad;

  cardPos.value = { top, left };
}

function handleNext() {
  if (isLastStep.value) {
    props.onFinish?.();
    currentIndex.value = 0;
    return;
  }
  currentIndex.value++;
}

function handleSkip() {
  props.onSkip?.();
  currentIndex.value = 0;
}

function onResize() {
  updatePosition();
}

watch(currentIndex, updatePosition, { immediate: true });

onMounted(() => {
  window.addEventListener('resize', onResize);
});

onUnmounted(() => {
  window.removeEventListener('resize', onResize);
});
</script>

<style scoped>
.tour-overlay {
  position: fixed;
  inset: 0;
  z-index: 900;
  pointer-events: none;
}

.tour-mask {
  position: fixed;
  background: var(--backdrop);
  pointer-events: auto;
}

.tour-mask-top {
  top: 0;
  left: 0;
  right: 0;
}

.tour-mask-bottom {
  left: 0;
  right: 0;
  bottom: 0;
}

.tour-mask-left {
  left: 0;
}

.tour-mask-right {
  right: 0;
}

.tour-highlight {
  position: fixed;
  z-index: 901;
  pointer-events: none;
  box-shadow: inset 0 0 0 2px var(--accent);
  border-radius: var(--radius-sm);
}

.tour-card {
  position: fixed;
  z-index: 902;
  min-width: 260px;
  max-width: 320px;
  background: var(--bg-primary);
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  padding: var(--space-6);
  box-shadow: var(--shadow-lg);
  pointer-events: auto;
}

.tour-card__header {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  margin-bottom: var(--space-4);
}

.tour-card__step {
  font-size: var(--font-xs);
  color: var(--accent);
  font-weight: 600;
  background: var(--accent-dim);
  padding: 2px 6px;
  border-radius: var(--radius-xs);
  white-space: nowrap;
}

.tour-card__title {
  font-size: var(--font-lg);
  font-weight: 600;
  color: var(--text-primary);
  margin: 0;
  line-height: 1.4;
}

.tour-card__content {
  font-size: var(--font-sm);
  color: var(--text-secondary);
  line-height: 1.6;
  margin: 0 0 var(--space-6) 0;
}

.tour-card__footer {
  display: flex;
  justify-content: flex-end;
  gap: var(--space-4);
}
</style>
