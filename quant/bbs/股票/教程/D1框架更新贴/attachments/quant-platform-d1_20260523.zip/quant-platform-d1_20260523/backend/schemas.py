# -*- coding: utf-8 -*-
"""Pydantic request models for workflow endpoints."""
from typing import Optional

from pydantic import BaseModel


class CreateWorkflowReq(BaseModel):
    name: str
    description: str = ""
    category: Optional[str] = ""
    steps: Optional[list] = []
    script: Optional[str] = ""
    conda_env: Optional[str] = "quantpy312"


class SaveWorkflowReq(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    category: Optional[str] = None
    steps: Optional[list] = None
    script: Optional[str] = None
    conda_env: Optional[str] = None


class RunWorkflowReq(BaseModel):
    start_from_step: Optional[int] = None
    step_params: Optional[dict] = None
