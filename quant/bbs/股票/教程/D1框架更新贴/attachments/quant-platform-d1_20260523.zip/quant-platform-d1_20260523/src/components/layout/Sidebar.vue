<template>
  <div class="sidebar">
    <div class="sidebar-logo">
      <div class="sidebar-logo-icon">
        <span class="sidebar-logo-mark">D1</span>
      </div>
      <div class="sidebar-logo-text">
        <span class="sidebar-logo-title">Quant</span>
        <span class="sidebar-logo-sub">Platform</span>
      </div>
    </div>
    <nav class="sidebar-nav">
      <router-link
        v-for="item in menuItems"
        :key="item.path"
        :to="item.path"
        class="nav-item"
        :class="{ 'nav-item--active': isActive(item.path) }"
      >
        <el-icon class="nav-icon">
          <component :is="item.icon" />
        </el-icon>
        <span class="nav-label">{{ item.title }}</span>
        <div class="nav-indicator" />
      </router-link>
    </nav>
    <div class="sidebar-footer">
      <div class="sidebar-footer-dot" />
      <div class="sidebar-footer-text">
        v1.0.0
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router';

const route = useRoute();

const menuItems = [
  { path: '/workflow', title: '工作流', icon: 'VideoPlay' },
  { path: '/backtest', title: '回测分析', icon: 'TrendCharts' },
  { path: '/builder', title: '构建器', icon: 'SetUp' },
  { path: '/library', title: '策略库', icon: 'Document' },
  { path: '/terminal', title: '终端', icon: 'Monitor' },
  { path: '/settings', title: '设置', icon: 'Setting' },
];

function isActive(path: string): boolean {
  return route.path === path || route.path.startsWith(path + '/');
}
</script>

<style scoped>
.sidebar {
  width: var(--sidebar-w, 220px);
  height: 100%;
  background: var(--bg-secondary);
  border-right: 1px solid var(--border-color);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.sidebar-logo {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: 18px var(--sidebar-padding);
  border-bottom: 1px solid var(--border-color);
  flex-shrink: 0;
}

.sidebar-logo-icon {
  width: 34px;
  height: 34px;
  border-radius: 10px;
  background: linear-gradient(135deg, var(--accent), var(--accent-hover));
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
  box-shadow: 0 2px 8px var(--accent-light);
}

.sidebar-logo-mark {
  font-size: 15px;
  font-weight: 800;
  color: #fff;
  letter-spacing: 1.5px;
  line-height: 1;
  text-shadow: 0 1px 2px rgba(0, 0, 0, 0.15);
}

.sidebar-logo-text {
  display: flex;
  flex-direction: column;
  gap: 0;
}

.sidebar-logo-title {
  font-size: var(--font-lg);
  font-weight: 700;
  color: var(--text-primary);
  line-height: 1.2;
  letter-spacing: -0.3px;
}

.sidebar-logo-sub {
  font-size: var(--font-2xs);
  color: var(--text-muted);
  line-height: 1.2;
  text-transform: uppercase;
  letter-spacing: 1.2px;
}

.sidebar-nav {
  flex: 1;
  padding: 10px calc(var(--sidebar-padding) - 6px);
  display: flex;
  flex-direction: column;
  gap: 2px;
  overflow-y: auto;
}

.nav-item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 9px 12px;
  border-radius: var(--radius);
  color: var(--text-secondary);
  text-decoration: none;
  font-size: var(--font-base);
  font-weight: 500;
  position: relative;
  transition: background-color var(--transition), color var(--transition);
}

.nav-item:hover {
  background: var(--bg-hover);
  color: var(--text-primary);
}

.nav-item--active {
  background: var(--accent-dim);
  color: var(--accent);
}

.nav-indicator {
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%) scaleY(0);
  width: 3px;
  height: 18px;
  background: var(--accent);
  border-radius: 0 2px 2px 0;
  transition: transform var(--transition-bounce);
}

.nav-item--active .nav-indicator {
  transform: translateY(-50%) scaleY(1);
}

.nav-icon {
  font-size: 16px;
  flex-shrink: 0;
  width: 18px;
}

.nav-label {
  flex: 1;
}

.sidebar-footer {
  padding: 12px var(--sidebar-padding);
  border-top: 1px solid var(--border-color);
  flex-shrink: 0;
  display: flex;
  align-items: center;
  gap: 8px;
}

.sidebar-footer-dot {
  width: 6px;
  height: 6px;
  border-radius: 50%;
  background: var(--success);
}

.sidebar-footer-text {
  font-size: var(--font-xs);
  color: var(--text-muted);
  font-family: var(--font-mono);
}

@media (max-width: 1023px) {
  .sidebar-logo-text {
    display: none;
  }
  .sidebar-logo {
    justify-content: center;
    padding: 18px 8px;
  }
  .nav-label {
    display: none;
  }
  .nav-item {
    justify-content: center;
    padding: 9px;
  }
  .sidebar-footer-text {
    display: none;
  }
  .sidebar-footer {
    justify-content: center;
    padding: 12px 8px;
  }
}

@media (max-width: 767px) {
  .sidebar {
    display: none;
  }
}
</style>
