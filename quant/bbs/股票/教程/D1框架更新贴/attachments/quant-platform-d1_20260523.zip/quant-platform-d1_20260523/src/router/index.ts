import type { RouteRecordRaw } from 'vue-router';
import { createRouter, createWebHistory } from 'vue-router';
import { setupRouterGuards } from './guards';

export const routes: RouteRecordRaw[] = [
  {
    path: '/',
    redirect: '/workflow',
  },
  {
    path: '/workflow',
    name: 'Workflow',
    component: () => import(/* webpackPrefetch: true */ '@/pages/workflow/WorkflowPage.vue'),
    meta: {
      title: '工作流',
    },
  },
  {
    path: '/backtest',
    name: 'Backtest',
    component: () => import(/* webpackPrefetch: true */ '@/pages/backtest/BacktestPage.vue'),
    meta: {
      title: '回测分析',
    },
  },
  {
    path: '/builder',
    name: 'Builder',
    component: () => import('@/pages/builder/BuilderPage.vue'),
    meta: {
      title: '构建器',
    },
  },
  {
    path: '/library',
    name: 'Library',
    component: () => import('@/pages/library/LibraryPage.vue'),
    meta: {
      title: '策略库',
    },
  },
  {
    path: '/settings',
    name: 'Settings',
    component: () => import('@/pages/settings/SettingsPage.vue'),
    meta: {
      title: '设置',
    },
  },
  {
    path: '/terminal',
    name: 'Terminal',
    component: () => import('@/pages/terminal/TerminalPage.vue'),
    meta: {
      title: '终端',
    },
  },
  {
    path: '/:pathMatch(.*)*',
    redirect: '/workflow',
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

setupRouterGuards(router);

export default router;
