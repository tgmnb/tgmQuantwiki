import { createApp } from 'vue';
import { createPinia } from 'pinia';
// Element Plus 通过 unplugin-vue-components 自动按需导入，无需全量注册
import { ElMessage } from 'element-plus';
import * as ElementPlusIconsVue from '@element-plus/icons-vue';
import App from './App.vue';
import router from './router';
import './assets/styles/variables.css';
import './assets/styles/global.css';
import { setErrorHandler, ApiError } from './api/request';
import { useUIStore } from './stores/ui';

const app = createApp(App);

// 图标全局注册（ElementPlusResolver 不处理 icons）
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component);
}

const pinia = createPinia();
app.use(pinia);
app.use(router);

// 注入 API 错误处理器（解耦 ElMessage）
setErrorHandler((msg: string) => ElMessage.error(msg));

// 全局错误处理（Vue 异步错误和未捕获的 Promise 拒绝）
app.config.errorHandler = (err, _instance, _info) => {
  console.error('[Vue Error]', err);
  if (err instanceof ApiError) {
    ElMessage.error(err.message);
  } else if (err instanceof Error) {
    ElMessage.error(err.message || 'An unexpected error occurred');
  }
};

// 监听未捕获的 Promise 拒绝
window.addEventListener('unhandledrejection', (event) => {
  console.error('[Unhandled Rejection]', event.reason);
  if (event.reason instanceof ApiError) {
    ElMessage.error(event.reason.message);
  } else if (event.reason instanceof Error) {
    ElMessage.error(event.reason.message || 'An unexpected error occurred');
  }
});

// 初始化主题（从 localStorage 恢复）
const uiStore = useUIStore();
uiStore.initTheme();

app.mount('#app');
