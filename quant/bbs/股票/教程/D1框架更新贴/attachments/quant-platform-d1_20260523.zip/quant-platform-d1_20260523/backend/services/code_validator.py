"""
D1 Quant Platform — 代码安全校验

校验 LLM 生成的代码是否包含危险操作。
"""

from __future__ import annotations

import re


# 危险模式：不允许出现在 LLM 生成的代码中
DANGEROUS_PATTERNS = [
    (r"os\.system\s*\(", "os.system() 禁止"),
    (r"subprocess\.(call|run|Popen)\s*\(", "subprocess 禁止"),
    (r"__import__\s*\(", "__import__ 禁止"),
    (r"\beval\s*\(", "eval() 禁止"),
    (r"\bexec\s*\(", "exec() 禁止"),
    (r"shutil\.rmtree", "shutil.rmtree 禁止"),
    (r"os\.remove\s*\(", "os.remove() 禁止"),
    (r"open\s*\([^)]*[\"']w", "文件写入需通过平台工具"),
]

# 最大文件大小限制（1MB）
MAX_FILE_SIZE = 1 * 1024 * 1024


def validate_generated_code(code: str) -> tuple[bool, str]:
    """
    校验 LLM 生成的代码安全性。

    Returns:
        (is_safe, reason) — 安全返回 (True, "")，不安全返回 (False, 原因)
    """
    for pattern, reason in DANGEROUS_PATTERNS:
        if re.search(pattern, code):
            return False, f"危险操作: {reason}"

    return True, ""


def validate_file_size(content: str) -> tuple[bool, str]:
    """校验文件大小是否在限制内。"""
    if len(content.encode("utf-8")) > MAX_FILE_SIZE:
        return False, f"文件过大: {len(content.encode('utf-8'))} bytes (限制 {MAX_FILE_SIZE} bytes)"
    return True, ""
