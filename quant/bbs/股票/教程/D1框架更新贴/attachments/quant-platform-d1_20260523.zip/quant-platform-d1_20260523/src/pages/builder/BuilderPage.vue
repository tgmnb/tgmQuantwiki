<template>
  <div class="builder-layout">
    <!-- Left Sidebar -->
    <div class="builder-sidebar">
      <div class="builder-sidebar__header">
        <div class="builder-sidebar__title-row">
          <span class="builder-sidebar__title">策略工作台</span>
          <div class="builder-sidebar__actions">
            <el-button
              size="small"
              text
              @click="showCreate = true; createName = ''; createType = 'stock_daily';"
            >
              <el-icon><Plus /></el-icon>
            </el-button>
            <el-button
              size="small"
              text
              @click="builder.loadStrategies()"
            >
              <el-icon><RefreshRight /></el-icon>
            </el-button>
          </div>
        </div>
        <div class="builder-sidebar__count">
          {{ builder.strategies.length }} 个策略
        </div>
      </div>

      <div class="builder-sidebar__search">
        <el-input
          v-model="strategySearch"
          size="small"
          placeholder="搜索策略..."
          clearable
          :prefix-icon="Search"
        />
      </div>

      <div class="builder-sidebar__body">
        <div
          v-for="([type, items]) in groupedStrategies"
          :key="type"
          class="strategy-group"
        >
          <div
            class="group-header"
            @click="toggleGroup(type)"
          >
            <el-icon
              class="group-arrow"
              :style="{ transform: expandedGroups[type] ? 'rotate(90deg)' : '' }"
            >
              <ArrowRight />
            </el-icon>
            <span class="group-name">{{ typeLabel(type) }}</span>
            <span class="group-count">{{ items.length }}</span>
          </div>
          <el-collapse-transition>
            <div
              v-show="expandedGroups[type]"
              class="group-items"
            >
              <div
                v-for="s in items"
                :key="s.path"
                class="strategy-item"
                :class="{ 'strategy-item--active': builder.currentStrategy?.path === s.path }"
                @click="builder.selectStrategy(s)"
              >
                <div class="strategy-item__main">
                  <el-icon class="strategy-item__icon">
                    <Document />
                  </el-icon>
                  <span class="strategy-item__name">{{ s.name || s.path }}</span>
                </div>
                <div class="strategy-item__actions">
                  <el-button
                    size="small"
                    text
                    type="danger"
                    title="删除"
                    @click.stop="deleteStrategy(s)"
                  >
                    <el-icon><Delete /></el-icon>
                  </el-button>
                </div>
              </div>
            </div>
          </el-collapse-transition>
        </div>
        <div
          v-if="groupedStrategies.length === 0"
          class="empty-hint"
        >
          <el-icon :size="24">
            <Search />
          </el-icon>
          <span>{{ strategySearch ? '无匹配策略' : '暂无策略' }}</span>
        </div>
      </div>
    </div>

    <!-- Main Content -->
    <div class="builder-main">
      <!-- Editor Tabs -->
      <div class="editor-tabs">
        <div class="editor-tabs__left">
          <div
            class="editor-tab"
            :class="{ 'editor-tab--active': builder.mode === 'visual' }"
            @click="builder.mode = 'visual'"
          >
            <el-icon><SetUp /></el-icon>
            <span>可视化构建</span>
          </div>
          <div
            class="editor-tab"
            :class="{ 'editor-tab--active': builder.mode === 'code' }"
            @click="builder.mode = 'code'"
          >
            <el-icon><DocumentChecked /></el-icon>
            <span>代码编辑</span>
          </div>
        </div>
        <div
          v-if="builder.currentStrategy"
          class="editor-tabs__right"
        >
          <el-tag
            size="small"
            :type="builder.currentStrategy.type === 'stock_1h' ? 'warning' : 'info'"
            effect="plain"
          >
            {{ typeLabel(builder.currentStrategy.type || '') }}
          </el-tag>
          <span class="strategy-name">{{ builder.currentStrategy.name }}</span>
        </div>
      </div>

      <!-- Content Area -->
      <div class="builder-content">
        <div
          v-if="!builder.currentStrategy"
          class="empty-workspace"
        >
          <EmptyState title="选择左侧策略开始构建" />
        </div>
        <template v-else>
          <VisualMode
            v-show="builder.mode === 'visual'"
            :is-new="builder.isNew"
            :selected-strategy="builder.currentStrategy"
            :strategy-name="builder.strategyName"
            :backtest-type="builder.backtestType"
            :modules="builder.modules"
            :selected-selection="builder.selectedSelection"
            :selected-timing="builder.selectedTiming"
            :selected-risk="builder.selectedRisk"
            :step="builder.visualStep"
            :loading-modules="builder.loadingModules"
            :strategy-params="builder.strategyParams"
            @prev="builder.wizardPrev()"
            @next="builder.wizardNext()"
            @goto="(s: number) => builder.wizardGoto(s)"
            @save="onSaveStrategy"
            @edit="builder.startEdit()"
            @cancel="builder.cancelEdit()"
            @update:strategy-name="(v: string) => builder.strategyName = v"
            @update:backtest-type="(v) => builder.setBacktestType(v)"
            @update:strategy-params="(v) => builder.strategyParams = v"
            @select:selection="(it: any) => builder.selectedSelection = it === null ? null : (builder.selectedSelection?.name === it.name ? null : it)"
            @select:timing="(it: any) => builder.selectedTiming = it === null ? null : (builder.selectedTiming?.name === it.name ? null : it)"
            @select:risk="(it: any) => builder.selectedRisk = it === null ? null : (builder.selectedRisk?.name === it.name ? null : it)"
          />
          <CodeMode
            v-show="builder.mode === 'code'"
            :selected-strategy="builder.currentStrategy"
            :backtest-type="builder.backtestType"
            :config-save-version="builder.configSaveVersion"
            @select-strategy="(s: any) => builder.selectStrategy(s)"
            @switch:mode="(m: BuilderMode) => builder.mode = m"
          />
        </template>
      </div>

      <!-- Create Dialog -->
      <el-dialog
        v-model="showCreate"
        title="新建策略"
        width="400px"
        destroy-on-close
      >
        <el-form
          label-position="top"
          @submit.prevent="createStrategy"
        >
          <el-form-item label="策略名称">
            <el-input
              v-model="createName"
              placeholder="输入策略名称"
              clearable
            />
            <div class="form-hint">
              仅限字母、数字、下划线、连字符
            </div>
          </el-form-item>
          <el-form-item label="回测类型">
            <el-radio-group v-model="createType">
              <el-radio-button value="stock_daily">
                股票日频
              </el-radio-button>
              <el-radio-button value="stock_1h">
                股票小时频
              </el-radio-button>
            </el-radio-group>
          </el-form-item>
        </el-form>
        <template #footer>
          <el-button @click="showCreate = false">
            取消
          </el-button>
          <el-button
            type="primary"
            :loading="creating"
            :disabled="!createName.trim()"
            @click="createStrategy"
          >
            创建
          </el-button>
        </template>
      </el-dialog>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import {
  Plus, RefreshRight, Search, Document, Delete,
  SetUp, DocumentChecked, ArrowRight,
} from '@element-plus/icons-vue';
import { useBuilderStore } from '@/stores/builder';
import { builderApi } from '@/api/builder';
import VisualMode from './VisualMode.vue';
import CodeMode from './CodeMode.vue';

type BuilderMode = 'visual' | 'code';

const builder = useBuilderStore();

const strategySearch = ref('');
const expandedGroups = ref<Record<string, boolean>>({});
const showCreate = ref(false);
const createName = ref('');
const createType = ref('stock_daily');
const creating = ref(false);

const BACKTEST_TYPES = [
  { id: 'stock_daily', label: '股票日频', desc: '基于日线数据的全市场扫描' },
  { id: 'stock_1h', label: '股票小时频', desc: '基于小时线数据的交易策略' },
];

function typeLabel(type: string): string {
  return BACKTEST_TYPES.find(t => t.id === type)?.label || type;
}

const groupedStrategies = computed(() => {
  const map: Record<string, any[]> = {};
  for (const s of builder.strategies) {
    const type = s.type || 'other';
    if (!map[type]) map[type] = [];
    const q = strategySearch.value.toLowerCase();
    if (!q || (s.name || '').toLowerCase().includes(q)) map[type].push(s);
  }
  return Object.entries(map).filter(([, items]) => items.length > 0);
});

onMounted(async () => {
  await builder.loadStrategies();
  const types = [...new Set(builder.strategies.map((s: any) => s.type || 'other'))];
  if (types.length > 0) expandedGroups.value = { [types[0]]: true };
});

function toggleGroup(type: string) {
  expandedGroups.value[type] = !expandedGroups.value[type];
}

async function deleteStrategy(strategy: any) {
  try {
    await ElMessageBox.confirm(
      `确定要删除策略「${strategy.name}」吗？此操作不可恢复。`,
      '删除确认',
      { confirmButtonText: '删除', cancelButtonText: '取消', type: 'warning' }
    );
  } catch { return; }
  try {
    const name = strategy.name.replace(/^\[账户\]\s*/, '');
    await builderApi.deleteStrategy(name, strategy.type);
    if (builder.currentStrategy?.path === strategy.path) {
      builder.selectStrategy(null);
    }
    await builder.loadStrategies();
    ElMessage.success('策略已删除');
  } catch (e: any) {
    ElMessage.error('删除失败: ' + (e.message || e));
  }
}

async function createStrategy() {
  if (!createName.value.trim()) return;
  creating.value = true;
  try {
    await builder.startNewStrategy(createName.value.trim(), createType.value);
    expandedGroups.value[createType.value] = true;
    showCreate.value = false;
    createName.value = '';
  } catch (e: any) {
    ElMessage.error('创建失败: ' + (e.message || e));
  } finally {
    creating.value = false;
  }
}

async function onSaveStrategy() {
  try {
    await builder.saveStrategy();
    builder.isNew = false; // 保存后退出 wizard，回到查看模式
    ElMessage.success('策略配置已保存');
  } catch (e: any) {
    ElMessage.error('保存失败: ' + (e.message || e));
  }
}
</script>

<style scoped>
.builder-layout {
  display: flex;
  height: 100%;
  overflow: hidden;
}

/* Sidebar */
.builder-sidebar {
  width: 260px;
  flex-shrink: 0;
  border-right: 1px solid var(--border-color);
  background: var(--bg-secondary);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}
.builder-sidebar__header {
  padding: var(--space-5) var(--space-6) var(--space-3);
  border-bottom: 1px solid var(--border-subtle);
  flex-shrink: 0;
}
.builder-sidebar__title-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.builder-sidebar__title {
  font-size: var(--font-base);
  font-weight: 600;
  color: var(--text-primary);
}
.builder-sidebar__actions {
  display: flex;
  gap: 2px;
}
.builder-sidebar__count {
  font-size: var(--font-xs);
  color: var(--text-muted);
  margin-top: var(--space-1);
}
.builder-sidebar__search {
  padding: var(--space-3) var(--space-5);
  border-bottom: 1px solid var(--border-subtle);
  flex-shrink: 0;
}
.builder-sidebar__body {
  flex: 1;
  overflow-y: auto;
  padding: var(--space-1);
}

/* Strategy Group */
.strategy-group {
  margin-bottom: 2px;
}
.group-header {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  padding: 5px 8px;
  font-size: var(--font-xs);
  font-weight: 600;
  color: var(--text-muted);
  cursor: pointer;
  user-select: none;
  border-radius: var(--radius);
  transition: background 0.15s;
}
.group-header:hover {
  background: var(--bg-hover);
  color: var(--text-secondary);
}
.group-arrow {
  font-size: var(--font-sm);
  transition: transform 0.2s;
  flex-shrink: 0;
}
.group-name {
  flex: 1;
}
.group-count {
  font-weight: 400;
  opacity: 0.6;
  font-size: var(--font-2xs);
}

/* Strategy Item */
.group-items {
  padding-left: var(--space-1);
}
.strategy-item {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 5px 8px;
  margin: 1px 0;
  border-radius: var(--radius);
  cursor: pointer;
  transition: all 0.15s;
  border: 1px solid transparent;
}
.strategy-item:hover {
  background: var(--bg-hover);
  border-color: var(--border);
}
.strategy-item--active {
  background: var(--bg-active);
  border-color: var(--accent);
  color: var(--accent);
}
.strategy-item__main {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  min-width: 0;
  flex: 1;
}
.strategy-item__icon {
  font-size: var(--font-base);
  color: var(--text-muted);
  flex-shrink: 0;
}
.strategy-item--active .strategy-item__icon {
  color: var(--accent);
}
.strategy-item__name {
  font-size: var(--font-sm);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.strategy-item__actions {
  display: flex;
  gap: 0;
  opacity: 0;
  transition: opacity 0.15s;
}
.strategy-item:hover .strategy-item__actions {
  opacity: 1;
}

/* Empty */
.empty-hint {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-3);
  padding: 40px 12px;
  color: var(--text-muted);
  font-size: var(--font-sm);
}

/* Main */
.builder-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* Editor Tabs */
.editor-tabs {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 0 12px;
  height: var(--h-lg);
  border-bottom: 1px solid var(--border-color);
  background: var(--bg-secondary);
  flex-shrink: 0;
  gap: var(--space-3);
}
.editor-tabs__left {
  display: flex;
  gap: 2px;
}
.editor-tab {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  padding: var(--space-1) var(--space-5);
  font-size: var(--font-sm);
  color: var(--text-muted);
  cursor: pointer;
  border-radius: var(--radius);
  border: 1px solid transparent;
  transition: all 0.15s;
  user-select: none;
}
.editor-tab:hover {
  color: var(--text-primary);
  background: var(--bg-hover);
}
.editor-tab--active {
  color: var(--accent);
  background: var(--bg-active);
  border-color: var(--accent);
  font-weight: 500;
}
.editor-tabs__right {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}
.editor-tabs__right .strategy-name {
  font-size: var(--font-sm);
  color: var(--text-primary);
  font-weight: 500;
}

/* Content */
.builder-content {
  flex: 1;
  overflow: hidden;
  position: relative;
}

/* Form hint */
.form-hint {
  font-size: var(--font-xs);
  color: var(--text-muted);
  margin-top: var(--space-1);
}
</style>
