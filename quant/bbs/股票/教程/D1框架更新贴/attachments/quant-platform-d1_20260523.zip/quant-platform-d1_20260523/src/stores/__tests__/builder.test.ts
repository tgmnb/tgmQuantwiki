import { describe, it, expect, beforeEach, vi } from 'vitest';
import { createPinia, setActivePinia } from 'pinia';
import { useBuilderStore } from '../builder';
import { builderApi } from '@/api/builder';

vi.mock('@/api/builder', () => ({
  builderApi: {
    listStrategies: vi.fn(),
    createStrategy: vi.fn(),
    getModules: vi.fn(),
    getStrategyConfig: vi.fn(),
    saveStrategyConfig: vi.fn(),
  },
}));

describe('Builder Store', () => {
  beforeEach(() => {
    setActivePinia(createPinia());
    vi.clearAllMocks();
  });

  it('should initialize with default state', () => {
    const store = useBuilderStore();
    expect(store.strategies).toEqual([]);
    expect(store.currentStrategy).toBeNull();
    expect(store.loading).toBe(false);
    expect(store.isNew).toBe(false);
    expect(store.visualStep).toBe(1);
    expect(store.modules.selections).toEqual([]);
    expect(store.modules.timing?.timing).toEqual([]);
    expect(store.modules.timing?.risk).toEqual([]);
  });

  it('should load strategies', async () => {
    const mockStrategies = [
      { name: 's1', path: 'p1', base: 'b1', group: 'g1' },
    ];
    (builderApi.listStrategies as any).mockResolvedValue({
      strategies: mockStrategies,
    });

    const store = useBuilderStore();
    await store.loadStrategies();

    expect(builderApi.listStrategies).toHaveBeenCalled();
    expect(store.strategies).toEqual(mockStrategies);
    expect(store.loading).toBe(false);
  });

  it('should start new strategy and load modules', async () => {
    const mockModules = {
      selections: [{ name: 'ma', description: 'MA' }],
      timing: { timing: [{ name: 'dma' }], risk: [{ name: 'stop_loss' }] },
    };
    (builderApi.createStrategy as any).mockResolvedValue({ success: true });
    (builderApi.listStrategies as any).mockResolvedValue({
      strategies: [{ name: 'new', path: 'new', base: 'b', group: 'g', type: 'stock_daily' }],
    });
    (builderApi.getModules as any).mockResolvedValue(mockModules);

    const store = useBuilderStore();
    await store.startNewStrategy('new', 'stock_daily');

    expect(store.isNew).toBe(true);
    expect(store.visualStep).toBe(1);
    expect(store.modules.selections).toEqual(mockModules.selections);
    expect(store.modules.timing?.risk).toEqual(mockModules.timing.risk);
  });

  it('should throw when created strategy not found in list', async () => {
    (builderApi.createStrategy as any).mockResolvedValue({ success: true });
    (builderApi.listStrategies as any).mockResolvedValue({ strategies: [] });

    const store = useBuilderStore();
    await expect(store.startNewStrategy('missing', 'stock_daily'))
      .rejects.toThrow('策略创建成功但列表中未找到');
  });
});
