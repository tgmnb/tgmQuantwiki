<template>
  <div class="visual-mode">
    <!-- ── 查看模式：已有策略 ─────────────────────────────── -->
    <template v-if="!isNew">
      <div class="view-mode">
        <!-- 策略信息头 -->
        <div class="view-header">
          <div class="view-header__left">
            <div class="view-header__name">
              {{ props.strategyName }}
            </div>
            <el-tag
              size="small"
              effect="plain"
            >
              {{ typeLabel }}
            </el-tag>
          </div>
          <div class="view-header__actions">
            <el-button
              type="primary"
              @click="emit('edit')"
            >
              <el-icon><EditPen /></el-icon>
              编辑策略
            </el-button>
          </div>
        </div>

        <!-- 模块配置摘要 -->
        <el-scrollbar>
          <div class="view-body">
            <div class="config-summary">
              <!-- 选股 -->
              <div
                class="summary-item"
                :class="{ 'summary-item--empty': !props.selectedSelection }"
              >
                <div class="summary-item__icon">
                  <el-icon :size="16">
                    <Search />
                  </el-icon>
                </div>
                <div class="summary-item__content">
                  <div class="summary-item__label">
                    选股模块
                  </div>
                  <template v-if="props.selectedSelection">
                    <div class="summary-item__name">
                      {{ props.selectedSelection.name }}
                    </div>
                    <div
                      v-if="props.selectedSelection.description"
                      class="summary-item__desc"
                    >
                      {{ props.selectedSelection.description }}
                    </div>
                  </template>
                  <span
                    v-else
                    class="summary-item__empty"
                  >未配置</span>
                </div>
              </div>

              <!-- 择时 -->
              <div
                class="summary-item"
                :class="{ 'summary-item--empty': !props.selectedTiming }"
              >
                <div class="summary-item__icon">
                  <el-icon :size="16">
                    <Timer />
                  </el-icon>
                </div>
                <div class="summary-item__content">
                  <div class="summary-item__label">
                    择时模块
                  </div>
                  <template v-if="props.selectedTiming">
                    <div class="summary-item__name">
                      {{ props.selectedTiming.name }}
                    </div>
                    <div
                      v-if="props.selectedTiming.description"
                      class="summary-item__desc"
                    >
                      {{ props.selectedTiming.description }}
                    </div>
                  </template>
                  <span
                    v-else
                    class="summary-item__empty"
                  >未配置</span>
                </div>
              </div>

              <!-- 风控 -->
              <div
                class="summary-item"
                :class="{ 'summary-item--empty': !props.selectedRisk }"
              >
                <div class="summary-item__icon">
                  <el-icon :size="16">
                    <Warning />
                  </el-icon>
                </div>
                <div class="summary-item__content">
                  <div class="summary-item__label">
                    风控模块
                  </div>
                  <template v-if="props.selectedRisk">
                    <div class="summary-item__name">
                      {{ props.selectedRisk.name }}
                    </div>
                    <div
                      v-if="props.selectedRisk.description"
                      class="summary-item__desc"
                    >
                      {{ props.selectedRisk.description }}
                    </div>
                  </template>
                  <span
                    v-else
                    class="summary-item__empty"
                  >未配置</span>
                </div>
              </div>

              <!-- 策略参数 -->
              <div class="summary-item">
                <div class="summary-item__icon">
                  <el-icon :size="16">
                    <TrendCharts />
                  </el-icon>
                </div>
                <div class="summary-item__content">
                  <div class="summary-item__label">
                    策略参数
                  </div>
                  <div class="param-summary-grid">
                    <div class="param-chip">
                      每日最大买入 <strong>{{ props.strategyParams.day_buy_num_max }}</strong>
                    </div>
                    <template v-if="props.backtestType === 'stock_daily'">
                      <div class="param-chip">
                        资金份数 <strong>{{ props.strategyParams.cap_amount }}</strong>
                      </div>
                      <div class="param-chip">
                        持股周期 <strong>{{ props.strategyParams.hold_period }}天</strong>
                      </div>
                      <div class="param-chip">
                        换仓时间 <strong>{{ props.strategyParams.swap_time }}</strong>
                      </div>
                      <div class="param-chip">
                        止盈 <strong>{{ props.strategyParams.stop_win?.is_open ? (props.strategyParams.stop_win.ratio * 100).toFixed(0) + '%' : '未启用' }}</strong>
                      </div>
                      <div class="param-chip">
                        止损 <strong>{{ props.strategyParams.stop_lose?.is_open ? (Math.abs(props.strategyParams.stop_lose.ratio) * 100).toFixed(0) + '%' : '未启用' }}</strong>
                      </div>
                      <div class="param-chip">
                        移动止盈 <strong>{{ props.strategyParams.moving_win?.is_open ? (props.strategyParams.moving_win.ratio * 100).toFixed(0) + '%' : '未启用' }}</strong>
                      </div>
                    </template>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </el-scrollbar>
      </div>
    </template>

    <!-- ── Wizard 模式：新策略 / 编辑 ───────────────────── -->
    <template v-else>
      <!-- Wizard Stepper -->
      <div class="wizard-stepper">
        <div
          v-for="(s, idx) in wizardSteps"
          :key="s.key"
          class="wizard-step"
          :class="{
            'wizard-step--active': props.step === s.step,
            'wizard-step--done': props.step > s.step,
            'wizard-step--pending': props.step < s.step,
          }"
          @click="onStepClick(s.step)"
        >
          <div class="wizard-step__indicator">
            <el-icon
              v-if="props.step > s.step"
              :size="14"
            >
              <Check />
            </el-icon>
            <span v-else>{{ s.step }}</span>
          </div>
          <span class="wizard-step__label">{{ s.label }}</span>
          <div
            v-if="idx < wizardSteps.length - 1"
            class="wizard-step__connector"
            :class="{ 'wizard-step__connector--done': props.step > s.step }"
          />
        </div>
      </div>

      <!-- Wizard Content -->
      <div class="wizard-content">
        <!-- Step 1: Basic Config -->
        <div
          v-show="props.step === 1"
          class="step-panel"
        >
          <el-scrollbar>
            <div class="step-panel__inner">
              <div class="step-panel__title">
                <el-icon :size="20">
                  <Setting />
                </el-icon>
                <span>基础配置</span>
              </div>
              <p class="step-panel__desc">
                设置策略名称和回测类型。
              </p>
              <el-card
                shadow="never"
                class="config-card"
              >
                <el-form label-position="top">
                  <el-form-item label="策略名称">
                    <el-input
                      :model-value="props.strategyName"
                      placeholder="例如: 小市值动量策略"
                      size="large"
                      disabled
                    />
                  </el-form-item>
                  <el-form-item label="回测类型">
                    <el-radio-group
                      :model-value="props.backtestType"
                      size="large"
                      @update:model-value="(v) => emit('update:backtestType', String(v))"
                    >
                      <el-radio-button
                        v-for="bt in BACKTEST_TYPES"
                        :key="bt.id"
                        :value="bt.id"
                      >
                        {{ bt.label }}
                      </el-radio-button>
                    </el-radio-group>
                    <div class="type-desc">
                      {{ BACKTEST_TYPES.find(t => t.id === props.backtestType)?.desc }}
                    </div>
                  </el-form-item>
                </el-form>
              </el-card>
            </div>
          </el-scrollbar>
        </div>

        <!-- Step 2: Selection Module -->
        <div
          v-show="props.step === 2"
          class="step-panel"
        >
          <el-scrollbar>
            <div class="step-panel__inner">
              <div class="step-panel__title">
                <el-icon :size="20">
                  <Search />
                </el-icon>
                <span>选股模块</span>
              </div>
              <p class="step-panel__desc">
                选择选股模块，系统将在每日收盘后按策略条件筛选股票池。
              </p>
              <div class="module-grid">
                <ModuleCard
                  v-for="m in props.modules.selections"
                  :key="m.name"
                  :module="m"
                  :is-selected="props.selectedSelection?.name === m.name"
                  @click="emit('select:selection', m)"
                />
              </div>
              <div
                v-if="!props.modules.selections?.length"
                class="empty-modules"
              >
                暂无可用选股模块
              </div>
            </div>
          </el-scrollbar>
        </div>

        <!-- Step 3: Timing & Risk Module -->
        <div
          v-show="props.step === 3"
          class="step-panel"
        >
          <el-scrollbar>
            <div class="step-panel__inner">
              <div class="step-panel__title">
                <el-icon :size="20">
                  <Timer />
                </el-icon>
                <span>择时与风控</span>
              </div>
              <p class="step-panel__desc">
                择时模块决定买入时机，风控模块在市场异常时自动平仓止损。
              </p>
              <div class="step-section">
                <div class="step-section__label">
                  <el-icon><ArrowRight /></el-icon>
                  择时模块
                </div>
                <div class="module-grid">
                  <ModuleCard
                    v-for="m in props.modules.timing?.timing"
                    :key="m.name"
                    :module="m"
                    :is-selected="props.selectedTiming?.name === m.name"
                    @click="emit('select:timing', m)"
                  />
                </div>
                <div
                  v-if="!props.modules.timing?.timing?.length"
                  class="empty-modules"
                >
                  暂无可用择时模块
                </div>
              </div>
              <div class="step-section">
                <div class="step-section__label">
                  <el-icon><Warning /></el-icon>
                  风控模块
                </div>
                <div class="module-grid">
                  <ModuleCard
                    v-for="m in props.modules.timing?.risk"
                    :key="m.name"
                    :module="m"
                    :is-selected="props.selectedRisk?.name === m.name"
                    @click="emit('select:risk', m)"
                  />
                </div>
                <div
                  v-if="!props.modules.timing?.risk?.length"
                  class="empty-modules"
                >
                  暂无可用风控模块
                </div>
              </div>
            </div>
          </el-scrollbar>
        </div>

        <!-- Step 4: Strategy Params -->
        <div
          v-show="props.step === 4"
          class="step-panel"
        >
          <el-scrollbar>
            <div class="step-panel__inner">
              <div class="step-panel__title">
                <el-icon :size="20">
                  <TrendCharts />
                </el-icon>
                <span>策略参数</span>
              </div>
              <p class="step-panel__desc">
                配置交易参数，包括买入数量、分仓、持股周期和止盈止损等。
              </p>
              <el-card
                shadow="never"
                class="config-card"
              >
                <el-form label-position="top">
                  <!-- 每日最大买入数 -->
                  <el-form-item label="每日最大买入数">
                    <el-input-number
                      :model-value="props.strategyParams.day_buy_num_max"
                      :min="1"
                      :max="50"
                      controls-position="right"
                      @update:model-value="updateParam('day_buy_num_max', $event)"
                    />
                  </el-form-item>

                  <!-- 日频专属参数 -->
                  <template v-if="props.backtestType === 'stock_daily'">
                    <el-form-item label="资金份数（分仓数）">
                      <el-input-number
                        :model-value="props.strategyParams.cap_amount"
                        :min="1"
                        :max="20"
                        controls-position="right"
                        @update:model-value="updateParam('cap_amount', $event)"
                      />
                    </el-form-item>
                    <el-form-item label="持股周期（天）">
                      <el-input-number
                        :model-value="props.strategyParams.hold_period"
                        :min="1"
                        :max="60"
                        controls-position="right"
                        @update:model-value="updateParam('hold_period', $event)"
                      />
                    </el-form-item>
                    <el-form-item label="换仓时间">
                      <el-input
                        :model-value="props.strategyParams.swap_time"
                        placeholder="例如: open-close"
                        @update:model-value="updateParam('swap_time', $event)"
                      />
                    </el-form-item>

                    <el-divider content-position="left">
                      止盈止损
                    </el-divider>

                    <el-form-item label="止盈">
                      <div class="stop-config-row">
                        <el-switch
                          :model-value="props.strategyParams.stop_win?.is_open"
                          @update:model-value="updateStopConfig('stop_win', 'is_open', $event)"
                        />
                        <el-input-number
                          v-if="props.strategyParams.stop_win?.is_open"
                          :model-value="props.strategyParams.stop_win?.ratio"
                          :min="0.01"
                          :max="1"
                          :step="0.01"
                          :precision="2"
                          controls-position="right"
                          @update:model-value="updateStopConfig('stop_win', 'ratio', $event)"
                        />
                        <span
                          v-if="props.strategyParams.stop_win?.is_open"
                          class="stop-config-label"
                        >（{{ (props.strategyParams.stop_win?.ratio * 100).toFixed(0) }}%）</span>
                      </div>
                    </el-form-item>
                    <el-form-item label="止损">
                      <div class="stop-config-row">
                        <el-switch
                          :model-value="props.strategyParams.stop_lose?.is_open"
                          @update:model-value="updateStopConfig('stop_lose', 'is_open', $event)"
                        />
                        <el-input-number
                          v-if="props.strategyParams.stop_lose?.is_open"
                          :model-value="props.strategyParams.stop_lose?.ratio"
                          :min="-1"
                          :max="-0.01"
                          :step="0.01"
                          :precision="2"
                          controls-position="right"
                          @update:model-value="updateStopConfig('stop_lose', 'ratio', $event)"
                        />
                        <span
                          v-if="props.strategyParams.stop_lose?.is_open"
                          class="stop-config-label"
                        >（{{ (Math.abs(props.strategyParams.stop_lose?.ratio) * 100).toFixed(0) }}%）</span>
                      </div>
                    </el-form-item>
                    <el-form-item label="移动止盈">
                      <div class="stop-config-row">
                        <el-switch
                          :model-value="props.strategyParams.moving_win?.is_open"
                          @update:model-value="updateStopConfig('moving_win', 'is_open', $event)"
                        />
                        <el-input-number
                          v-if="props.strategyParams.moving_win?.is_open"
                          :model-value="props.strategyParams.moving_win?.ratio"
                          :min="0.01"
                          :max="1"
                          :step="0.01"
                          :precision="2"
                          controls-position="right"
                          @update:model-value="updateStopConfig('moving_win', 'ratio', $event)"
                        />
                        <span
                          v-if="props.strategyParams.moving_win?.is_open"
                          class="stop-config-label"
                        >（{{ (props.strategyParams.moving_win?.ratio * 100).toFixed(0) }}%）</span>
                      </div>
                    </el-form-item>
                  </template>
                </el-form>
              </el-card>
            </div>
          </el-scrollbar>
        </div>

        <!-- Step 5: Confirm -->
        <div
          v-show="props.step === 5"
          class="step-panel"
        >
          <el-scrollbar>
            <div class="step-panel__inner">
              <div class="step-panel__title">
                <el-icon :size="20">
                  <CircleCheck />
                </el-icon>
                <span>构建完成</span>
              </div>
              <p class="step-panel__desc">
                确认策略配置无误后，点击保存将配置写入 stg_config.py。
              </p>
              <div class="confirm-card">
                <div class="confirm-row">
                  <span class="confirm-row__label">策略名称</span>
                  <span class="confirm-row__value">{{ props.strategyName || '—' }}</span>
                </div>
                <div class="confirm-row">
                  <span class="confirm-row__label">回测类型</span>
                  <el-tag
                    size="small"
                    effect="plain"
                  >
                    {{ typeLabel }}
                  </el-tag>
                </div>
                <el-divider />
                <div class="confirm-row">
                  <span class="confirm-row__label">
                    <el-icon><Search /></el-icon> 选股模块
                  </span>
                  <el-tag
                    v-if="props.selectedSelection?.name"
                    size="small"
                    type="success"
                  >
                    {{ props.selectedSelection.name }}
                  </el-tag>
                  <span
                    v-else
                    class="confirm-row__empty"
                  >未选择</span>
                </div>
                <div class="confirm-row">
                  <span class="confirm-row__label">
                    <el-icon><Timer /></el-icon> 择时模块
                  </span>
                  <el-tag
                    v-if="props.selectedTiming?.name"
                    size="small"
                    type="success"
                  >
                    {{ props.selectedTiming.name }}
                  </el-tag>
                  <span
                    v-else
                    class="confirm-row__empty"
                  >未选择</span>
                </div>
                <div class="confirm-row">
                  <span class="confirm-row__label">
                    <el-icon><Warning /></el-icon> 风控模块
                  </span>
                  <el-tag
                    v-if="props.selectedRisk?.name"
                    size="small"
                    type="success"
                  >
                    {{ props.selectedRisk.name }}
                  </el-tag>
                  <span
                    v-else
                    class="confirm-row__empty"
                  >未选择</span>
                </div>
                <el-divider />
                <div class="confirm-row">
                  <span class="confirm-row__label">
                    <el-icon><TrendCharts /></el-icon> 每日最大买入
                  </span>
                  <span class="confirm-row__value">{{ props.strategyParams.day_buy_num_max }}</span>
                </div>
                <template v-if="props.backtestType === 'stock_daily'">
                  <div class="confirm-row">
                    <span class="confirm-row__label">资金份数</span>
                    <span class="confirm-row__value">{{ props.strategyParams.cap_amount }}</span>
                  </div>
                  <div class="confirm-row">
                    <span class="confirm-row__label">持股周期</span>
                    <span class="confirm-row__value">{{ props.strategyParams.hold_period }} 天</span>
                  </div>
                  <div class="confirm-row">
                    <span class="confirm-row__label">换仓时间</span>
                    <span class="confirm-row__value">{{ swapTimeLabel }}</span>
                  </div>
                  <div class="confirm-row">
                    <span class="confirm-row__label">止盈</span>
                    <span class="confirm-row__value">
                      {{ props.strategyParams.stop_win?.is_open ? (props.strategyParams.stop_win.ratio * 100).toFixed(0) + '%' : '未启用' }}
                    </span>
                  </div>
                  <div class="confirm-row">
                    <span class="confirm-row__label">止损</span>
                    <span class="confirm-row__value">
                      {{ props.strategyParams.stop_lose?.is_open ? (Math.abs(props.strategyParams.stop_lose.ratio) * 100).toFixed(0) + '%' : '未启用' }}
                    </span>
                  </div>
                  <div class="confirm-row">
                    <span class="confirm-row__label">移动止盈</span>
                    <span class="confirm-row__value">
                      {{ props.strategyParams.moving_win?.is_open ? (props.strategyParams.moving_win.ratio * 100).toFixed(0) + '%' : '未启用' }}
                    </span>
                  </div>
                </template>
              </div>
            </div>
          </el-scrollbar>
        </div>
      </div>

      <!-- Wizard Footer -->
      <div class="wizard-footer">
        <div class="wizard-footer__left">
          <el-button @click="emit('cancel')">
            取消
          </el-button>
        </div>
        <div class="wizard-footer__nav">
          <el-button
            v-if="props.step > 1"
            @click="emit('prev')"
          >
            <el-icon><ArrowLeft /></el-icon>
            上一步
          </el-button>
          <el-button
            v-if="props.step < 5"
            type="primary"
            :disabled="props.loadingModules"
            @click="emit('next')"
          >
            {{ props.loadingModules ? '加载中...' : '下一步' }}
            <el-icon><ArrowRight /></el-icon>
          </el-button>
          <el-button
            v-if="props.step === 5"
            type="primary"
            @click="emit('save')"
          >
            <el-icon><FolderOpened /></el-icon>
            保存策略
          </el-button>
        </div>
      </div>
    </template>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import type { PropType } from 'vue';
import {
  Setting, Search, Timer, Warning,
  ArrowRight, ArrowLeft,
  Check, CircleCheck, FolderOpened, EditPen,
  TrendCharts,
} from '@element-plus/icons-vue';
import ModuleCard from './ModuleCard.vue';

interface Module { name: string; description?: string }
interface Modules { selections?: Module[]; timing?: { timing?: Module[]; risk?: Module[] } }

const props = defineProps({
  isNew: { type: Boolean, default: false },
  selectedStrategy: { type: Object as PropType<any>, default: null },
  strategyName: { type: String, default: '' },
  backtestType: { type: String, default: 'stock_daily' },
  modules: { type: Object as PropType<Modules>, default: () => ({}) },
  selectedSelection: { type: Object as PropType<Module | null>, default: null },
  selectedTiming: { type: Object as PropType<Module | null>, default: null },
  selectedRisk: { type: Object as PropType<Module | null>, default: null },
  step: { type: Number, required: true },
  loadingModules: { type: Boolean, default: false },
  strategyParams: { type: Object as PropType<any>, default: () => ({}) },
});

const emit = defineEmits([
  'select:selection', 'select:timing', 'select:risk',
  'prev', 'next', 'save', 'edit', 'cancel',
  'update:backtestType', 'goto',
  'update:strategyParams',
]);

const BACKTEST_TYPES = [
  { id: 'stock_daily', label: '股票日频', desc: '基于日线数据的全市场扫描' },
  { id: 'stock_1h', label: '股票小时频', desc: '基于小时线数据的短线策略' },
];

const wizardSteps = [
  { key: 'basic', step: 1, label: '基础配置', icon: Setting },
  { key: 'selection', step: 2, label: '选股模块', icon: Search },
  { key: 'timing', step: 3, label: '择时风控', icon: Timer },
  { key: 'params', step: 4, label: '策略参数', icon: TrendCharts },
  { key: 'confirm', step: 5, label: '构建完成', icon: CircleCheck },
];

const typeLabel = computed(() => {
  const labels: Record<string, string> = { stock_daily: '股票日频', stock_1h: '股票小时频' };
  return labels[props.backtestType] || props.backtestType;
});

const swapTimeLabel = computed(() => props.strategyParams.swap_time || '—');

function onStepClick(step: number) {
  if (step < props.step) {
    emit('goto', step);
  }
}

function updateParam(key: string, value: unknown) {
  emit('update:strategyParams', { ...props.strategyParams, [key]: value });
}

function updateStopConfig(stopKey: string, field: string, value: unknown) {
  const current = props.strategyParams[stopKey] || {};
  emit('update:strategyParams', {
    ...props.strategyParams,
    [stopKey]: { ...current, [field]: value },
  });
}

</script>

<style scoped>
.visual-mode {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}

/* ── View Mode ─────────────────────────────────────────── */
.view-mode {
  display: flex;
  flex-direction: column;
  height: 100%;
  overflow: hidden;
}
.view-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 20px 24px;
  border-bottom: 1px solid var(--border-subtle);
  flex-shrink: 0;
  gap: 16px;
}
.view-header__left {
  display: flex;
  align-items: center;
  gap: 12px;
}
.view-header__name {
  font-size: 18px;
  font-weight: 600;
  color: var(--text-primary);
}
.view-header__actions {
  display: flex;
  gap: 8px;
}
.view-body {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
}
.config-summary {
  display: flex;
  flex-direction: column;
  gap: 16px;
  max-width: 600px;
}
.summary-item {
  display: flex;
  align-items: flex-start;
  gap: 12px;
  padding: 14px 16px;
  background: var(--bg-secondary);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius);
}
.summary-item__icon {
  width: 32px;
  height: 32px;
  border-radius: 8px;
  background: var(--bg-active);
  color: var(--accent);
  display: flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}
.summary-item__content {
  flex: 1;
  min-width: 0;
}
.summary-item__label {
  font-size: 11px;
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 2px;
}
.summary-item__name {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary);
}
.summary-item__desc {
  font-size: 12px;
  color: var(--text-muted);
  margin-top: 2px;
}
.summary-item--empty {
  opacity: 0.5;
  border-style: dashed;
}
.summary-item__empty {
  font-size: 13px;
  color: var(--text-muted);
  font-style: italic;
}
.view-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 12px;
  padding: 60px 24px;
  color: var(--text-muted);
  text-align: center;
}
.view-empty p {
  font-size: 14px;
  margin: 0;
}

/* ── Wizard ──────────────────────────────────────────── */
.wizard-stepper {
  display: flex;
  align-items: center;
  padding: 16px 24px;
  border-bottom: 1px solid var(--border-subtle);
  flex-shrink: 0;
}
.wizard-step {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  user-select: none;
}
.wizard-step__indicator {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 12px;
  font-weight: 600;
  transition: all 0.2s;
}
.wizard-step--active .wizard-step__indicator {
  background: var(--accent);
  color: #fff;
}
.wizard-step--done .wizard-step__indicator {
  background: var(--success, #67c23a);
  color: #fff;
}
.wizard-step--pending .wizard-step__indicator {
  background: var(--bg-secondary);
  color: var(--text-muted);
  border: 1px solid var(--border);
}
.wizard-step__label {
  font-size: 13px;
  color: var(--text-secondary);
}
.wizard-step--active .wizard-step__label {
  color: var(--text-primary);
  font-weight: 500;
}
.wizard-step--done .wizard-step__label {
  color: var(--success, #67c23a);
}
.wizard-step__connector {
  width: 40px;
  height: 1px;
  background: var(--border);
  margin: 0 8px;
}
.wizard-step__connector--done {
  background: var(--success, #67c23a);
}

.wizard-content {
  flex: 1;
  overflow: hidden;
}
.step-panel {
  height: 100%;
  overflow: hidden;
}
.step-panel__inner {
  padding: 24px;
  max-width: 800px;
}
.step-panel__title {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 8px;
}
.step-panel__desc {
  font-size: 13px;
  color: var(--text-muted);
  margin-bottom: 16px;
}

.module-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(220px, 1fr));
  gap: 12px;
  margin-bottom: 16px;
}
.empty-modules {
  padding: 24px;
  text-align: center;
  color: var(--text-muted);
  font-size: 13px;
  background: var(--bg-secondary);
  border-radius: var(--radius);
}

.step-section {
  margin-bottom: 24px;
}
.step-section__label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  font-weight: 500;
  color: var(--text-secondary);
  margin-bottom: 12px;
}

.confirm-card {
  background: var(--bg-secondary);
  border: 1px solid var(--border-subtle);
  border-radius: var(--radius);
  padding: 16px 20px;
}
.confirm-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 8px 0;
}
.confirm-row__label {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
  color: var(--text-secondary);
}
.confirm-row__value {
  font-size: 13px;
  color: var(--text-primary);
  font-weight: 500;
}
.confirm-row__empty {
  font-size: 12px;
  color: var(--text-muted);
  font-style: italic;
}

.type-desc {
  font-size: 12px;
  color: var(--text-muted);
  margin-top: 6px;
}

.config-card {
  margin-bottom: 16px;
}

.wizard-footer {
  display: flex;
  align-items: center;
  justify-content: space-between;
  border-top: 1px solid var(--border-subtle);
  padding: 12px 24px;
  flex-shrink: 0;
}
.wizard-footer__nav {
  display: flex;
  gap: 8px;
}
.wizard-footer__left {
  display: flex;
  gap: 8px;
}

.stop-config-row {
  display: flex;
  align-items: center;
  gap: 12px;
}
.stop-config-label {
  font-size: 12px;
  color: var(--text-muted);
}

.param-summary-grid {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
  margin-top: 4px;
}
.param-chip {
  font-size: 12px;
  color: var(--text-secondary);
  background: var(--bg-tertiary, var(--bg-primary));
  padding: 2px 8px;
  border-radius: var(--radius);
}
.param-chip strong {
  color: var(--text-primary);
}
</style>
