<template>
  <div class="app-layout">
    <Sidebar />
    <div class="app-main">
      <TopBar :page-title="route.meta?.title as string || ''" />
      <div class="app-content">
        <RouterView v-slot="{ Component }">
          <Transition
            name="page"
            mode="out-in"
          >
            <component :is="Component" />
          </Transition>
        </RouterView>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { useRoute } from 'vue-router';
import Sidebar from './Sidebar.vue';
import TopBar from './TopBar.vue';

const route = useRoute();
</script>

<style scoped>
.app-layout {
  display: flex;
  width: 100%;
  height: 100%;
  background: var(--bg-primary);
}

.app-main {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  min-width: 0;
}

.app-content {
  flex: 1;
  overflow: hidden;
  display: flex;
  flex-direction: column;
  position: relative;
}

/* Page transition */
.page-enter-active {
  transition: opacity 0.25s ease, transform 0.25s ease;
}
.page-leave-active {
  transition: opacity 0.15s ease;
}
.page-enter-from {
  opacity: 0;
  transform: translateY(6px);
}
.page-leave-to {
  opacity: 0;
}

@media (max-width: 767px) {
  .app-layout {
    flex-direction: column;
  }
  .app-content {
    padding: var(--space-2);
  }
}
</style>
