import { describe, it, expect, vi, beforeEach } from 'vitest';
import { workflowApi } from '../workflow';

// Mock request module
vi.mock('../request', () => ({
  request: {
    get: vi.fn(),
    post: vi.fn(),
    put: vi.fn(),
    delete: vi.fn(),
  },
}));

describe('Workflow API', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it('should have all required methods', () => {
    expect(typeof workflowApi.list).toBe('function');
    expect(typeof workflowApi.get).toBe('function');
    expect(typeof workflowApi.create).toBe('function');
    expect(typeof workflowApi.update).toBe('function');
    expect(typeof workflowApi.delete).toBe('function');
    expect(typeof workflowApi.run).toBe('function');
    expect(typeof workflowApi.stop).toBe('function');
    expect(typeof workflowApi.listNodes).toBe('function');
    expect(typeof workflowApi.listRuns).toBe('function');
    expect(typeof workflowApi.getRunLogs).toBe('function');
  });
});
