"""
K线数据 API — 数据源：stg_cache 预处理数据（日线 Parquet / 1h Parquet）

日线数据: stg_cache/预处理数据/股票预处理数据.parquet（大宽表 ~1287万行×6006股×29列）
1h数据:   stock-1h-trading-data-pro/{code}.parquet（按股票分文件）

架构设计:
  - 日线大表采用 LazyFrame 缓存 + codes 列表缓存
  - 首次访问时 scan_parquet（惰性，仅读取 schema）
  - stocks 接口缓存 unique codes（带 TTL 120s）
  - data 接口在缓存的 LazyFrame 上 filter + collect
"""

from __future__ import annotations

import logging
import os
import signal
import threading
import time
from pathlib import Path

import config as _config
import polars as pl
from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse

logger = logging.getLogger("quant.kline")

# --------------------------------------------------------------------------
# 超时保护（用于防止大表查询无限阻塞）
# Windows 不支持 SIGALRM，使用线程 Timer 作为兜底
# --------------------------------------------------------------------------

import threading

_HAVE_SIGALRM = hasattr(signal, "SIGALRM")


class QueryTimeoutError(Exception):
    """K线数据查询超时异常。"""

    pass


def _timeout_handler(signum, frame):
    raise QueryTimeoutError("操作超时（30s），数据文件可能过大")


if _HAVE_SIGALRM:
    try:
        signal.signal(signal.SIGALRM, _timeout_handler)
    except (ValueError, OSError):
        pass

ROUTER_TIMEOUT_SEC = 30


def _set_timeout(seconds: int):
    """启动超时闹钟。Windows 下无操作（线程 Timer 在子线程不生效）。"""
    if _HAVE_SIGALRM:
        signal.alarm(seconds)


def _clear_timeout():
    """清除超时闹钟。"""
    if _HAVE_SIGALRM:
        signal.alarm(0)

router = APIRouter(prefix="/api/kline", tags=["kline"])

# ---------------------------------------------------------------------------
# 数据源路径（每次调用动态读取 _config.DATA_DIR）
# ---------------------------------------------------------------------------

def _data_dir() -> Path | None:
    return _config.DATA_DIR


def _get_daily_parquet() -> Path | None:
    d = _data_dir()
    if not d:
        return None
    return d / "stg_cache" / "预处理数据" / "股票预处理数据.parquet"


def _get_1h_dir() -> Path | None:
    d = _data_dir()
    if not d:
        return None
    return d / "stock-1h-trading-data-pro"


# ---------------------------------------------------------------------------
# 日线大表预加载缓存
# ---------------------------------------------------------------------------

_daily_lf: pl.LazyFrame | None = None          # 惰性 Frame（scan_parquet 结果）
_daily_parquet_path: str | None = None         # 对应的文件路径（用于检测变化）
_daily_codes: list[str] | None = None           # 缓存的股票代码列表
_daily_codes_time: float = 0                    # codes 缓存时间
_daily_load_time: float = 0                     # lf 加载时间
CACHE_TTL = 120.0                               # codes 缓存秒数

# 1h 文件列表缓存（含 TTL）
_1h_files: list[dict] | None = None
_1h_files_time: float = 0

# 缓存读写锁
_cache_lock = threading.Lock()


def _get_1h_files(refresh: bool = False) -> list[dict]:
    """获取并缓存 1h 目录下的股票代码列表（TTL 120s）。"""
    global _1h_files, _1h_files_time
    now = time.monotonic()
    with _cache_lock:
        if not refresh and _1h_files is not None and (now - _1h_files_time) < CACHE_TTL:
            return _1h_files

        h1_dir = _get_1h_dir()
        if not h1_dir or not h1_dir.is_dir():
            _1h_files = []
            _1h_files_time = now
            return _1h_files

    files = []
    try:
        for f in sorted(h1_dir.iterdir()):
            if f.is_file() and f.suffix.lower() == ".parquet":
                files.append({"code": f.stem, "name": "", "path": f"1h:{f.stem}"})
    except OSError:
        pass

    with _cache_lock:
        _1h_files = files
        _1h_files_time = now
    logger.info("1h 文件列表已缓存: %d 只", len(files))
    return files


def _ensure_daily_lazy() -> pl.LazyFrame | None:
    """确保日线 LazyFrame 已加载（惰性扫描，不读取实际数据）。"""
    global _daily_lf, _daily_parquet_path, _daily_load_time
    pq = _get_daily_parquet()
    if not pq or not pq.exists():
        return None
    pq_str = str(pq)
    with _cache_lock:
        # 路径未变且最近已加载 → 复用
        if (_daily_lf is not None
                and _daily_parquet_path == pq_str
                and (time.monotonic() - _daily_load_time) < CACHE_TTL * 10):
            return _daily_lf
    # 重新扫描（I/O 操作在锁外，减少持锁时间）
    try:
        new_lf = pl.scan_parquet(pq_str)
        with _cache_lock:
            _daily_lf = new_lf
            _daily_parquet_path = pq_str
            _daily_load_time = time.monotonic()
        logger.info("日线大表已惰性加载: %s (%dMB)", pq.name, pq.stat().st_size // 1024 // 1024)
        return new_lf
    except Exception as e:
        logger.error("日线 LazyFrame 加载失败: %s", e)
        with _cache_lock:
            _daily_lf = None
        return None


def _get_daily_codes(refresh: bool = False) -> list[str]:
    """获取并缓存日线股票代码列表。"""
    global _daily_codes, _daily_codes_time
    now = time.monotonic()
    with _cache_lock:
        if not refresh and _daily_codes is not None and (now - _daily_codes_time) < CACHE_TTL:
            return _daily_codes

    ldf = _ensure_daily_lazy()
    if ldf is None:
        return []

    try:
        # 从 LazyFrame 提取唯一 code（这是唯一需要触发的 collect）
        codes = (
            ldf.select(pl.col("code").unique())
            .collect()
            .to_series()
            .sort()
            .to_list()
        )
        with _cache_lock:
            _daily_codes = codes
            _daily_codes_time = now
        logger.info("日线股票代码已缓存: %d 只", len(codes))
        return codes
    except Exception as e:
        logger.error("获取日线 codes 失败: %s", e)
        return []


def _parse_source(source: str) -> str:
    """将前端传来的 source 标准化为内部标识。

    支持:
      - "daily" / "1h" （标准名）
      - 包含 "股票预处理数据" 或 "预处理数据" 的路径 → daily
      - 其他 → 原值返回（用于 1h 等场景）
    """
    s = source.strip()
    if s in ("daily", "1h"):
        return s
    if "股票预处理数据" in s or "预处理数据" in s:
        return "daily"
    # 如果路径中包含 stock-1h 或 1h-trading
    if "1h" in s.lower() or "trading-data" in s.lower():
        return "1h"
    return s


# ---------------------------------------------------------------------------
# 辅助函数
# ---------------------------------------------------------------------------

def _count_files(d: Path, suffix: str) -> int:
    try:
        return sum(1 for name in os.listdir(d) if name.endswith(suffix))
    except (PermissionError, OSError):
        return 0


# ===========================================================================
# API: 数据源列表
# ===========================================================================

@router.get("/sources")
async def list_kline_sources():
    """列出可用的 K 线数据源。"""
    sources = []

    # 1. 日线预处理数据 (Parquet)
    daily_pq = _get_daily_parquet()
    if daily_pq and daily_pq.exists():
        try:
            sources.append({
                "name": "daily",
                "path": "daily",                          # ← 改为标准名，方便前端使用
                "label": f"日线行情（预处理数据）",
                "format": "parquet",
                "columns": ["date", "code", "open", "high", "low", "close", "volume"],
                "estimated_total": True,
                "note": f"{daily_pq.stat().st_size / 1024 / 1024:.0f}MB · ~6000+ 股票",
            })
        except OSError:
            pass

    # 2. 1h 行情数据
    h1_dir = _get_1h_dir()
    if h1_dir and h1_dir.is_dir():
        try:
            cnt = _count_files(h1_dir, ".parquet")
            if cnt > 0:
                sources.append({
                    "name": "1h",
                    "path": "1h",
                    "label": "1小时行情",
                    "format": "parquet",
                    "columns": ["datetime", "code", "open", "high", "low", "close", "volume"],
                    "count": cnt,
                    "estimated": cnt >= 300,
                })
        except OSError:
            pass

    return {"sources": sources}


# ===========================================================================
# API: 股票列表
# ===========================================================================

@router.get("/stocks")
async def list_kline_stocks(source: str = Query("daily"), limit: int = Query(5000)):
    """列出指定数据源下的股票代码列表。"""
    src = _parse_source(source)
    stocks = []

    if src == "daily":
        codes = _get_daily_codes()
        for c in codes[:limit]:
            stocks.append({"code": c, "name": "", "path": f"daily:{c}"})

    elif src == "1h":
        stocks = _get_1h_files()
        if len(stocks) == 0:
            return JSONResponse(status_code=404, content={"detail": "1h 数据目录不存在或为空"})
        stocks = stocks[:limit]
    else:
        return JSONResponse(status_code=404, content={"detail": f"未知数据源: {source}"})

    result = {"source": src, "total": len(stocks), "stocks": stocks, "truncated": len(stocks) >= limit}
    return result


# ===========================================================================
# API: K线数据（核心接口）
# ===========================================================================

@router.get("/data")
async def get_kline_data(
    source: str = Query(...),
    code: str = Query(...),
    limit: int = Query(8000),
    sample: str = Query("day"),
):
    """获取 K 线 OHLCV 数据。

    日线流程: 缓存 LazyFrame → filter(code) → select(OHLCV) → sort → tail(limit) → collect
    1h流程:   直接读对应 parquet 文件 → 列名映射 → tail(limit)

    超时保护: 30s，防止大表查询无限阻塞。
    """
    src = _parse_source(source)
    df = None

    # 设置 SIGALRM 超时（30s），防止大表查询阻塞
    _set_timeout(ROUTER_TIMEOUT_SEC)
    try:
        if src == "daily":
            df = _read_daily_kline(code, limit)
        elif src == "1h":
            df = _read_1h_kline(code, limit)
        else:
            _clear_timeout()
            return JSONResponse(status_code=404, content={"detail": f"未知数据源: {source}"})
    except QueryTimeoutError:
        _clear_timeout()
        return JSONResponse(
            status_code=504,
            content={"detail": "请求超时（30s），数据文件可能过大，请分小时间段查询或减少 limit"},
        )
    except Exception as e:
        _clear_timeout()
        logger.error("get_kline_data unexpected error: %s", e)
        return JSONResponse(status_code=500, content={"detail": f"读取数据失败: {e}"})
    finally:
        _clear_timeout()  # 确保关闭闹钟

    if df is None or len(df) == 0:
        return JSONResponse(status_code=404, content={"detail": f"未找到数据: {code}"})

    if sample == "week":
        df = _resample_ohlv(df)
    elif sample == "month":
        df = _resample_ohlm(df)

    return {"data": df.to_dicts(), "total": len(df), "sample": sample}


# ---------------------------------------------------------------------------
# 内部读取函数
# ---------------------------------------------------------------------------

def _read_daily_kline(code: str, limit: int) -> pl.DataFrame | None:
    """从日线预处理 Parquet 读取单只股票 OHLCV。

    使用缓存的 LazyFrame 进行 filter，避免重复扫描文件。
    """
    ldf = _ensure_daily_lazy()
    if ldf is None:
        return None
    try:
        # 在 LazyFrame 上过滤 → 选择列 → 排序 → 取最后 N 条
        result = (
            ldf.filter(pl.col("code") == code)
            .select(
                pl.col("trade_date").alias("date"),
                pl.col("code"),
                pl.col("open"),
                pl.col("high"),
                pl.col("low"),
                pl.col("close"),
                pl.col("vol").alias("volume"),
            )
            .sort("date")
        )
        if limit < 200000:
            result = result.tail(limit)

        df = result.collect()
        if df.height == 0:
            # 后缀匹配: 600971 匹配 sh600971 / sz600971
            if code and not code.startswith(('sh', 'sz', 'bj', 'SH', 'SZ', 'BJ')):
                df = ldf.filter(pl.col("code").str.ends_with(code)).sort("date")
                if limit < 200000:
                    df = df.tail(limit)
                df = df.collect()
            if df.height == 0:
                return None
        # date 列转为字符串
        df = df.with_columns(pl.col("date").cast(pl.Utf8))
        return df
    except Exception as e:
        logger.error("_read_daily_kline error for %s: %s", code, e)
        return None


def _read_1h_kline(code: str, limit: int) -> pl.DataFrame | None:
    """从 1h 目录读取单只股票 OHLCV。"""
    h1_dir = _get_1h_dir()
    if not h1_dir or not h1_dir.is_dir():
        return None
    file_path = h1_dir / f"{code}.parquet"
    if not file_path.exists():
        return None
    try:
        df = pl.read_parquet(str(file_path), n_rows=limit * 2)

        col_map = {}
        for c in df.columns:
            cl = c.lower()
            if "时间" in cl or "datetime" in cl:
                col_map[c] = "date"
            elif "代码" in cl:
                col_map[c] = "code"
            elif c == "开盘价":
                col_map[c] = "open"
            elif c == "最高价":
                col_map[c] = "high"
            elif c == "最低价":
                col_map[c] = "low"
            elif c == "收盘价":
                col_map[c] = "close"
            elif c == "成交量":
                col_map[c] = "volume"
        if col_map:
            df = df.rename(col_map)

        keep = [c for c in ["date", "code", "open", "high", "low", "close", "volume"] if c in df.columns]
        if not keep:
            return None
        df = df.select(keep)
        if len(df) > limit:
            df = df.tail(limit)
        if "date" in df.columns:
            # 清理 1h datetime: 去掉纳秒尾缀，保留 YYYY-MM-DD HH:MM
            df = df.with_columns(
                pl.col("date").cast(pl.Utf8).str.replace(r"\.\d+$", "").alias("date")
            )
        return df
    except Exception as e:
        logger.error("_read_1h_kline error for %s: %s", code, e)
        return None


# ---------------------------------------------------------------------------
# 重采样
# ---------------------------------------------------------------------------

def _resample_ohlv(df: pl.DataFrame) -> pl.DataFrame:
    if "date" not in df.columns or len(df) == 0:
        return df
    try:
        df = df.with_columns(pl.col("date").str.slice(0, 10).alias("_w"))
        agg = df.group_by("_w").agg(
            pl.col("open").first(), pl.col("high").max(), pl.col("low").min(),
            pl.col("close").last(), pl.col("volume").sum(),
        ).sort("_w")
        return agg.rename({"_w": "date"})
    except Exception:
        return df


def _resample_ohlm(df: pl.DataFrame) -> pl.DataFrame:
    if "date" not in df.columns or len(df) == 0:
        return df
    try:
        df = df.with_columns(pl.col("date").str.slice(0, 7).alias("_m"))
        agg = df.group_by("_m").agg(
            pl.col("open").first(), pl.col("high").max(), pl.col("low").min(),
            pl.col("close").last(), pl.col("volume").sum(),
        ).sort("_m")
        return agg.rename({"_m": "date"})
    except Exception:
        return df
