"""
LRU 缓存实现 — 供 compare 等需要容量限制缓存的场景使用

仅包含 LRUCache 类（线程安全、TTL 过期、容量限制 LRU 淘汰）。
d1 已有自己的 cache_service.py（简单 TTL 字典），本模块用于需要 LRU 策略的场景。
"""

from __future__ import annotations

import threading
import time
from collections import OrderedDict
from dataclasses import dataclass
from typing import Generic, TypeVar

T = TypeVar("T")


@dataclass
class CacheEntry(Generic[T]):
    """缓存条目。"""
    timestamp: float
    data: T
    ttl: float


class LRUCache:
    """LRU 缓存，支持 TTL 过期和容量限制。

    特性:
    - LRU 淘汰策略：当容量满时淘汰最久未使用的条目
    - TTL 过期：支持每个条目的独立过期时间
    - 线程安全：使用 threading.Lock 保护所有操作
    - 自动清理：定期清理过期条目（间隔 5s）
    """

    def __init__(self, max_size: int = 100, default_ttl: float = 60.0) -> None:
        """
        Args:
            max_size: 最大缓存条目数，超过后淘汰最久未使用的条目。
            default_ttl: 默认缓存时间（秒）。
        """
        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._max_size = max_size
        self._default_ttl = default_ttl
        self._lock = threading.Lock()
        self._cleanup_stamp = 0.0
        self._cleanup_interval = 5.0  # 清理间隔（秒）

    def get(self, key: str) -> T | None:
        """获取缓存值。如果已过期或不存在返回 None。

        命中时将条目移到末尾（LRU 策略）。
        """
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                return None

            now = time.monotonic()
            if (now - entry.timestamp) >= entry.ttl:
                del self._cache[key]
                return None

            # 移动到末尾 — 最近使用
            self._cache.move_to_end(key)
            return entry.data

    def set(self, key: str, data: T, ttl: float | None = None) -> None:
        """设置缓存值。

        已存在的 key 更新数据并移到末尾；
        容量满时淘汰最久未使用的条目（popitem(last=False)）。
        """
        with self._lock:
            now = time.monotonic()

            if key in self._cache:
                # 更新已有条目
                self._cache[key] = CacheEntry(
                    timestamp=now,
                    data=data,
                    ttl=ttl or self._default_ttl,
                )
                self._cache.move_to_end(key)
            else:
                # 容量满则淘汰最旧的
                if len(self._cache) >= self._max_size:
                    self._cache.popitem(last=False)

                self._cache[key] = CacheEntry(
                    timestamp=now,
                    data=data,
                    ttl=ttl or self._default_ttl,
                )

            # 定期清理过期条目
            self._maybe_cleanup(now)

    def delete(self, key: str) -> bool:
        """删除指定 key 的缓存。返回是否成功删除。"""
        with self._lock:
            if key in self._cache:
                del self._cache[key]
                return True
            return False

    def clear(self) -> None:
        """清空所有缓存。"""
        with self._lock:
            self._cache.clear()

    def _maybe_cleanup(self, now: float | None = None) -> None:
        """定期清理过期缓存（由 set/get 触发）。"""
        if now is None:
            now = time.monotonic()

        if (now - self._cleanup_stamp) < self._cleanup_interval:
            return

        self._cleanup_stamp = now
        expired_keys = [
            k for k, v in self._cache.items()
            if (now - v.timestamp) >= v.ttl
        ]
        for k in expired_keys:
            del self._cache[k]

    def cleanup(self) -> int:
        """手动清理过期缓存，返回清理的条目数。"""
        with self._lock:
            now = time.monotonic()
            expired_keys = [
                k for k, v in self._cache.items()
                if (now - v.timestamp) >= v.ttl
            ]
            for k in expired_keys:
                del self._cache[k]
            self._cleanup_stamp = now
            return len(expired_keys)

    def keys(self) -> list[str]:
        """获取所有缓存键。"""
        with self._lock:
            return list(self._cache.keys())

    def size(self) -> int:
        """获取当前缓存条目数量。"""
        with self._lock:
            return len(self._cache)

    def get_stats(self) -> dict:
        """获取缓存统计信息。"""
        with self._lock:
            now = time.monotonic()
            expired = sum(
                1 for v in self._cache.values()
                if (now - v.timestamp) >= v.ttl
            )
            return {
                "total": len(self._cache),
                "max_size": self._max_size,
                "active": len(self._cache) - expired,
                "expired": expired,
                "ttl": self._default_ttl,
                "keys": list(self._cache.keys()),
            }
