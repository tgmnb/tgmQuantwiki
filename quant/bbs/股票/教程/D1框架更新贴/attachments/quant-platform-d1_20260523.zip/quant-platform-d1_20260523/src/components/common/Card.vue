<template>
  <div
    class="card"
    :class="{
      'card--shadow': shadow,
      'card--bordered': bordered,
      'card--hoverable': hoverable,
      'card--glow': glow,
    }"
    :style="{ padding: padding }"
  >
    <div
      v-if="$slots.header || title"
      class="card__header"
    >
      <div class="card__header-left">
        <span
          v-if="icon"
          class="card__icon"
        >
          <el-icon><component :is="icon" /></el-icon>
        </span>
        <h3
          v-if="title"
          class="card__title"
        >
          {{ title }}
        </h3>
      </div>
      <slot name="header" />
    </div>
    <div class="card__body">
      <slot />
    </div>
    <div
      v-if="$slots.footer"
      class="card__footer"
    >
      <slot name="footer" />
    </div>
  </div>
</template>

<script setup lang="ts">
interface Props {
  title?: string;
  icon?: string;
  shadow?: boolean;
  bordered?: boolean;
  hoverable?: boolean;
  glow?: boolean;
  padding?: string;
}

withDefaults(defineProps<Props>(), {
  shadow: true,
  bordered: true,
  hoverable: true,
  glow: false,
  padding: '16px',
});
</script>

<style scoped>
.card {
  background: var(--bg-secondary);
  border-radius: var(--radius-lg);
  overflow: hidden;
  transition: border-color var(--transition), box-shadow var(--transition), transform var(--transition);
  position: relative;
}

.card--shadow {
  box-shadow: var(--shadow-sm);
}

.card--bordered {
  border: 1px solid var(--border-color);
}

.card--hoverable:hover {
  border-color: var(--border2);
  box-shadow: var(--shadow-md);
  transform: translateY(-1px);
}

.card--glow::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 2px;
  background: linear-gradient(90deg, var(--accent), #a78bfa);
  opacity: 0;
  transition: opacity 0.2s;
}
.card--glow:hover::before {
  opacity: 1;
}

.card__header {
  padding: 14px 16px;
  border-bottom: 1px solid var(--border-color);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
}

.card__header-left {
  display: flex;
  align-items: center;
  gap: 8px;
}

.card__icon {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border-radius: var(--radius-sm);
  background: var(--accent-dim);
  color: var(--accent);
  font-size: 14px;
}

.card__title {
  margin: 0;
  font-size: var(--font-md);
  font-weight: 600;
  color: var(--text-primary);
  letter-spacing: -0.2px;
}

.card__body {
  color: var(--text-primary);
}

.card__footer {
  padding: 12px 16px;
  border-top: 1px solid var(--border-color);
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 8px;
}
</style>
