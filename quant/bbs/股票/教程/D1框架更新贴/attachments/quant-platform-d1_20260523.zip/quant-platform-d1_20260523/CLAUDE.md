# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## 项目概述

量化交易平台（Vue 3 + TypeScript 前端 + FastAPI 后端）。后端位于 `backend/` 目录，前端通过 Vite 代理 `/api` 到后端。生产环境后端直接托管 `dist/` 静态文件。

## 常用命令

```bash
npm run dev          # 启动开发服务器（localhost:5173）
npm run build        # vue-tsc 类型检查 + vite 构建
npm run preview      # 预览构建产物
npm run lint         # ESLint 检查 + 自动修复
npm run format       # Prettier 格式化 src/ 下 .vue/.ts/.tsx/.css
npm run type-check   # 仅 vue-tsc 类型检查
npm run test         # Vitest 运行测试
npm run test -- --coverage  # 运行测试并生成覆盖率报告
```

单个测试文件：`npx vitest run src/stores/__tests__/ui.test.ts`

后端启动：`cd backend && conda activate quantpy312 && python main.py`（端口 5180）

## 架构概览

### 前后端关系

- 前端 Vite 开发服务器（5173）代理 `/api` 请求到后端（5180）
- 生产构建后，后端直接托管 `dist/` 下的 Vue SPA 静态文件
- 后端用 Polars 读 CSV/Parquet 文件做数据分析；SQLite（`data/quant_platform.db`）做回测扫描结果缓存
- 实时日志通过 SSE（Server-Sent Events）推送

### 前端分层

`pages/` → `stores/` → `api/` → `request.ts`（Axios 封装）

- **pages/** — 路由对应的页面组件，按模块分目录（workflow, backtest, builder, library, settings）
- **stores/** — Pinia Store（workflow, backtest, builder, ui, simplifiedWorkflow），Composition API 风格，统一在 `stores/index.ts` 导出
- **api/** — 每个 API 模块一个文件（workflow, simplifiedWorkflow, backtest, builder, factors, selection, timing, kline, settings, financialFactors），统一通过 `request.ts` 发请求；响应拦截器自动解包 `response.data` 并抛 `ApiError`，`main.ts` 启动时通过 `setErrorHandler` 注入 `ElMessage.error` 弹错误
- **components/** — 共享组件按类型分目录：common/（Button, Card, Loading, MetricCard, MetricBadge, EmptyState, SkeletonCard, ResizableChart, TourOverlay 及各种 Badge）、editor/（CodeEditor, CodeToolbar, CodeViewer）、layout/（AppLayout, Sidebar, TopBar）
- **composables/** — `useSSE`（SSE 连接管理）、`useSavedParams`、`useLibraryCode`；workflow 页面内 composables 在 `pages/workflow/composables/`（useAutoSave, useInlineEdit, useRunHistory）
- **utils/** — dag.ts（仅 generateId）、echarts.ts、echartsTheme.ts、editor-themes.ts、date.ts
- **types/** — 全局类型定义，核心类型 re-export 在 `index.ts`，API 类型在 `api.ts`

### 后端分层

`main.py` → `routers/` → `services/`

- **routers/** — API 路由薄层，一个模块一个文件（workflow, simplified_workflow, backtest, builder, factors, financial_factors, timing, selection, kline, strategies, platform, settings, task_manager）
- **services/** — 业务逻辑层：
  - `task_manager` — 通用异步任务管理（subprocess 执行 + 日志进度解析），被 workflow/builder 等模块复用
  - `workflow_service` — 工作流 Facade，统一对外 API，实际逻辑委托给以下模块：
    - `workflow_storage` — JSON 文件 CRUD 与缓存（存储于 `quant_proj/workflows/{id}.json`）
    - `workflow_executor` — 线性顺序执行引擎
    - `workflow_stream` — SSE 事件生成与推送
    - `workflow_utils` — 清理辅助函数
  - `nodes/` — 工作流节点实现（因子计算、回测、选股、择时等，每个节点一个文件）
  - `backtest_service` — 回测扫描与结果读取
  - `data_service` — 文件系统缓存（CSV/Parquet 读写）
  - `db_service` — SQLite ORM（`data/quant_platform.db`），回测缓存与 Alembic 迁移
  - `cache_service` / `cache_manager` — 多级缓存
  - `platform_context` — 量化项目知识图谱（从 quant 项目目录结构构建）
  - `log_service` — 日志初始化与管理
  - `safe_exec` — 安全代码执行沙箱
  - `metrics_service`、`factor_analysis_service`、`tree_service`、`code_validator`、`research_context` 等
- **models/** — Pydantic/ORM 模型（`response.py`），`schemas.py` 定义请求/响应 schema
- **config.py** — 全局配置，从 `settings.json` 和 quant 项目的 `config.py` 读取路径，线程安全，自动检测 conda 环境
- **middleware/** — 异常处理、请求 ID、日志中间件
- **alembic/** — SQLite 数据库迁移（`alembic/versions/`）

### 路由

所有路由懒加载，默认 `/` 重定向到 `/workflow`。页面：workflow、backtest、builder、library、settings。未匹配路径也重定向到 `/workflow`。路由守卫设置 `document.title`。使用 `createWebHistory`（HTML5 History 模式）。

### 自动导入

通过 `unplugin-auto-import` 和 `unplugin-vue-components`：
- Vue/Router/Pinia API 自动导入，无需手动 import
- Element Plus 组件按需自动导入
- Element Plus 图标全局注册（`main.ts` 中 `* as ElementPlusIconsVue`）
- 类型声明在 `src/types/auto-imports.d.ts` 和 `components.d.ts`

### 主题系统

dark/light/eye-care 三主题，通过 `data-theme` 属性切换。CSS 变量定义在 `assets/styles/variables.css`。UI Store 管理主题状态，持久化到 localStorage（key: `d1-theme`）。主题切换顺序：dark → light → eye-care → dark。

### 构建分包

vite.config.ts 中 `manualChunks` 按库拆分：vendor-vue-runtime、vendor-vue-platform、vendor-pinia、vendor-vue-router、vendor-element、vendor-codemirror、vendor-echarts-core、vendor-zrender。

### 实时通信模式

后端通过 SSE 向前端推送任务日志和进度。前端 `useSSE` composable 管理 EventSource 连接，工作流（含简化工作流）和回测任务执行时使用。`simplifiedWorkflow` Store 内建 SSE 重连机制（最多 5 次）。后端 `task_manager` 通过 subprocess 执行量化脚本，解析 tqdm 日志输出获取进度百分比，通过 SSE 流式推送。

## 关键约定

- Path alias：`@/` → `src/`
- 组件命名：PascalCase；composable 命名：`use` 前缀
- CSS 类名：kebab-case；样式用 scoped 或 BEM
- API 响应拦截器已自动解包，调用 `request.get()` 直接拿到 data；错误抛 `ApiError` 类（含 code、statusCode、detail）
- Git 提交：Conventional Commits（feat/fix/docs/refactor/test）
- ESLint flat config（`eslint.config.js`）：`@typescript-eslint/no-explicit-any` 为 warn，`@typescript-eslint/no-unused-vars` 为 warn（`argsIgnorePattern: '^_'`），`no-console` warn（允许 warn/error），`no-debugger` error
- Prettier（`.prettierrc`）：无分号、单引号、2 空格缩进、trailingComma "all"、printWidth 100、arrowParens "avoid"、endOfLine "lf"
- TypeScript strict 模式，`noUnusedLocals` 和 `noUnusedParameters` 开启

## 测试

Vitest + jsdom 环境，globals 模式（`vitest/globals` 类型声明在 tsconfig.json），配置在 `vitest.config.ts`（与 `vite.config.ts` 独立）。测试文件放在对应模块的 `__tests__/` 目录。覆盖率阈值：全局 60%、分支 50%。运行 `npm run test`。

## 后端 API 文档

后端启动后访问 `http://localhost:5180/docs`（Swagger UI）或 `/redoc` 查看完整 API 文档。
