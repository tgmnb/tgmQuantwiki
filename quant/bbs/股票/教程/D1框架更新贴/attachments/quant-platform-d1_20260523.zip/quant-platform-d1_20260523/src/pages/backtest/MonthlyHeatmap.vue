<template>
  <div class="bt-section">
    <div class="bt-section__header">
      <span class="bt-section__title">月度收益率</span>
      <span class="mh-hint">颜色深浅表示月度收益率高低</span>
    </div>
    <div
      v-if="noData"
      class="mh-empty"
    >
      暂无足够净值数据生成月度热力图
    </div>
    <div
      v-else
      ref="chartRef"
      class="mh-chart"
    />
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, onUnmounted, watch, nextTick } from 'vue';
import type { PropType } from 'vue';
import { getEcharts } from '@/utils/echarts';

interface NavRow { [key: string]: string | number }

const props = defineProps({
  nav: {
    type: Object as PropType<{ headers?: string[]; rows?: NavRow[] }>,
    required: true,
  },
});

const chartRef = ref<HTMLElement | null>(null);
let chartInstance: any = null;
let resizeHandler: () => void = () => chartInstance?.resize();

/** 提取月度收益率数据 */

const monthlyData = computed(() => {
  const rows = props.nav?.rows;
  const headers = props.nav?.headers;
  if (!rows || rows.length < 2 || !headers) return [];

  const dateKey = headers.find(h => /时间|日期|date|time/i.test(h)) || headers[0];
  const valKey = headers.find(h => /净值|nav|总资产/i.test(h)) || headers[1] || headers[0];

  // 提取 (date, nav) 对
  const pairs: Array<[string, number]> = [];
  for (const r of rows) {
    const d = String(r[dateKey] || '').slice(0, 10);
    const v = parseFloat(String(r[valKey] ?? ''));
    if (d && !isNaN(v) && isFinite(v) && v > 0) pairs.push([d, v]);
  }
  if (pairs.length < 2) return [];

  // 按月分组
  const bucketMap = new Map<string, { first: number; last: number }>();
  for (const [d, v] of pairs) {
    const ym = d.slice(0, 7); // "YYYY-MM"
    const bucket = bucketMap.get(ym);
    if (!bucket) {
      bucketMap.set(ym, { first: v, last: v });
    } else {
      bucket.last = v; // 最后一个会覆盖为最新
    }
  }

  // 排序年月
  const sortedYM = [...bucketMap.keys()].sort();

  // 构建月度收益率 (用月末净值/上月末净值 - 1)
  // 第一个月用月初/月初-1 的方式
  const result: Array<{ year: number; month: number; ret: number }> = [];

  for (let i = 0; i < sortedYM.length; i++) {
    const ym = sortedYM[i];
    const bucket = bucketMap.get(ym)!;
    const [yStr, mStr] = ym.split('-');
    const year = parseInt(yStr, 10);
    const month = parseInt(mStr, 10);

    let ret: number;
    if (i === 0) {
      // 第一个月：用月末/月初 - 1
      ret = bucket.first > 0 ? (bucket.last / bucket.first - 1) : 0;
    } else {
      const prevBucket = bucketMap.get(sortedYM[i - 1])!;
      ret = prevBucket.last > 0 ? (bucket.last / prevBucket.last - 1) : 0;
    }
    result.push({ year, month, ret });
  }

  return result;
});

const noData = computed(() => monthlyData.value.length === 0);

/** 收集所有出现过的年份，排序 */
const years = computed(() => {
  const s = new Set(monthlyData.value.map(d => d.year));
  return [...s].sort();
});

async function initChart() {
  if (!chartRef.value || noData.value) return;

  if (chartInstance) { chartInstance.dispose(); chartInstance = null; }

  const ec = await getEcharts();
  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';

  const monthLabels = ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月'];
  const yearList = years.value;

  // 构建 heatmap 数据: [x(month-1), y(yearIndex), value]
  // ECharts heatmap 需要 [x, y, value] 格式
  const heatData: Array<[number, number, number]> = [];
  const retMap = new Map<string, number>();
  for (const d of monthlyData.value) {
    retMap.set(`${d.year}-${d.month}`, d.ret);
  }

  let maxAbs = 0;
  for (const d of monthlyData.value) {
    maxAbs = Math.max(maxAbs, Math.abs(d.ret));
  }
  if (maxAbs === 0) maxAbs = 0.05;

  for (let yi = 0; yi < yearList.length; yi++) {
    for (let mi = 1; mi <= 12; mi++) {
      const ret = retMap.get(`${yearList[yi]}-${mi}`);
      if (ret !== undefined) {
        heatData.push([mi - 1, yi, parseFloat((ret * 100).toFixed(2))]);
      }
    }
  }

  chartInstance = ec.init(chartRef.value, isDark ? 'custom-dark' : null, { renderer: 'canvas' });

  const textColor = isDark ? '#9ca3af' : '#374151';

  chartInstance.setOption({
    animation: false,
    tooltip: {
      position: 'top',
      backgroundColor: isDark ? '#0f0f14' : '#ffffff',
      borderColor: isDark ? '#1f1f2e' : '#e5e7eb',
      textStyle: { color: textColor, fontSize: 12 },
      formatter: (params: any) => {
        const [mi, yi] = params.data;
        const year = yearList[yi];
        const month = mi + 1;
        const val = params.data[2];
        const sign = val > 0 ? '+' : '';
        const color = val > 0 ? '#ef4444' : val < 0 ? '#22c55e' : textColor;
        return `<div style="font-weight:600;margin-bottom:4px;">${year}年${month}月</div>`
          + `<span style="color:${color};font-weight:700;font-family:monospace;">${sign}${val.toFixed(2)}%</span>`;
      },
    },
    grid: {
      left: 60,
      right: 20,
      top: 10,
      bottom: 50,
    },
    xAxis: {
      type: 'category',
      data: monthLabels,
      splitArea: { show: false },
      axisLabel: { color: textColor, fontSize: 10 },
      axisTick: { show: false },
      axisLine: { lineStyle: { color: isDark ? '#1f1f2e' : '#e5e7eb' } },
    },
    yAxis: {
      type: 'category',
      data: yearList.map(String),
      inverse: true,
      axisLabel: { color: textColor, fontSize: 10 },
      axisTick: { show: false },
      axisLine: { lineStyle: { color: isDark ? '#1f1f2e' : '#e5e7eb' } },
    },
    visualMap: {
      min: -(maxAbs * 100),
      max: maxAbs * 100,
      calculable: false,
      orient: 'horizontal',
      left: 'center',
      bottom: 4,
      itemWidth: 14,
      itemHeight: 140,
      textStyle: { color: textColor, fontSize: 12 },
      inRange: {
        color: ['#22c55e', '#86efac', '#f0fdf4', '#fef2f2', '#fca5a5', '#ef4444'],
      },
      formatter: (val: number) => `${val > 0 ? '+' : ''}${val.toFixed(0)}%`,
    },
    series: [{
      type: 'heatmap',
      data: heatData,
      label: {
        show: true,
        fontSize: yearList.length > 10 ? 9 : yearList.length > 6 ? 10 : 11,
        fontFamily: 'monospace',
        color: '#111111',
        formatter: (params: any) => {
          const val = params.data[2];
          if (val === 0) return '0';
          return `${val > 0 ? '+' : ''}${val.toFixed(1)}`;
        },
      },
      emphasis: {
        itemStyle: {
          shadowBlur: 6,
          shadowColor: 'rgba(0,0,0,0.3)',
        },
      },
      itemStyle: {
        borderColor: isDark ? '#0a0e17' : '#ffffff',
        borderWidth: 2,
        borderRadius: 3,
      },
    }],
  });

  window.addEventListener('resize', resizeHandler);
}

onMounted(() => nextTick(() => initChart()));
watch(() => props.nav, () => nextTick(() => initChart()), { deep: true });
onUnmounted(() => {
  window.removeEventListener('resize', resizeHandler);
  chartInstance?.dispose();
  chartInstance = null;
});
</script>

<style scoped>
.bt-section {
  background: var(--bg-card, var(--bg-secondary));
  border: 1px solid var(--border);
  border-radius: var(--radius-lg, 12px);
  overflow: hidden;
  box-shadow: var(--shadow-sm, 0 1px 2px rgba(0,0,0,0.04));
  transition: box-shadow 0.2s;
  display: flex;
  flex-direction: column;
  height: 100%;
}
.bt-section:hover {
  box-shadow: var(--shadow-md, 0 4px 12px rgba(0,0,0,0.06));
}
.bt-section__header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 16px;
  background: linear-gradient(180deg, var(--bg-secondary) 0%, var(--bg-tertiary, var(--bg-secondary)) 100%);
  border-bottom: 1px solid var(--border);
}
.bt-section__title {
  font-size: 12px;
  font-weight: 700;
  color: var(--text-secondary);
  text-transform: uppercase;
  letter-spacing: 0.6px;
}
.mh-hint {
  margin-left: auto;
  font-size: 11px;
  color: var(--text-muted);
}
.mh-empty {
  padding: 32px;
  text-align: center;
  color: var(--text-muted);
  font-size: var(--font-sm);
}
.mh-chart {
  width: 100%;
  flex: 1;
  min-height: 0;
  padding: 12px;
}
</style>
