@echo off
setlocal enabledelayedexpansion

set "PORT=5180"
set "MAX_WAIT=10"

echo ========================================
echo   D1 Quant Platform - Backend Restart
echo ========================================
echo.

echo [1/4] Checking port %PORT%...
set "FOUND=0"
for /f "tokens=5" %%a in ('netstat -aon ^| findstr ":%PORT%" ^| findstr "LISTENING"') do (
    set "FOUND=1"
    echo       Found PID: %%a
    taskkill /F /PID %%a >nul 2>&1
    if !errorlevel! equ 0 (
        echo       Killed PID %%a
    ) else (
        echo       [WARN] Failed to kill PID %%a
    )
)
if "!FOUND!"=="0" (
    echo       Port %PORT% is free
)

echo.
echo [2/4] Waiting for port release...
set "WAITED=0"
:wait_loop
if !WAITED! geq %MAX_WAIT% (
    echo       [WARN] Timeout - port may still be in use
    goto :skip_wait
)
netstat -aon | findstr ":%PORT%" | findstr "LISTENING" >nul 2>&1
if !errorlevel! neq 0 (
    echo       Port released ^(!WAITED!s^)
    goto :skip_wait
)
set /a "WAITED+=1"
timeout /t 1 /nobreak >nul
goto :wait_loop
:skip_wait

echo.
echo [3/4] Activating conda env...
call conda activate quantpy312
if !errorlevel! neq 0 (
    echo       [ERROR] Failed to activate conda env
    pause
    exit /b 1
)

echo.
echo [4/4] Starting backend...
echo       Port: %PORT%
echo       Time: %date% %time%
echo       ----------------------------------------
echo.

python start_server.py
set "EXIT_CODE=!errorlevel!"
echo.
if !EXIT_CODE! neq 0 (
    echo       [ERROR] Server exited with code !EXIT_CODE!
) else (
    echo       Server stopped
)
pause
