<template>
  <div
    class="module-card"
    :class="{ 'module-card--selected': isSelected }"
    @click="emit('select', module)"
  >
    <div class="module-card__header">
      <el-icon :size="14">
        <component :is="isSelected ? 'Check' : 'Folder'" />
      </el-icon>
      <span class="module-card__name">{{ module.name }}</span>
    </div>
    <div
      v-if="module.description"
      class="module-card__desc"
    >
      {{ module.description }}
    </div>
  </div>
</template>

<script setup lang="ts">
import type { PropType } from 'vue';

defineProps({
  module: {
    type: Object as PropType<{ name: string; description?: string }>,
    required: true,
  },
  isSelected: {
    type: Boolean,
    default: false,
  },
});

const emit = defineEmits(['select']);
</script>

<style scoped>
.module-card {
  padding: 10px 12px;
  border-radius: var(--radius);
  border: 1px solid var(--border-color);
  background: var(--bg-primary);
  cursor: pointer;
  transition: all 0.15s;
  display: flex;
  flex-direction: column;
  gap: 4px;
}
.module-card:hover {
  border-color: var(--accent);
  background: rgba(64, 158, 255, 0.04);
}
.module-card--selected {
  border-color: var(--accent);
  background: rgba(64, 158, 255, 0.08);
}
.module-card__header {
  display: flex;
  align-items: center;
  gap: 6px;
}
.module-card__name {
  font-size: 12px;
  font-weight: 500;
  color: var(--text-primary);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.module-card--selected .module-card__name {
  color: var(--accent);
}
.module-card__desc {
  font-size: 11px;
  color: var(--text-muted);
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  line-height: 1.4;
}
</style>
