from . import register_node

register_node({
    "id": "factor_financial",
    "type": "atomic",
    "name": "\u8d22\u52a1\u56e0\u5b50\u8ba1\u7b97",
    "description": "\u8ba1\u7b97\u8d22\u52a1\u56e0\u5b50\uff08\u57fa\u672c\u9762\u56e0\u5b50\uff09",
    "icon": "icon-factor",
    "category": "\u56e0\u5b50",
    "slots_in": [
        {
            "id": "price_data",
            "name": "\u884c\u60c5\u6570\u636e",
            "type": "file",
            "required": False,
            "ui": {"widget": "hidden"},
        },
    ],
    "slots_out": [
        {"id": "factor_data", "name": "\u8d22\u52a1\u56e0\u5b50\u6570\u636e", "type": "file"},
    ],
    "params": [
        {
            "id": "factor_to_calc",
            "name": "\u6307\u5b9a\u56e0\u5b50",
            "type": "list[str]",
            "default": None,
            "required": False,
            "ui": {"widget": "tag_input", "placeholder": "\u8f93\u5165\u56e0\u5b50\u540d\u79f0\uff0c\u7559\u7a7a\u8ba1\u7b97\u5168\u90e8"},
        },
    ],
    "script": "workflow/\u56e0\u5b50\u8ba1\u7b97.py",
    "func": "\u56e0\u5b50\u8ba1\u7b97",
    "conda_env": "quantpy312",
    "note": "\u76ee\u524d\u4e0e factor_compute \u5171\u7528\u540c\u4e00\u811a\u672c\uff0c\u540e\u7eed\u53ef\u62c6\u5206\u4e3a\u72ec\u7acb\u811a\u672c",
})
