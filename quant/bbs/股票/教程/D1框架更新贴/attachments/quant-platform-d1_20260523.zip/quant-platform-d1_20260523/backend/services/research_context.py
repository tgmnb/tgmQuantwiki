# -*- coding: utf-8 -*-
"""Create services/research_context.py"""
import json
from pathlib import Path
from datetime import datetime
from typing import Optional

class ResearchContext:
    """Persistent research context store (insights + next_steps)."""

    def __init__(self, path: Optional[Path] = None):
        if path is None:
            from config import QUANT_PROJ
            path = QUANT_PROJ / "data" / "research_context.json"
        self.path = Path(path)
        self._ensure_parent()

    def _ensure_parent(self):
        self.path.parent.mkdir(parents=True, exist_ok=True)

    def load(self) -> dict:
        if self.path.exists():
            try:
                return json.loads(self.path.read_text(encoding="utf-8"))
            except Exception:
                pass
        return self._default()

    def _default(self) -> dict:
        return {
            "insights": [],
            "next_steps": [],
            "last_updated": None,
            "last_session": None,
        }

    def save(self, data: dict) -> None:
        data["last_updated"] = datetime.now().isoformat()
        self.path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    def update(self, insights: list[str] = None, next_steps: list[str] = None,
               session_id: str = None) -> dict:
        """Update context fields."""
        data = self.load()
        if insights is not None:
            # Append new insights, dedupe
            existing = set(data.get("insights", []))
            for ins in insights:
                if ins and ins.strip() and ins.strip() not in existing:
                    data.setdefault("insights", []).append(ins.strip())
        if next_steps is not None:
            existing = set(data.get("next_steps", []))
            for ns in next_steps:
                if ns and ns.strip() and ns.strip() not in existing:
                    data.setdefault("next_steps", []).append(ns.strip())
        if session_id:
            data["last_session"] = session_id
        self.save(data)
        return data

    def get_summary(self) -> str:
        """Compact string for AI context."""
        data = self.load()
        parts = []
        insights = data.get("insights", [])
        next_steps = data.get("next_steps", [])
        if insights:
            parts.append(f"Insights ({len(insights)}): " + "; ".join(insights[-5:]))
        if next_steps:
            parts.append(f"Next Steps ({len(next_steps)}): " + "; ".join(next_steps[-5:]))
        if data.get("last_updated"):
            parts.append(f"Updated: {data['last_updated'][:10]}")
        # Scan latest backtest results
        bt_summary = self._scan_backtest_summary()
        if bt_summary:
            parts.append(bt_summary)
        return " | ".join(parts) if parts else "No research context yet."

    def _scan_backtest_summary(self) -> str:
        """Scan latest backtest summary CSVs and return a brief overview."""
        try:
            from config import _BACKTEST_PROJ_DIR
            import csv
            bt_dir = _BACKTEST_PROJ_DIR
            if not bt_dir or not bt_dir.exists():
                return ""
            psr = bt_dir / "param_sweep_results"
            if not psr.exists():
                return ""
            # Get 3 most recent summary CSVs
            csv_files = sorted(
                [f for f in psr.glob("summary_*.csv")],
                key=lambda x: x.stat().st_mtime,
                reverse=True
            )
            if not csv_files:
                return ""
            results = []
            for f in csv_files[:3]:
                try:
                    with open(f, "r", encoding="utf-8-sig") as fp:
                        reader = csv.DictReader(fp)
                        rows = list(reader)
                        if not rows:
                            continue
                        # Get top 3 by annual_return
                        sorted_rows = sorted(rows, key=lambda r: float(r.get("annual_return", 0) or 0), reverse=True)
                        for row in sorted_rows[:2]:
                            results.append({
                                "strategy": f.stem[:30],
                                "annual_return": row.get("annual_return", "?"),
                                "max_drawdown": row.get("max_drawdown", "?"),
                                "calmar": row.get("calmar_ratio", "?"),
                                "params": f"short={row.get('short_window','?')}, long={row.get('long_window','?')}"
                            })
                except Exception:
                    continue
            if not results:
                return ""
            lines = []
            for r in results[:6]:
                lines.append(
                    f'{r["strategy"]}: ret={r["annual_return"]}, mdd={r["max_drawdown"]}, calmar={r["calmar"]} ({r["params"]})'
                )
            return "Recent Backtests:\n" + "\n".join(lines)
        except Exception:
            return ""


# Singleton
_svc: Optional[ResearchContext] = None

def get_research_context() -> ResearchContext:
    global _svc
    if _svc is None:
        _svc = ResearchContext()
    return _svc
