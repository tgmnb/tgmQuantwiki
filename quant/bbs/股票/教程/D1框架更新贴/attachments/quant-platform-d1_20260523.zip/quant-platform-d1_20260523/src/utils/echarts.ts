/**
 * ECharts 按需导入配置
 *
 * 从 NavChart / CompareChart / BacktestDetail / PnLBar 确认需要：
 * LineChart, BarChart, CandlestickChart, GridComponent, TooltipComponent,
 * LegendComponent, DataZoomComponent, CanvasRenderer
 */

// 按需导入核心 + 必要的组件/图表/渲染器
import * as echarts from 'echarts/core';
import { LineChart, BarChart, CandlestickChart, ScatterChart, HeatmapChart } from 'echarts/charts';
import {
  GridComponent,
  TooltipComponent,
  LegendComponent,
  DataZoomComponent,
  VisualMapComponent,
} from 'echarts/components';
import { CanvasRenderer } from 'echarts/renderers';

// 注册所需的组件（只需注册一次）
echarts.use([
  LineChart,
  BarChart,
  CandlestickChart,
  ScatterChart,
  HeatmapChart,
  GridComponent,
  TooltipComponent,
  LegendComponent,
  DataZoomComponent,
  VisualMapComponent,
  CanvasRenderer,
]);

// Lazy-loads echarts once, registers 'custom-dark' theme, returns the instance
let echartsPromise: Promise<typeof echarts> | null = null;

export function getEcharts(): Promise<typeof echarts> {
  if (!echartsPromise) {
    echartsPromise = Promise.resolve(echarts).then(ec => {
      // Register a custom dark theme matching our CSS variable palette
      ec.registerTheme('custom-dark', {
        color: ['#6366f1', '#ef4444', '#22c55e', '#f59e0b', '#8b5cf6', '#06b6d4', '#ec4899'],
        backgroundColor: 'transparent',
        textStyle: { color: '#9ca3af', fontFamily: 'inherit' },
        grid: { borderColor: '#1f1f2e', containLabel: true },
        categoryAxis: {
          axisLine: { lineStyle: { color: '#1f1f2e' } },
          axisTick: { lineStyle: { color: '#1f1f2e' } },
          axisLabel: { color: '#9ca3af', fontSize: 12 },
          splitLine: { lineStyle: { color: '#1f1f2e', type: 'dashed' } },
        },
        valueAxis: {
          axisLine: { show: false },
          axisTick: { show: false },
          axisLabel: { color: '#9ca3af', fontSize: 12 },
          splitLine: { lineStyle: { color: '#1f1f2e', type: 'dashed' } },
        },
      });
      return ec;
    });
  }
  return echartsPromise;
}

export type { echarts };
