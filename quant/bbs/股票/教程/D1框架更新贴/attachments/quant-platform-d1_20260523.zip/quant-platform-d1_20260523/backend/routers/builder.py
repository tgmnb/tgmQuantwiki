"""
策略构建器 API — 预设/快速组合/回测任务提交/任务状态查询

核心改进：
1. 动态预设：从已有策略自动生成预设列表
2. 快速组合：选股+择时自动组合为可回测策略
3. 参数自解析：从 stg_config.py 自动提取可编辑参数
4. 增量日志：SSE 推送实时日志输出
5. 任务管理复用 TaskManager（消除约 300 行重复代码）
"""

from __future__ import annotations

import json
import logging
import os
import sys
import re
import subprocess
import tempfile
import time
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import JSONResponse

import config as _config
from services.safe_exec import safe_load_config, load_project_config, SafeExecError
from services.task_manager import TaskManager
from services.data_service import get_cached, invalidate_scan_cache
from services.tree_service import to_posix_path
from routers.settings import require_quant_proj

_logger = logging.getLogger("quant.builder")
router = APIRouter(prefix="/api/builder", tags=["builder"])

# ---------------------------------------------------------------------------
# 任务管理器实例（复用 TaskManager，消除 builder 内部重复实现）
# ---------------------------------------------------------------------------

_QUALIFIED_PYTHON = _config.QUANT_PYTHON_PATH

_builder_task_manager = TaskManager(
    tmp_subfolder="quant_builder",
    python_path=_QUALIFIED_PYTHON,
    task_prefix="builder",
    timeout_minutes=120,
    max_file_age_hours=24,
    allow_parallel=False,
)

# ---------------------------------------------------------------------------
# 输入校验
# ---------------------------------------------------------------------------

_STRATEGY_NAME_RE = re.compile(r'^[\w\u4e00-\u9fff]+$')


def _validate_identifier(name: str, field: str = "参数") -> str:
    if not name or not _STRATEGY_NAME_RE.match(name):
        raise ValueError(f"{field}不合法: {name}")
    return name


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------

def _load_strategy_config(stg_config_path: Path) -> dict:
    """安全加载策略配置文件（AST 检查 + 沙箱执行）。"""
    if not stg_config_path.exists():
        raise FileNotFoundError(f"策略配置文件不存在: {stg_config_path}")

    try:
        return safe_load_config(stg_config_path)
    except SafeExecError as e:
        _logger.error("策略配置包含不安全操作: %s - %s", stg_config_path, e)
        raise HTTPException(status_code=400, detail=f"策略配置包含不安全操作: {e}")
    except Exception as e:
        _logger.error("策略配置执行失败: %s - %s", stg_config_path, e)
        raise HTTPException(status_code=400, detail=f"策略配置执行失败: {e}")


def _scan_strategies_uncached(quant_proj: Path) -> dict:
    strategies: dict = {}
    strategy_hub = quant_proj / "backtest" / "strategies"
    if not strategy_hub.exists():
        return strategies
    for backtest_type_dir in sorted(strategy_hub.iterdir()):
        if not backtest_type_dir.is_dir() or backtest_type_dir.name.startswith("_"):
            continue
        if backtest_type_dir.name in ("templates", "__pycache__"):
            continue
        type_name = backtest_type_dir.name
        strategies[type_name] = []
        for strategy_dir in sorted(backtest_type_dir.iterdir()):
            if not strategy_dir.is_dir() or strategy_dir.name.startswith("_"):
                continue
            stg_config_path = strategy_dir / "stg_config.py"
            has_config = stg_config_path.exists()
            strategies[type_name].append({
                "name": strategy_dir.name,
                "path": to_posix_path(strategy_dir, quant_proj),
                "has_config": has_config,
            })
    return strategies


def _scan_strategies(quant_proj: Path) -> dict:
    cache_key = str((quant_proj / "backtest" / "strategies").resolve())
    return get_cached(cache_key, _scan_strategies_uncached, quant_proj)


def _extract_module_desc(py_path: Path) -> str:
    """从 Python 文件提取模块描述"""
    try:
        text = py_path.read_text(encoding="utf-8")
        lines = text.splitlines()
        start = 0
        for i, line in enumerate(lines):
            stripped = line.strip()
            if stripped and not stripped.startswith("#!") and not stripped.startswith("# -*-"):
                start = i
                break
        first = lines[start].strip() if start < len(lines) else ""

        if first.startswith('"""') or first.startswith("'''"):
            quote = first[:3]
            end_quote = first.find(quote, 3)
            if end_quote > 3:
                return first[3:end_quote].strip()
            doc_lines = [first[3:]]
            for line in lines[start + 1:]:
                if quote in line:
                    idx = line.index(quote)
                    doc_lines.append(line[:idx])
                    break
                doc_lines.append(line)
            return "\n".join(doc_lines).strip()[:200]
        if first.startswith("#"):
            comment_lines = []
            for line in lines[start:]:
                if line.strip().startswith("#"):
                    comment_lines.append(line.strip().lstrip("#").strip())
                else:
                    break
            return " ".join(comment_lines)[:200] if comment_lines else ""
    except Exception:
        pass
    return ""


def _scan_selection_modules_uncached(quant_proj: Path) -> list[dict]:
    sel_root = quant_proj / "backtest" / "select_hub"
    if not sel_root.exists():
        return []
    modules = []
    for p in sorted(sel_root.rglob("*.py")):
        if p.name == "__init__.py":
            continue
        rel = p.relative_to(sel_root)
        parts = rel.parts
        category = parts[0] if len(parts) > 1 else "其他"
        desc = _extract_module_desc(p)
        modules.append({
            "name": p.stem,
            "path": to_posix_path(p, quant_proj),
            "category": category,
            "description": desc,
            "freq": "daily",
        })
    return modules


def _scan_selection_modules(quant_proj: Path) -> list[dict]:
    cache_key = str((quant_proj / "backtest" / "select_hub").resolve())
    return get_cached(cache_key, _scan_selection_modules_uncached, quant_proj)


def _scan_timing_modules_uncached(quant_proj: Path) -> dict:
    result: dict = {"timing": [], "risk": []}
    stg_base = quant_proj / "backtest"
    for freq in ("daily", "hour"):
        d = stg_base / "signal_hub" / "stock" / freq
        if d.exists():
            for p in sorted(d.iterdir()):
                if p.suffix == ".py" and p.name not in ("__init__.py",):
                    desc = _extract_module_desc(p)
                    result["timing"].append({
                        "name": p.stem,
                        "path": to_posix_path(p, quant_proj),
                        "type": freq,
                        "description": desc,
                        "freq": freq,
                    })
    for freq in ("daily", "hour"):
        d = stg_base / "signal_hub" / "risk" / freq
        if d.exists():
            for p in sorted(d.iterdir()):
                if p.suffix == ".py" and p.name not in ("__init__.py",):
                    desc = _extract_module_desc(p)
                    result["risk"].append({
                        "name": p.stem,
                        "path": to_posix_path(p, quant_proj),
                        "type": freq,
                        "description": desc,
                        "freq": freq,
                    })
    return result


def _scan_timing_modules(quant_proj: Path) -> dict:
    cache_key = str((quant_proj / "backtest" / "signal_hub").resolve())
    return get_cached(cache_key, _scan_timing_modules_uncached, quant_proj)


def _parse_stg_config_params(config_dict: dict) -> list[dict]:
    """从 stg_config 字典中提取可编辑参数"""
    params = []
    strategy_config = config_dict.get("strategy_config", {})
    timing_config = config_dict.get("timing_config", {})

    param_defs = {
        "select_target": {"label": "选股模式", "type": "text", "group": "选股"},
        "day_buy_num_max": {"label": "每日最大买入", "type": "number", "group": "交易", "min": 1, "max": 50},
        "cap_amount": {"label": "分仓数", "type": "number", "group": "仓位", "min": 1, "max": 20},
        "hold_period": {"label": "持 股周期", "type": "text", "group": "交易"},
        "swap_time": {"label": "换仓时间", "type": "select", "group": "交易",
                       "options": ["open-close", "open-1455", "close-open"]},
        "sell_uplimit_hold_mode": {"label": "涨停继续持有", "type": "boolean", "group": "交易"},
    }

    for key, value in strategy_config.items():
        if key in ("stop_win", "stop_lose", "moving_win"):
            if isinstance(value, dict):
                params.append({
                    "key": f"strategy_config.{key}",
                    "label": {"stop_win": "止盈", "stop_lose": "止损", "moving_win": "移动止盈"}[key],
                    "type": "object",
                    "group": "风控",
                    "value": value,
                    "fields": [
                        {"key": "is_open", "label": "启用", "type": "boolean"},
                        {"key": "ratio", "label": "比例", "type": "number", "step": 0.01},
                    ],
                })
            continue

        meta = param_defs.get(key, None)
        if meta:
            params.append({
                "key": f"strategy_config.{key}",
                "label": meta["label"],
                "type": meta["type"],
                "group": meta["group"],
                "value": value,
                **({k: v for k, v in meta.items() if k in ("min", "max", "step", "options")}),
            })
        elif isinstance(value, (int, float, str, bool)):
            inferred_type = "text"
            if isinstance(value, bool):
                inferred_type = "boolean"
            elif isinstance(value, (int, float)):
                inferred_type = "number"
            params.append({
                "key": f"strategy_config.{key}",
                "label": key,
                "type": inferred_type,
                "group": "策略",
                "value": value,
            })
    return params


def _generate_run_script(strategy_name, backtest_type, overrides, quant_proj, output_dir,
                          date_start, date_end, init_capital):
    overrides_json = json.dumps(overrides, ensure_ascii=False)
    quant_proj_str = str(quant_proj).replace("\\", "/")
    return f'''#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Auto-generated backtest script"""
import sys
sys.path.insert(0, "{quant_proj_str}")
import json
from backtest.core.backtest import BacktestEngine
from backtest.core.enums import BacktestType, BacktestMode, AccountType, AssetType
from backtest.core.config_loader import build_backtest_config

base_config = {{
    "backtest_type": BacktestType.{backtest_type.upper()},
    "backtest_mode": BacktestMode.SINGLE,
    "strategy_name": "{strategy_name}",
    "account_type": AccountType.STRATEGY,
    "asset_type": AssetType.STOCK,
    "date_start": "{date_start}",
    "date_end": None if "{date_end}" == "None" else "{date_end}",
    "init_capital": {init_capital},
}}
full_config = build_backtest_config(base_config)

overrides = json.loads("""{overrides_json}""")
strategy_config = full_config["strategy_config_dict"]["{strategy_name}"]
for key_path, value in overrides.items():
    parts = key_path.split(".")
    d = strategy_config
    for p in parts[:-1]:
        d = d[p]
    d[parts[-1]] = value

engine = BacktestEngine.from_full_config(full_config)
engine.initialize()
evaluate_kwargs = engine.run()
engine.generate_report(evaluate_kwargs)
sys.stdout.write("BACKTEST_DONE\\n")
sys.stdout.flush()
'''


# ===========================================================================
# API: 策略列表
# ===========================================================================

@router.get("/strategies")
async def list_strategies(quant_proj: Path = Depends(require_quant_proj)):
    return {"strategies": _scan_strategies(quant_proj)}


# ===========================================================================
# API: 动态预设
# ===========================================================================

@router.get("/presets")
async def list_presets(quant_proj: Path = Depends(require_quant_proj)):
    """从已有策略自动生成预设列表"""
    presets = []
    strategies = _scan_strategies(quant_proj)

    for bt_type, stg_list in strategies.items():
        for stg in stg_list:
            if not stg.get("has_config"):
                continue
            stg_dir = quant_proj / stg["path"]
            try:
                config_dict = _load_strategy_config(stg_dir / "stg_config.py")
            except Exception:
                continue

            strategy_config = config_dict.get("strategy_config", {})
            timing_config = config_dict.get("timing_config", {})

            preset = {
                "id": f"{bt_type}/{stg['name']}",
                "name": stg["name"],
                "backtest_type": bt_type,
                "select_target": strategy_config.get("select_target", ""),
                "timing_signal": "",
                "risk_signal": "",
                "has_timing": timing_config.get("stock", {}).get("is_open", False),
                "has_risk": timing_config.get("risk", {}).get("is_open", False),
            }
            if preset["has_timing"]:
                preset["timing_signal"] = timing_config.get("stock", {}).get("signal", "")
            if preset["has_risk"]:
                preset["risk_signal"] = timing_config.get("risk", {}).get("signal", "")

            presets.append(preset)

    presets.insert(0, {
        "id": "custom",
        "name": "自定义策略",
        "backtest_type": "stock_daily",
        "select_target": "",
        "timing_signal": "",
        "risk_signal": "",
        "has_timing": False,
        "has_risk": False,
    })
    return {"presets": presets}


# ===========================================================================
# API: 策略配置（含可编辑参数）
# ===========================================================================

@router.get("/strategy/{backtest_type}/{strategy_name}")
async def get_strategy_config(backtest_type: str, strategy_name: str, quant_proj: Path = Depends(require_quant_proj)):
    stg_config_path = quant_proj / "backtest" / "strategies" / backtest_type / strategy_name / "stg_config.py"
    try:
        config_dict = _load_strategy_config(stg_config_path)
    except FileNotFoundError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        _logger.error("加载策略配置失败: %s", exc)
        raise HTTPException(status_code=500, detail=f"加载策略配置失败: {exc}") from exc

    editable_params = _parse_stg_config_params(config_dict)
    return {
        "strategy_name": strategy_name,
        "backtest_type": backtest_type,
        "config": config_dict,
        "editable_params": editable_params,
    }


# ===========================================================================
# API: 模块列表（一次返回选股+择时+风控）
# ===========================================================================

@router.get("/modules")
async def list_modules(type: str = Query("", description="backtest type: stock_daily, stock_1h, account"), quant_proj: Path = Depends(require_quant_proj)):
    freq_map = {"stock_daily": "daily", "stock_1h": "hour"}
    target_freq = freq_map.get(type, "")

    selections = _scan_selection_modules(quant_proj)
    timing_data = _scan_timing_modules(quant_proj)

    if target_freq:
        filtered_timing = [m for m in timing_data["timing"] if m.get("freq") == target_freq]
        filtered_risk = [m for m in timing_data["risk"] if m.get("freq") == target_freq]
    else:
        filtered_timing = timing_data["timing"]
        filtered_risk = timing_data["risk"]

    return {
        "selections": selections,
        "timing": {"timing": filtered_timing, "risk": filtered_risk},
    }


# ===========================================================================
# API: 提交回测任务
# ===========================================================================

@router.post("/run")
async def run_backtest_task(request: Request, quant_proj: Path = Depends(require_quant_proj)):
    try:
        body = await request.body()
        payload = json.loads(body)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"请求体解析失败: {exc}") from exc

    strategy_name = payload.get("strategy_name")
    backtest_type = payload.get("backtest_type", "stock_daily")
    overrides = payload.get("overrides", {})

    if not strategy_name:
        raise HTTPException(status_code=400, detail="strategy_name 不能为空")
    try:
        _validate_identifier(strategy_name, "strategy_name")
        _validate_identifier(backtest_type, "backtest_type")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    # TaskManager 内部处理串行限制
    try:
        _builder_task_manager.get_running_task()
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    quant_proj = _config.QUANT_PROJ
    if not _QUALIFIED_PYTHON.exists():
        raise HTTPException(status_code=500, detail=f"quantpy312 Python 未找到: {_QUALIFIED_PYTHON}")

    # 从 quant config 读取全局回测参数
    quant_config_path = quant_proj / "config.py"
    quant_cfg = {}
    if quant_config_path.exists():
        try:
            quant_cfg = load_project_config(quant_config_path)
        except SafeExecError as e:
            _logger.warning("quant config 加载失败（安全检查）: %s", e)
        except Exception as e:
            _logger.warning("quant config 执行失败: %s", e)

    date_start = quant_cfg.get("date_start", "2014-01-01")
    date_end = quant_cfg.get("date_end") or "None"
    init_capital = quant_cfg.get("init_capital", 1e7)

    # 构造脚本生成器（捕获当前作用域的变量值）
    def script_generator():
        return _generate_run_script(
            strategy_name=strategy_name,
            backtest_type=backtest_type,
            overrides=overrides,
            quant_proj=quant_proj,
            output_dir=quant_proj / "backtest" / "data" / backtest_type / strategy_name,
            date_start=date_start,
            date_end=date_end,
            init_capital=init_capital,
        )

    task_metadata = {
        "strategy_name": strategy_name,
        "backtest_type": backtest_type,
        "overrides": overrides,
    }

    try:
        result = _builder_task_manager.create_task(
            script_generator=script_generator,
            script_filename="run_builder",
            cwd=quant_proj,
            task_metadata=task_metadata,
        )
    except RuntimeError as exc:
        raise HTTPException(status_code=409, detail=str(exc)) from exc

    _logger.info("回测任务已提交: task_id=%s, strategy=%s, type=%s",
                 result["task_id"], strategy_name, backtest_type)
    return result


# ===========================================================================
# API: 任务列表 / 详情 / 终止
# ===========================================================================

@router.get("/tasks")
async def list_tasks():
    tasks = _builder_task_manager.list_tasks()
    return {"tasks": sorted(tasks, key=lambda x: x.get("start_time", ""), reverse=True)[:50]}


@router.get("/task/{task_id}")
async def get_task(task_id: str):
    result = _builder_task_manager.get_task_with_log(task_id, log_lines=200)
    if result is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    return result


# ============================================================================
# API: 历史记录（从 backtest/data 目录扫描）
# ============================================================================

@router.get("/history")
async def list_history(page: int = Query(1, ge=1), page_size: int = Query(20, ge=1, le=100)):
    """从 QUANT_PROJ/backtest/data 扫描回测结果目录，返回分页历史记录。"""
    data_root = _config.QUANT_PROJ / "backtest" / "data"
    if not data_root.exists():
        return {"records": [], "total": 0, "page": page, "page_size": page_size}

    records = []
    for stg_dir in sorted(data_root.iterdir(), key=lambda p: p.stat().st_mtime, reverse=True):
        if not stg_dir.is_dir():
            continue
        nav_files = sorted(stg_dir.glob("nav_*.csv"), key=lambda p: p.stat().st_mtime, reverse=True)
        if not nav_files:
            continue
        nav_file = nav_files[0]
        stat = nav_file.stat()
        try:
            lines = nav_file.read_text(encoding="utf-8", errors="ignore").splitlines()
            if len(lines) >= 2:
                last_line = lines[-1].split(",")
                first_line = lines[1].split(",")
                if len(last_line) >= 2 and len(first_line) >= 2:
                    records.append({
                        "name": stg_dir.name,
                        "strategy_name": stg_dir.name,
                        "path": to_posix_path(stg_dir, _config.QUANT_PROJ),
                        "nav_file": nav_file.name,
                        "start_date": first_line[0] if first_line else "",
                        "end_date": last_line[0] if last_line else "",
                        "final_nav": last_line[-1] if last_line else "",
                        "ctime": stat.st_ctime,
                        "mtime": stat.st_mtime,
                        "size": stat.st_size,
                        "status": "completed",
                    })
        except Exception:
            pass

    total = len(records)
    start = (page - 1) * page_size
    end = start + page_size
    page_records = records[start:end]
    return {
        "records": page_records,
        "total": total,
        "page": page,
        "page_size": page_size,
    }


@router.post("/task/{task_id}/stop")
async def stop_task(task_id: str):
    result = _builder_task_manager.stop_task(task_id)
    # stop_task 返回值不含 task_id 顶层 key，补齐以保持兼容
    if "task_id" not in result:
        result["task_id"] = task_id
    return result


# ===========================================================================
# API: 保存策略配置
# ===========================================================================

@router.post("/save_config")
async def save_strategy_config(request: Request, quant_proj: Path = Depends(require_quant_proj)):
    """保存策略配置到 stg_config.py 文件。"""
    try:
        body = await request.body()
        payload = json.loads(body)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"请求体解析失败: {exc}") from exc

    strategy_name = payload.get("strategy_name")
    backtest_type = payload.get("backtest_type", "stock_daily")
    strategy_config = payload.get("strategy_config", {})
    timing_config = payload.get("timing_config", {})
    data_source = payload.get("data_source")

    _logger.info(
        "保存策略配置: %s/%s, timing_config=%s",
        backtest_type, strategy_name, timing_config,
    )

    if not strategy_name:
        raise HTTPException(status_code=400, detail="strategy_name 不能为空")

    stg_dir = quant_proj / "backtest" / "strategies" / backtest_type / strategy_name
    if not stg_dir.exists():
        raise HTTPException(status_code=404, detail=f"策略目录不存在: {stg_dir}")

    # 构建 Python 代码
    def _dict_repr(d: dict, indent: int = 4) -> str:
        """将字典转为格式化 Python 代码（单行键值展开）。"""
        pad = " " * indent
        lines = []
        for k, v in d.items():
            if v is None:
                lines.append(f"{pad}'{k}': None,")
            elif isinstance(v, dict):
                lines.append(f"{pad}'{k}': {{")
                lines.append(_dict_repr(v, indent + 4))
                lines.append(f"{pad}}},")
            elif isinstance(v, bool):
                lines.append(f"{pad}'{k}': {'True' if v else 'False'},")
            elif isinstance(v, (int, float)):
                lines.append(f"{pad}'{k}': {repr(v)},")
            elif isinstance(v, list):
                items = ", ".join(repr(x) for x in v)
                lines.append(f"{pad}'{k}': [{items}],")
            else:
                lines.append(f"{pad}'{k}': {repr(v)},")
        return "\n".join(lines)

    sc_str = _dict_repr(strategy_config)
    tc_str = _dict_repr(timing_config)

    sections = [
        f'"""\n{strategy_name} 策略配置\n"""\n',
        f"strategy_config = {{\n{sc_str}\n}}\n",
    ]

    if data_source and isinstance(data_source, dict):
        ds_str = _dict_repr(data_source)
        sections.append(f"data_source = {{\n{ds_str}\n}}\n")

    sections.append(f"timing_config = {{\n{tc_str}\n}}\n")

    code = "\n".join(sections)
    config_path = stg_dir / "stg_config.py"
    config_path.write_text(code, encoding="utf-8")

    # 清除扫描缓存，确保下次 list_strategies 能读到最新数据
    cache_key = str((quant_proj / "backtest" / "strategies").resolve())
    invalidate_scan_cache(cache_key)

    _logger.info("策略配置已保存: %s/%s", backtest_type, strategy_name)
    return {"success": True, "path": to_posix_path(config_path, quant_proj)}


# ===========================================================================
# SSE: 实时进度 + 日志
# ===========================================================================

@router.get("/task/{task_id}/stream")
async def stream_task_progress(task_id: str, request: Request):
    task = _builder_task_manager.get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")

    from fastapi.responses import StreamingResponse
    return StreamingResponse(
        _builder_task_manager.stream_events(task_id, request=request),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
