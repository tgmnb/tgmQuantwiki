"""
D1 Quant Platform - 配置管理模块

封装所有全局路径变量和设置读写逻辑。
从 quant-test-d1-pro/config.py 动态读取 data_dir。
"""

from __future__ import annotations

import json
import logging
import os
import re
from pathlib import Path
from threading import Lock

_logger = logging.getLogger("quant.config")

# ---------------------------------------------------------------------------
# 线程锁 - 保护全局变量并发访问
# ---------------------------------------------------------------------------
_config_lock = Lock()

# ---------------------------------------------------------------------------
# 项目根路径
# ---------------------------------------------------------------------------
PROJECT_DIR = Path(__file__).resolve().parent
SETTINGS_FILE = PROJECT_DIR / "settings.json"
_DEFAULT_QUANT_PROJ = "E:/quantclassCode/mystockCode/quant-test-d1-pro"

# ---------------------------------------------------------------------------
# 模块级动态变量（通过 apply_settings 初始化）
# ---------------------------------------------------------------------------
QUANT_PROJ: Path = None          # 量化项目根目录
_CONFIG_PY: Path = None       # config.py 路径
DATA_DIR: Path = None         # 数据根目录（K线/因子）
_BACKTEST_PROJ_DIR: Path = None  # 回测结果目录
STOCK_DAILY_DIR: Path = None   # K线数据目录（DATA_DIR/stock/daily/stock_market）
PREPROCESS_DIR: Path = None    # 预处理数据目录（DATA_DIR/stg_cache/预处理数据）
QUANT_PYTHON_PATH: Path = None  # quantpy312 Python 解释器路径


def _load_data_dir_from_config(config_py: Path) -> str:
    """从 quant-test-d1-pro 的 config.py 读取 data_dir"""
    text = config_py.read_text(encoding="utf-8")
    m = re.search(r'^data_dir\s*=\s*["\'](.+?)["\']', text, re.MULTILINE)
    if m:
        return m.group(1)
    _logger.warning("未在 %s 中找到 data_dir 赋值，使用默认值", config_py)
    return "E:/quantClassData"


def _normalize_path(p: str) -> str:
    """统一路径分隔符为正斜线"""
    return p.replace("\\", "/").strip().rstrip("/")


def _detect_quant_python() -> Path:
    """自动检测 quantpy312 Python 解释器路径。

    检测顺序：
    1. 从 settings.json 读取 quant_python_path
    2. 尝试 conda env 列表（如果可用）
    3. 尝试常见安装路径

    Returns:
        检测到的 Python 路径，如果都失败则返回 None
    """
    # 1. 从配置读取
    settings = load_settings()
    configured_path = settings.get("quant_python_path")
    if configured_path:
        p = Path(_normalize_path(configured_path))
        if p.exists() and p.is_file():
            _logger.info("从配置读取 Python 路径: %s", p)
            return p

    # 2. 尝试 conda env 检测
    try:
        import subprocess
        result = subprocess.run(
            ["conda", "env", "list"],
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=5
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if "quantpy312" in line:
                    # 提取路径（conda 输出格式：quantpy312  *  /path/to/env）
                    parts = line.split()
                    if len(parts) >= 3:
                        env_path = parts[2]
                        python_path = Path(env_path) / "python.exe"
                        if python_path.exists():
                            _logger.info("通过 conda 检测到 Python: %s", python_path)
                            return python_path
    except (FileNotFoundError, subprocess.TimeoutExpired, Exception):
        pass  # conda 不可用，继续尝试其他方法

    # 3. 尝试常见安装路径
    common_paths = [
        "D:/anaconda3/envs/quantpy312/python.exe",
        "C:/anaconda3/envs/quantpy312/python.exe",
        "D:/miniconda3/envs/quantpy312/python.exe",
        "C:/miniconda3/envs/quantpy312/python.exe",
    ]

    for p_str in common_paths:
        p = Path(p_str)
        if p.exists() and p.is_file():
            _logger.info("检测到 Python: %s", p)
            return p

    _logger.warning("未找到 quantpy312 Python 解释器，请在 settings.json 中配置 quant_python_path")
    return None



def apply_settings(quant_proj_path: str) -> None:
    """更新模块级路径变量（线程安全）

    Args:
        quant_proj_path: 量化项目路径
    """
    global QUANT_PROJ, _CONFIG_PY, DATA_DIR, _BACKTEST_PROJ_DIR, STOCK_DAILY_DIR, PREPROCESS_DIR, QUANT_PYTHON_PATH
    
    with _config_lock:  # 获取锁，保证并发安全
        _orig = quant_proj_path
        _proj = Path(_normalize_path(quant_proj_path))
        QUANT_PROJ = _proj
        _CONFIG_PY = _proj / "config.py"
        
        if _CONFIG_PY.exists():
            _raw_dd = _load_data_dir_from_config(_CONFIG_PY)
            _dd = _normalize_path(_raw_dd)
            _dd_abs = _dd
            DATA_DIR = Path(_dd_abs).resolve()
            _logger.info("配置加载成功: quant_proj=%s -> %s, config.py=%s, data_dir=%s",
                         _orig, _proj, _CONFIG_PY, DATA_DIR)
        else:
            DATA_DIR = _proj.resolve()
            _logger.warning("未检测到 config.py: %s, data_dir 降级为 quant_proj: %s",
                            _CONFIG_PY, DATA_DIR)
        
        _BACKTEST_PROJ_DIR = _proj / "backtest" / "data"
        STOCK_DAILY_DIR = DATA_DIR / "stock" / "daily"   # K线数据源
        PREPROCESS_DIR = DATA_DIR / "stg_cache" / "预处理数据"  # 预处理数据
        
        # 检测 quantpy312 Python 路径
        QUANT_PYTHON_PATH = _detect_quant_python()
        
        # 刷新平台知识图谱
        try:
            platform_context.refresh(QUANT_PROJ)
        except Exception:
            pass
    # 锁在这里自动释放


# ---- settings.json 读写 ---------------------------------------------------

def load_settings() -> dict:
    """加载 settings.json，不存在则返回空字典"""
    if SETTINGS_FILE.exists():
        try:
            return json.loads(SETTINGS_FILE.read_text(encoding="utf-8"))
        except Exception:
            return {}
    return {}


def save_settings(data: dict) -> None:
    """保存 settings.json（先写临时文件再 rename，保证原子性）"""
    tmp = SETTINGS_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    tmp.replace(SETTINGS_FILE)  # 原子替换


# ---------------------------------------------------------------------------
# 启动初始化（模块导入时自动执行）
# ---------------------------------------------------------------------------
from services.platform_context import PlatformContext as _PCls
platform_context: _PCls = _PCls(QUANT_PROJ)

_settings = load_settings()

apply_settings(_settings.get("quant_proj", _DEFAULT_QUANT_PROJ))


# ---------------------------------------------------------------------------
# 线程安全的配置读取接口
# ---------------------------------------------------------------------------

def get_config() -> dict:
    """
    线程安全地读取当前配置。
    
    Returns:
        包含所有配置路径的字典
    """
    with _config_lock:
        return {
            "QUANT_PROJ": QUANT_PROJ,
            "_CONFIG_PY": _CONFIG_PY,
            "DATA_DIR": DATA_DIR,
            "_BACKTEST_PROJ_DIR": _BACKTEST_PROJ_DIR,
            "STOCK_DAILY_DIR": STOCK_DAILY_DIR,
            "PREPROCESS_DIR": PREPROCESS_DIR,
            "QUANT_PYTHON_PATH": QUANT_PYTHON_PATH,
        }


def is_initialized() -> bool:
    """检查配置是否已初始化"""
    with _config_lock:
        return QUANT_PROJ is not None and DATA_DIR is not None
