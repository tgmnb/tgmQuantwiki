<template>
  <div class="bt-layout">
    <!-- Left: Strategy List -->
    <div class="bt-sidebar">
      <div class="bt-sidebar-header">
        <span class="bt-sidebar-title">Strategies</span>
        <div style="flex:1" />
        <button
          v-if="compareSet.size >= 2"
          class="btn btn-primary btn-xs"
          :disabled="compareLoading"
          @click="runCompare"
        >
          对比 {{ compareSet.size }}
        </button>
        <button
          v-if="compareSet.size > 0"
          class="btn btn-ghost btn-xs"
          @click="clearCompare"
        >
          清除
        </button>
      </div>
      <div class="bt-sidebar-search">
        <div class="search-wrap">
          <input
            v-model="sidebarSearch"
            type="text"
            class="search-input"
            placeholder="搜索策略..."
          >
          <button
            v-if="sidebarSearch"
            class="search-clear"
            @click="sidebarSearch = ''"
          >
            ×
          </button>
        </div>
      </div>
      <div class="bt-sidebar-list">
        <div
          v-for="entry in filteredEntries"
          :key="entry[0]"
          class="strategy-group"
        >
          <div
            class="group-header"
            @click="toggleGroup(entry[0])"
          >
            <span
              class="group-arrow"
              :style="{ transform: expandedGroups[entry[0]] ? 'rotate(90deg)' : '' }"
            >&#9654;</span>
            <span class="group-name">{{ entry[0] }}</span>
            <span class="group-count">{{ entry[1].length }}</span>
          </div>
          <div
            v-if="expandedGroups[entry[0]]"
            class="group-items"
          >
            <div
              v-for="item in entry[1]"
              :key="item.path"
              class="strategy-item"
              :class="{ 'strategy-item--active': selectedPath === item.path && !compareData }"
              @click="loadDetail(item)"
            >
              <input
                type="checkbox"
                class="strategy-checkbox"
                :checked="compareSet.has(item.path)"
                :disabled="!compareSet.has(item.path) && compareSet.size >= 5"
                @click.stop
                @change="toggleCompare(item)"
              >
              <span class="strategy-name">{{ item.name }}</span>
            </div>
          </div>
        </div>
        <div
          v-if="filteredEntries.length === 0"
          class="empty-hint"
        >
          {{ sidebarSearch ? '无匹配' : '暂无策略' }}
        </div>
      </div>
    </div>

    <!-- Right: Detail -->
    <div class="bt-content">
      <div
        v-if="warningMessage"
        class="error-msg"
        style="margin: 12px;"
      >
        {{ warningMessage }}
      </div>
      <Loading
        v-if="detailLoading || compareLoading"
        text="加载中..."
        size="md"
      />
      <BacktestDetail
        v-else-if="detail && !compareData"
        :detail="detail"
        :strategy-base="selectedBase"
      />
      <ComparePanel
        v-else-if="compareData"
        :data="compareData"
      />
      <EmptyState
        v-else
        title="选择策略查看详情"
        description="从左侧列表选择一个策略查看回测详情"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted } from 'vue';
import { backtestApi } from '@/api/backtest';
import BacktestDetail from './BacktestDetail.vue';
import ComparePanel from './ComparePanel.vue';

const groups = ref<Record<string, any[]>>({});
const expandedGroups = ref<Record<string, boolean>>({});
const selectedPath = ref<string | null>(null);
const selectedBase = ref('');
const detail = ref<any>(null);
const detailLoading = ref(false);
const loading = ref(false);
const compareSet = ref<Set<string>>(new Set());
const compareData = ref<any>(null);
const compareLoading = ref(false);
const sidebarSearch = ref('');

onMounted(async () => {
  loading.value = true;
  try {
    const d: any = await backtestApi.getList();
    groups.value = d?.groups || {};
    const entries = Object.entries(d?.groups || {}).filter(([k]) => k !== 'warning');
    if (entries.length > 0) expandedGroups.value = { [entries[0][0]]: true };
  } catch (e) { console.error('Failed to load strategies', e); }
  finally { loading.value = false; }
});

const filteredEntries = computed(() => {
  const entries = Object.entries(groups.value).filter(([k]) => k !== 'warning');
  if (!sidebarSearch.value.trim()) return entries;
  const q = sidebarSearch.value.toLowerCase();
  const matched = entries
    .map(([g, items]) => [g, (items as any[]).filter((item: any) => item.name?.toLowerCase().includes(q))])
    .filter(([, items]) => (items as any[]).length > 0) as [string, any[]][];
  // Auto-expand all matched groups
  if (q) {
    matched.forEach(([g]) => { expandedGroups.value[g] = true; });
  }
  return matched;
});

const warningMessage = computed(() => groups.value?.warning || '');

function toggleGroup(key: string) {
  expandedGroups.value[key] = !expandedGroups.value[key];
}

async function loadDetail(item: any) {
  if (selectedPath.value === item.path && detail.value && !compareData.value) {
    selectedPath.value = null;
    detail.value = null;
    return;
  }
  selectedPath.value = item.path;
  selectedBase.value = item.base || '';
  compareData.value = null;
  detailLoading.value = true;
  try {
    const d: any = await backtestApi.getDetail(item.path, item.base || '');
    detail.value = d;
  } catch (e) {
    detail.value = null;
    console.error('Failed to load detail', e);
  } finally {
    detailLoading.value = false;
  }
}

function toggleCompare(item: any) {
  const next = new Set(compareSet.value);
  if (next.has(item.path)) next.delete(item.path);
  else { if (next.size < 5) next.add(item.path); }
  compareSet.value = next;
}

function findBaseByPath(path: string): string {
  for (const items of Object.values(groups.value as Record<string, any[]>) as Iterable<any[]>) {
    const found = items.find((item) => item.path === path);
    if (found) return found.base || '';
  }
  return '';
}

async function runCompare() {
  if (compareSet.value.size < 2) return;
  compareLoading.value = true;
  compareData.value = null;
  detail.value = null;
  try {
    const paths = Array.from(compareSet.value);
    const bases = paths.map((p) => findBaseByPath(p));
    const d: any = await backtestApi.compare(paths, bases);
    compareData.value = d;
  } catch { compareData.value = null; }
  finally { compareLoading.value = false; }
}

function clearCompare() {
  compareSet.value = new Set();
  compareData.value = null;
}
</script>

<style scoped>
.bt-layout { display: flex; height: 100%; width: 100%; gap: 0; overflow: hidden; }

.bt-sidebar {
  width: 200px; flex-shrink: 0; border-right: 1px solid var(--border);
  display: flex; flex-direction: column; background: var(--bg-secondary); overflow: hidden;
}
.bt-sidebar-header {
  display: flex; align-items: center; gap: 6px;
  padding: 16px 16px 12px; border-bottom: 1px solid var(--border); flex-shrink: 0; height: 52px; box-sizing: border-box;
}
.bt-sidebar-title { font-size: 11px; font-weight: 600; color: var(--text-primary); letter-spacing: 0.5px; text-transform: uppercase; }
.bt-sidebar-search { padding: 6px 10px; border-bottom: 1px solid var(--border); flex-shrink: 0; }
.search-wrap { position: relative; display: flex; align-items: center; }
.search-input {
  width: 100%; height: 28px; padding: 0 28px 0 10px;
  background: var(--bg-primary); color: var(--text-primary);
  border: 1px solid var(--border); border-radius: var(--radius);
  font-size: 11px; font-family: inherit; outline: none;
}
.search-input:focus { border-color: var(--accent); }
.search-input::placeholder { color: var(--text-muted); }
.search-clear {
  position: absolute; right: 6px; width: 18px; height: 18px;
  background: var(--bg-tertiary); border: none; border-radius: 50%;
  color: var(--text-muted); cursor: pointer; font-size: 12px; line-height: 1;
  display: flex; align-items: center; justify-content: center;
  transition: background 0.15s;
}
.search-clear:hover { background: var(--border); color: var(--text-primary); }

.bt-sidebar-list { flex: 1; overflow-y: auto; padding: 6px 0; }

.strategy-group { margin-bottom: 4px; }
.group-header {
  display: flex; align-items: center; gap: 6px;
  padding: 5px 8px; font-size: 11px; font-weight: 600;
  color: var(--text-muted); cursor: pointer; user-select: none;
  text-transform: uppercase; letter-spacing: 0.5px;
  border-radius: 5px; height: 24px; box-sizing: border-box;
}
.group-header:hover { background: var(--bg-hover); color: var(--text-secondary); }
.group-arrow { font-size: 8px; transition: transform 0.15s; flex-shrink: 0; }
.group-name { flex: 1; }
.group-count { font-weight: 400; opacity: 0.6; font-size: 12px; }

.group-items { margin-left: 8px; }
.strategy-item {
  display: flex; align-items: center; gap: 8px;
  padding: 6px 12px; font-size: 11px; color: var(--text-primary);
  cursor: pointer; border-radius: 5px; margin: 1px 0;
  transition: background 0.1s; border: 1px solid transparent; height: 28px; box-sizing: border-box;
}
.strategy-item:hover { background: var(--bg-hover); border-color: var(--border); }
.strategy-item--active { background: var(--accent-dim); border-color: rgba(124, 110, 245, 0.3); color: var(--accent); }
.strategy-checkbox { cursor: pointer; flex-shrink: 0; width: 12px; height: 12px; accent-color: var(--accent); }
.strategy-name { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 11px; }

.empty-hint { padding: 20px 12px; text-align: center; color: var(--text-muted); font-size: 11px; }

.bt-content { flex: 1; overflow-y: auto; display: flex; flex-direction: column; min-width: 0; }


.btn { display: inline-flex; align-items: center; justify-content: center; padding: 3px 8px; border-radius: 5px; font-size: 11px; cursor: pointer; border: 1px solid transparent; font-weight: 500; transition: all 0.15s; }
.btn-primary { background: var(--accent); color: #fff; }
.btn-primary:hover { opacity: 0.85; }
.btn-ghost { background: transparent; color: var(--text-muted); border-color: var(--border); }
.btn-ghost:hover { background: var(--bg-hover); color: var(--text-primary); }
.btn-xs { padding: 2px 6px; font-size: 12px; }

.spinner {
  width: 22px; height: 22px; border: 2px solid var(--border);
  border-top-color: var(--accent); border-radius: 50%;
  animation: spin 0.8s linear infinite;
}
@keyframes spin { to { transform: rotate(360deg); } }
</style>
