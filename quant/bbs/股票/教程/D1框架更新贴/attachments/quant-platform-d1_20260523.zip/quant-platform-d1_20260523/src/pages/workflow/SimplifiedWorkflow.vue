<template>
  <div class="sw-page">
    <div class="sw-page__header">
      <h2 class="sw-page__title">
        工作流
      </h2>
    </div>

    <div class="sw-page__body">
      <!-- 工作流卡片网格 -->
      <div class="sw-grid">
        <div
          v-for="wf in store.workflows"
          :key="wf.id"
          class="sw-card"
          :class="{ 'sw-card--running': store.running && store.runningWorkflowId === wf.id }"
        >
          <!-- 卡片头部 -->
          <div class="sw-card__hd">
            <span class="sw-card__name">{{ wf.name }}</span>
            <span
              v-if="store.running && store.runningWorkflowId === wf.id"
              class="sw-card__dot"
            />
          </div>

          <!-- 描述 -->
          <p class="sw-card__desc">
            {{ wf.doc || '使用当前配置参数运行' }}
          </p>

          <!-- 独特参数 -->
          <div
            v-if="getUniqueParam(wf.id) !== null"
            class="sw-card__param"
          >
            <span class="sw-card__param-label">{{ getUniqueParamLabel(wf.id) }}</span>
            <el-select
              v-if="isMultiParam(wf.id)"
              :model-value="getUniqueParam(wf.id) as string[]"
              multiple
              collapse-tags
              collapse-tags-tooltip
              placeholder="选择"
              size="small"
              style="width: 100%"
              @update:model-value="v => store.updateParams(wf.id, { [getUniqueParamKey(wf.id)!]: v })"
            >
              <el-option
                v-for="opt in getParamOptions(wf)"
                :key="opt"
                :label="opt"
                :value="opt"
              />
            </el-select>
            <el-select
              v-else
              :model-value="getUniqueParam(wf.id) as string ?? ''"
              placeholder="选择"
              size="small"
              clearable
              style="width: 100%"
              @update:model-value="v => store.updateParams(wf.id, { [getUniqueParamKey(wf.id)!]: v })"
            >
              <el-option
                v-for="opt in getParamOptions(wf)"
                :key="opt"
                :label="opt"
                :value="opt"
              />
            </el-select>
          </div>



          <!-- 运行状态 & 按钮 -->
          <div class="sw-card__ft">
            <span
              v-if="store.running && store.runningWorkflowId === wf.id"
              class="sw-card__status"
            >
              运行中...
            </span>
            <el-button
              type="primary"
              size="small"
              :loading="store.running && store.runningWorkflowId === wf.id"
              :disabled="store.running && store.runningWorkflowId !== wf.id"
              @click="handleRun(wf.id)"
            >
              {{ store.running && store.runningWorkflowId === wf.id ? '运行中' : '运行' }}
            </el-button>
          </div>
        </div>
      </div>

      <!-- 日志面板 -->
      <div class="sw-page__log">
        <LogPanel
          :log-lines="store.logLines"
          :running="store.running"
          :current-step-name="getRunningWorkflowName()"
          @clear="store.clearLogs()"
        />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { onMounted } from 'vue'
import { ElMessage } from 'element-plus'
import LogPanel from './LogPanel.vue'
import { useSimplifiedWorkflowStore } from '@/stores/simplifiedWorkflow'

const store = useSimplifiedWorkflowStore()

// 每个工作流对应的独特参数 key（去掉了 date_start/date_end）
const UNIQUE_PARAM_KEY: Record<string, string | null> = {
  '因子计算':        'factor_name_list',
  '因子计算_板块':  'factor_name_list',
  '日频策略回测':   'strategy_name_list',
  '小时频策略回测': 'minute_strategy_name_list',
  '账户回测':       'account_name_list',
  '选股':           'select_code_list',
  '指数合成':       null,
}

const PARAM_LABELS: Record<string, string> = {
  'factor_name_list':             '计算因子',
  'strategy_name_list':            '策略',
  'minute_strategy_name_list':    '分钟策略',
  'account_name_list':            '账户',
  'select_code_list':            '选股列表',
}

const MULTI_PARAMS = new Set(['factor_name_list', 'select_code_list'])

function getUniqueParamKey(wfId: string): string | null {
  return UNIQUE_PARAM_KEY[wfId] ?? null
}

function getUniqueParamLabel(wfId: string): string {
  const key = getUniqueParamKey(wfId)
  return key ? (PARAM_LABELS[key] ?? key) : ''
}

function isMultiParam(wfId: string): boolean {
  const key = getUniqueParamKey(wfId)
  return key ? MULTI_PARAMS.has(key) : false
}

function getUniqueParam(wfId: string): unknown {
  const key = getUniqueParamKey(wfId)
  if (!key) return null
  return store.getParams(wfId)[key] ?? store.configParams[key]
}

function getParamOptions(wf: { id: string }): string[] {
  const key = getUniqueParamKey(wf.id)
  if (!key) return []
  const opts = store.configParams[key]
  return Array.isArray(opts) ? opts : []
}

function getRunningWorkflowName(): string {
  if (!store.runningWorkflowId) return ''
  const wf = store.workflows.find(w => w.id === store.runningWorkflowId)
  return wf ? wf.name : ''
}

async function handleRun(wfId: string) {
  try {
    await store.runWorkflow(wfId, store.getParams(wfId))
  } catch {
    ElMessage.error('启动工作流失败')
  }
}

onMounted(async () => {
  await store.loadWorkflows()
  await store.loadTasks()
})
</script>

<style scoped>
.sw-page {
  display: flex;
  flex-direction: column;
  height: 100%;
}

.sw-page__header {
  padding: 12px 16px;
  border-bottom: 1px solid var(--border-color);
  flex-shrink: 0;
}

.sw-page__title {
  margin: 0;
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
}

.sw-page__body {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: 16px;
  gap: 16px;
}

/* 卡片网格：3列固定 */
.sw-grid {
  display: grid;
  grid-template-columns: repeat(3, 1fr);
  gap: 14px;
  flex-shrink: 0;
}

/* 卡片 */
.sw-card {
  background: var(--bg-secondary);
  border: 1px solid var(--border-color);
  border-radius: 10px;
  padding: 14px 16px;
  display: flex;
  flex-direction: column;
  gap: 8px;
  transition: border-color 0.2s, box-shadow 0.2s;
}

.sw-card:hover {
  border-color: var(--accent, #409eff);
  box-shadow: 0 2px 12px rgba(0, 0, 0, 0.15);
}

.sw-card--running {
  border-color: var(--accent, #409eff);
  background: color-mix(in srgb, var(--accent, #409eff) 6%, var(--bg-secondary));
  box-shadow: 0 0 0 1px var(--accent, #409eff);
}

/* 卡片头部 */
.sw-card__hd {
  display: flex;
  align-items: center;
  gap: 8px;
}

.sw-card__name {
  font-size: 14px;
  font-weight: 600;
  color: var(--text-primary);
  flex: 1;
}

.sw-card__dot {
  width: 7px;
  height: 7px;
  border-radius: 50%;
  background: var(--accent, #409eff);
  flex-shrink: 0;
  animation: pulse 1.4s ease-in-out infinite;
}

@keyframes pulse {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.5; transform: scale(0.8); }
}

/* 描述 */
.sw-card__desc {
  font-size: 11px;
  color: var(--text-muted);
  margin: 0;
  line-height: 1.4;
  min-height: 28px;
}

/* 参数 */
.sw-card__param {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.sw-card__param-label {
  font-size: 10px;
  color: var(--text-muted);
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.sw-card__param-hint {
  font-size: 11px;
  color: var(--text-muted);
  text-align: center;
  padding: 4px 0;
}

/* 底部 */
.sw-card__ft {
  display: flex;
  align-items: center;
  justify-content: space-between;
  margin-top: auto;
  padding-top: 4px;
}

.sw-card__status {
  font-size: 11px;
  color: var(--accent, #409eff);
}

/* 日志区域 */
.sw-page__log {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  border: 1px solid var(--border-color);
  border-radius: 8px;
  overflow: hidden;
}
</style>
