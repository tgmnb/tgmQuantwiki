<template>
  <div class="bt-section">
    <div class="bt-section__header">
      <span class="bt-section__title">净值曲线</span>
      <span class="nav-badge nav-badge--nav">净值(左轴)</span>
      <span class="nav-badge nav-badge--dd">回撤(右轴)</span>
      <span class="bt-section__hint">拖拽底部调节高度</span>
    </div>
    <div class="nav-chart-body">
      <!-- Drag handle -->
      <div
        class="nav-resize-handle"
        title="拖拽调节高度"
        @mousedown.prevent="onResizeStart"
      >
        <div class="nav-resize-dots" />
      </div>
      <!-- Chart -->
      <div
        ref="chartRef"
        :style="{ height: chartHeight + 'px', width: '100%' }"
      />
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, onMounted, onUnmounted, watch, nextTick } from 'vue';
import type { PropType } from 'vue';
import { getEcharts } from '@/utils/echarts';

const props = defineProps({
  nav: {
    type: Object as PropType<{ headers?: string[]; rows?: Record<string, any>[] }>,
    required: true,
  },
  name: { type: String, default: '' },
});

const chartRef = ref<HTMLElement | null>(null);
const chartHeight = ref(260);

const MIN_H = 180;
const MAX_H = 500;

let chartInstance: any = null;
let resizeHandler: () => void = () => chartInstance?.resize();

// Drag state
let dragging = false;
let startY = 0;
let startH = 0;

function onResizeStart(e: MouseEvent) {
  dragging = true;
  startY = e.clientY;
  startH = chartHeight.value;
  document.body.style.userSelect = 'none';
  document.body.style.cursor = 'ns-resize';
  window.addEventListener('mousemove', onResizeMove);
  window.addEventListener('mouseup', onResizeEnd);
}

function onResizeMove(e: MouseEvent) {
  if (!dragging) return;
  const delta = e.clientY - startY;
  chartHeight.value = Math.min(MAX_H, Math.max(MIN_H, startH + delta));
  nextTick(() => chartInstance?.resize());
}

function onResizeEnd() {
  if (!dragging) return;
  dragging = false;
  document.body.style.userSelect = '';
  document.body.style.cursor = '';
  window.removeEventListener('mousemove', onResizeMove);
  window.removeEventListener('mouseup', onResizeEnd);
}

async function initChart() {
  if (!chartRef.value) return;

  if (chartInstance) { chartInstance.dispose(); chartInstance = null; }

  const ec = await getEcharts();
  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
  const textColor = isDark ? '#9ca3af' : '#374151';
  const gridColor = isDark ? '#1f1f2e' : '#e5e7eb';

  const headers = props.nav?.headers || [];
  const dateKey = headers.find((h: string) => /时间|日期|date|time/i.test(h)) || headers[0];
  const valKey = headers.find((h: string) => /净值|nav|总资产/i.test(h))
    || headers[1] || headers[0];

  const dates: string[] = [], values: number[] = [];
  (props.nav?.rows || []).forEach((r: Record<string, any>) => {
    const d = String(r[dateKey] || '').slice(0, 10);
    const raw = r[valKey];
    const v = raw === null || raw === undefined || raw === '' ? NaN : parseFloat(raw);
    if (d && !isNaN(v) && isFinite(v) && v > 0) { dates.push(d); values.push(v); }
  });
  if (dates.length === 0) return;

  const initVal = values[0];
  const normValues = values.map((v: number) => v / initVal);
  const drawdownValues: number[] = [];
  let peak = values[0];
  values.forEach((v: number) => {
    if (v >= peak) { peak = v; drawdownValues.push(0); }
    else drawdownValues.push(v / peak - 1);
  });

  chartInstance = ec.init(chartRef.value, isDark ? 'custom-dark' : null, { renderer: 'canvas' });
  chartInstance.setOption({
    animation: false,
    grid: { left: 60, right: 60, top: 40, bottom: 50 },
    legend: {
      show: true, top: 8, left: 'center', itemWidth: 14, itemHeight: 2,
      textStyle: { color: textColor, fontSize: 11 },
    },
    tooltip: {
      trigger: 'axis',
      backgroundColor: isDark ? '#0f0f14' : '#ffffff',
      borderColor: gridColor,
      textStyle: { color: textColor, fontSize: 11 },
      formatter: (params: any[]) => {
        if (!params?.length) return '';
        const idx = params[0].dataIndex;
        if (idx < 0 || idx >= dates.length) return '';
        const dt = dates[idx];
        let h = `<div style="font-weight:600;margin-bottom:6px;">${dt}</div>`;
        params.forEach((p: any) => {
          if (p.seriesName === '基准') return;
          const v = parseFloat(p.value);
          if (isNaN(v)) return;
          if (p.seriesName === '净值') {
            const pct = ((v - 1) * 100).toFixed(2);
            const col = v >= 1 ? '#ef4444' : '#22c55e';
            h += `<div style="display:flex;gap:12px;align-items:center;margin:2px 0;">`;
            h += `<span style="width:8px;height:8px;border-radius:50%;background:${p.color};"></span>`;
            h += `<span>${p.seriesName}:</span>`;
            h += `<span style="font-weight:600;color:${col};">${v.toFixed(4)}</span>`;
            h += `<span style="color:${col};">(${v >= 1 ? '+' : ''}${pct}%)</span>`;
            h += `</div>`;
          } else if (p.seriesName === '回撤') {
            const pct = (v * 100).toFixed(2);
            h += `<div style="display:flex;gap:12px;align-items:center;margin:2px 0;">`;
            h += `<span style="width:8px;height:8px;border-radius:50%;background:${p.color};"></span>`;
            h += `<span>${p.seriesName}:</span>`;
            h += `<span style="font-weight:600;color:#14b8a6;">${pct}%</span>`;
            h += `</div>`;
          }
        });
        return h;
      },
    },
    xAxis: {
      type: 'category', data: dates, boundaryGap: false,
      axisLine: { lineStyle: { color: gridColor } },
      axisTick: { show: false },
      axisLabel: { color: textColor, fontSize: 12 },
      splitLine: { show: false },
    },
    yAxis: [
      {
        scale: true, axisLine: { show: false }, axisTick: { show: false },
        axisLabel: { color: textColor, fontSize: 12, formatter: (v: number) => v.toFixed(2) },
        splitLine: { lineStyle: { color: gridColor, type: 'dashed' } },
      },
      {
        scale: true, max: 0, axisLine: { show: false }, axisTick: { show: false },
        axisLabel: { color: textColor, fontSize: 12, formatter: (v: number) => (v * 100).toFixed(0) + '%' },
        splitLine: { show: false },
      },
    ],
    series: [
      {
        name: '基准', type: 'line', data: dates.map(() => 1), smooth: false,
        showSymbol: false, lineStyle: { color: '#6b7280', width: 1, type: 'dashed' },
        emphasis: { disabled: true },
      },
      {
        name: '净值', type: 'line', yAxisIndex: 0, data: normValues, smooth: false,
        showSymbol: false,
        lineStyle: { color: '#6366f1', width: 2.5 },
        areaStyle: {
          color: {
            type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: '#6366f1' + '60' },
              { offset: 0.5, color: '#6366f1' + '18' },
              { offset: 1, color: '#6366f1' + '02' },
            ],
          },
        },
      },
      {
        name: '回撤', type: 'line', yAxisIndex: 1, data: drawdownValues, smooth: false,
        showSymbol: false, lineStyle: { color: '#14b8a6', width: 1.5 },
        areaStyle: {
          color: {
            type: 'linear', x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(20,184,166,0.25)' },
              { offset: 0.5, color: 'rgba(20,184,166,0.08)' },
              { offset: 1, color: 'rgba(20,184,166,0.01)' },
            ],
          },
        },
        connectNulls: false,
      },
    ],
    dataZoom: [{ type: 'inside', start: 0, end: 100 }],
  });

  window.addEventListener('resize', resizeHandler);
}

onMounted(() => nextTick(() => initChart()));
watch(() => [props.nav, props.name], () => nextTick(() => initChart()), { deep: true });
onUnmounted(() => {
  window.removeEventListener('resize', resizeHandler);
  window.removeEventListener('mousemove', onResizeMove);
  window.removeEventListener('mouseup', onResizeEnd);
  chartInstance?.dispose();
  chartInstance = null;
});
</script>

<style scoped>
.bt-section {
  border: 1px solid var(--border);
  border-radius: var(--radius, 8px);
  overflow: hidden;
  margin-bottom: 12px;
}
.bt-section__header {
  display: flex; align-items: center; gap: 8px;
  padding: 10px 14px; background: var(--bg-secondary);
  border-bottom: 1px solid var(--border);
}
.bt-section__title {
  font-size: 11px; font-weight: 600; color: var(--text-secondary);
  text-transform: uppercase; letter-spacing: 0.5px;
}
.bt-section__hint {
  margin-left: auto; font-size: 12px; color: var(--text-muted);
}
.nav-badge {
  font-size: 12px; padding: 2px 6px; border-radius: 10px;
  border: 1px solid; font-weight: 500;
}
.nav-badge--nav {
  color: var(--accent); background: var(--accent-dim);
  border-color: rgba(99,102,241,0.25);
}
.nav-badge--dd {
  color: #14b8a6; background: rgba(20,184,166,0.08);
  border-color: rgba(20,184,166,0.2);
}
.nav-chart-body {
  padding: 0 14px 12px;
}
.nav-resize-handle {
  height: 12px; cursor: ns-resize; display: flex; align-items: center; justify-content: center;
  position: relative;
}
.nav-resize-handle:hover .nav-resize-dots {
  opacity: 1;
}
.nav-resize-dots {
  width: 32px; height: 3px;
  background: repeating-linear-gradient(
    90deg,
    var(--border) 0px, var(--border) 2px,
    transparent 2px, transparent 5px
  );
  border-radius: 2px; opacity: 0.5; transition: opacity 0.15s;
}
</style>
