"""
选股代码管理 API
"""

from __future__ import annotations

import config as _config
from fastapi import APIRouter, Query

from routers._code_reader import read_code_file
from services.tree_service import to_posix_path

router = APIRouter(prefix="/api/selection", tags=["selection"])


@router.get("/list")
async def list_selection_codes():
    """列出 select_hub 下所有层级的选股 Python 代码（递归扫描子目录）。"""
    sel_root = _config.QUANT_PROJ / "backtest" / "select_hub"
    if not sel_root.exists():
        return {"strategies": []}

    strategies = []
    for p in sorted(sel_root.rglob("*.py")):
        if p.name == "__init__.py":
            continue
        # 相对路径作为 name，保留子目录层级
        rel = p.relative_to(sel_root)
        name = str(rel).replace("/", " / ").replace("\\", " / ")
        strategies.append({
            "name": name,
            "path": to_posix_path(p, _config.QUANT_PROJ),
            "size_kb": round(p.stat().st_size / 1024, 1),
        })

    return {"strategies": strategies}


@router.get("/content")
async def get_selection_content(path: str = Query(...), limit: int = Query(300)):
    """读取选股策略 Python 代码内容。"""
    return read_code_file(_config.QUANT_PROJ, path, limit)


@router.post("/save")
async def save_selection_code(data: dict):
    """保存选股策略代码。"""
    from fastapi.responses import JSONResponse

    path = data.get("path", "")
    content = data.get("content", "")
    target = _config.QUANT_PROJ / path
    sel_root = _config.QUANT_PROJ / "backtest" / "select_hub"
    try:
        if not target.resolve().is_relative_to(sel_root.resolve()):
            return JSONResponse(status_code=403, content={"success": False, "detail": "只允许保存到 backtest/select_hub 目录下"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"success": False, "detail": "路径校验失败"})
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return {"success": True}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "detail": str(e)})


@router.post("/delete")
async def delete_selection_code(data: dict):
    """删除选股策略代码文件。"""
    path = data.get("path", "")
    target = _config.QUANT_PROJ / path
    sel_root = _config.QUANT_PROJ / "backtest" / "select_hub"
    try:
        if not target.resolve().is_relative_to(sel_root.resolve()):
            return JSONResponse(status_code=403, content={"success": False, "detail": "只允许删除 backtest/select_hub 目录下的文件"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"success": False, "detail": "路径校验失败"})

    if not target.exists():
        return JSONResponse(status_code=404, content={"success": False, "detail": "文件不存在"})

    try:
        target.unlink()
        return {"success": True}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "detail": str(e)})
