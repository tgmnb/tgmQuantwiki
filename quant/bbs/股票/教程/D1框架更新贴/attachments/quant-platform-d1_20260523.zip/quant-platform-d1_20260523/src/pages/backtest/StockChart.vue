<template>
  <div class="bt-section">
    <div class="bt-section__header">
      <span class="bt-section__title">个股买卖点</span>
      <div style="margin-left:auto;display:flex;align-items:center;gap:6px;">
        <select
          v-model="source"
          class="select select-sm"
        >
          <option value="daily">
            日线
          </option>
          <option value="1h">
            1小时
          </option>
        </select>
      </div>
    </div>
    <div class="stock-chart-layout">
      <!-- Left: Stock list -->
      <div class="stock-list">
        <div class="stock-search-wrap">
          <input
            v-model="stockSearch"
            type="text"
            class="input stock-search"
            placeholder="搜索股票..."
          >
        </div>
        <div class="stock-items">
          <div
            v-for="s in filteredStocks"
            :key="s.code"
            class="stock-item"
            :class="{ 'stock-item--active': selectedStock === s.code }"
            @click="loadStockChart(s.code)"
          >
            <div class="stock-item-top">
              <span class="stock-code">{{ s.code }}</span>
              <span
                v-if="s.name"
                class="stock-name"
              >{{ s.name }}</span>
            </div>
            <div class="stock-item-counts">
              <span class="count-buy">买{{ s.buy_count || 0 }}</span>
              <span class="count-sell">卖{{ s.sell_count || 0 }}</span>
            </div>
          </div>
          <div
            v-if="stocks.length === 0 && !stocksLoading"
            class="stock-empty"
          >
            暂无股票数据
          </div>
        </div>
      </div>

      <!-- Right: Chart area -->
      <div class="stock-chart-area">
        <div
          v-if="selectedStock"
          class="stock-chart-header"
        >
          <span class="stock-chart-code">{{ selectedStock }}</span>
          <span
            v-if="currentStock?.name"
            class="stock-chart-name"
          >{{ currentStock.name }}</span>
          <span
            v-if="currentStock"
            class="stock-chart-counts"
          >
            <span class="count-buy">买 {{ currentStock.buy_count || 0 }}</span>
            <span class="count-sell">卖 {{ currentStock.sell_count || 0 }}</span>
          </span>
          <button
            class="stock-chart-close"
            @click="selectedStock = ''"
          >
            ×
          </button>
        </div>

        <Loading
          v-if="loading"
          text="加载K线数据..."
          size="sm"
        />

        <div
          v-else-if="chartError"
          class="stock-error"
        >
          {{ chartError }}
        </div>

        <div
          v-else-if="klineData"
          class="stock-chart-wrap"
        >
          <div
            ref="chartRef"
            class="stock-echarts"
          />
          <div
            v-if="stockTrades"
            class="stock-chart-footer"
          >
            <span>共{{ stockTrades.trades?.length || 0 }}笔</span>
            <span class="count-buy">买入 {{ stockTrades.buy_count || 0 }}</span>
            <span class="count-sell">卖出 {{ stockTrades.sell_count || 0 }}</span>
          </div>
        </div>

        <EmptyState
          v-else
          title="从左侧选择股票"
          description="选择股票查看K线图"
        />
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, nextTick, onUnmounted } from 'vue';
import type { PropType } from 'vue';
import { backtestApi } from '@/api/backtest';
import { klineApi } from '@/api/kline';
import { getEcharts } from '@/utils/echarts';
import { normalizeDate, findNearestDateIndex } from '@/utils/date';

interface StockInfo {
  code: string;
  name?: string;
  buy_count?: number;
  sell_count?: number;
}

interface StockTrade {
  date?: string;
  price?: string | number;
  volume?: string | number;
  action?: string;
}

interface KlineItem {
  date?: string;
  datetime?: string;
  open?: string | number;
  close?: string | number;
  high?: string | number;
  low?: string | number;
  volume?: string | number;
}

const props = defineProps({
  detailPath: {
    type: String as PropType<string>,
    required: true,
  },
  strategyBase: {
    type: String as PropType<string>,
    default: '',
  },
});

// ── Stock list ────────────────────────────────────────
const stocks = ref<StockInfo[]>([]);
const stocksLoading = ref(false);
const stockSearch = ref('');
const selectedStock = ref('');
const source = ref<'daily' | '1h'>('daily');
let userTouchedSource = false; // 用户是否手动切换过 source

const filteredStocks = computed(() => {
  const q = stockSearch.value.trim().toLowerCase();
  if (!q) return stocks.value.slice(0, 50);
  return stocks.value
    .filter((s) => s.code.toLowerCase().includes(q) || (s.name || '').toLowerCase().includes(q))
    .slice(0, 50);
});

const currentStock = computed(() => stocks.value.find((s) => s.code === selectedStock.value));

// ── Chart state ───────────────────────────────────────
const chartRef = ref<HTMLElement | null>(null);
const klineData = ref<KlineItem[] | null>(null);
const stockTrades = ref<{ trades?: StockTrade[]; buy_count?: number; sell_count?: number } | null>(null);
const loading = ref(false);
const chartError = ref('');

let chartInstance: any = null;
let resizeObserver: ResizeObserver | null = null;
const handleResize = () => chartInstance?.resize();
let lastLoadedPath = '';
let isMounted = true;
let isProgrammaticSourceChange = false; // 防止代码同步 source 时触发 watcher

// ── Load stock list ───────────────────────────────────
async function loadStockList() {
  if (!props.detailPath) return;
  if (lastLoadedPath === props.detailPath) return;
  lastLoadedPath = props.detailPath;
  stocksLoading.value = true;
  try {
    const d: any = await backtestApi.getTradeStocks(props.detailPath, props.strategyBase || '');
    stocks.value = d.stocks || [];
  } catch (e) {
    console.error('Failed to load stock list', e);
  } finally {
    stocksLoading.value = false;
  }
}

// ── Load stock chart ─────────────────────────────────
async function loadStockChart(code: string) {
  if (!code || !props.detailPath) return;
  selectedStock.value = code;
  loading.value = true;
  chartError.value = '';
  klineData.value = null;
  stockTrades.value = null;

  if (chartInstance) {
    chartInstance.dispose();
    chartInstance = null;
  }

  try {
    const autoSource = props.detailPath.includes('stock_1h') ? '1h' : 'daily';
    // 用户手动切换过 source → 尊重用户选择；否则用 autoSource 推断
    const src = userTouchedSource ? source.value : autoSource;
    // 同步 source 下拉框到实际使用的数据源（程序同步，不算用户操作）
    if (source.value !== src) {
      isProgrammaticSourceChange = true;
      source.value = src as 'daily' | '1h';
      nextTick(() => { isProgrammaticSourceChange = false; });
    }

    const klinePromise = klineApi.getData(src, code, 5000);
    const tradesPromise = backtestApi.getTradesByStock(props.detailPath, props.strategyBase ?? '', code);

    let klineResp: any = await klinePromise.catch(() => null);
    const tradesResp: any = await tradesPromise.catch(() => null);

    if (!klineResp || klineResp.detail || !klineResp.data || klineResp.data.length === 0) {
      const fallbackSrc = src === '1h' ? 'daily' : '1h';
      const fallback: any = await klineApi.getData(fallbackSrc, code, 5000).catch(() => null);
      if (fallback && !fallback.detail && fallback.data && fallback.data.length > 0) {
        klineResp = fallback;
      }
    }

    if (!klineResp || klineResp.detail || !klineResp.data || klineResp.data.length === 0) {
      chartError.value = `未找到K线数据 ${code}`;
    } else {
      klineData.value = klineResp.data;
    }
    if (tradesResp) stockTrades.value = tradesResp;
  } catch (e: any) {
    if (!isMounted) return;
    chartError.value = '加载失败: ' + (e?.message || String(e));
  } finally {
    if (isMounted) {
      loading.value = false;
    }
  }
}

// ── Render ECharts ────────────────────────────────────
async function renderChart() {
  if (!chartRef.value || !klineData.value || klineData.value.length === 0) return;

  if (chartInstance) {
    chartInstance.dispose();
    chartInstance = null;
  }

  const ec = await getEcharts();
  const isDark = document.documentElement.getAttribute('data-theme') !== 'light';
  const textColor = isDark ? '#9ca3af' : '#374151';
  const gridColor = isDark ? '#1f1f2e' : '#e5e7eb';
  // 红涨绿跌：涨=红，跌=绿 (Preact 一致)
  const upColor = '#ef4444';
  const downColor = '#22c55e';

  const dates: string[] = [];
  const candlestickData: [number, number, number, number][] = [];
  const volumeData: { value: number; itemStyle: { color: string } }[] = [];

  (klineData.value as KlineItem[]).forEach((d) => {
    const dt = normalizeDate(d.date || d.datetime);
    dates.push(dt);
    candlestickData.push([
      parseFloat(String(d.open)) || 0,
      parseFloat(String(d.close)) || 0,
      parseFloat(String(d.low)) || 0,
      parseFloat(String(d.high)) || 0,
    ]);
    const vol = parseFloat(String(d.volume)) || 0;
    const cl = parseFloat(String(d.close)) || 0;
    const op = parseFloat(String(d.open)) || 0;
    volumeData.push({ value: vol, itemStyle: { color: cl >= op ? upColor + '66' : downColor + '66' } });
  });

  const dateIndex: Record<string, number> = {};
  dates.forEach((d, i) => { dateIndex[d] = i; });

  // ── 买卖点标记（scatter 系列，比 markPoint 更稳定） ──
  const buyScatterData: any[] = [];
  const sellScatterData: any[] = [];

  if (stockTrades.value?.trades) {
    const buyCountByDate: Record<string, number> = {};
    const sellCountByDate: Record<string, number> = {};
    (stockTrades.value.trades as StockTrade[]).forEach((t) => {
      const origDt = normalizeDate(t.date);
      const idx = findNearestDateIndex(origDt, dateIndex);
      if (idx === undefined) return;
      const price = parseFloat(String(t.price)) || 0;
      const action = String(t.action || '');
      if (action.includes('买') || action === 'buy') {
        const cnt = (buyCountByDate[origDt] || 0);
        buyCountByDate[origDt] = cnt + 1;
        const xOff = (cnt % 2 === 0 ? -1 : 1) * Math.ceil(cnt / 2) * 14;
        buyScatterData.push({
          value: [idx, price],
          symbolOffset: [xOff, '-35%'],
          label: {
            show: true,
            formatter: 'B',
            position: 'inside',
            fontSize: 10,
            fontWeight: 'bold',
            color: '#fff',
          },
          itemStyle: {
            color: '#ef4444',
            borderColor: '#fee2e2',
            borderWidth: 1,
            shadowBlur: 6,
            shadowColor: 'rgba(239,68,68,0.4)',
          },
        });
      } else if (action.includes('卖') || action === 'sell') {
        const cnt = (sellCountByDate[origDt] || 0);
        sellCountByDate[origDt] = cnt + 1;
        const xOff = (cnt % 2 === 0 ? -1 : 1) * Math.ceil(cnt / 2) * 14;
        sellScatterData.push({
          value: [idx, price],
          symbolOffset: [xOff, '35%'],
          label: {
            show: true,
            formatter: 'S',
            position: 'inside',
            fontSize: 10,
            fontWeight: 'bold',
            color: '#fff',
          },
          itemStyle: {
            color: '#22c55e',
            borderColor: '#dcfce7',
            borderWidth: 1,
            shadowBlur: 6,
            shadowColor: 'rgba(34,197,94,0.4)',
          },
        });
      }
    });
  }

  const zoomStart = Math.max(0, 100 - Math.round(500 / dates.length * 100));

  chartInstance = ec.init(chartRef.value, isDark ? 'custom-dark' : null, { renderer: 'canvas' });
  chartInstance.setOption({
    backgroundColor: 'transparent',
    animation: false,
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'cross' },
      backgroundColor: isDark ? '#0f0f14' : '#ffffff',
      borderColor: gridColor,
      textStyle: { color: textColor, fontSize: 12 },
      formatter: (params: any[]) => {
        if (!params?.length) return '';
        const idx = params[0].dataIndex;
        const dt = dates[idx];
        let h = `<div style="font-weight:600;margin-bottom:4px;">${dt}</div>`;
        params.forEach((p: any) => {
          if (p.seriesType === 'candlestick') {
            const d = p.data;
            h += `<div style="display:flex;gap:10px;"><span>开:${parseFloat(d[0]).toFixed(2)}</span><span>收:${parseFloat(d[1]).toFixed(2)}</span><span>低:${parseFloat(d[2]).toFixed(2)}</span><span>高:${parseFloat(d[3]).toFixed(2)}</span></div>`;
          } else if (p.seriesType === 'bar') {
            h += `<div>成交量: ${(p.value || 0).toLocaleString()}</div>`;
          }
        });
        if (stockTrades.value?.trades) {
          const dayTrades = stockTrades.value.trades.filter((t: StockTrade) => normalizeDate(t.date) === dt);
          dayTrades.forEach((t: StockTrade) => {
            const isBuy = String(t.action || '').includes('买') || t.action === 'buy';
            const col = isBuy ? '#ef4444' : '#22c55e';
            h += `<div style="color:${col};font-weight:600;margin-top:4px;">${isBuy ? '▲ B' : '▼ S'} @ ${parseFloat(String(t.price)).toFixed(2)}${t.volume ? ' x' + parseInt(String(t.volume)) : ''}</div>`;
          });
        }
        return h;
      },
    },
    axisPointer: { link: [{ xAxisIndex: 'all' }] },
    legend: { data: ['K线', '成交量'], top: 0, textStyle: { color: textColor, fontSize: 11 }, itemWidth: 14, itemHeight: 10 },
    grid: [
      { left: 55, right: 16, top: 28, bottom: 24, height: '62%' },
      { left: 55, right: 16, top: '74%', bottom: 24, height: '18%' },
    ],
    xAxis: [
      { type: 'category', data: dates, gridIndex: 0, boundaryGap: false, axisLine: { lineStyle: { color: gridColor } }, axisTick: { show: false }, axisLabel: { color: textColor, fontSize: 10 }, splitLine: { show: false } },
      { type: 'category', data: dates, gridIndex: 1, boundaryGap: false, axisLine: { lineStyle: { color: gridColor } }, axisTick: { show: false }, axisLabel: { show: false }, splitLine: { show: false } },
    ],
    yAxis: [
      { scale: true, gridIndex: 0, axisLine: { lineStyle: { color: gridColor } }, axisTick: { show: false }, axisLabel: { color: textColor, fontSize: 10 }, splitLine: { lineStyle: { color: gridColor, type: 'dashed' } } },
      { scale: true, gridIndex: 1, splitNumber: 2, axisLine: { show: false }, axisTick: { show: false }, axisLabel: { show: false }, splitLine: { show: false } },
    ],
    dataZoom: [
      { type: 'inside', xAxisIndex: [0, 1], start: zoomStart, end: 100 },
    ],
    series: [
      {
        name: 'K线',
        type: 'candlestick',
        xAxisIndex: 0,
        yAxisIndex: 0,
        data: candlestickData,
        itemStyle: { color: upColor, color0: downColor, borderColor: upColor, borderColor0: downColor },
      },
      { name: '成交量', type: 'bar', xAxisIndex: 1, yAxisIndex: 1, data: volumeData, barMaxWidth: 6 },
      ...(buyScatterData.length ? [{
        name: '买入',
        type: 'scatter',
        xAxisIndex: 0,
        yAxisIndex: 0,
        data: buyScatterData,
        symbol: 'path://M10,1 L16,7 L12,7 L12,18 L8,18 L8,7 L4,7 Z',
        symbolSize: 20,
        z: 10,
        tooltip: { show: false },
      }] : []),
      ...(sellScatterData.length ? [{
        name: '卖出',
        type: 'scatter',
        xAxisIndex: 0,
        yAxisIndex: 0,
        data: sellScatterData,
        symbol: 'path://M10,1 L16,7 L12,7 L12,18 L8,18 L8,7 L4,7 Z',
        symbolRotate: 180,
        symbolSize: 20,
        z: 10,
        tooltip: { show: false },
      }] : []),
    ],
  });

  window.addEventListener('resize', handleResize);

  // ResizeObserver: 监听容器尺寸变化（ResizableChart 拖拽高度时触发）
  resizeObserver?.disconnect();
  resizeObserver = new ResizeObserver(() => {
    chartInstance?.resize();
  });
  if (chartRef.value) {
    resizeObserver.observe(chartRef.value);
  }
}

// ── Watchers ──────────────────────────────────────────
watch([klineData, stockTrades], () => {
  if (klineData.value) {
    nextTick(() => renderChart());
  }
});

watch(source, () => {
  if (isProgrammaticSourceChange) return; // 代码同步 source，不算用户操作
  userTouchedSource = true;
  if (selectedStock.value) {
    loadStockChart(selectedStock.value);
  }
});

watch(() => props.detailPath, (newPath) => {
  if (!newPath) return;
  // detailPath 变了，说明用户切换了策略 → 重置状态，重新加载股票列表
  lastLoadedPath = '';
  userTouchedSource = false;
  selectedStock.value = '';
  klineData.value = null;
  stockTrades.value = null;
  if (chartInstance) {
    chartInstance.dispose();
    chartInstance = null;
  }
  loadStockList();
});

// ── Lifecycle ─────────────────────────────────────────
loadStockList();

onUnmounted(() => {
  isMounted = false;
  window.removeEventListener('resize', handleResize);
  resizeObserver?.disconnect();
  chartInstance?.dispose();
  chartInstance = null;
});
</script>

<style scoped>
.bt-section {
  border: 1px solid var(--border);
  border-radius: var(--radius-md);
  overflow: hidden;
  height: 100%;
  display: flex;
  flex-direction: column;
}

.bt-section__header {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  padding: 9px 14px;
  background: var(--bg-secondary);
  border-bottom: 1px solid var(--border);
}

.bt-section__title {
  font-size: var(--font-sm);
  font-weight: 700;
  color: var(--text-primary);
  letter-spacing: 0.3px;
}

.stock-chart-layout {
  display: flex;
  flex: 1;
  min-height: 0;
  height: 100%;
}

.stock-list {
  width: 170px;
  flex-shrink: 0;
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.stock-search-wrap {
  padding: var(--space-3) var(--space-4);
  border-bottom: 1px solid var(--border);
}

.stock-search {
  width: 100%;
  font-size: var(--font-xs);
  height: var(--h-sm);
  padding: 0 8px;
}

.stock-items {
  flex: 1;
  overflow-y: auto;
  padding: var(--space-2);
}

.stock-item {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: var(--space-2) var(--space-3);
  cursor: pointer;
  border-radius: 5px;
  margin-bottom: 2px;
  transition: background 0.1s;
}

.stock-item:hover { background: var(--bg-hover); }

.stock-item--active {
  background: var(--accent-dim);
}

.stock-item-top {
  display: flex;
  align-items: center;
  gap: var(--space-1);
}

.stock-code {
  font-size: var(--font-sm);
  font-weight: 700;
  color: var(--accent);
}

.stock-name {
  font-size: var(--font-2xs);
  color: var(--text-muted);
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.stock-item-counts {
  display: flex;
  gap: var(--space-2);
}

.count-buy { font-size: var(--font-2xs); color: #ef4444; font-weight: 600; }
.count-sell { font-size: var(--font-2xs); color: #22c55e; font-weight: 600; }

.stock-empty {
  padding: var(--space-3) var(--space-2);
  text-align: center;
  color: var(--text-muted);
  font-size: var(--font-xs);
}

.stock-chart-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  padding: var(--space-2) var(--space-3);
}

.stock-chart-header {
  display: flex;
  align-items: center;
  gap: var(--space-4);
  margin-bottom: var(--space-2);
  padding: 4px 8px;
  background: var(--bg-secondary);
  border-radius: var(--radius);
  border: 1px solid var(--border);
}

.stock-chart-code {
  font-size: var(--font-md);
  font-weight: 700;
  color: var(--accent);
}

.stock-chart-name {
  font-size: var(--font-sm);
  color: var(--text-secondary);
}

.stock-chart-counts {
  margin-left: auto;
  font-size: var(--font-xs);
  display: flex;
  gap: var(--space-3);
}

.stock-chart-close {
  background: none;
  border: none;
  color: var(--text-muted);
  cursor: pointer;
  font-size: 16px;
  padding: 0 4px;
  line-height: 1;
}

.stock-error {
  flex: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--text-muted);
  font-size: var(--font-sm);
}

.stock-chart-wrap {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
}

.stock-echarts {
  flex: 1;
  min-height: 0;
  width: 100%;
}

.stock-chart-footer {
  display: flex;
  gap: var(--space-5);
  margin-top: var(--space-2);
  font-size: var(--font-xs);
  color: var(--text-muted);
}

.spinner {
  width: 22px;
  height: 22px;
  border: 2px solid var(--border);
  border-top-color: var(--accent);
  border-radius: 50%;
  animation: spin 0.8s linear infinite;
}

@keyframes spin { to { transform: rotate(360deg); } }

.select {
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 2px 6px;
  font-size: var(--font-xs);
  height: var(--h-sm);
  background: var(--bg-primary);
  color: var(--text-primary);
  outline: none;
  cursor: pointer;
}
.select:focus { border-color: var(--accent); }

.input {
  border: 1px solid var(--border);
  border-radius: var(--radius);
  padding: 0 8px;
  font-family: inherit;
  color: var(--text-primary);
  background: var(--bg-primary);
  outline: none;
  box-sizing: border-box;
}
.input:focus { border-color: var(--accent); }
</style>
