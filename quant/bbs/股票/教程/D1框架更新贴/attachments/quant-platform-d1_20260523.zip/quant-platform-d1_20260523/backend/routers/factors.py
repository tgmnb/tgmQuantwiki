﻿# -*- coding: utf-8 -*-
"""D1 Quant Platform - Factors Router"""

from pathlib import Path
from fastapi import APIRouter, Depends, Query
from fastapi.responses import JSONResponse

import config

router = APIRouter(prefix="/api/factors")

_FACTOR_REL = "factor_calculate/factor_hub"


def require_quant_proj() -> Path:
    if not config.QUANT_PROJ or not config.QUANT_PROJ.exists():
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail="QUANT_PROJ not configured")
    return config.QUANT_PROJ


@router.get("/list")
async def list_factors(quant_proj: Path = Depends(require_quant_proj)):
    """List all available factors from factor_hub directories."""
    from services.platform_context import PlatformContext
    ctx = PlatformContext(quant_proj).build()
    # Transform to include full path
    factors = ctx.get("factors", {})
    result = {}
    for cat, files in factors.items():
        result[cat] = [f"{_FACTOR_REL}/{cat}/{f}" for f in files]
    return {"factors": result}


@router.get("/content")
async def get_factor_content(path: str = Query(...), limit: int = Query(300)):
    """读取因子 Python 代码内容"""
    from routers._code_reader import read_code_file
    return read_code_file(config.QUANT_PROJ, path, limit)


@router.post("/save")
async def save_factor_code(data: dict, quant_proj: Path = Depends(require_quant_proj)):
    """保存因子 Python 代码"""
    import re

    path = data.get("path", "")
    content = data.get("content", "")

    # 安全修复：修正正则，字符类外需要 + 量词来匹配多字符路径
    if not re.match(r'^[a-zA-Z0-9_\-/+]+\.py$', path):
        return JSONResponse(status_code=400, content={"success": False, "detail": "Invalid path"})

    target = quant_proj / path
    factor_root = quant_proj / _FACTOR_REL
    try:
        if not target.resolve().is_relative_to(factor_root.resolve()):
            return JSONResponse(status_code=403, content={"success": False, "detail": "只能保存到 factor_calculate/factor_hub 目录下"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"success": False, "detail": "路径校验失败"})
    try:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(content, encoding="utf-8")
        return {"success": True}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "detail": str(e)})


@router.post("/delete")
async def delete_factor_code(data: dict, quant_proj: Path = Depends(require_quant_proj)):
    """删除因子 Python 代码文件"""
    import re

    path = data.get("path", "")
    # 安全修复：修正正则
    if not re.match(r'^[a-zA-Z0-9_\-/+]+\.py$', path):
        return JSONResponse(status_code=400, content={"success": False, "detail": "Invalid path"})

    target = quant_proj / path
    factor_root = quant_proj / _FACTOR_REL
    try:
        if not target.resolve().is_relative_to(factor_root.resolve()):
            return JSONResponse(status_code=403, content={"success": False, "detail": "只能删除 factor_calculate/factor_hub 目录下的文件"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"success": False, "detail": "路径校验失败"})

    if not target.exists():
        return JSONResponse(status_code=404, content={"success": False, "detail": "文件不存在"})

    try:
        target.unlink()
        return {"success": True}
    except Exception as e:
        return JSONResponse(status_code=500, content={"success": False, "detail": str(e)})
