import { request } from './request';

export const timingApi = {
  async list() {
    return request.get('/api/timing/list');
  },

  async getContent(path: string) {
    return request.get('/api/timing/content', { params: { path } });
  },

  async save(path: string, content: string) {
    return request.post('/api/timing/save', { path, content });
  },

  async delete(path: string) {
    return request.post('/api/timing/delete', { path });
  },
};
