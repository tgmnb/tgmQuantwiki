# -*- coding: utf-8 -*-
"""
终端路由 — WebSocket 终端 + 路径查询
"""

from __future__ import annotations

import asyncio
import json
import logging

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect

from services.terminal_service import create_session, remove_session, get_cwd_path

logger = logging.getLogger("quant.terminal")

router = APIRouter(prefix="/api/terminal", tags=["terminal"])


@router.get("/path")
async def terminal_path():
    return {"path": get_cwd_path()}


@router.websocket("/ws")
async def terminal_ws(ws: WebSocket, cols: int = Query(80), rows: int = Query(24)):
    await ws.accept()
    session = create_session(cols=cols, rows=rows)
    logger.info("WebSocket 终端连接, session=%s", session.id)

    async def read_pty():
        loop = asyncio.get_event_loop()
        while True:
            try:
                data = await loop.run_in_executor(None, session.read, 4096)
                if data:
                    await ws.send_text(data)
                else:
                    await asyncio.sleep(0.01)
            except Exception:
                break

    read_task = asyncio.create_task(read_pty())

    try:
        while True:
            msg = await ws.receive_text()
            try:
                parsed = json.loads(msg)
                if isinstance(parsed, dict):
                    if parsed.get("type") == "resize":
                        session.resize(parsed.get("cols", 80), parsed.get("rows", 24))
                        continue
                    if parsed.get("type") == "input":
                        session.write(parsed.get("data", ""))
                        continue
            except (json.JSONDecodeError, KeyError):
                pass
            session.write(msg)
    except WebSocketDisconnect:
        logger.info("WebSocket 终端断开, session=%s", session.id)
    finally:
        read_task.cancel()
        remove_session(session.id)
