<template>
  <div
    class="metric-badge"
    :class="[colorClass, `metric-badge--${variant}`, `metric-badge--${size}`]"
  >
    <span class="metric-badge__label">{{ label }}</span>
    <span class="metric-badge__value">{{ formattedValue }}</span>
    <span
      v-if="trend !== 'neutral' && variant !== 'inline'"
      class="metric-badge__trend"
    >
      {{ trend === 'up' ? '↑' : '↓' }}
    </span>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';

interface Props {
  label: string;
  value: number | string;
  trend?: 'up' | 'down' | 'neutral';
  precision?: number;
  format?: 'number' | 'percent' | 'currency' | 'raw';
  variant?: 'badge' | 'card' | 'inline';
  size?: 'sm' | 'md' | 'lg';
  thresholds?: { good?: number; warn?: number; invert?: boolean };
}

const props = withDefaults(defineProps<Props>(), {
  trend: 'neutral',
  precision: 2,
  format: 'raw',
  variant: 'badge',
  size: 'md',
});

const formattedValue = computed(() => {
  if (typeof props.value === 'string') return props.value;
  if (typeof props.value !== 'number') return String(props.value);

  // 百分比格式：自动检测 < 1 的值
  if (props.format === 'percent' || (props.format !== 'raw' && props.format !== 'number' && props.format !== 'currency' && Math.abs(props.value) < 1)) {
    return (props.value * 100).toFixed(props.precision) + '%';
  }
  if (props.format === 'currency') return '¥' + props.value.toFixed(props.precision);
  if (props.format === 'raw') return String(props.value);
  return props.value.toFixed(props.precision);
});

const colorClass = computed(() => {
  if (props.thresholds) {
    const { good, warn, invert } = props.thresholds;
    const v = typeof props.value === 'number' ? props.value : 0;
    const isGood = invert ? v < good! : v > good!;
    const isWarn = invert ? v >= good! && v < warn! : v < warn!;
    if (isGood) return 'metric-badge--good';
    if (isWarn) return 'metric-badge--warn';
    return 'metric-badge--bad';
  }
  if (props.trend === 'up') return 'metric-badge--up';
  if (props.trend === 'down') return 'metric-badge--down';
  return 'metric-badge--neutral';
});
</script>

<style scoped>
.metric-badge {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 4px 10px;
  border-radius: 12px;
  font-size: 13px;
  background-color: var(--bg-secondary);
  border: 1px solid var(--border-color);
  transition: all 0.2s;
}

.metric-badge--up {
  background-color: rgba(16, 185, 129, 0.1);
  border-color: var(--accent-success);
  color: var(--accent-success);
}

.metric-badge--down {
  background-color: rgba(239, 68, 68, 0.1);
  border-color: var(--accent-danger);
  color: var(--accent-danger);
}

.metric-badge--neutral {
  color: var(--text-primary);
}

.metric-badge--good { background-color: rgba(16, 185, 129, 0.1); border-color: var(--up); color: var(--up); }
.metric-badge--warn { background-color: rgba(249, 115, 22, 0.1); border-color: var(--warn); color: var(--warn); }
.metric-badge--bad { background-color: rgba(239, 68, 68, 0.1); border-color: var(--down); color: var(--down); }

/* variant */
.metric-badge--card { flex-direction: column; align-items: flex-start; padding: 12px; border-radius: 8px; }
.metric-badge--inline { background: transparent; border: none; padding: 0; }

/* size */
.metric-badge--sm { font-size: 11px; padding: 2px 6px; }
.metric-badge--lg { font-size: 16px; padding: 6px 14px; }

.metric-badge__label {
  color: var(--text-secondary);
  font-size: 12px;
}

.metric-badge__value {
  font-weight: 600;
}

.metric-badge--up .metric-badge__value,
.metric-badge--down .metric-badge__value {
  color: inherit;
}

.metric-badge__trend {
  font-size: 14px;
  font-weight: 700;
}
</style>
