import { request } from './request';
import type {
  Strategy,
  StrategyConfigResponse,
  StrategyFilesResponse,
  FileContentResponse,
  SaveFileResponse,
  RunBacktestRequest,
  RunBacktestResponse,
  CreateStrategyResponse,
  HistoryResponse,
} from '@/types/api';

export const builderApi = {
  /** 策略列表 (扫描) */
  async listStrategies(): Promise<{ strategies: Strategy[] }> {
    return request.get('/api/builder/strategies');
  },

  /** 获取模块列表 */
  async getModules(type: string): Promise<{ selections: unknown[]; timing: { timing: unknown[]; risk: unknown[] } }> {
    return request.get('/api/builder/modules', { params: { type } });
  },

  /** 获取策略配置 */
  async getStrategyConfig(type: string, name: string): Promise<StrategyConfigResponse> {
    return request.get(`/api/builder/strategy/${type}/${name}`);
  },

  /** 启动回测 */
  async runBacktest(payload: RunBacktestRequest): Promise<RunBacktestResponse> {
    return request.post('/api/builder/run', payload);
  },

  /** 停止回测 */
  async stopTask(taskId: string): Promise<void> {
    return request.post(`/api/builder/stop/${taskId}`);
  },

  /** 历史记录 */
  async getHistory(params?: { page?: number; page_size?: number }): Promise<HistoryResponse> {
    return request.get('/api/builder/history', { params });
  },

  /** 策略文件列表 */
  async getStrategyFiles(path: string): Promise<StrategyFilesResponse> {
    return request.get('/api/strategies/config', { params: { path } });
  },

  /** 获取文件内容 */
  async getFileContent(path: string, limit?: number): Promise<FileContentResponse> {
    const params: Record<string, unknown> = { path };
    if (limit) params.limit = limit;
    return request.get('/api/strategies/content', { params });
  },

  /** 保存文件 */
  async saveFile(payload: { path: string; file: string; content: string }): Promise<SaveFileResponse> {
    return request.post('/api/strategies/save', payload);
  },

  /** 创建策略 */
  async createStrategy(name: string, backtestType: string): Promise<CreateStrategyResponse> {
    return request.post('/api/strategies/create', { name, backtest_type: backtestType });
  },

  /** 删除策略 */
  async deleteStrategy(name: string, backtestType: string): Promise<void> {
    return request.post('/api/strategies/delete_dir', { name, backtest_type: backtestType });
  },

  /** 保存策略配置（stg_config.py） */
  async saveStrategyConfig(payload: {
    strategy_name: string;
    backtest_type: string;
    strategy_config: Record<string, unknown>;
    timing_config: Record<string, unknown>;
    data_source?: Record<string, unknown>;
  }): Promise<{ success: boolean; path: string }> {
    return request.post('/api/builder/save_config', payload);
  },
};
