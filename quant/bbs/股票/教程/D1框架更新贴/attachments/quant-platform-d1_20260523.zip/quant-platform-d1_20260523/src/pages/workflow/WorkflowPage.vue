<template>
  <div class="workflow-page">
    <SimplifiedWorkflow />
  </div>
</template>

<script setup lang="ts">
import SimplifiedWorkflow from './SimplifiedWorkflow.vue'
</script>

<style scoped>
.workflow-page {
  display: flex;
  height: 100%;
  width: 100%;
}
</style>
