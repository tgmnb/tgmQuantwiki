<template>
  <div class="code-mode">
    <!-- File Sidebar -->
    <div class="file-sidebar">
      <div class="file-sidebar__header">
        <el-icon><Folder /></el-icon>
        <span>文件</span>
        <span
          v-if="fileNames.length"
          class="file-count"
        >{{ fileNames.length }}</span>
      </div>
      <div class="file-sidebar__body">
        <div
          v-for="fname in fileNames"
          :key="fname"
          class="file-item"
          :class="{ 'file-item--active': activeFile === fname }"
          @click="onSelectFile(fname)"
        >
          <el-icon :size="14">
            <component :is="fileIcon(fname)" />
          </el-icon>
          <span class="file-item__name">{{ fname }}</span>
          <span
            v-if="isEditing && activeFile === fname && isModified"
            class="file-item__modified"
            title="有未保存的修改"
          >●</span>
        </div>
        <div
          v-if="!fileNames.length"
          class="file-empty"
        >
          <el-icon :size="20">
            <DocumentDelete />
          </el-icon>
          <span>暂无文件</span>
        </div>
      </div>
    </div>

    <!-- Editor Area -->
    <div class="editor-area">
      <!-- Toolbar -->
      <div class="editor-toolbar">
        <div class="toolbar-left">
          <template v-if="activeFile">
            <el-icon :size="14">
              <component :is="fileIcon(activeFile)" />
            </el-icon>
            <el-text
              size="small"
              class="filename-text"
              truncated
            >
              {{ activeFile }}
            </el-text>
            <el-tag
              v-if="isEditing && isModified"
              size="small"
              type="warning"
              effect="plain"
            >
              已修改
            </el-tag>
            <el-tag
              v-else-if="isEditing && !isModified"
              size="small"
              type="success"
              effect="plain"
            >
              已保存
            </el-tag>
          </template>
        </div>

        <div class="toolbar-right">
          <!-- View Mode Actions -->
          <template v-if="!isEditing">
            <el-button
              size="small"
              text
              :disabled="!activeFile"
              @click="startEdit"
            >
              <el-icon><EditPen /></el-icon>
              编辑
            </el-button>
            <el-button
              size="small"
              text
              :disabled="!activeFile"
              @click="copyToClipboard"
            >
              <el-icon><CopyDocument /></el-icon>
              复制
            </el-button>
          </template>

          <!-- Edit Mode Actions -->
          <template v-else>
            <el-text
              size="small"
              type="info"
              class="shortcut-hint"
            >
              Ctrl+S 保存
            </el-text>
            <el-button
              size="small"
              @click="cancelEdit"
            >
              取消
            </el-button>
            <el-button
              size="small"
              type="primary"
              :loading="isSaving"
              :disabled="!isModified"
              @click="saveEdit"
            >
              {{ isSaving ? '保存中...' : '保存' }}
            </el-button>
          </template>

          <el-divider direction="vertical" />

          <el-button
            size="small"
            text
            type="primary"
            @click="emit('switch:mode', 'visual')"
          >
            <el-icon><SetUp /></el-icon>
            可视化
          </el-button>
        </div>
      </div>

      <!-- Breadcrumb -->
      <div
        v-if="selectedStrategy"
        class="editor-breadcrumb"
      >
        <el-icon :size="12">
          <FolderOpened />
        </el-icon>
        <el-text
          size="small"
          type="info"
        >
          {{ selectedStrategy.path }}
        </el-text>
      </div>

      <!-- Content -->
      <div class="editor-content">
        <!-- Empty State -->
        <div
          v-if="!selectedStrategy"
          class="editor-empty"
        >
          <EmptyState title="选择左侧策略以查看代码" />
        </div>
        <div
          v-else-if="!activeFile"
          class="editor-empty"
        >
          <EmptyState title="该策略暂无代码文件" />
        </div>

        <!-- CodeMirror (edit & read-only view) -->
        <div
          v-else
          class="codemirror-wrap"
        >
          <CodeEditor
            v-model="editContent"
            :readonly="!isEditing"
            height="100%"
            @change="onEditChange"
            @save="saveEdit"
          />
        </div>
      </div>

      <!-- Status Bar -->
      <div
        v-if="isEditing"
        class="status-bar"
      >
        <span class="status-item">{{ fileTypeLabel }}</span>
        <span class="status-item">{{ lineCount }} 行</span>
        <span
          v-if="saveMsg"
          class="status-item"
          :class="saveMsg.type === 'success' ? 'status-ok' : 'status-err'"
        >
          {{ saveMsg.text }}
        </span>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue';
import type { PropType } from 'vue';
import {
  Folder, FolderOpened, EditPen, CopyDocument, SetUp,
  DocumentDelete,
} from '@element-plus/icons-vue';
import { builderApi } from '@/api/builder';
import CodeEditor from '@/components/editor/CodeEditor.vue';

const props = defineProps({
  selectedStrategy: { type: Object as PropType<any>, default: null },
  backtestType: { type: String, default: 'stock_daily' },
  configSaveVersion: { type: Number, default: 0 },
});

const emit = defineEmits(['switch:mode']);

const files = ref<Record<string, { lines?: string[] }>>({});
const activeFile = ref('');
const isEditing = ref(false);
const editContent = ref('');
const isModified = ref(false);
const isSaving = ref(false);
const saveMsg = ref<{ type: 'success' | 'danger'; text: string } | null>(null);

const fileNames = computed(() => {
  return Object.keys(files.value).sort((a, b) => {
    if (a === 'stg_config.py') return -1;
    if (b === 'stg_config.py') return 1;
    if (a === 'strategy.py') return -1;
    if (b === 'strategy.py') return 1;
    return a.localeCompare(b);
  });
});

const currentLines = computed(() => {
  return files.value[activeFile.value]?.lines || [];
});

const lineCount = computed(() => editContent.value.split('\n').length);

const fileTypeLabel = computed(() => {
  if (activeFile.value.endsWith('.py')) return 'Python';
  if (activeFile.value.endsWith('.json')) return 'JSON';
  if (activeFile.value.endsWith('.yaml') || activeFile.value.endsWith('.yml')) return 'YAML';
  if (activeFile.value.endsWith('.md')) return 'Markdown';
  return 'Text';
});

function fileIcon(fname: string) {
  if (fname.endsWith('.py')) return 'DocumentChecked';
  if (fname.endsWith('.json')) return 'Document';
  if (fname.endsWith('.yaml') || fname.endsWith('.yml')) return 'Document';
  if (fname.endsWith('.md')) return 'Document';
  return 'Document';
}

onMounted(async () => { await loadStrategyFiles(); });

watch(() => props.selectedStrategy?.path, async () => {
  await loadStrategyFiles();
});

watch(() => props.configSaveVersion, async (newVal) => {
  if (newVal > 0 && props.selectedStrategy) {
    await loadStrategyFiles();
  }
});

async function loadStrategyFiles() {
  isEditing.value = false;
  editContent.value = '';
  saveMsg.value = null;
  isModified.value = false;

  if (!props.selectedStrategy) {
    files.value = {};
    activeFile.value = '';
    return;
  }
  try {
    const d = await builderApi.getStrategyFiles(props.selectedStrategy.path);
    files.value = d.files || {};
    const keys = Object.keys(d.files || {});
    activeFile.value = keys.includes('stg_config.py') ? 'stg_config.py' : keys[0] || '';
    if (activeFile.value) {
      editContent.value = currentLines.value.join('\n');
    }
  } catch (e) {
    console.error('Failed to load strategy files', e);
    files.value = {};
    activeFile.value = '';
  }
}

async function onSelectFile(fname: string) {
  if (isEditing.value && isModified && fname !== activeFile.value) {
    try {
      await ElMessageBox.confirm('当前文件有未保存的修改，切换后将丢失，是否继续？', '未保存的修改', {
        confirmButtonText: '继续',
        cancelButtonText: '取消',
        type: 'warning',
      });
    } catch {
      return;
    }
  }
  activeFile.value = fname;
  isEditing.value = false;
  saveMsg.value = null;
  editContent.value = currentLines.value.join('\n');
  isModified.value = false;
}

async function startEdit() {
  if (!props.selectedStrategy || !activeFile.value) return;
  saveMsg.value = null;
  try {
    const d = await builderApi.getFileContent(props.selectedStrategy.path, 99999);
    const full = d.files?.[activeFile.value];
    editContent.value = full?.lines ? full.lines.join('\n') : currentLines.value.join('\n');
  } catch {
    editContent.value = currentLines.value.join('\n');
  }
  isModified.value = false;
  isEditing.value = true;
}

function cancelEdit() {
  isEditing.value = false;
  editContent.value = currentLines.value.join('\n');
  isModified.value = false;
  saveMsg.value = null;
}

function onEditChange() {
  isModified.value = true;
  saveMsg.value = null;
}

async function saveEdit() {
  if (!props.selectedStrategy || !activeFile.value) return;
  isSaving.value = true;
  saveMsg.value = null;
  try {
    const res = await builderApi.saveFile({
      path: props.selectedStrategy.path,
      file: activeFile.value,
      content: editContent.value,
    });
    if (res.success) {
      saveMsg.value = { type: 'success', text: res.backup ? '已保存（已备份）' : '已保存' };
      isModified.value = false;
      const d = await builderApi.getStrategyFiles(props.selectedStrategy.path);
      files.value = d.files || {};
    } else {
      saveMsg.value = { type: 'danger', text: res.detail || '保存失败' };
    }
  } catch (e: any) {
    saveMsg.value = { type: 'danger', text: '保存失败: ' + (e.message || e) };
  } finally {
    isSaving.value = false;
  }
}

function copyToClipboard() {
  const text = currentLines.value.join('\n');
  if (!text) return;
  navigator.clipboard.writeText(text).then(() => {
    ElMessage.success('已复制到剪贴板');
  }).catch(() => {
    ElMessage.error('复制失败');
  });
}
</script>

<style scoped>
.code-mode {
  display: flex;
  height: 100%;
  overflow: hidden;
}

/* File Sidebar */
.file-sidebar {
  width: 200px;
  flex-shrink: 0;
  border-right: 1px solid var(--border-color);
  display: flex;
  flex-direction: column;
  background: var(--bg-secondary);
}
.file-sidebar__header {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-4) var(--space-5);
  border-bottom: 1px solid var(--border-subtle);
  font-size: var(--font-sm);
  font-weight: 600;
  color: var(--text-primary);
  flex-shrink: 0;
}
.file-count {
  margin-left: auto;
  font-size: var(--font-xs);
  font-weight: 400;
  color: var(--text-muted);
  background: var(--bg-tertiary);
  padding: 0 6px;
  border-radius: var(--radius);
}
.file-sidebar__body {
  flex: 1;
  overflow-y: auto;
  padding: 4px 0;
}
.file-item {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-2) var(--space-4);
  margin: 0 4px;
  cursor: pointer;
  font-size: var(--font-sm);
  border-radius: var(--radius);
  color: var(--text-primary);
  transition: all 0.15s;
}
.file-item:hover {
  background: var(--bg-hover);
}
.file-item--active {
  background: var(--bg-active);
  color: var(--accent);
}
.file-item__name {
  flex: 1;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}
.file-item__modified {
  color: var(--accent);
  font-size: var(--font-2xs);
}
.file-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-10) var(--space-5);
  color: var(--text-muted);
  font-size: var(--font-sm);
}

/* Editor Area */
.editor-area {
  flex: 1;
  display: flex;
  flex-direction: column;
  overflow: hidden;
  min-height: 0;
}

/* Toolbar */
.editor-toolbar {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-3);
  padding: var(--space-2) var(--space-5);
  border-bottom: 1px solid var(--border-subtle);
  flex-shrink: 0;
  min-height: var(--h-lg);
}
.toolbar-left {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex: 1;
  min-width: 0;
}
.filename-text {
  font-weight: 500;
  max-width: 300px;
}
.toolbar-right {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  flex-shrink: 0;
}
.shortcut-hint {
  color: var(--text-muted);
  margin-right: var(--space-1);
}

/* Breadcrumb */
.editor-breadcrumb {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  padding: var(--space-1) var(--space-5);
  border-bottom: 1px solid var(--border-subtle);
  background: var(--bg-tertiary);
  flex-shrink: 0;
}

/* Content */
.editor-content {
  flex: 1;
  overflow: hidden;
  min-height: 0;
  position: relative;
}

.codemirror-wrap {
  height: 100%;
  width: 100%;
}
.codemirror-wrap :deep(.code-editor),
.codemirror-wrap :deep(.code-editor .cm-editor) {
  height: 100%;
}

/* Status Bar */
.status-bar {
  display: flex;
  align-items: center;
  gap: var(--space-5);
  padding: 3px 12px;
  border-top: 1px solid var(--border-subtle);
  background: var(--bg-tertiary);
  flex-shrink: 0;
  font-size: var(--font-xs);
  color: var(--text-muted);
}
.status-item {
  display: flex;
  align-items: center;
  gap: var(--space-1);
}
.status-ok {
  color: var(--success-color, #67c23a);
}
.status-err {
  color: var(--danger-color, #f56c6c);
}
</style>
