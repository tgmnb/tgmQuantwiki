<template>
  <div class="bt-section">
    <div class="bt-section__header">
      <span class="bt-section__title">分年收益对比</span>
      <span class="yr-hint">基于净值曲线按自然年计算年化收益率</span>
    </div>
    <div class="yr-body">
      <div
        v-if="yearlyData.length === 0"
        class="yr-empty"
      >
        暂无足够净值数据生成分年收益表
      </div>
      <table
        v-else
        class="yr-table"
      >
        <thead>
          <tr>
            <th class="yr-th yr-th--year">
              年份
            </th>
            <th class="yr-th">
              策略收益
            </th>
            <th class="yr-th">
              基准收益
            </th>
            <th class="yr-th">
              超额收益
            </th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="row in yearlyData"
            :key="row.year"
            class="yr-row"
          >
            <td class="yr-td yr-td--year">
              {{ row.year }}
            </td>
            <td
              class="yr-td"
              :class="pctClass(row.strategyReturn)"
            >
              {{ formatPct(row.strategyReturn) }}
            </td>
            <td
              class="yr-td"
              :class="pctClass(row.benchmarkReturn)"
            >
              {{ formatPct(row.benchmarkReturn) }}
            </td>
            <td
              class="yr-td"
              :class="pctClass(row.excess)"
            >
              {{ formatPct(row.excess) }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>
  </div>
</template>

<script setup lang="ts">
import { computed } from 'vue';
import type { PropType } from 'vue';

interface NavRow { [key: string]: string | number }

const props = defineProps({
  nav: {
    type: Object as PropType<{ headers?: string[]; rows?: NavRow[] }>,
    required: true,
  },
});

interface YearRow {
  year: string;
  strategyReturn: number;
  benchmarkReturn: number;
  excess: number;
}

/** 从净值 rows 提取 [date, nav] 对 */
function extractNavPairs(rows: NavRow[], headers: string[]): Array<[string, number]> {
  const dateKey = headers.find(h => /时间|日期|date|time/i.test(h)) || headers[0];
  const valKey = headers.find(h => /净值|nav|总资产/i.test(h)) || headers[1] || headers[0];
  return rows
    .map(r => {
      const d = String(r[dateKey] || '').slice(0, 10);
      const v = parseFloat(String(r[valKey] ?? ''));
      return (!d || isNaN(v) || !isFinite(v) || v <= 0) ? null as unknown as [string, number] : [d, v] as [string, number];
    })
    .filter((pair): pair is [string, number] => !!pair);
}

/** 计算分段收益率：(endVal - startVal) / startVal */
function calcReturn(pairs: Array<[string, number]>): number {
  if (pairs.length < 2) return 0;
  const startVal = pairs[0][1];
  const endVal = pairs[pairs.length - 1][1];
  if (startVal <= 0) return 0;
  return (endVal - startVal) / startVal;
}

const yearlyData = computed<YearRow[]>(() => {
  const rows = props.nav?.rows;
  const headers = props.nav?.headers;
  if (!rows || rows.length < 2 || !headers) return [];

  const pairs = extractNavPairs(rows, headers);
  if (pairs.length < 2) return [];

  // 按年分组
  const yearMap = new Map<string, Array<[string, number]>>();
  for (const p of pairs) {
    const year = p[0].slice(0, 4);
    if (!yearMap.has(year)) yearMap.set(year, []);
    yearMap.get(year)!.push(p);
  }

  // 基准 = 初始净值 1.0 的线性增长（如果只有策略净值，基准 = 0%）
  // 这里基准 = 等权持有现金（收益=0），如果未来有指数基准可以扩展
  const sortedYears = [...yearMap.keys()].sort();
  const result: YearRow[] = [];

  for (const year of sortedYears) {
    const yearPairs = yearMap.get(year)!;
    if (yearPairs.length < 2) continue;
    const stratRet = calcReturn(yearPairs);
    const benchRet = 0; // 基准暂为 0，可后续对接指数数据
    result.push({
      year,
      strategyReturn: stratRet * 100,
      benchmarkReturn: benchRet,
      excess: (stratRet - benchRet) * 100,
    });
  }

  return result;
});

function formatPct(val: number): string {
  if (val === 0) return '--';
  const sign = val > 0 ? '+' : '';
  return `${sign}${val.toFixed(2)}%`;
}

function pctClass(val: number): string {
  if (val > 0) return 'yr-td--up';
  if (val < 0) return 'yr-td--down';
  return '';
}


</script>

<style scoped>
.bt-section {
  background: var(--bg-card, var(--bg-secondary));
  border: 1px solid var(--border);
  border-radius: var(--radius-lg, 12px);
  overflow: hidden;
  box-shadow: var(--shadow-sm, 0 1px 2px rgba(0,0,0,0.04));
  transition: box-shadow 0.2s;
  display: flex;
  flex-direction: column;
  height: 100%;
}
.bt-section:hover {
  box-shadow: var(--shadow-md, 0 4px 12px rgba(0,0,0,0.06));
}
.bt-section__header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 12px 16px;
  background: linear-gradient(180deg, var(--bg-secondary) 0%, var(--bg-tertiary, var(--bg-secondary)) 100%);
  border-bottom: 1px solid var(--border);
}
.bt-section__title {
  font-size: 12px;
  font-weight: 700;
  color: var(--text-secondary);
  text-transform: uppercase;
  letter-spacing: 0.6px;
}
.yr-hint {
  margin-left: auto;
  font-size: 11px;
  color: var(--text-muted);
}
.yr-body {
  flex: 1;
  overflow: auto;
  min-height: 0;
}
.yr-empty {
  padding: 32px;
  text-align: center;
  color: var(--text-muted);
  font-size: var(--font-sm);
}
.yr-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-sm);
}
.yr-th {
  padding: 10px 14px;
  text-align: right;
  font-weight: 600;
  font-size: var(--font-2xs);
  color: var(--text-muted);
  text-transform: uppercase;
  letter-spacing: 0.5px;
  border-bottom: 1px solid var(--border);
  white-space: nowrap;
  background: var(--bg-tertiary, var(--bg-secondary));
}
.yr-th--year {
  text-align: left;
  padding-left: 16px;
}
.yr-row {
  transition: background 0.15s;
}
.yr-row:hover {
  background: var(--bg-hover);
}
.yr-td {
  padding: 10px 14px;
  text-align: right;
  font-family: var(--font-mono, monospace);
  font-weight: 500;
  font-size: 13px;
  border-bottom: 1px solid var(--border);
  white-space: nowrap;
}
.yr-td--year {
  text-align: left;
  color: var(--text-primary);
  font-weight: 600;
  font-family: inherit;
  padding-left: 16px;
}
.yr-td--up {
  color: #ef4444;
}
.yr-td--down {
  color: #22c55e;
}
</style>
