"""
策略管理 API
"""

from __future__ import annotations

from pathlib import Path

import config as _config
from fastapi import APIRouter, Query
from fastapi.responses import JSONResponse

from services.tree_service import safe_resolve, to_posix_path
from services.data_service import invalidate_scan_cache

router = APIRouter(prefix="/api/strategies", tags=["strategies"])

# ---------------------------------------------------------------------------
# 策略模板 — strategy.py 从文件读取，stg_config.py 使用格式化模板
# ---------------------------------------------------------------------------
_TEMPLATES_DIR = Path(__file__).resolve().parent.parent / "templates"


def _read_strategy_template(backtest_type: str) -> str:
    """从 templates 目录读取 strategy.py 模板。"""
    name = "strategy_1h.py" if backtest_type == "stock_1h" else "strategy_daily.py"
    path = _TEMPLATES_DIR / name
    if not path.exists():
        raise FileNotFoundError(f"策略模板文件不存在: {path}")
    return path.read_text(encoding="utf-8")

_STG_CONFIG_DAILY_TEMPLATE = '''\
"""{name} 策略配置"""
strategy_config = {{
    'day_buy_num_max': 3,
    'cap_amount': 3,
    'hold_period': 2,
    'swap_time': 'open-close',
    'stop_win': {{'is_open': False, 'ratio': 0.15}},
    'stop_lose': {{'is_open': False, 'ratio': -0.15}},
    'moving_win': {{'is_open': False, 'ratio': 0.2}},
    'sell_mode': 1,
}}

timing_config = {{
    'period': 'daily',
    'risk': {{'is_open': False}},
    'stock': {{'is_open': False}},
}}
'''

_STG_CONFIG_1H_TEMPLATE = '''\
"""{name} 策略配置"""
strategy_config = {{
    'day_buy_num_max': 5,
}}

timing_config = {{
    'period': 'hour',
    'risk': {{'is_open': False}},
    'stock': {{'is_open': False}},
}}
'''


def _invalidate_strategy_cache():
    """失效 builder router 使用的策略扫描缓存。"""
    cache_key = str((_config.QUANT_PROJ / "backtest" / "strategies").resolve())
    invalidate_scan_cache(cache_key)


@router.get("/list")
async def list_strategies():
    """列出所有策略，含元信息（类型/路径）。"""
    stg_base = _config.QUANT_PROJ / "backtest"
    result = []

    # 单策略
    for stg_type in ("stock_daily", "stock_1h"):
        type_dir = stg_base / "strategies" / stg_type
        if not type_dir.exists():
            continue
        for p in sorted(type_dir.iterdir()):
            if not p.is_dir():
                continue
            cfg_file = p / "stg_config.py"
            result.append({
                "name": p.name,
                "type": stg_type,
                "path": to_posix_path(p, _config.QUANT_PROJ),
                "has_config": cfg_file.exists(),
            })

    # 多策略账户
    accounts_dir = stg_base / "accounts"
    if accounts_dir.exists():
        for p in sorted(accounts_dir.iterdir()):
            if not p.is_dir():
                continue
            result.append({
                "name": f"[账户] {p.name}",
                "type": "account",
                "path": to_posix_path(p, _config.QUANT_PROJ),
                "has_config": True,
            })

    return {"strategies": result}


@router.get("/config")
async def get_strategy_config(path: str = Query(...)):
    """读取策略配置文件内容。"""
    try:
        target = safe_resolve(_config.QUANT_PROJ, path)
    except ValueError:
        return JSONResponse(status_code=403, content={"detail": "路径越界"})
    if not target.exists():
        return JSONResponse(status_code=404, content={"detail": "路径不存在"})

    files = {}
    for fname in ["strategy.py", "stg_config.py"]:
        f = target / fname
        if f.exists():
            try:
                content = f.read_text(encoding="utf-8")
                lines = content.splitlines()
                files[fname] = {
                    "lines": lines[:200],
                    "total": len(lines),
                    "truncated": len(lines) > 200,
                }
            except (OSError, UnicodeDecodeError):
                pass

    if not files:
        return JSONResponse(status_code=404, content={"detail": "未找到配置文件"})

    return {"files": files, "path": path}


@router.get("/content")
async def get_strategy_content(path: str = Query(...), limit: int = Query(300)):
    """读取策略目录下所有 Python 文件内容。"""
    try:
        target = safe_resolve(_config.QUANT_PROJ, path)
    except ValueError:
        return JSONResponse(status_code=403, content={"detail": "路径越界"})
    if not target.exists() or not target.is_dir():
        return JSONResponse(status_code=404, content={"detail": "策略目录不存在"})

    py_files = {}
    for ext in [".py", ".yaml", ".yml"]:
        for p in sorted(target.glob(f"*{ext}")):
            if p.name in ("__init__.py", "__pycache__"):
                continue
            try:
                lines = p.read_text(encoding="utf-8").splitlines()
                py_files[p.name] = {
                    "lines": lines[:limit],
                    "total": len(lines),
                    "truncated": len(lines) > limit,
                }
            except (OSError, UnicodeDecodeError):
                pass

    if not py_files:
        return JSONResponse(status_code=404, content={"detail": "未找到 Python 文件"})

    return {"files": py_files, "path": path}


@router.post("/save")
async def save_strategy_file(data: dict):
    """保存策略文件内容（自动备份）
    
    Args:
        data: {path: 策略目录相对路径, file: 文件名, content: 文件内容}
    """
    path = data.get("path", "")
    fname = data.get("file", "")
    file_content = data.get("content", "")
    
    if not path or not fname:
        return JSONResponse(status_code=400, content={"detail": "path 和 file 不能为空"})
    
    # 安全检查
    try:
        target_dir = safe_resolve(_config.QUANT_PROJ, path)
    except ValueError:
        return JSONResponse(status_code=403, content={"detail": "路径越界"})

    if not target_dir.exists() or not target_dir.is_dir():
        return JSONResponse(status_code=404, content={"detail": "策略目录不存在"})

    # 只允许保存到 backtest 目录下的策略/账户目录
    backtest_root = _config.QUANT_PROJ / "backtest"
    try:
        if not target_dir.resolve().is_relative_to(backtest_root.resolve()):
            return JSONResponse(status_code=403, content={"detail": "只允许保存到 backtest 目录下"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"detail": "路径校验失败"})

    # 只允许保存指定类型文件
    allowed_ext = (".py", ".yaml", ".yml", ".json", ".txt", ".md", ".csv")
    if not any(fname.endswith(ext) for ext in allowed_ext):
        return JSONResponse(status_code=400, content={"detail": f"不支持的文件类型: {fname}"})
    
    target_file = target_dir / fname
    
    # 确保文件在目标目录内
    try:
        target_file.resolve().relative_to(target_dir.resolve())
    except ValueError:
        return JSONResponse(status_code=403, content={"detail": "文件路径越界"})
    
    # 自动备份
    backup_path = None
    if target_file.exists():
        import time
        bak_name = f"{fname}.{int(time.time())}.bak"
        bak_file = target_dir / bak_name
        try:
            bak_file.write_bytes(target_file.read_bytes())
            backup_path = bak_name
        except OSError as e:
            return JSONResponse(status_code=500, content={"detail": f"备份失败: {e}"})
    
    # 写入新内容
    try:
        target_file.write_text(file_content, encoding="utf-8")
    except OSError as e:
        return JSONResponse(status_code=500, content={"detail": f"写入失败: {e}"})
    
    return {"success": True, "backup": backup_path, "path": path, "file": fname}


@router.post("/delete")
async def delete_strategy_file(data: dict):
    """删除策略目录下的指定文件。"""
    path = data.get("path", "")
    fname = data.get("file", "")

    if not path or not fname:
        return JSONResponse(status_code=400, content={"detail": "path 和 file 不能为空"})

    try:
        target_dir = safe_resolve(_config.QUANT_PROJ, path)
    except ValueError:
        return JSONResponse(status_code=403, content={"detail": "路径越界"})

    if not target_dir.exists() or not target_dir.is_dir():
        return JSONResponse(status_code=404, content={"detail": "策略目录不存在"})

    backtest_root = _config.QUANT_PROJ / "backtest"
    try:
        if not target_dir.resolve().is_relative_to(backtest_root.resolve()):
            return JSONResponse(status_code=403, content={"detail": "只允许删除 backtest 目录下的文件"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"detail": "路径校验失败"})

    target_file = target_dir / fname
    try:
        target_file.resolve().relative_to(target_dir.resolve())
    except ValueError:
        return JSONResponse(status_code=403, content={"detail": "文件路径越界"})

    if not target_file.exists():
        return JSONResponse(status_code=404, content={"detail": "文件不存在"})

    try:
        target_file.unlink()
        return {"success": True}
    except Exception as e:
        return JSONResponse(status_code=500, content={"detail": str(e)})


@router.post("/create")
async def create_strategy(data: dict):
    """创建新策略目录及模板文件。"""
    import re

    name = data.get("name", "").strip()
    backtest_type = data.get("backtest_type", "").strip()

    if not name or not backtest_type:
        return JSONResponse(status_code=400, content={"detail": "name 和 backtest_type 不能为空"})

    if not re.match(r'^[a-zA-Z0-9_\-]+$', name):
        return JSONResponse(status_code=400, content={"detail": "策略名只允许字母、数字、下划线、连字符"})

    if backtest_type not in ("stock_daily", "stock_1h", "account"):
        return JSONResponse(status_code=400, content={"detail": f"不支持的回测类型: {backtest_type}"})

    if backtest_type == "account":
        stg_dir = _config.QUANT_PROJ / "backtest" / "accounts" / name
    else:
        stg_dir = _config.QUANT_PROJ / "backtest" / "strategies" / backtest_type / name

    # 安全校验
    backtest_root = _config.QUANT_PROJ / "backtest"
    try:
        if not stg_dir.resolve().is_relative_to(backtest_root.resolve()):
            return JSONResponse(status_code=403, content={"detail": "路径越界"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"detail": "路径校验失败"})

    if stg_dir.exists():
        return JSONResponse(status_code=409, content={"detail": f"策略 '{name}' 已存在"})

    try:
        stg_dir.mkdir(parents=True, exist_ok=True)

        if backtest_type == "stock_1h":
            (stg_dir / "strategy.py").write_text(_read_strategy_template("stock_1h"), encoding="utf-8")
            (stg_dir / "stg_config.py").write_text(
                _STG_CONFIG_1H_TEMPLATE.format(name=name), encoding="utf-8"
            )
        elif backtest_type == "stock_daily":
            (stg_dir / "strategy.py").write_text(_read_strategy_template("stock_daily"), encoding="utf-8")
            (stg_dir / "stg_config.py").write_text(
                _STG_CONFIG_DAILY_TEMPLATE.format(name=name), encoding="utf-8"
            )
    except OSError as e:
        import shutil
        if stg_dir.exists():
            shutil.rmtree(stg_dir, ignore_errors=True)
        return JSONResponse(status_code=500, content={"detail": f"创建失败: {e}"})

    _invalidate_strategy_cache()
    return {"success": True, "path": to_posix_path(stg_dir, _config.QUANT_PROJ)}


@router.post("/delete_dir")
async def delete_strategy_dir(data: dict):
    """删除整个策略目录。"""
    import shutil

    name = data.get("name", "").strip()
    backtest_type = data.get("backtest_type", "").strip()

    if not name or not backtest_type:
        return JSONResponse(status_code=400, content={"detail": "name 和 backtest_type 不能为空"})

    if backtest_type not in ("stock_daily", "stock_1h", "account"):
        return JSONResponse(status_code=400, content={"detail": f"不支持的回测类型: {backtest_type}"})

    if backtest_type == "account":
        stg_dir = _config.QUANT_PROJ / "backtest" / "accounts" / name
    else:
        stg_dir = _config.QUANT_PROJ / "backtest" / "strategies" / backtest_type / name

    backtest_root = _config.QUANT_PROJ / "backtest"
    try:
        if not stg_dir.resolve().is_relative_to(backtest_root.resolve()):
            return JSONResponse(status_code=403, content={"detail": "路径越界"})
    except (ValueError, OSError):
        return JSONResponse(status_code=403, content={"detail": "路径校验失败"})

    if not stg_dir.exists():
        return JSONResponse(status_code=404, content={"detail": "策略目录不存在"})

    try:
        shutil.rmtree(stg_dir)
    except OSError as e:
        return JSONResponse(status_code=500, content={"detail": f"删除失败: {e}"})

    _invalidate_strategy_cache()
    return {"success": True}
