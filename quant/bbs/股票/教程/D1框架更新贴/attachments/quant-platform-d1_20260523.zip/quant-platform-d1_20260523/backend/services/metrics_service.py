"""
绩效指标服务 — 完整的回测绩效计算

纯函数式: 输入 rows (list[dict]) → 输出 dict
从资金净值 CSV 和交易记录 CSV 提取数据，计算 12 项量化指标。
"""

from __future__ import annotations

import math


# ---------------------------------------------------------------------------
# 工具函数
# ---------------------------------------------------------------------------

def _parse_val(v) -> float | None:
    """解析数值字符串（处理百分号、空值等）。"""
    if v is None:
        return None
    s = str(v).strip()
    if not s:
        return None
    if s.endswith("%"):
        s = s[:-1]
    try:
        return float(s)
    except (ValueError, TypeError):
        return None


def _safe_float(val, default=0.0) -> float:
    """安全的浮点数提取。"""
    try:
        return float(val)
    except (TypeError, ValueError):
        return default


# ---------------------------------------------------------------------------
# 核心计算函数
# ---------------------------------------------------------------------------

def calc_full_metrics(nav_rows: list[dict], trade_rows: list[dict] | None = None) -> dict:
    """从资金净值数据(必需)和交易记录数据(可选)计算完整指标。

    Args:
        nav_rows: 资金净值.csv 的解析行列表, 含「时间/总资产」等字段。
        trade_rows: 交易记录.csv 的解析行列表, 可选。

    Returns:
        包含 12 项指标的字典。
    """
    metrics: dict = {}

    # ---- 从净值数据计算 ----
    if nav_rows:
        _metrics_from_nav(nav_rows, metrics)

    # ---- 从交易记录计算 ----
    if trade_rows:
        _metrics_from_trades(trade_rows, metrics)

    return metrics


def calc_full_metrics_from_indicator_csv(indicator_rows: list[dict], nav_rows: list[dict] | None = None) -> dict:
    """从策略绩效指标.csv读取已有指标，补充计算缺失的波动率/Sharpe/Sortino。

    Args:
        indicator_rows: 策略绩效指标.csv 的解析行列表。
        nav_rows: 资金净值.csv 的解析行列表（用于补充计算波动率）。
    """
    metrics: dict = {}
    if not indicator_rows:
        return metrics

    row = indicator_rows[0]
    # 累积净值
    metrics["累积净值"] = _parse_val(row.get("累积净值"))
    # 年化收益率（CSV 中通常名为"年化收益"）
    metrics["年化收益率"] = _parse_val(row.get("年化收益"))
    # 最大回撤
    metrics["最大回撤"] = _parse_val(row.get("最大回撤"))
    # Calmar 比率（CSV 中通常名为"年化收益/回撤比"）
    metrics["Calmar比率"] = _parse_val(row.get("年化收益/回撤比"))
    # 胜率
    metrics["胜率"] = _parse_val(row.get("胜率"))
    # 盈亏比（CSV 中通常名为"盈亏收益比"）
    metrics["盈亏比"] = _parse_val(row.get("盈亏收益比"))
    # 总交易次数 = 盈利次数 + 亏损次数
    win_count = _parse_val(row.get("盈利次数")) or 0
    loss_count = _parse_val(row.get("亏损次数")) or 0
    metrics["总交易次数"] = int(win_count + loss_count)
    # 最大连续盈利/亏损（次数）
    metrics["最大连续盈利"] = _parse_val(row.get("最大连续盈利次数"))
    metrics["最大连续亏损"] = _parse_val(row.get("最大连续亏损次数"))

    # 补充计算波动率 / Sharpe / Sortino（从净值数据）
    if nav_rows:
        _supplement_vol_sharpe_sortino(nav_rows, metrics)

    return metrics


def _metrics_from_nav(nav_rows: list[dict], m: dict) -> None:
    """从资金净值行计算基础指标。"""

    # 数值列名映射 (兼容多种表头)
    total_asset_key = _find_key(nav_rows[0], ["总资产", "nav", "累积净值"])
    time_key = _find_key(nav_rows[0], ["时间", "date", "日期"])

    # 提取总资产序列
    nav_values = []
    for row in nav_rows:
        v = _safe_float(row.get(total_asset_key))
        if v > 0:
            nav_values.append(v)

    if len(nav_values) < 2:
        # 单点数据：累积净值定义为 1.0（相对初始值），避免返回绝对资金
        m["累积净值"] = 1.0 if nav_values else None
        return

    # 累积净值 (相对值，初始为 1.0)
    final_nav = nav_values[-1]
    init_nav = nav_values[0]
    m["累积净值"] = round(final_nav / init_nav, 4) if init_nav > 0 else None

    # 年化收益率 (假设一年252个交易日)
    T = len(nav_values)
    if init_nav > 0 and T > 0:
        annual_return = (final_nav / init_nav) ** (252 / T) - 1
        m["年化收益率"] = round(annual_return * 100, 4)
    else:
        m["年化收益率"] = None

    # 日收益率序列
    daily_returns = []
    for i in range(1, len(nav_values)):
        if nav_values[i - 1] > 0:
            r = nav_values[i] / nav_values[i - 1] - 1
            daily_returns.append(r)

    # 最大回撤 (peak-to-trough drawdown)
    max_dd = 0.0
    peak = nav_values[0]
    for v in nav_values:
        if v > peak:
            peak = v
        dd = (peak - v) / peak if peak > 0 else 0
        if dd > max_dd:
            max_dd = dd
    m["最大回撤"] = round(max_dd * 100, 4)

    # 年化波动率
    if len(daily_returns) >= 2:
        mean_r = sum(daily_returns) / len(daily_returns)
        var_r = sum((r - mean_r) ** 2 for r in daily_returns) / (len(daily_returns) - 1)
        annual_vol = math.sqrt(var_r * 252)
        m["年化波动率"] = round(annual_vol * 100, 4)

        # Sharpe Ratio (无风险利率按3%估算)
        rf = 0.03
        sharpe = (annual_return - rf) / annual_vol if annual_vol > 0 else 0
        m["Sharpe比率"] = round(sharpe, 4)

        # Sortino Ratio (只看下行波动率)
        negative_returns = [r for r in daily_returns if r < 0]
        if len(negative_returns) >= 2:
            down_var = sum(r ** 2 for r in negative_returns) / len(negative_returns)
            down_vol = math.sqrt(down_var * 252)
            sortino = (annual_return - rf) / down_vol if down_vol > 0 else 0
            m["Sortino比率"] = round(sortino, 4)
        else:
            m["Sortino比率"] = None

        # Calmar 比率
        calmar = abs(annual_return / max_dd) if max_dd > 0 else 0
        m["Calmar比率"] = round(calmar, 4)
    else:
        m["年化波动率"] = None
        m["Sharpe比率"] = None
        m["Sortino比率"] = None
        m["Calmar比率"] = None


def _supplement_vol_sharpe_sortino(nav_rows: list[dict], m: dict) -> None:
    """从净值数据补充年化波动率、Sharpe(rf=3%)、Sortino(仅下行偏差)。

    使用 Welford 单次遍历算法同时计算方差和下行偏差。
    """
    total_asset_key = _find_key(nav_rows[0], ["总资产", "nav", "累积净值"])
    nav_values = []
    for row in nav_rows:
        v = _safe_float(row.get(total_asset_key))
        if v > 0:
            nav_values.append(v)

    if len(nav_values) < 3:
        m["年化波动率"] = None
        m["Sharpe比率"] = None
        m["Sortino比率"] = None
        return

    # Welford 单次遍历计算方差 + 同时收集下行偏差
    mean_r = 0.0
    m2 = 0.0
    count = 0
    dn_mean = 0.0
    dn_m2 = 0.0
    dn_count = 0

    for i in range(1, len(nav_values)):
        if nav_values[i - 1] > 0:
            r = nav_values[i] / nav_values[i - 1] - 1
            count += 1
            delta = r - mean_r
            mean_r += delta / count
            m2 += delta * (r - mean_r)
            if r < 0:
                dn_count += 1
                dn_delta = r - dn_mean
                dn_mean += dn_delta / dn_count
                dn_m2 += dn_delta * (r - dn_mean)

    if count >= 2:
        var_r = m2 / (count - 1)
        annual_vol = math.sqrt(var_r * 252)
        m["年化波动率"] = round(annual_vol * 100, 4)

        annual_return = m.get("年化收益率")
        if annual_return is not None:
            annual_return_decimal = annual_return / 100
            rf = 0.03
            sharpe = (annual_return_decimal - rf) / annual_vol if annual_vol > 0 else 0
            m["Sharpe比率"] = round(sharpe, 4)

            if dn_count >= 2:
                down_var = dn_m2 / (dn_count - 1)
                down_vol = math.sqrt(down_var * 252)
                sortino = (annual_return_decimal - rf) / down_vol if down_vol > 0 else 0
                m["Sortino比率"] = round(sortino, 4)
            else:
                m["Sortino比率"] = None
        else:
            m["Sharpe比率"] = None
            m["Sortino比率"] = None
    else:
        m["年化波动率"] = None
        m["Sharpe比率"] = None
        m["Sortino比率"] = None


def _metrics_from_trades(trade_rows: list[dict], m: dict) -> None:
    """从交易记录行计算交易类指标。"""

    if not trade_rows:
        m["胜率"] = None
        m["盈亏比"] = None
        m["总交易次数"] = 0
        m["最大连续亏损"] = None
        m["最大连续盈利"] = None
        return

    # 尝试找到盈亏/收益/涨跌幅列
    pnl_key = _find_key(
        trade_rows[0],
        ["收益", "盈亏", "当日收益", "当日盈亏", "当日涨跌", "pnl", "利润"],
    )

    # 提取每笔交易的盈亏
    pnls = []
    for row in trade_rows:
        v = _parse_val(row.get(pnl_key))
        if v is not None and v != 0:
            pnls.append(v)

    total_trades = len(pnls)
    m["总交易次数"] = total_trades

    if total_trades == 0:
        m["胜率"] = None
        m["盈亏比"] = None
        m["最大连续亏损"] = None
        m["最大连续盈利"] = None
        return

    wins = [p for p in pnls if p > 0]
    losses = [p for p in pnls if p < 0]

    # 胜率
    win_rate = len(wins) / total_trades * 100
    m["胜率"] = round(win_rate, 2)

    # 盈亏比 (平均盈利 / 平均亏损绝对值)
    avg_win = sum(wins) / len(wins) if wins else 0
    avg_loss = abs(sum(losses) / len(losses)) if losses else 1e-9
    profit_factor = avg_win / avg_loss
    m["盈亏比"] = round(profit_factor, 4)

    # 最大连续亏损 / 盈利 (扫描盈亏序列)
    if pnls:
        # 连续亏损
        max_consec_loss, _ = _max_consecutive(pnls, lambda x: x < 0)
        m["最大连续亏损"] = round(abs(max_consec_loss), 4) if max_consec_loss != 0 else 0

        # 连续盈利
        max_consec_profit, _ = _max_consecutive(pnls, lambda x: x > 0)
        m["最大连续盈利"] = round(max_consec_profit, 4)


# ---------------------------------------------------------------------------
# 内部工具
# ---------------------------------------------------------------------------

def _find_key(row: dict, candidates: list[str]) -> str | None:
    """在字典中查找第一个匹配的键。

    构建 lowercase→original 映射表，将 O(candidates×row_keys) 降为 O(row_keys+len(candidates))。
    """
    row_keys_lower = {k.lower(): k for k in row.keys() if k}
    for c in candidates:
        low_c = c.lower()
        if low_c in row_keys_lower:
            return row_keys_lower[low_c]
    return None


def _max_consecutive(values: list[float], predicate) -> tuple[float, int]:
    """返回满足 predicate 的最长连续子序列的和与长度。"""
    best_sum = 0.0
    best_len = 0
    cur_sum = 0.0
    cur_len = 0

    for v in values:
        if predicate(v):
            cur_sum += v
            cur_len += 1
            if abs(cur_sum) > abs(best_sum):
                best_sum = cur_sum
                best_len = cur_len
        else:
            cur_sum = 0.0
            cur_len = 0

    return best_sum, best_len
