<template>
  <div class="settings-page">
    <h2 class="settings-title">
      设置
    </h2>

    <!-- 主题切换 -->
    <div class="settings-section">
      <h3 class="settings-section__title">
        外观
      </h3>
      <div class="settings-card">
        <div class="settings-row">
          <div class="settings-row__info">
            <div class="settings-row__label">
              主题模式
            </div>
            <div class="settings-row__desc">
              选择深色、浅色或护眼主题
            </div>
          </div>
          <div class="theme-selector">
            <button
              v-for="t in themeOptions"
              :key="t.value"
              class="theme-selector__btn"
              :class="{ 'theme-selector__btn--active': uiStore.theme === t.value }"
              @click="handleThemeChange(t.value)"
            >
              <el-icon :size="16">
                <component :is="t.icon" />
              </el-icon>
              <span>{{ t.label }}</span>
            </button>
          </div>
        </div>
      </div>
    </div>

    <!-- API 服务器配置 -->
    <div class="settings-section">
      <h3 class="settings-section__title">
        服务器
      </h3>
      <div class="settings-card">
        <div class="settings-field">
          <label class="settings-field__label">API 服务器地址</label>
          <div class="settings-field__row">
            <el-input
              v-model="apiServer"
              placeholder="http://localhost:5180"
              class="settings-field__input"
              @keyup.enter="saveApiServer"
            />
            <el-button
              type="primary"
              :loading="saving"
              @click="saveApiServer"
            >
              保存
            </el-button>
          </div>
          <div class="settings-field__hint">
            修改后需要刷新页面生效
          </div>
        </div>
      </div>
    </div>

    <!-- Platform 设置 -->
    <div
      v-if="!loading"
      class="settings-section"
    >
      <h3 class="settings-section__title">
        Platform
      </h3>
      <div class="settings-card">
        <!-- 警告信息 -->
        <div
          v-if="!platformSettings?.quant_proj_exists"
          class="alert alert--error"
        >
          quant_proj 未配置，请先在下方设置项目路径
        </div>
        <div
          v-else-if="!platformSettings?.quant_proj_has_config"
          class="alert alert--warning"
        >
          项目目录中没有找到 config.py，请确认是 quant-test-d1-pro 项目
        </div>
        <!-- 项目路径 -->
        <div class="settings-field">
          <label class="settings-field__label">quant_proj 项目路径</label>
          <div class="settings-field__row">
            <el-input
              v-model="quantProj"
              placeholder="E:/quantclassCode/teamStockCode/quant-test-d1-pro"
              class="settings-field__input"
            />
            <el-button
              type="primary"
              :loading="platformSaving"
              @click="handlePlatformSave"
            >
              {{ platformSaving ? '保存中...' : '保存路径' }}
            </el-button>
          </div>
        </div>
        <!-- 状态信息 -->
        <div class="settings-status">
          <span>项目存在: <span :class="platformSettings?.quant_proj_exists ? 'text-success' : 'text-error'">{{ platformSettings?.quant_proj_exists ? '是' : '否' }}</span></span>
          <span>config.py: <span :class="platformSettings?.quant_proj_has_config ? 'text-success' : 'text-error'">{{ platformSettings?.quant_proj_has_config ? '有' : '无' }}</span></span>
        </div>
      </div>
    </div>

    <!-- quant-test Config -->
    <div
      v-if="!loading && platformSettings?.quant_proj_has_config"
      class="settings-section"
    >
      <h3 class="settings-section__title">
        quant-test Config
      </h3>
      <div class="settings-card settings-card--flat">
        <div
          v-for="field in QUANT_CONFIG_FIELDS"
          :key="field.key"
          class="config-field"
        >
          <div class="config-field__info">
            <div class="config-field__label">
              {{ field.label }}
            </div>
            <div
              v-if="field.hint"
              class="config-field__hint"
            >
              {{ field.hint }}
            </div>
          </div>
          <div class="config-field__control">
            <!-- bool -->
            <el-switch
              v-if="field.type === 'bool'"
              :model-value="getFieldValue(field.key)"
              style="--el-switch-on-color: var(--accent);"
              @update:model-value="(val: any) => handleFieldChange(field.key, val)"
            />
            <!-- select -->
            <el-select
              v-else-if="field.type === 'select'"
              :model-value="getFieldValue(field.key)"
              class="config-field__input"
              :placeholder="field.hint"
              @update:model-value="(val: any) => handleFieldChange(field.key, val)"
            >
              <el-option
                v-for="opt in field.options"
                :key="opt"
                :label="opt === '' ? '(空/自适应)' : opt"
                :value="opt"
              />
            </el-select>
            <!-- number -->
            <el-input-number
              v-else-if="field.type === 'number'"
              :model-value="getFieldValue(field.key)"
              controls-position="right"
              class="config-field__input"
              :placeholder="field.hint"
              @update:model-value="(val: any) => handleFieldChange(field.key, val)"
            />
            <!-- list -->
            <el-input
              v-else-if="field.type === 'list'"
              :model-value="getListValue(field.key)"
              :placeholder="field.hint"
              @update:model-value="(val: any) => handleListChange(field.key, val)"
            />
            <!-- text (default) -->
            <el-input
              v-else
              :model-value="getFieldValue(field.key)"
              :placeholder="field.hint"
              @update:model-value="(val: any) => handleFieldChange(field.key, val)"
            />
          </div>
          <div class="config-field__action">
            <el-button
              v-if="isDirty(field.key)"
              type="primary"
              size="small"
              :loading="savingField === field.key"
              @click="handleFieldSave(field.key)"
            >
              {{ savingField === field.key ? '...' : '保存' }}
            </el-button>
          </div>
        </div>
      </div>
    </div>

    <!-- 缓存清理 -->
    <div class="settings-section">
      <h3 class="settings-section__title">
        缓存
      </h3>
      <div class="settings-card">
        <div class="settings-row">
          <div class="settings-row__info">
            <div class="settings-row__label">
              清理本地缓存
            </div>
            <div class="settings-row__desc">
              清除 localStorage 中的所有缓存数据（{{ cacheSize }} KB）
            </div>
          </div>
          <el-button
            type="danger"
            :loading="clearing"
            @click="clearCache"
          >
            清理缓存
          </el-button>
        </div>
      </div>
    </div>

    <!-- 关于信息 -->
    <div class="settings-section">
      <h3 class="settings-section__title">
        关于
      </h3>
      <div class="settings-card">
        <div class="about-grid">
          <div class="about-row">
            <span class="about-row__label">应用名称</span>
            <span class="about-row__value">量化交易平台</span>
          </div>
          <div class="about-row">
            <span class="about-row__label">版本</span>
            <span class="about-row__value">1.0.0</span>
          </div>
          <div class="about-row">
            <span class="about-row__label">技术栈</span>
            <span class="about-row__value">Vue 3 + TypeScript + ECharts</span>
          </div>
          <div class="about-row">
            <span class="about-row__label">构建时间</span>
            <span class="about-row__value">{{ buildTime }}</span>
          </div>
        </div>
      </div>
    </div>

    <!-- 成功消息 -->
    <Transition name="msg">
      <div
        v-if="successMsg"
        class="msg msg--success"
      >
        <el-icon><CircleCheck /></el-icon>
        <span>{{ successMsg }}</span>
      </div>
    </Transition>

    <!-- 错误消息 -->
    <Transition name="msg">
      <div
        v-if="errorMsg"
        class="msg msg--error"
      >
        <el-icon><CircleClose /></el-icon>
        <span>{{ errorMsg }}</span>
      </div>
    </Transition>
  </div>
</template>

<script setup lang="ts">
import { ref, computed, onMounted, markRaw } from 'vue';
import { useUIStore } from '@/stores/ui';
import { settingsApi } from '@/api/settings';
import { Moon, Sunny, View } from '@element-plus/icons-vue';

const QUANT_CONFIG_FIELDS = [
  { key: 'date_start', label: '开始日期', type: 'text', hint: 'YYYY-MM-DD' },
  { key: 'date_end', label: '结束日期', type: 'text', hint: 'None=最近交易日' },
  { key: 'data_dir', label: '数据目录', type: 'text', hint: 'E:/quantClassData' },
  { key: 'exclude_stock_patterns', label: '排除板块', type: 'text', hint: "['bj']" },
  { key: 'fq_type', label: '复权方式', type: 'select', options: ['hfq', 'None', 'qfq'], hint: '后复权/前复权/不复权' },
  { key: 'boost', label: '并行计算', type: 'bool' },
  { key: 'batching_mode', label: '分批模式', type: 'select', options: ['', 'count', 'balanced'], hint: '空=自适应' },
  { key: 'n_jobs', label: '并行进程数', type: 'number', hint: 'CPU核心数' },
  { key: 'prepare_data_length', label: '预计算天数', type: 'number', hint: '因子预热天数' },
  { key: 'index_code', label: '参考指数', type: 'text', hint: 'sh000300' },
  { key: 'select_code_list', label: '选股列表', type: 'list', hint: '逗号分隔' },
  { key: 'strategy_name_list', label: '单策略列表', type: 'list', hint: '逗号分隔' },
  { key: 'account_name_list', label: '多策略账户列表', type: 'list', hint: '逗号分隔' },
  { key: 'init_capital', label: '初始资金', type: 'number', hint: '默认1000万' },
  { key: 'commission_ratio', label: '佣金比率', type: 'number', hint: '默认0.00012' },
  { key: 'tax_ratio', label: '印花税比率', type: 'number', hint: '默认0.0005' },
];

const uiStore = useUIStore();

const themeOptions = [
  { value: 'dark', label: '深色', icon: markRaw(Moon) },
  { value: 'light', label: '浅色', icon: markRaw(Sunny) },
  { value: 'eye-care', label: '护眼', icon: markRaw(View) },
];

const apiServer = ref('');
const saving = ref(false);
const clearing = ref(false);
const successMsg = ref('');
const errorMsg = ref('');
const buildTime = ref('');

const loading = ref(true);
const platformSettings = ref<any>(null);
const quantProj = ref('');
const platformSaving = ref(false);

const quantConfig = ref<Record<string, any>>({});
const dirtyFields = ref<Record<string, any>>({});
const savingField = ref<string | null>(null);

const cacheSize = computed(() => {
  let total = 0;
  for (const key in localStorage) {
    if (Object.prototype.hasOwnProperty.call(localStorage, key)) {
      total += localStorage[key].length + key.length;
    }
  }
  return Math.round(total / 1024 * 100) / 100;
});

function handleThemeChange(value: string) {
  uiStore.setTheme(value);
  settingsApi.savePlatformSettings(quantProj.value, value).catch((e) => {
    console.warn('主题保存到后端失败:', e?.message || e);
  });
  const labels: Record<string, string> = { dark: '深色', light: '浅色', 'eye-care': '护眼' };
  showSuccess('主题已切换为 ' + (labels[value] || value) + ' 模式');
}

async function saveApiServer() {
  if (!apiServer.value.trim()) {
    errorMsg.value = '请输入 API 服务器地址';
    return;
  }

  saving.value = true;
  try {
    localStorage.setItem('d1-api-server', apiServer.value.trim());
    showSuccess('API 服务器地址已保存');
  } catch (e) {
    errorMsg.value = '保存失败：' + (e instanceof Error ? e.message : '未知错误');
  } finally {
    saving.value = false;
  }
}

async function clearCache() {
  clearing.value = true;
  try {
    await settingsApi.clearServerCache();
    localStorage.clear();
    showSuccess('服务端和本地缓存已清理');
  } catch (e) {
    errorMsg.value = '清理失败：' + (e instanceof Error ? e.message : '未知错误');
  } finally {
    clearing.value = false;
  }
}

function showSuccess(msg: string) {
  successMsg.value = msg;
  setTimeout(() => {
    successMsg.value = '';
  }, 2000);
}

async function handlePlatformSave() {
  platformSaving.value = true;
  try {
    await settingsApi.savePlatformSettings(quantProj.value);
    platformSettings.value = await settingsApi.getPlatformSettings();
    showSuccess('平台设置已保存');
  } catch (e) {
    errorMsg.value = '保存失败：' + (e instanceof Error ? e.message : '未知错误');
  } finally {
    platformSaving.value = false;
  }
}

function getFieldValue(key: string): any {
  if (dirtyFields.value[key] !== undefined) {
    return dirtyFields.value[key];
  }
  return quantConfig.value[key] ?? '';
}

function getListValue(key: string): string {
  const val = getFieldValue(key);
  if (Array.isArray(val)) return val.join(', ');
  return val || '';
}

function isDirty(key: string): boolean {
  return key in dirtyFields.value;
}

function handleFieldChange(key: string, value: any) {
  dirtyFields.value = { ...dirtyFields.value, [key]: value };
}

function handleListChange(key: string, value: string) {
  const list = value.split(',').map(s => s.trim()).filter(Boolean);
  dirtyFields.value = { ...dirtyFields.value, [key]: list };
}

async function handleFieldSave(key: string) {
  const value = dirtyFields.value[key];
  if (value === undefined) return;
  savingField.value = key;
  try {
    const result = await settingsApi.saveQuantConfigField(key, value);
    if (result.error) {
      errorMsg.value = '保存失败: ' + result.error;
    } else {
      quantConfig.value = { ...quantConfig.value, [key]: value };
      const { [key]: _, ...rest } = dirtyFields.value; // eslint-disable-line @typescript-eslint/no-unused-vars
      dirtyFields.value = rest;
      showSuccess(`${key} 已保存`);
    }
  } catch {
    errorMsg.value = '保存失败';
  } finally {
    savingField.value = null;
  }
}

onMounted(async () => {
  apiServer.value = localStorage.getItem('d1-api-server') || 'http://localhost:5180';

  buildTime.value = new Date().toLocaleString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
  });

  try {
    platformSettings.value = await settingsApi.getPlatformSettings();
    quantProj.value = platformSettings.value.quant_proj || '';
  } catch {
    // ignore
  }

  try {
    const config = await settingsApi.getQuantConfig();
    if (!config.error) {
      quantConfig.value = config;
    }
  } catch {
    // ignore
  }

  loading.value = false;
});
</script>

<style scoped>
.settings-page {
  flex: 1;
  overflow-y: auto;
  padding: 24px;
  max-width: 900px;
}

.settings-title {
  font-size: var(--font-xl);
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 24px;
  letter-spacing: -0.3px;
}

.settings-section {
  margin-bottom: 24px;
}

.settings-section__title {
  font-size: var(--font-xs);
  font-weight: 600;
  color: var(--text-secondary);
  margin-bottom: 10px;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.settings-card {
  background: var(--bg-secondary);
  border: 1px solid var(--border);
  border-radius: var(--radius-lg);
  padding: 16px;
  transition: border-color var(--transition), box-shadow var(--transition);
}

.settings-card:hover {
  border-color: var(--border2);
  box-shadow: var(--shadow-sm);
}

.settings-card--flat {
  padding: 0;
  overflow: hidden;
}

.settings-row {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}

.settings-row__info {
  flex: 1;
  min-width: 0;
}

.settings-row__label {
  font-size: var(--font-md);
  font-weight: 500;
  color: var(--text-primary);
}

.settings-row__desc {
  font-size: var(--font-xs);
  color: var(--text-muted);
  margin-top: 2px;
}

.settings-field {
  margin-bottom: 12px;
}

.settings-field:last-child {
  margin-bottom: 0;
}

.settings-field__label {
  display: block;
  font-size: var(--font-xs);
  color: var(--text-muted);
  margin-bottom: 6px;
  font-weight: 500;
}

.settings-field__row {
  display: flex;
  gap: 8px;
  align-items: center;
}

.settings-field__input {
  flex: 1;
}

.settings-field__hint {
  font-size: var(--font-xs);
  color: var(--text-muted);
  margin-top: 4px;
}

.settings-status {
  display: flex;
  gap: 16px;
  font-size: var(--font-xs);
  color: var(--text-muted);
  margin-top: 10px;
}

.alert {
  padding: 12px;
  border-radius: var(--radius-md);
  margin-bottom: 16px;
  font-size: var(--font-sm);
}

.alert--error {
  background: rgba(255, 77, 94, 0.08);
  border: 1px solid rgba(255, 77, 94, 0.2);
  color: var(--error);
}

.alert--warning {
  background: rgba(245, 166, 35, 0.08);
  border: 1px solid rgba(245, 166, 35, 0.2);
  color: var(--warning);
}

.config-field {
  display: flex;
  align-items: center;
  padding: 10px 16px;
  border-bottom: 1px solid var(--border);
  gap: 16px;
  transition: background var(--transition);
}

.config-field:hover {
  background: var(--bg-hover);
}

.config-field:last-child {
  border-bottom: none;
}

.config-field__info {
  width: 160px;
  flex-shrink: 0;
}

.config-field__label {
  font-size: var(--font-md);
  font-weight: 500;
  color: var(--text-primary);
}

.config-field__hint {
  font-size: var(--font-2xs);
  color: var(--text-muted);
  margin-top: 2px;
}

.config-field__control {
  flex: 1;
  min-width: 0;
}

.config-field__input {
  width: 100%;
}

.config-field__action {
  width: 60px;
  flex-shrink: 0;
  display: flex;
  justify-content: flex-end;
}

.about-grid {
  display: flex;
  flex-direction: column;
  gap: 10px;
}

.about-row {
  display: flex;
  justify-content: space-between;
  font-size: var(--font-sm);
}

.about-row__label {
  color: var(--text-muted);
}

.about-row__value {
  color: var(--text-primary);
  font-weight: 500;
}

.text-success {
  color: var(--success);
  font-weight: 500;
}

.text-error {
  color: var(--error);
  font-weight: 500;
}

/* Message toast */
.msg {
  position: fixed;
  bottom: 24px;
  left: 50%;
  transform: translateX(-50%);
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 18px;
  border-radius: var(--radius-lg);
  font-size: var(--font-sm);
  font-weight: 500;
  box-shadow: var(--shadow-lg);
  z-index: var(--z-toast);
  backdrop-filter: blur(8px);
}

.msg--success {
  background: rgba(0, 200, 122, 0.15);
  border: 1px solid rgba(0, 200, 122, 0.3);
  color: var(--success);
}

.msg--error {
  background: rgba(255, 77, 94, 0.15);
  border: 1px solid rgba(255, 77, 94, 0.3);
  color: var(--error);
}

.msg-enter-active,
.msg-leave-active {
  transition: opacity 0.2s ease;
}

.msg-enter-from,
.msg-leave-to {
  opacity: 0;
}

/* Element Plus overrides */
:deep(.el-switch) {
  --el-switch-on-color: var(--accent);
}

:deep(.el-button--primary) {
  background-color: var(--accent);
  border-color: var(--accent);
}

:deep(.el-button--primary:hover) {
  background-color: var(--accent-hover);
  border-color: var(--accent-hover);
}

:deep(.el-button--danger) {
  background-color: var(--down);
  border-color: var(--down);
}

:deep(.el-input__inner) {
  background-color: var(--bg-primary);
  color: var(--text-primary);
  border-color: var(--border);
}

:deep(.el-input__inner:focus) {
  border-color: var(--accent);
}

/* Theme Selector */
.theme-selector {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  background: var(--bg-tertiary);
  padding: 4px;
  border-radius: var(--radius-md);
  border: 1px solid var(--border);
}

.theme-selector__btn {
  display: inline-flex;
  align-items: center;
  gap: 6px;
  padding: 6px 14px;
  border-radius: var(--radius-sm);
  border: none;
  background: transparent;
  color: var(--text-secondary);
  font-size: var(--font-sm);
  font-weight: 500;
  cursor: pointer;
  transition: all 0.25s ease;
  font-family: inherit;
}

.theme-selector__btn:hover {
  color: var(--text-primary);
  background: var(--bg-hover);
}

.theme-selector__btn--active {
  background: var(--bg-primary);
  color: var(--accent);
  box-shadow: var(--shadow-sm);
}
</style>
