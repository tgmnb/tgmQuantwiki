/**
 * Library 共享代码编辑逻辑 composable
 *
 * 消除 SelectionTab / TimingTab / FinancialFactorsTab 之间约 200 行重复代码。
 *
 * 状态: mode (view|edit|create), selectedItem, codeContent, editContent, saving, error
 * 操作: startEdit, startCreate, cancelEdit, saveEdit, deleteItem
 */

import { ref, computed } from 'vue';

export type CodeContent = { lines?: string[] };
export type SelectedItem = { name: string; path: string };

export interface LibraryCodeOptions {
  onSave: (path: string, content: string) => Promise<{ success: boolean; detail?: string }>;
  onDelete?: (path: string) => Promise<{ success: boolean }>;
  reloadAfterSave?: boolean;
  onReload?: () => void;
  onWarn?: (msg: string) => void;
  onConfirm?: (msg: string) => Promise<boolean>;
  onSuccess?: (msg: string) => void;
}

export function useLibraryCode(options: LibraryCodeOptions) {
  const { onSave, onDelete, onReload } = options;

  const mode = ref<'view' | 'edit' | 'create'>('view');
  const selectedItem = ref<SelectedItem | null>(null);
  const codeContent = ref<CodeContent>({});
  const editContent = ref('');
  const newFileName = ref('');
  const saving = ref(false);
  const saveMsg = ref<{ type: 'success' | 'error'; text: string } | null>(null);

  const codeDisplay = computed(() => (codeContent.value.lines || []).join('\n'));
  const isView = computed(() => mode.value === 'view');

  function startEdit() {
    if (!selectedItem.value) return;
    editContent.value = (codeContent.value.lines || []).join('\n');
    mode.value = 'edit';
    saveMsg.value = null;
  }

  function startCreate() {
    selectedItem.value = null;
    codeContent.value = { lines: [] };
    editContent.value = '';
    mode.value = 'create';
    saveMsg.value = null;
    newFileName.value = '';
  }

  function cancelEdit() {
    mode.value = 'view';
    editContent.value = '';
    newFileName.value = '';
    saveMsg.value = null;
  }

  function setSelectedItem(item: SelectedItem | null, content: CodeContent = {}) {
    selectedItem.value = item;
    codeContent.value = content;
    mode.value = 'view';
    editContent.value = '';
    newFileName.value = '';
    saveMsg.value = null;
  }

  async function saveEdit(newPath?: string) {
    if (mode.value === 'create' && !newFileName.value.trim()) {
      options.onWarn?.('请输入文件名');
      return;
    }

    const targetPath = mode.value === 'create'
      ? (newPath ?? newFileName.value.trim())
      : (selectedItem.value?.path ?? newPath ?? '');
    if (!targetPath) return;

    saving.value = true;
    saveMsg.value = null;
    try {
      const res = await onSave(targetPath, editContent.value);
      if (res.success) {
        saveMsg.value = { type: 'success', text: '已保存' };
        const isCreate = mode.value === 'create';
        mode.value = 'view';
        if (isCreate) {
          selectedItem.value = { name: targetPath.split('/').pop() || targetPath, path: targetPath };
        }
        onReload?.();
      } else {
        saveMsg.value = { type: 'error', text: res.detail || '保存失败' };
      }
    } catch (e: unknown) {
      const msg = e instanceof Error ? e.message : String(e);
      saveMsg.value = { type: 'error', text: '保存失败: ' + msg };
    } finally {
      saving.value = false;
    }
  }

  async function deleteItem() {
    if (!selectedItem.value) return;
    try {
      const confirmed = options.onConfirm
        ? await options.onConfirm(`删除 ${selectedItem.value.name}？`)
        : true;
      if (!confirmed) return;
      if (!onDelete) return;
      const res = await onDelete(selectedItem.value.path);
      if (res.success) {
        selectedItem.value = null;
        codeContent.value = {};
        mode.value = 'view';
        onReload?.();
        options.onSuccess?.('已删除');
      }
    } catch { /* ignore */ }
  }

  return {
    // state
    mode,
    selectedItem,
    codeContent,
    editContent,
    newFileName,
    saving,
    saveMsg,
    // computed
    codeDisplay,
    isView,
    // actions
    startEdit,
    startCreate,
    cancelEdit,
    setSelectedItem,
    saveEdit,
    deleteItem,
  };
}
