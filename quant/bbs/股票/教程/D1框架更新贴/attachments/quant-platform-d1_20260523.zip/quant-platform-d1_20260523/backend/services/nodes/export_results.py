from . import register_node

register_node({
    "id": "export_results",
    "type": "atomic",
    "name": "\u5bfc\u51fa\u56de\u6d4b\u7ed3\u679c",
    "description": "\u5bfc\u51fa\u56de\u6d4b\u7ee9\u6548\u62a5\u544a\uff0c\u5305\u62ec\u6536\u76ca\u66f2\u7ebf\u3001\u7ee9\u6548\u6307\u6807\u3001\u4ea4\u6613\u8bb0\u5f55",
    "icon": "icon-export",
    "category": "\u8f93\u51fa",
    "slots_in": [
        {"id": "backtest_result", "name": "\u56de\u6d4b\u7ed3\u679c", "type": "file", "required": True},
    ],
    "slots_out": [],
    "params": [
        {
            "id": "export_format",
            "name": "\u5bfc\u51fa\u683c\u5f0f",
            "type": "select",
            "options": [
                {"value": "csv", "label": "CSV"},
                {"value": "excel", "label": "Excel"},
                {"value": "json", "label": "JSON"},
            ],
            "default": "csv",
            "ui": {"widget": "select", "allow_link": False},
        },
        {
            "id": "include_equity_curve",
            "name": "\u5305\u542b\u51c0\u503c\u66f2\u7ebf",
            "type": "bool",
            "default": True,
            "ui": {"widget": "checkbox"},
        },
        {
            "id": "include_trades",
            "name": "\u5305\u542b\u4ea4\u6613\u8bb0\u5f55",
            "type": "bool",
            "default": True,
            "ui": {"widget": "checkbox"},
        },
    ],
    "script": "workflow/\u5bfc\u51fa\u7ed3\u679c.py",
    "func": "\u5bfc\u51fa\u7ed3\u679c",
    "conda_env": "quantpy312",
    "note": "\u5c06\u56de\u6d4b\u7ed3\u679c\u5bfc\u51fa\u4e3a\u6307\u5b9a\u683c\u5f0f\uff0c\u542b\u51c0\u503c\u66f2\u7ebf\u548c\u7ee9\u6548\u6458\u8981",
})
