import { request } from './request'
import type { Workflow, WorkflowListResponse, WorkflowResponse, NodeListResponse, TemplateListResponse } from '@/types/api'

/** 运行历史记录 */
export interface WorkflowRun {
  run_id: string;
  wf_id: string;
  status: string;
  started_at?: number;
  ended_at?: number;
  duration_seconds?: number;
  error?: string;
}

/** 运行日志响应 */
export interface RunLogsResponse {
  lines: string[];
}

export const workflowApi = {
  /** 获取 Workflow 列表 */
  async list(category?: string): Promise<WorkflowListResponse> {
    const params = category ? { category } : {};
    return request.get('/api/workflows', { params });
  },

  /** 获取单个 Workflow */
  async get(id: string): Promise<WorkflowResponse> {
    return request.get(`/api/workflows/${id}`);
  },

  /** 创建 Workflow */
  async create(data: Partial<Workflow>): Promise<WorkflowResponse> {
    return request.post('/api/workflows', data);
  },

  /** 更新 Workflow */
  async update(id: string, data: Partial<Workflow>): Promise<WorkflowResponse> {
    return request.put(`/api/workflows/${id}`, data);
  },

  /** 删除 Workflow */
  async delete(id: string): Promise<void> {
    return request.delete(`/api/workflows/${id}`);
  },

  /** 停止 Workflow */
  async stop(id: string): Promise<void> {
    return request.post(`/api/workflows/${id}/stop`);
  },

  /** 运行 Workflow (POST 触发运行，store 层负责 SSE 连接管理) */
  async run(id: string, startFromStep?: number, stepParams?: Record<string, unknown>): Promise<void> {
    await request.post(`/api/workflows/${id}/run`, { start_from_step: startFromStep, step_params: stepParams });
  },

  /** 获取 Workflow 运行历史 */
  async listRuns(wfId: string): Promise<WorkflowRun[]> {
    return request.get(`/api/workflows/${wfId}/runs`);
  },

  /** 获取某次运行的日志 */
  async getRunLogs(wfId: string, runId: string): Promise<RunLogsResponse> {
    return request.get(`/api/workflows/${wfId}/runs/${runId}/logs`);
  },

  /** 获取节点定义列表 */
  async listNodes(): Promise<NodeListResponse> {
    return request.get('/api/workflows/nodes');
  },

  async listTemplates(): Promise<TemplateListResponse> {
    return request.get('/api/workflows/templates')
  },
};
