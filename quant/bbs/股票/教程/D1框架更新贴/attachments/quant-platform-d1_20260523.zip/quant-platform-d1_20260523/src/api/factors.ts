import { request } from './request';

export const factorsApi = {
  async list() {
    return request.get('/api/factors/list');
  },

  async getContent(path: string) {
    return request.get('/api/factors/content', { params: { path } });
  },

  async save(path: string, content: string) {
    return request.post('/api/factors/save', { path, content });
  },

  async delete(path: string) {
    return request.post('/api/factors/delete', { path });
  },
};
