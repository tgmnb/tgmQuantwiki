"""
简化工作流 API - 支持 quant-test-d1-pro 固定工作流的扫描与执行
"""
from __future__ import annotations

import ast
import json
import logging
import os
import re
import subprocess
import sys
import tempfile
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse

import config as _config
from services.safe_exec import load_project_config, SafeExecError

logger = logging.getLogger("quant.simplified_workflow")
router = APIRouter(prefix="/api/simplified-workflows", tags=["simplified-workflows"])

# 工作流名称 -> 中文展示名
WORKFLOW_LABELS = {
    "因子计算":        "因子计算",
    "因子计算_板块":  "因子计算（板块）",
    "日频策略回测":   "日频策略回测",
    "小时频策略回测": "小时频策略回测",
    "账户回测":       "账户回测",
    "选股":           "选股",
    "指数合成":       "指数合成",
}

# 工作流 -> 需要的 config 参数 key 列表
WORKFLOW_CONFIG_PARAMS = {
    "因子计算":        ["factor_name_list"],
    "因子计算_板块":  ["factor_name_list"],
    "日频策略回测":   ["strategy_name_list"],
    "小时频策略回测": ["minute_strategy_name_list"],
    "账户回测":       ["account_name_list"],
    "选股":           ["select_code_list"],
    "指数合成":       [],
}

# config 参数 key -> 工作流函数 kwargs 名称映射（只改 key，value 保持不变）
WORKFLOW_PARAM_MAP = {
    "因子计算":        {"factor_name_list": "factor_to_calc"},
    "因子计算_板块":  {"factor_name_list": "factor_to_calc"},
    "选股":           {"select_code_list": "select_code_list_override"},
}

# 工作流文件名 -> 函数名映射（部分工作流文件里函数名与文件名不一致）
WORKFLOW_FUNC_NAME_MAP = {
    "因子计算":        "因子计算",
    "因子计算_板块":  "因子计算_板块",
    "小时频策略回测": "回测",
    "指数合成":       "指数合成",
    "日频策略回测":  "回测",
    "账户回测":       "回测",
    "选股":           "选股",
}

# ----------------------------------------------------------------------
# 内部工具
# ----------------------------------------------------------------------

def _get_quant_proj() -> Path:
    proj = _config.QUANT_PROJ
    if proj is None:
        raise HTTPException(status_code=500, detail="量化项目未配置")
    return proj


def _scan_workflow_functions(workflow_dir: Path) -> list[dict]:
    if not workflow_dir.exists():
        return []

    workflows = []
    for py_file in sorted(workflow_dir.glob("*.py")):
        if py_file.name.startswith("_"):
            continue

        wf_id = py_file.stem
        label = WORKFLOW_LABELS.get(wf_id, wf_id)

        func_name_map = {
            "因子计算":       "因子计算",
            "因子计算_板块": "因子计算_板块",
            "小时频策略回测": "回测",
            "指数合成":      "指数合成",
            "日频策略回测":  "回测",
            "账户回测":      "回测",
            "选股":          "选股",
        }
        target_func = func_name_map.get(wf_id, wf_id)

        try:
            source = py_file.read_text(encoding="utf-8")
            tree = ast.parse(source)

            func_node = None
            for node in ast.walk(tree):
                if isinstance(node, ast.FunctionDef) and node.name == target_func:
                    func_node = node
                    break

            doc = ast.get_docstring(func_node) or "" if func_node else ""

            params = []
            if func_node:
                args = func_node.args
                n_defaults = len(args.defaults)
                n_args = len(args.args)
                for i, arg in enumerate(args.args):
                    required = i < n_args - n_defaults
                    default = None
                    if not required:
                        def_idx = i - (n_args - n_defaults)
                        d = args.defaults[def_idx]
                        if isinstance(d, ast.Constant):
                            default = d.value
                        elif isinstance(d, ast.NameConstant):
                            default = d.value
                        elif isinstance(d, ast.List):
                            default = []
                        elif isinstance(d, ast.Dict):
                            default = {}
                    params.append({
                        "name": arg.arg,
                        "type": "string",
                        "default": default,
                        "required": required,
                    })

            workflows.append({
                "id": wf_id,
                "name": label,
                "script": "workflow." + wf_id,
                "doc": doc.strip()[:200] if doc else "",
                "params": params,
                "config_params": WORKFLOW_CONFIG_PARAMS.get(wf_id, []),
            })
        except Exception as e:
            logger.warning(f"解析工作流文件失败 {py_file}: {e}")
            continue

    return workflows


def _load_config_params(quant_proj: Path) -> dict:
    config_path = quant_proj / "config.py"
    if not config_path.exists():
        return {}
    try:
        cfg = load_project_config(config_path)
        return cfg
    except Exception as e:
        logger.warning(f"加载 config.py 失败: {e}")
        return {}


def _build_workflow_script(workflow_name: str, params: dict, quant_proj: Path) -> str:
    func_name = WORKFLOW_FUNC_NAME_MAP.get(workflow_name, workflow_name)
    qpath = str(quant_proj)

    # 应用 config key -> function kwarg 映射
    param_map = WORKFLOW_PARAM_MAP.get(workflow_name, {})
    resolved_params = {}
    for key, value in params.items():
        resolved_key = param_map.get(key, key)
        resolved_params[resolved_key] = value

    # 工作流函数的可选 kwargs（只对有函数参数的 因子计算/选股 有意义）
    WORKFLOW_FUNC_KWARGS = {
        "因子计算":        ["factor_to_calc"],
        "因子计算_板块":  ["factor_to_calc"],
        "选股":           ["select_code_list_override"],
    }
    func_kwargs_keys = set(WORKFLOW_FUNC_KWARGS.get(workflow_name, []))
    func_kwargs = {k: v for k, v in resolved_params.items() if k in func_kwargs_keys and v is not None}

    # 导入工作流模块（用于注入全局变量）
    script_lines = [
        "#!/usr/bin/env python3",
        "# -*- coding: utf-8 -*-",
        "import sys",
        "from pathlib import Path",
        f"sys.path.insert(0, r'{qpath}')",
        f"import workflow.{workflow_name} as _mod",
        "",
    ]
    # 注入所有 resolved params 到模块全局变量（供函数内部读取）
    for key in resolved_params:
        value = resolved_params[key]
        if value is None:
            continue
        if isinstance(value, str):
            script_lines.append(f"_mod.{key} = {repr(value)}")
        elif isinstance(value, list):
            items = ", ".join(repr(v) for v in value)
            script_lines.append(f"_mod.{key} = [{items}]")
        else:
            script_lines.append(f"_mod.{key} = {repr(value)}")
    script_lines.append("")
    script_lines.append("# 调用工作流函数")
    if func_kwargs:
        kwargs_parts = []
        for k, v in func_kwargs.items():
            if isinstance(v, str):
                kwargs_parts.append(f"    {k}={repr(v)}")
            elif isinstance(v, list):
                items = ", ".join(repr(x) for x in v)
                kwargs_parts.append(f"    {k}=[{items}]")
            else:
                kwargs_parts.append(f"    {k}={repr(v)}")
        script_lines.append(f"_mod.{func_name}(")
        script_lines.append(",\n".join(kwargs_parts))
        script_lines.append(")")
    else:
        script_lines.append(f"_mod.{func_name}()")
    return "\n".join(script_lines)


# ----------------------------------------------------------------------
# Task Manager
# ----------------------------------------------------------------------

_QUALIFIED_PYTHON = _config.QUANT_PYTHON_PATH
_simplified_task_manager = None


def _get_task_manager():
    global _simplified_task_manager
    if _simplified_task_manager is None:
        from services.task_manager import TaskManager
        _simplified_task_manager = TaskManager(
            tmp_subfolder="simplified_workflow",
            python_path=_QUALIFIED_PYTHON,
            task_prefix="swf",
            timeout_minutes=120,
            max_file_age_hours=24,
            allow_parallel=False,
        )
    return _simplified_task_manager


# ----------------------------------------------------------------------
# API: 列表
# ----------------------------------------------------------------------

@router.get("")
async def list_workflows():
    quant_proj = _get_quant_proj()
    workflow_dir = quant_proj / "workflow"
    workflows = _scan_workflow_functions(workflow_dir)
    config_params = _load_config_params(quant_proj)

    for wf in workflows:
        cfg_keys = wf.get("config_params", [])
        wf["config_values"] = {k: config_params.get(k) for k in cfg_keys if k in config_params}

    return {
        "workflows": workflows,
        "config_params": config_params,
    }


# ----------------------------------------------------------------------
# API: 运行
# ----------------------------------------------------------------------

@router.post("/{workflow_name}/run")
async def run_workflow(workflow_name: str, request: Request):
    quant_proj = _get_quant_proj()
    workflow_dir = quant_proj / "workflow"

    workflow_file = workflow_dir / (workflow_name + ".py")
    if not workflow_file.exists():
        raise HTTPException(status_code=404, detail="工作流不存在: " + workflow_name)

    try:
        body = await request.body()
        params = json.loads(body) if body else {}
    except Exception as e:
        raise HTTPException(status_code=400, detail="参数解析失败: " + str(e))

    try:
        _get_task_manager().get_running_task()
    except RuntimeError as e:
        raise HTTPException(status_code=409, detail=str(e))

    if not _QUALIFIED_PYTHON or not _QUALIFIED_PYTHON.exists():
        raise HTTPException(status_code=500, detail="Python 解释器未找到: " + str(_QUALIFIED_PYTHON))

    # 合并 config 中的日期参数（前端不传日期，由后端补全）
    config_params = _load_config_params(quant_proj)
    for _key in ["date_start", "date_end", "minute_date_start", "minute_date_end"]:
        if _key in config_params and _key not in params:
            params[_key] = config_params[_key]

    script_content = _build_workflow_script(workflow_name, params, quant_proj)

    def script_generator():
        return script_content

    task_metadata = {
        "workflow_name": workflow_name,
        "params": params,
    }

    try:
        result = _get_task_manager().create_task(
            script_generator=script_generator,
            script_filename=("run_" + workflow_name),
            cwd=quant_proj,
            task_metadata=task_metadata,
        )
    except RuntimeError as e:
        raise HTTPException(status_code=409, detail=str(e))

    logger.info("简化工作流任务已提交: workflow=%s, params=%s", workflow_name, params)
    return result


# ----------------------------------------------------------------------
# API: 任务
# ----------------------------------------------------------------------

@router.get("/tasks")
async def list_tasks():
    tasks = _get_task_manager().list_tasks()
    return {"tasks": sorted(tasks, key=lambda x: x.get("start_time", ""), reverse=True)[:50]}


@router.get("/task/{task_id}")
async def get_task(task_id: str):
    result = _get_task_manager().get_task_with_log(task_id, log_lines=200)
    if result is None:
        raise HTTPException(status_code=404, detail="任务不存在")
    return result


@router.post("/task/{task_id}/stop")
async def stop_task(task_id: str):
    result = _get_task_manager().stop_task(task_id)
    if "task_id" not in result:
        result["task_id"] = task_id
    return result


# ----------------------------------------------------------------------
# SSE
# ----------------------------------------------------------------------

@router.get("/task/{task_id}/stream")
async def stream_task_logs(task_id: str, request: Request):
    task = _get_task_manager().get_task(task_id)
    if task is None:
        raise HTTPException(status_code=404, detail="Task not found")

    tm = _get_task_manager()
    return StreamingResponse(
        tm.stream_events(task_id, request=request),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )
