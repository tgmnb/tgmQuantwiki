<template>
  <MetricBadge
    v-bind="$attrs"
    label="胜率"
    :value="winRate"
    format="percent"
    :thresholds="{ good: 0.5, warn: 0.4, invert: false }"
  />
</template>
<script setup lang="ts">
defineProps<{ winRate: number | string }>();
</script>
