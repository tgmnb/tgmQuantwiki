from . import register_node

register_node({
    "id": "factor_compute",
    "type": "atomic",
    "name": "\u56e0\u5b50\u8ba1\u7b97",
    "description": "\u8ba1\u7b97\u65e5\u9891\u6280\u672f\u56e0\u5b50",
    "icon": "icon-factor",
    "category": "\u56e0\u5b50",
    "slots_in": [
        {
            "id": "price_data",
            "name": "\u884c\u60c5\u6570\u636e",
            "type": "file",
            "required": False,
            "description": "\u53ef\u9009\uff1a\u8f93\u5165\u884c\u60c5\u6570\u636e\u8def\u5f84",
        },
    ],
    "slots_out": [
        {"id": "factor_data", "name": "\u56e0\u5b50\u6570\u636e", "type": "file"},
    ],
    "params": [
        {
            "id": "factor_to_calc",
            "name": "\u6307\u5b9a\u56e0\u5b50",
            "type": "list[str]",
            "default": None,
            "required": False,
            "description": "\u6307\u5b9a\u8981\u8ba1\u7b97\u7684\u56e0\u5b50\u5217\u8868\uff0c\u4e3a\u7a7a\u5219\u8ba1\u7b97\u5168\u90e8",
            "ui": {"widget": "tag_input", "placeholder": "\u8f93\u5165\u56e0\u5b50\u540d\u79f0\uff0c\u7559\u7a7a\u8ba1\u7b97\u5168\u90e8"},
        },
    ],
    "script": "workflow/\u56e0\u5b50\u8ba1\u7b97.py",
    "func": "\u56e0\u5b50\u8ba1\u7b97",
    "conda_env": "quantpy312",
})
